#!/bin/bash
# Code&Paint by Code&Paint Studio — double-click to start (macOS).
# Runs a small web server for THIS folder, on this computer only, and opens the studio in your browser.
# Keep this window open while you use it; close it to stop.
cd "$(dirname "$0")" || exit 1
if command -v node >/dev/null 2>&1; then
  node serve.mjs
elif command -v python3 >/dev/null 2>&1; then
  python3 serve.py
else
  echo "Code&Paint needs Python 3 (or Node.js) to run here."
  echo "Install Python from https://www.python.org/downloads/ (or run:  xcode-select --install),"
  echo "then double-click start.command again."
  read -r -p "Press Return to close."
fi
