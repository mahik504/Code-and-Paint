# Code&Paint — Local Creative Studio

Version 5.0.0

Drop in any picture and watch it painted in code, stroke by stroke, with the program writing itself underneath.
Add a song and the painting follows its hits and sections; add stroke sounds and every stroke plays a note.
Record it as an MP4 (in real time, or rendered frame by frame), save the code, an SVG, 4K / 8K PNGs, stills and covers.
*window* (top of the out panel) opens the painting in a window of its own: drag it to a projector or a second screen
and double-click it for full screen.

Everything runs in the browser: pictures, songs and videos never leave your machine. No account, no server.
Best in Chrome, Edge, Brave, or Safari on a desktop or laptop.

This is the whole studio run from your own computer: with the bridge to **Resolume** (or any VJ app):
the painting and its code out as live sources, and any Syphon / Spout source in as a live input.

## Start

- **Mac**: double-click start.command.
- **Windows**: double-click start.bat.

Your browser opens the studio at http://localhost:8765. Keep the terminal window open while you use it.
Requires Node.js or Python 3.

## Resolume (out and in)

Syphon on Mac, Spout on Windows.

1. Double-click send/send-to-resolume.command (Mac) or send/send-to-resolume.bat (Windows).
2. **Out**: press *send* (top of the out panel): it blinks until it finds the bridge, then lights green. In Resolume:
   Sources → Syphon / Spout → *Code&Paint*. With *code* on, the code goes out too as *Code&Paint code*.
3. **In**: switch on Resolume's Syphon / Spout output, then pick *live input → Syphon / Spout* in the studio.

© Code&Paint Studio.
