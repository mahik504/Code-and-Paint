'use strict';
// g048 — "Pink mask maze badges": a glossy pink carnival mask with zebra hair and a rainbow streak, layered
// with a scalloped zebra panel, a violet labyrinth with lilac pipes, an orange keyhole frame holding a pearl,
// a brown cartoon badge and a maroon disc with a teal glyph, all in a black frame.
REC.register('g048', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, rr = rng(48);
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    keep();
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st) => { const g = a.createRadialGradient(x, y, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const F = (path, c) => { a.fillStyle = c; a.fill(path); };

    // ── textures ──
    const mazeTex = (c0, c1, f, seed) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = vnoise(p * ${f.toFixed(3)} + ${seed.toFixed(1)}) * 0.7 + vnoise(p * ${(f * 2.3).toFixed(3)} + ${(seed + 3).toFixed(1)}) * 0.3;
      float v = abs(fract(n * 7.) - 0.5);
      return mix(vec3(${c0}), vec3(${c1}), smoothstep(0.16, 0.24, v)); }`));
    const purpleMaze = mazeTex('.42,.34,.70', '.27,.21,.50', 0.07, 1);
    const blueMaze = mazeTex('.40,.50,.90', '.14,.20,.62', 0.09, 5);
    const coralMesh = mazeTex('.98,.55,.42', '.86,.24,.18', 0.12, 9);
    const zebra = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 14. * vec2(vnoise(p * 0.03), vnoise(p * 0.03 + 7.)) ;
      float s = dot(q, vec2(0.97, -0.24)) / 14. + 0.9 * sin(p.y * 0.045 + p.x * 0.01) + 1.2 * fbm(p * 0.01);
      float cut = smoothstep(0.55, 0.62, vnoise(vec2(p.x * 0.05, p.y * 0.012) + 3.));
      float v = abs(fract(s) - 0.5);
      float w = smoothstep(0.26, 0.2, v) * (1. - cut * 0.5);
      return mix(vec3(.04,.03,.04), vec3(.96,.94,.90), w); }`));
    const hair = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(350., 330.); float an = atan(d.x, -d.y);
      float s = an * 13. + 0.4 * sin(length(d) * 0.03);
      float v = abs(fract(s / 6.2832 * 6.) - 0.5);
      return mix(vec3(.05,.04,.05), vec3(.97,.96,.93), smoothstep(0.24, 0.18, v)); }`));
    const speck = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float h = vnoise(p * 0.35) * 0.6 + hash(floor(p * 0.5)) * 0.4;
      return mix(vec3(.25,.48,.62), vec3(.48,.70,.80), smoothstep(.4,.7,h)); }`));

    // ── frame + backdrop bands ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#060507', 0, 0);
    const PIC = rrect(21, 16, 685, 989, 0);
    clipA(PIC, () => {
      F(rrect(0, 0, 726, 1024, 0), '#0e0c10');
      soft(x => { x.fillStyle = '#f2a020'; x.fill(ellipseP(32, 175, 24, 70, 0)); }, 10, 0.9);
      R.flat(rrect(22, 18, 800, 1100, 170), '#fdf2a6', 0.04, 3);
      R.flat(rrect(52, 46, 800, 1100, 140), '#8ecfc8', 0.06, 3);
      R.flat(P([[22, 470], [60, 480], [70, 560], [64, 700], [50, 790], [22, 800]]), speck, 0.06, 3);
      F(P([[22, 790], [50, 790], [44, 1005], [22, 1005]]), '#1a1a20');
      keep();

      // ── pink mask body (lower) ──
      const lower = P([[52, 640], [100, 600], [200, 560], [480, 560], [706, 560], [706, 1010], [40, 1010], [46, 800]]);
      R.dome(lower, lin(40, 640, 420, 1000, [[0, '#f83a44'], [0.35, '#f86c78'], [0.7, '#f88a98'], [1, '#f49ab8']]), 0.06, 0.2, 90, 1);
      soft(x => {
        x.fillStyle = '#f49ebd'; x.fill(ellipseP(560, 940, 200, 90, 0));
        const g = x.createLinearGradient(330, 0, 580, 0);
        [[0, 'rgba(110,170,250,0)'], [0.2, '#6cadf6'], [0.4, '#40d8f4'], [0.6, '#6de4ba'], [0.78, '#e8e63e'], [1, 'rgba(247,144,142,0)']].forEach(([t, c]) => g.addColorStop(t, c));
        x.fillStyle = g; x.fill(P([[330, 1005], [350, 900], [420, 860], [520, 850], [580, 870], [570, 1005]]));
        x.fillStyle = '#ffffff'; x.fill(ellipseP(150, 920, 20, 12, -0.3));
      }, 18, 0.95);
      R.flat(ellipseP(150, 792, 48, 86, 0.05), '#070304', 0.02, 0);
      soft(x => { x.fillStyle = 'rgba(255,255,255,0.8)'; x.fill(ellipseP(76, 870, 8, 40, 0.1)); }, 6, 1);
      F(P([[650, 940], [706, 930], [706, 1005], [640, 1005]]), '#e8d088');

      // ── purple labyrinth (right) ──
      const purple = P([[500, 10], [710, 10], [710, 800], [650, 816], [590, 832], [520, 840], [480, 826], [474, 700], [480, 600], [470, 480], [474, 400], [492, 330], [474, 300], [456, 250], [482, 212], [520, 228], [548, 236], [566, 200], [552, 150], [526, 90]]);
      R.dome(purple, purpleMaze, 0.1, 0.04, 14, 3);
      // lilac pipe maze: albedo + encoded height from one noise-contour field
      const mz = `float field(vec2 p){ return vnoise(p * 0.02 + 4.) * 0.7 + vnoise(p * 0.045 + 9.) * 0.3; }
        float dist(vec2 p){ float n = field(p); return abs(fract(n * 10.) - 0.5); }`;
      const albM = E.fx(mz + `vec3 fx(vec2 uv, vec2 p){ float v = dist(p);
        vec3 c = vec3(.33,.27,.60);
        c = mix(c, vec3(.12,.08,.22), smoothstep(0.25, 0.23, v));
        c = mix(c, vec3(.95,.88,.98), smoothstep(0.2, 0.18, v));
        return c; }`);
      const hgtM = E.fx(mz + `vec3 fx(vec2 uv, vec2 p){ float v = dist(p);
        float t = clamp(1. - v / 0.2, 0., 1.);
        float h = 0.1 + 0.08 * sqrt(max(0., t * (2. - t))) * step(0.001, t);
        float m = t > 0. ? 1. : 3.;
        float k = h * 255.; return vec3(floor(k) / 255., m * 32. / 255., fract(k)); }`);
      const mazeZone = P([[490, 160], [600, 150], [710, 140], [710, 800], [650, 816], [590, 832], [520, 840], [480, 826], [474, 700], [480, 600], [470, 480], [480, 400], [500, 330], [520, 250]]);
      clipA(mazeZone, () => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(albM, 0, 0); a.restore(); });
      R.h.save(); R.h.clip(mazeZone); R.h.setTransform(1, 0, 0, 1, 0, 0); R.h.drawImage(hgtM, 0, 0); R.h.restore();
      // coral mesh + yellow blob
      R.dome(P(blob(648, 92, 58, 46, 3, 14, 0.25, 0.2)), coralMesh, 0.16, 0.06, 12, 1);
      R.dome(P(blob(712, 210, 26, 36, 4, 10, 0.2)), '#f8d040', 0.16, 0.06, 10, 1);
      keep();

      // ── upper face ──
      const face = P([[128, 165], [150, 110], [175, 40], [240, 10], [340, 6], [430, 6], [510, 10], [540, 70], [552, 120], [568, 180], [566, 250], [540, 300], [470, 330], [380, 340], [260, 335], [170, 320], [140, 270], [128, 220]]);
      R.dome(face, lin(130, 60, 560, 340, [[0, '#f494a0'], [0.5, '#f48c98'], [1, '#e88090']]), 0.12, 0.22, 60, 1);
      // rainbow streak down the forehead and nose
      clipA(face, () => soft(x => {
        const g = x.createLinearGradient(300, 0, 470, 0);
        [[0, 'rgba(250,120,140,0)'], [0.2, '#fb4a58'], [0.45, '#fc3a3e'], [0.68, '#fc5a30'], [0.88, '#fc9048'], [1, 'rgba(250,160,120,0)']].forEach(([t, c]) => g.addColorStop(t, c));
        x.fillStyle = g; x.fill(P([[320, 0], [480, 0], [450, 200], [430, 340], [330, 340], [330, 200]]));
      }, 10, 1));
      clipA(face, () => soft(x => { x.fillStyle = 'rgba(200,40,70,0.55)'; x.fill(ellipseP(130, 230, 50, 140, 0)); x.fill(ellipseP(560, 230, 30, 120, 0)); }, 24, 1));
      // eye holes
      R.dome(ellipseP(254, 210, 76, 50, 0.05), '#d86878', 0.1, 0.06, 14, 1);
      R.flat(ellipseP(254, 210, 64, 42, 0.05), '#050304', 0.02, 0);
      R.dome(ellipseP(488, 208, 60, 54, -0.1), '#d86878', 0.1, 0.06, 14, 1);
      R.flat(ellipseP(488, 208, 50, 45, -0.1), '#050304', 0.02, 0);
      // nose
      R.dome(P([[338, 220], [380, 220], [392, 270], [404, 300], [388, 318], [356, 322], [326, 314], [318, 296], [332, 268]]), '#f0707c', 0.3, 0.12, 24, 1);
      R.flat(ellipseP(334, 300, 9, 6, 0.3), '#3a0810', 0.36, 1); R.flat(ellipseP(372, 302, 9, 6, -0.3), '#3a0810', 0.36, 1);
      R.dome(ellipseP(372, 322, 16, 10, 0), '#f490a0', 0.34, 0.06, 6, 1);
      // zebra hair
      const hairL = P(ragged([[150, 150], [165, 100], [178, 50], [195, 10], [355, 10], [365, 60], [345, 100], [300, 122], [240, 134], [180, 148]], 6, 10, 14, 10, 21), true, false);
      const hairR = P(ragged([[440, 116], [436, 60], [446, 10], [512, 10], [536, 70], [552, 136], [520, 124], [480, 118]], 5, 8, 14, 10, 22), true, false);
      for (const hp of [hairL, hairR]) { R.pipe(hp, 8, '#c8b4dc', 0.3, 0.04, 1); R.dome(hp, hair, 0.28, 0.06, 14, 1); }
      keep();

      // ── orange / blue shapes by the right eye ──
      R.dome(P([[470, 340], [500, 300], [550, 284], [600, 290], [596, 312], [550, 312], [510, 330], [490, 352]]), '#f6943e', 0.3, 0.08, 10, 1);
      R.dome(P([[490, 296], [540, 276], [590, 278], [588, 290], [540, 292], [500, 310]]), '#f8a850', 0.34, 0.05, 6, 1);
      R.dome(P(blob(572, 368, 52, 42, 8, 14, 0.25, 0.4)), blueMaze, 0.28, 0.06, 12, 1);
      R.dome(P([[540, 380], [600, 410], [606, 440], [560, 420], [536, 400]]), '#f8e030', 0.3, 0.04, 6, 1);
      R.dome(P([[538, 470], [560, 466], [570, 540], [566, 620], [548, 640], [536, 600], [540, 530]]), '#f8b018', 0.24, 0.06, 8, 1);
      R.dome(P([[548, 480], [556, 480], [558, 560], [550, 620], [544, 560]]), '#f8e8a0', 0.3, 0.02, 3, 1);

      // ── zebra panel with white rim and lavender scalloped border ──
      const zpts = [[58, 440], [70, 380], [108, 342], [160, 320], [220, 305], [290, 300], [350, 304], [410, 318], [460, 336], [490, 380], [486, 440], [460, 500], [420, 540], [380, 560], [300, 570], [240, 600], [210, 660], [190, 700], [140, 694], [96, 670], [66, 620], [56, 540]];
      const scal = P(ragged(zpts.map(([x, y]) => [x + (x - 270) * 0.07, y + (y - 470) * 0.07]), 0, zpts.length, 9, 6, 11));
      R.dome(scal, '#a88cc8', 0.14, 0.04, 8, 3);
      R.dome(P(zpts.map(([x, y]) => [x + (x - 270) * 0.035, y + (y - 470) * 0.035])), '#f4f0f4', 0.18, 0.04, 6, 1);
      R.dome(P(zpts), zebra, 0.2, 0.06, 20, 1);
      keep();

      // ── brown cartoon badge ──
      const brown = ellipseP(308, 602, 104, 108, 0.1);
      R.pipe(brown, 8, '#2a1a10', 0.26, 0.04, 1);
      R.dome(brown, rad(270, 560, 150, [[0, '#9a7a50'], [0.6, '#7a5a3a'], [1, '#5a3e2a']]), 0.26, 0.12, 30, 4);
      R.pipe(P([[238, 640], [244, 600], [262, 572], [290, 548], [320, 530], [346, 522], [366, 534], [372, 552]], false), 9, '#f8d830', 0.42, 0.05, 1);
      R.pipe(P([[238, 640], [252, 650], [262, 630]], false), 9, '#f8d830', 0.42, 0.05, 1);
      R.dome(P([[292, 566], [330, 548], [372, 548], [392, 566], [380, 584], [350, 578], [320, 588], [296, 584]]), '#f6943e', 0.4, 0.05, 8, 1);
      R.dome(P([[296, 590], [340, 580], [392, 584], [396, 610], [370, 630], [330, 630], [302, 612]]), '#f080c4', 0.4, 0.05, 8, 1);
      R.dome(rrect(330, 600, 62, 44, 6), '#e8902a', 0.42, 0.04, 6, 1);
      for (let i = 0; i < 4; i++) { R.groove(P([[336 + i * 15, 602], [336 + i * 15, 642]], false), 4, '#7a3a10', 0.46, 0.04, 1); R.groove(P([[332, 608 + i * 11], [390, 608 + i * 11]], false), 4, '#7a3a10', 0.46, 0.04, 1); }
      R.flat(circleP(322, 552, 7), '#0a0606', 0.3, 0); R.flat(circleP(346, 540, 6), '#0a0606', 0.3, 0);
      // brown jagged bits left of the disc
      R.dome(P([[196, 760], [226, 738], [240, 780], [232, 830], [244, 862], [206, 860], [190, 820], [204, 800]]), '#6a4a32', 0.2, 0.06, 8, 4);

      // ── maroon disc + teal glyph ──
      const disc = circleP(346, 776, 114);
      R.pipe(disc, 10, '#f2eef4', 0.24, 0.04, 1);
      R.dome(disc, rad(310, 730, 170, [[0, '#d24a60'], [0.6, '#b23448'], [1, '#8a2234']]), 0.26, 0.14, 50, 1);
      for (const pth of [[[300, 700], [330, 730], [352, 760], [372, 800], [390, 830]], [[300, 752], [318, 790], [324, 840]], [[280, 830], [330, 800], [372, 780], [418, 770], [432, 750]], [[358, 706], [380, 690], [400, 700], [406, 730], [392, 746], [376, 740]], [[262, 790], [300, 780]], [[340, 830], [342, 860]], [[400, 770], [430, 790]]])
        R.pipe(P(pth, false), 30, '#5ad0bc', 0.42, 0.08, 1);
      keep();

      // ── orange keyhole frame + pearl ──
      const OR = '#fa9a1c';
      const frameP = [P([[524, 336], [512, 380], [500, 430], [490, 462]], false),
        P([[440, 640], [400, 650], [340, 656], [290, 680], [254, 720], [242, 770]], false),
        P([[474, 640], [470, 700], [462, 760], [450, 820], [436, 862]], false)];
      R.dome(ellipseP(472, 545, 86, 104, 0), OR, 0.3, 0.12, 30, 1);
      R.dome(P([[440, 620], [500, 620], [496, 660], [450, 668]]), OR, 0.3, 0.1, 14, 1);
      for (const fp of frameP) R.pipe(fp, 30, OR, 0.3, 0.12, 1);
      R.dome(ellipseP(472, 545, 62, 74, 0), '#5a3a22', 0.3, 0.02, 4, 4);
      for (let k = 0; k < 4; k++) R.pipe(ellipseP(472, 545, 54 - k * 6, 64 - k * 6, 0), 4, k % 2 ? '#3a2416' : '#8a6a4a', 0.32, 0.03, 4);
      R.bead(472, 540, 32, '#f4f4f8', 0.34, 0.2, 5);
      R.bead(510, 432, 9, '#7ad8c0', 0.44, 0.04, 1);
      keep();
    });

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.95, spec: 1.3, shin: 70, wrap: 0.35, ao: 0.6, coat: 0.25, rim: 0.1 }),                 // 1 glossy plastic
        E.mat({ dif: 0.6, metal: 0.6, spec: 1.2, shin: 60, ao: 0.4 }),                                         // 2 metal
        E.mat({ dif: 1.0, spec: 0.35, shin: 25, wrap: 0.4, ao: 0.6, grain: 0.15 }),                            // 3 matte / textured
        E.mat({ dif: 0.95, spec: 0.8, shin: 40, wrap: 0.3, ao: 0.6, coat: 0.1 }),                              // 4 satin brown
        E.mat({ dif: 0.9, spec: 1.6, shin: 120, wrap: 0.5, ao: 0.3, coat: 0.35, emis: 0.1 })                    // 5 pearl
      ],
      light: [-0.55, 0.65, 0.55], lc: [1.0, 0.98, 0.95], amb: [0.3, 0.29, 0.3],
      envTop: [1.1, 1.08, 1.05], envHor: [0.6, 0.56, 0.56], envBot: [0.12, 0.1, 0.1], envK: [0.3, 1.2, 0.3, 0],
      rimC: [0.1, 0.08, 0.1], rimD: [0, 1, 0], r1: 1.4, r2: 7, k: [0, 0.6, 0.4, 90], shadow: [6, 8, 0.7, 6]
    });
    E.bloom(0.06, 6);
    E.grain(0.03, 48);
  }
});
