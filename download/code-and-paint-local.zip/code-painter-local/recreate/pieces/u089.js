'use strict';
// u089 — "Cream-ridged star whale": a huge clay beast of cream ridges fanning from a segmented spine wears a
// green crown of yellow spikes; a ribbed shell, a teal deck of purple-green cups, a starry porthole and a green
// robot body drift with a glowing blue planet through a speckled black starfield.
REC.register('u089', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a, r0 = 0) => { const g = ctx.createRadialGradient(x, y, r0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), line = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };

    // ── black starfield with gold dust (top right) and green dust (bottom right) ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#040405', 0, 0);
    soft(x => {
      fill(ellipseP(600, 150, 110, 120, 0.3), 'rgba(70,50,30,0.55)', x);
      fill(ellipseP(40, 20, 80, 30, 0), 'rgba(60,45,30,0.5)', x);
      fill(ellipseP(700, 880, 90, 160, 0), 'rgba(40,90,60,0.55)', x);
      fill(ellipseP(640, 1000, 120, 60, 0), 'rgba(50,80,50,0.5)', x);
    }, 40, 1);
    { const r = rng(89);
      for (let i = 0; i < 900; i++) { const x = r() * 726, y = r() * 1024, rr = r() < 0.92 ? 0.4 + r() * 0.7 : 1 + r() * 1.6;
        a.globalAlpha = 0.35 + r() * 0.65; fill(circleP(x, y, rr), r() < 0.25 ? '#f0d8a0' : '#f4f4ff'); }
      a.globalAlpha = 1; }
    fill(circleP(230, 32, 7), '#e890b0');

    // ── glowing blue planet on the left with an orange veined orb ──
    const planet = sm([[-30, 52], [28, 56], [66, 76], [92, 112], [106, 170], [104, 240], [90, 300], [66, 356], [36, 400], [6, 428], [-30, 445]]);
    soft(x => stroke(planet, '#3a8ee8', 16, x), 8, 1);
    R.dome(planet, rad(10, 200, 240, [[0, '#6a6278'], [0.45, '#5e6a86'], [0.8, '#7890b8'], [1, '#5a90d0']]), 0.02, 0.12, 40, 6);
    soft(x => { fill(circleP(8, 190, 70), 'rgba(80,130,220,0.5)', x); }, 14, 1);
    R.dome(circleP(4, 188, 56), rad(0, 196, 60, [[0, '#f0a072'], [0.55, '#d87a60'], [0.85, '#c06058'], [1, '#e86858']]), 0.12, 0.06, 20, 6);
    { const vr = rng(7);
      for (let i = 0; i < 9; i++) { let x = 4 + (vr() - 0.5) * 60, y = 188 + (vr() - 0.5) * 80; const pts = [[x, y]];
        for (let k = 0; k < 4; k++) { x += (vr() - 0.5) * 40; y += (vr() - 0.5) * 30; pts.push([x, y]); }
        clipA(circleP(4, 188, 66), () => stroke(line(pts), '#ffb060', 2)); } }
    fill(circleP(42, 190, 6), '#ffe890');
    for (const [x, y, r] of [[28, 375, 12], [92, 278, 9], [72, 470, 6]]) { R.bead(x, y, r, '#2a3448', 0.15, 0.08, 2); fill(circleP(x - r * 0.3, y - r * 0.3, r * 0.3), '#e8f0ff'); }

    // ── the ribbed shell (top right): cream ribs on black ──
    const shell = sm([[408, 96], [428, 70], [452, 60], [480, 76], [508, 104], [548, 134], [604, 170], [652, 210], [690, 256], [712, 302], [716, 342], [700, 366], [652, 344], [600, 306], [540, 266], [482, 236], [446, 210], [424, 162]]);
    R.dome(shell, '#14100e', 0.04, 0.08, 14, 1);
    const RIBS = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p - vec2(420., 70.);
      float ang = mix(0.12, 0.62, smoothstep(40., 260., q.x));
      float d = -sin(ang) * q.x + cos(ang) * q.y + 6. * sin(q.x * 0.03);
      float s = sin(6.2832 * d / 10.5);
      return vec3(smoothstep(0.5, 0.8, s)); }`);
    clipA(shell, () => {
      fill(shell, '#c8baa8'); a.save(); a.globalCompositeOperation = 'multiply'; img(RIBS); a.restore();
      R.h.save(); R.h.clip(shell); R.h.globalAlpha = 0.5; R.h.globalCompositeOperation = 'lighter';
      R.h.save(); R.h.setTransform(1, 0, 0, 1, 0, 0);
      const hcv = E.newCanvas(), hx = hcv.getContext('2d'); hx.drawImage(RIBS, 0, 0); hx.globalCompositeOperation = 'multiply'; hx.fillStyle = 'rgb(16,0,0)'; hx.fillRect(0, 0, hcv.width, hcv.height);
      R.h.drawImage(hcv, 0, 0); R.h.restore(); R.h.restore();
    });

    // ── teal deck with purple-green cups ──
    const navy = sm([[400, 300], [470, 330], [560, 380], [640, 420], [660, 470], [600, 480], [520, 450], [450, 420], [410, 360]]);
    R.flat(navy, '#141a30', 0.02, 0);
    const deck = sm([[338, 236], [400, 222], [446, 210], [478, 222], [528, 242], [586, 268], [642, 298], [690, 332], [720, 372], [722, 418], [700, 428], [668, 418], [620, 394], [560, 364], [500, 334], [452, 306], [410, 284], [372, 268], [346, 254]]);
    R.dome(deck, lin(340, 220, 720, 420, [[0, '#48c0c8'], [0.25, '#2fae9a'], [0.6, '#22966e'], [1, '#1e4e6a']]), 0.14, 0.1, 20, 2);
    { const pr = rng(31);
      for (let i = 0; i < 14; i++) { const x0 = 470 + pr() * 200, y0 = 260 + pr() * 110, pts = [[x0, y0]];
        for (let k = 1; k < 5; k++) pts.push([x0 + k * 12, y0 + k * 5 + (pr() - 0.5) * 6]);
        clipA(deck, () => stroke(line(pts), 'rgba(190,140,230,0.75)', 1.6)); } }
    for (const [cx, cy, r] of [[440, 318, 44], [520, 360, 44], [596, 402, 40]]) {
      R.dome(ellipseP(cx, cy, r, r * 0.78, 0.45), '#5228a0', 0.2, 0.14, 12, 2);
      R.dome(ellipseP(cx + 6, cy - 4, r * 0.68, r * 0.52, 0.45), '#2a9850', 0.26, 0.12, 10, 2);
      R.dome(ellipseP(cx + 8, cy - 6, r * 0.36, r * 0.28, 0.45), '#7ad870', 0.34, 0.06, 6, 2);
    }
    // cream plaque with a little window
    const plaque = sm([[330, 232], [372, 226], [404, 232], [410, 262], [400, 296], [362, 300], [336, 280]]);
    R.dome(plaque, '#d8d0c8', 0.18, 0.06, 8, 1);
    R.dome(rrect(356, 246, 18, 18, 4), '#383840', 0.24, 0.02, 3, 3);
    // purple sphere + tube
    R.pipe(line([[392, 176], [418, 196], [446, 214]]), 30, '#5a2aa8', 0.2, 0.14, 2);
    R.bead(390, 170, 28, '#7a60d8', 0.26, 0.2, 2);

    // ── the cream-ridged mass ──
    const mass = sm([[150, 246], [118, 272], [92, 304], [66, 344], [40, 384], [12, 424], [-14, 456], [-14, 648], [40, 646], [100, 638], [170, 626], [236, 612], [300, 606], [350, 640], [382, 690], [420, 722], [468, 722], [510, 698], [556, 660], [586, 614], [592, 560], [578, 506], [548, 462], [504, 428], [462, 396], [428, 356], [404, 312], [388, 270], [372, 238], [336, 232], [300, 244], [250, 256], [200, 254]]);
    R.dome(mass, '#7a7278', 0.08, 0.06, 20, 5);
    const spine = [[318, 290], [320, 340], [326, 390], [336, 440], [346, 490], [356, 540], [366, 590], [376, 640], [390, 690]];
    const leftReg = new Path2D(); leftReg.addPath(sm([[150, 246], [118, 272], [92, 304], [66, 344], [40, 384], [12, 424], [-14, 456], [-14, 648], [40, 646], [100, 638], [170, 626], [236, 612], [300, 606], [350, 640], [382, 690], [400, 700], [380, 600], [356, 500], [334, 400], [328, 300], [320, 250], [250, 256], [200, 254]]));
    const rightReg = sm([[328, 260], [336, 400], [356, 500], [380, 600], [400, 700], [420, 722], [468, 722], [510, 698], [556, 660], [586, 614], [592, 560], [578, 506], [548, 462], [504, 428], [462, 396], [428, 356], [404, 312], [388, 270]]);
    // fine stripe textures
    const FINE = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.01);
      vec2 d = p - vec2(380., 60.);
      float ang = atan(d.x, d.y);
      float s = sin(length(d) * 1.25 + n * 9.);
      vec3 base = mix(vec3(.40, .37, .40), vec3(.50, .46, .49), n);
      return base + smoothstep(.4, 1., s) * vec3(.12, .11, .11); }`);
    clipA(leftReg, () => img(FINE));
    const BLUE = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.008), m = fbm(p * 0.03 + 5.);
      float v = cos(6.2832 * (fbm(p * 0.009 + 1.3) * 9. + p.y * 0.012 + m * .4));
      vec3 base = mix(vec3(.26, .28, .36), vec3(.36, .38, .48), smoothstep(.3, .7, fbm(p * 0.004 + 2.)));
      return base + smoothstep(.82, .98, v) * vec3(.26, .32, .44); }`);
    clipA(rightReg, () => img(BLUE));
    // cream fingers: tapered clay ridges in staggered rows, fanning from a point above the picture
    const finger = (cx, cy, th, L, wd, bend) => {
      const dx = Math.cos(th), dy = Math.sin(th), A = [], B = [];
      for (let k = 0; k <= 12; k++) {
        const t = k / 12, r = (t - 0.5) * L, w = wd * 0.5 * Math.pow(Math.sin(Math.PI * clamp(t, 0.03, 0.97)), 0.5), b = bend * Math.sin(Math.PI * t);
        const x = cx + dx * r - dy * b, y = cy + dy * r + dx * b;
        A.push([x - dy * w, y + dx * w]); B.push([x + dy * w, y - dx * w]);
      }
      return P([...A, ...B.reverse()]);
    };
    { const F = [380, 60], rr = rng(12);
      clipA(leftReg, () => {
        for (let j = 0; j < 4; j++) for (let i = 0; i < 12; i++) {
          const th = 1.74 + i * 0.054 + (j % 2) * 0.027 + (rr() - 0.5) * 0.012, rc = 250 + j * 105 + (rr() - 0.5) * 30 + i * 4;
          const cx = F[0] + Math.cos(th) * rc, cy = F[1] + Math.sin(th) * rc;
          if (cy > (cx > 230 ? 620 : 545) || cx < -20) continue;
          R.dome(finger(cx, cy, th + (rr() - 0.5) * 0.06, 100 + rr() * 60, 18 + rr() * 7, (rr() - 0.5) * 10), '#c4b9b4', 0.12, 0.12, 9, 1);
        }
      });
    }
    // segmented spine
    for (let i = 0; i < 4; i++) for (let k = 0; k < 4; k++) {
      const t = k / 4, x = spine[i][0] + (spine[i + 1][0] - spine[i][0]) * t, y = spine[i][1] + (spine[i + 1][1] - spine[i][1]) * t;
      R.dome(ellipseP(x, y, 17, 8, 0.12), '#dcd2cc', 0.2, 0.1, 7, 1);
    }
    R.pipe(line([[324, 420], [350, 470], [390, 510], [430, 540]]), 5, '#7090c8', 0.14, 0.03, 5);
    // long white lobes below the spine
    for (const [cx, cy, L, wd, th] of [[338, 520, 150, 22, 1.5], [366, 600, 190, 26, 1.52], [396, 630, 150, 24, 1.55], [300, 520, 130, 20, 1.62], [418, 650, 110, 18, 1.5]])
      R.dome(finger(cx, cy, th, L, wd, 3), '#e0d8d4', 0.16, 0.14, 11, 1);
    // pale translucent fin below the spine
    const fin = sm([[384, 650], [420, 690], [462, 716], [482, 730], [468, 780], [446, 826], [430, 830], [414, 780], [398, 720]]);
    R.dome(fin, lin(390, 660, 470, 830, [[0, '#c0c4d0'], [0.6, '#9aa0b4'], [1, '#6a7490']]), 0.12, 0.08, 14, 1);
    R.dome(sm([[420, 820], [446, 830], [450, 900], [440, 1000], [428, 960], [418, 880]]), '#7a8496', 0.1, 0.04, 6, 1);
    // orange spiral spike
    { const sp = P([[332, 204], [314, 312], [296, 306]]);
      R.dome(sp, lin(300, 300, 330, 210, [[0, '#d06818'], [0.5, '#f0a040'], [1, '#e88830']]), 0.25, 0.12, 6, 4);
      for (let k = 0; k < 9; k++) { const y = 300 - k * 10; R.groove(line([[300 + k * 2.6, y], [314 + k * 1.6, y - 6]]), 2.5, '#8a3a10', 0.4, 0.05, 4, 0.9); } }
    // pink/orange beads on the spine
    R.bead(404, 638, 10, '#e89a70', 0.25, 0.1, 2);
    for (const [x, y, r] of [[246, 338, 8], [120, 500, 7], [428, 522, 6], [380, 590, 5]]) { R.bead(x, y, r, '#22283a', 0.2, 0.06, 2); fill(circleP(x - 2, y - 2, r * 0.35), '#e8f0ff'); }

    // ── glassy crown: cream vertebrae with yellow leaf spikes on a green band ──
    R.flat(sm([[160, 212], [232, 226], [306, 230], [330, 246], [306, 264], [240, 266], [176, 256], [156, 234]]), '#16161c', 0.1, 3);
    for (let i = 0; i < 6; i++) R.groove(line([[176 + i * 24, 236], [196 + i * 24, 252]]), 4, '#5a5a66', 0.16, 0.04, 3, 0.8);
    const crown = sm([[148, 212], [146, 170], [160, 140], [196, 118], [250, 108], [300, 116], [332, 140], [346, 178], [338, 208], [300, 224], [220, 222]]);
    R.dome(crown, lin(150, 110, 340, 220, [[0, '#4a6a8a'], [0.6, '#6a86a8'], [1, '#4a6888']]), 0.14, 0.1, 12, 2);
    R.dome(sm([[150, 186], [200, 198], [260, 208], [306, 214], [304, 230], [240, 228], [178, 222], [150, 212]]), '#168a50', 0.2, 0.06, 6, 2);
    for (let i = 0; i < 9; i++) {
      const cx = 178 + i * 18.5, cy = 150 + i * 7.5;
      R.dome(P([[cx - 8, cy - 12], [cx - 2 + 8, cy - 46 + i * 1.5], [cx + 30, cy - 52 + i * 2], [cx + 14, cy - 16]]), '#e6c43a', 0.22, 0.1, 6, 4);
      R.dome(P([[cx - 12, cy + 18], [cx - 8, cy + 30], [cx + 6, cy + 30]]), '#1e9a5a', 0.22, 0.06, 4, 2);
    }
    for (let i = 0; i < 9; i++) R.dome(ellipseP(178 + i * 18.5, 158 + i * 7.5, 12, 24, -0.35), '#e2dad2', 0.3, 0.12, 10, 1);

    // ── starry porthole ──
    const PC = [150, 786];
    R.dome(circleP(PC[0], PC[1], 132), '#44505c', 0.16, 0.1, 14, 3);
    R.groove(circleP(PC[0], PC[1], 116), 6, '#14181e', 0.26, 0.06, 3);
    R.dome(circleP(PC[0], PC[1], 108), '#4a525e', 0.2, 0.04, 6, 3);
    const win = circleP(PC[0], PC[1] + 1, 100);
    const STARS = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.02), m = fbm(p * 0.06 + 3.);
      vec3 c = mix(vec3(.14, .13, .36), vec3(.22, .26, .50), n);
      c = mix(c, vec3(.55, .45, .85), smoothstep(.6, .8, m) * .6);
      c += vec3(.2, .5, .6) * smoothstep(.62, .75, fbm(p * 0.035 + 9.)) * .8;
      float s = step(.985, hash(floor(p / 2.))); c += s * .8;
      float l = smoothstep(.92, 1., sin(p.x * .12 + n * 30.)) * smoothstep(.5, .7, m); c += l * vec3(.5, .6, .8);
      return c; }`);
    R.flat(win, '#30306a', 0.18, 0);
    clipA(win, () => img(STARS));
    { const rot = 0.24, c = Math.cos(rot), s = Math.sin(rot);
      clipA(win, () => {
        R.pipe(line([[PC[0] - s * 110, PC[1] - c * 110], [PC[0] + s * 110, PC[1] + c * 110]]), 15, '#38387e', 0.22, 0.06, 2);
        R.pipe(line([[PC[0] - c * 110, PC[1] + s * 110], [PC[0] + c * 110, PC[1] - s * 110]]), 15, '#38387e', 0.22, 0.06, 2);
      }); }
    R.bead(PC[0] + 2, PC[1], 8, '#a0a8c0', 0.28, 0.06, 3);
    R.bead(100, 782, 30, '#3a3c4a', 0.24, 0.06, 3);
    R.bead(100, 782, 22, '#f08a40', 0.28, 0.08, 6);
    for (const [x, y, w, h] of [[160, 660, 24, 26], [254, 760, 18, 32], [174, 892, 24, 22], [36, 760, 14, 30]]) R.dome(rrect(x - w / 2, y - h / 2, w, h, 4), '#2a3038', 0.24, 0.06, 4, 3);
    R.pipe(line([[62, 560], [62, 690]]), 14, '#3a2420', 0.2, 0.08, 3);
    R.dome(rrect(46, 644, 34, 56, 6), '#1e2228', 0.28, 0.08, 6, 3);

    // ── green robot body ──
    const body = sm([[236, 700], [244, 660], [262, 630], [300, 622], [330, 640], [348, 690], [390, 720], [430, 760], [450, 840], [466, 930], [480, 1040], [230, 1040], [244, 960], [252, 900]]);
    R.dome(body, lin(240, 620, 470, 1000, [[0, '#1c6a4a'], [0.4, '#144a3c'], [1, '#0c302c']]), 0.1, 0.12, 30, 2);
    R.dome(ellipseP(286, 656, 40, 32, 0), '#1e6a4a', 0.16, 0.08, 18, 2);
    R.bead(272, 656, 6, '#f0e060', 0.34, 0.04, 6);
    R.dome(sm([[260, 700], [330, 700], [356, 740], [320, 770], [270, 760]]), '#1e7050', 0.2, 0.08, 14, 2);
    R.pipe(line([[214, 878], [270, 868], [330, 852]]), 14, '#1e7050', 0.3, 0.08, 2);
    R.dome(circleP(370, 850, 52), '#1a5e4a', 0.22, 0.1, 14, 2);
    R.dome(circleP(370, 850, 40), '#6a3ab8', 0.28, 0.06, 6, 2);
    R.dome(circleP(370, 850, 32), '#1e7a56', 0.3, 0.06, 8, 2);
    R.bead(372, 848, 14, '#98e090', 0.34, 0.08, 2);
    for (const [x, y] of [[296, 708], [340, 770], [420, 700], [300, 940], [262, 930], [330, 900]]) R.bead(x, y, 5, '#9aa0a8', 0.3, 0.06, 3);

    // ── right side: dark body, blue arm, striped wing ──
    R.flat(sm([[470, 724], [540, 690], [590, 620], [600, 540], [630, 480], [640, 560], [642, 650], [624, 760], [592, 880], [562, 1040], [470, 1040], [460, 900], [440, 800]]), '#060810', 0.04, 0);
    R.dome(sm([[620, 420], [690, 432], [726, 452], [726, 570], [700, 540], [666, 500], [634, 470]]), lin(620, 430, 726, 560, [[0, '#24304c'], [1, '#5a7aa8']]), 0.12, 0.08, 14, 2);
    const wing = sm([[640, 690], [652, 640], [684, 612], [726, 600], [726, 664], [690, 678]]);
    R.dome(wing, '#4a4a52', 0.1, 0.06, 8, 1);
    clipA(wing, () => { for (let k = 0; k < 9; k++) stroke(line([[640, 700 - k * 9], [690, 640 - k * 7], [730, 620 - k * 5]]), '#c8c4c8', 2.5); });
    // bottom-left pale glow
    soft(x => { fill(ellipseP(0, 680, 40, 50, 0), '#8aa0c0', x); fill(ellipseP(10, 900, 50, 40, 0), '#7a8aa0', x); }, 14, 0.9);
    R.dome(sm([[-14, 880], [30, 896], [80, 930], [150, 966], [200, 1004], [220, 1040], [-14, 1040]]), lin(0, 900, 200, 1024, [[0, '#7a8490'], [0.4, '#c0b4ae'], [1, '#6a8498']]), 0.06, 0.08, 20, 6);
    R.bead(110, 970, 14, '#18283a', 0.14, 0.06, 2);
    // glass bubble
    R.bead(552, 806, 20, '#30584e', 0.2, 0.2, 6);
    // gold spikes
    for (const [x, y, h, w] of [[488, 160, 46, 7], [536, 186, 50, 8], [572, 196, 56, 9], [676, 378, 64, 12]])
      R.dome(P([[x, y], [x + w, y + h], [x - w, y + h]]), lin(x, y, x, y + h, [[0, '#f0c070'], [1, '#c06818']]), 0.3, 0.1, 4, 4);
    for (const [x, y] of [[642, 466], [720, 518], [700, 1000]]) R.bead(x, y, 6, '#f0a040', 0.3, 0.06, 6);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 22, wrap: 0.45, ao: 0.7, rim: 0.4 }),                       // 1 cream clay
        E.mat({ dif: 1, spec: 1.1, shin: 70, wrap: 0.25, coat: 0.18, ao: 0.4, rim: 0.6 }),           // 2 glossy plastic
        E.mat({ dif: 0.8, metal: 0.4, spec: 0.9, shin: 40, ao: 0.5, rim: 0.4 }),                       // 3 dark metal
        E.mat({ dif: 0.8, metal: 0.4, spec: 0.9, shin: 30, tint: [1.1, 0.95, 0.6], emis: 0.15 }),     // 4 gold
        E.mat({ dif: 1, spec: 0.25, shin: 16, wrap: 0.6, ao: 0.4, emis: 0.05 }),                       // 5 grey textured mass
        E.mat({ dif: 0.7, spec: 0.8, shin: 40, wrap: 0.5, emis: 0.3, rim: 0.8 })                       // 6 glowing glass
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.72, 0.7, 0.7], amb: [0.3, 0.3, 0.33],
      envTop: [0.8, 0.8, 0.85], envHor: [0.3, 0.32, 0.38], envBot: [0.04, 0.05, 0.08], envK: [0.2, 0.7, 0.4, 0],
      rimC: [0.2, 0.3, 0.6], rimD: [0.5, 0.4, 0.4], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 90], shadow: [-4, 5, 0.6, 7]
    });

    // ── glowing blue outlines ──
    const glow = (path, c, wd, px, al = 1) => { o.save(); o.globalAlpha = al; o.globalCompositeOperation = 'screen'; o.filter = `blur(${px * S}px)`; stroke(path, c, wd, o); o.restore(); };
    glow(mass, '#5a90e8', 4, 2, 0.8);
    glow(line([[600, 330], [630, 480], [642, 600], [636, 700], [612, 800], [584, 900], [560, 1030]]), '#b0c8ff', 3, 1.5, 0.9);
    glow(line([[600, 330], [630, 480], [642, 600], [636, 700], [612, 800], [584, 900], [560, 1030]]), '#4070e0', 12, 8, 0.6);
    glow(deck, '#6aa0f0', 3, 2, 0.6);
    glow(shell, '#a0a0b0', 3, 3, 0.4);
    glow(line([[430, 1000], [436, 900], [428, 830]]), '#c0d0f0', 3, 2, 0.6);
    glow(line([[300, 1010], [312, 960], [318, 920]]), '#ffb0e0', 4, 2, 0.8);
    glow(line([[500, 940], [520, 880], [530, 840], [560, 780], [580, 730], [600, 712]]), '#c8d0ff', 2, 1, 0.7);
    E.bloom(0.15, 10);
    E.grain(0.03, 89);
  }
});
