'use strict';
// s25 — "Black glitch bust, holo shards": a glossy black crumpled figure on a grey
// studio sweep, with an orange triangle-mosaic plane, a rainbow holo spike and
// streaky holographic debris bursting from its shoulder.
REC.register('s25', {
  w: 818, h: 1024,
  draw(E) {
    const o = E.out, W = 818, H = 1024;
    const poly = (pts) => P(pts, true, false);
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };

    // ── grey studio sweep ──
    const bg = E.fx(`vec3 fx(vec2 uv, vec2 px){
      vec2 q = px - vec2(340.0, 0.0);
      float L = mix(205.0, 232.0, smoothstep(480.0, 900.0, px.y)) - 125.0 * exp(-(q.x * q.x / (2.0 * 200.0 * 200.0) + q.y * q.y / (2.0 * 280.0 * 280.0)));
      L = L / 255.0;
      L += 0.02 * (vnoise(px * 0.01) - 0.5);
      return vec3(L);
    }`);
    o.drawImage(bg, 0, 0, W, H);

    // blob silhouette (right edge traced; left side runs off canvas)
    const BLOB = [[-20, -20], [272, -20], [305, 8], [348, 34], [372, 62], [362, 96], [352, 140], [336, 178], [318, 205], [360, 222],
      [385, 262], [400, 300], [390, 360], [345, 420], [330, 470], [360, 520], [420, 552], [466, 585], [472, 648], [446, 700],
      [402, 750], [377, 800], [351, 850], [323, 900], [306, 950], [300, 1000], [295, 1044], [-20, 1044]];
    const blobP = P(BLOB, true, false);
    // soft contact shadow on the sweep, fading toward the bottom
    const shC = E.newCanvas(), sx = shC.getContext('2d'); sx.setTransform(E.S, 0, 0, E.S, 0, 0);
    sx.filter = `blur(${70 * E.S}px)`; sx.fillStyle = '#303030'; sx.translate(40, 10); sx.fill(blobP);
    sx.setTransform(1, 0, 0, 1, 0, 0); sx.filter = 'none'; sx.globalCompositeOperation = 'destination-in';
    const fg = sx.createLinearGradient(0, 700 * E.S, 0, 1000 * E.S); fg.addColorStop(0, 'rgba(0,0,0,1)'); fg.addColorStop(1, 'rgba(0,0,0,0.75)');
    sx.fillStyle = fg; sx.fillRect(0, 0, shC.width, shC.height);
    E.draw(shC, 0.38);

    // ── black body in relief ──
    const R = E.relief();
    R.a.drawImage(E.snapshot(), 0, 0, W, H);                   // background as unlit albedo (mat 0)
    R.dome(blobP, lin(0, 0, 100, 1000, [[0, '#0c0c0c'], [0.5, '#141414'], [1, '#2c2c2c']]), 0.05, 0.3, 160, 1);
    // large soft tonal forms: shoulder, chest, belly, head mass
    const forms = [[70, 360, 150, 190, 0.2, '#161616'], [230, 320, 120, 120, -0.3, '#141414'], [260, 560, 150, 110, 0.1, '#161616'],
      [120, 700, 170, 160, 0, '#232323'], [200, 900, 180, 140, 0.1, '#262626'], [40, 560, 70, 120, 0, '#262626'], [330, 640, 110, 90, 0.4, '#1e1e1e'],
      [140, 180, 120, 90, 0, '#141414']];
    forms.forEach(([x, y, rx, ry, rot, c]) => { const p = ellipseP(x, y, rx, ry, rot); R.a.save(); R.a.clip(blobP); R.a.filter = `blur(${30 * E.S}px)`; R.a.fillStyle = c; R.a.fill(p); R.a.restore(); });
    R.a.save(); R.a.clip(blobP); R.a.globalCompositeOperation = 'multiply'; R.a.fillStyle = lin(0, 0, 100, 1000, [[0, '#303030'], [0.45, '#707070'], [0.7, '#b0b0b0'], [1, '#d0d0d0']]); R.a.fillRect(0, 0, W, H); R.a.restore();
    // crumpled crystalline hair at the top
    const gr = rng(25);
    for (let i = 0; i < 90; i++) {
      const x = gr() * 370, y = gr() * 200, s = 14 + gr() * 34, an = gr() * 6.28;
      if (x > 330 + (y > 100 ? -30 : 20)) continue;
      const pts = [0, 1, 2].map(k => [x + Math.cos(an + k * 2.1 + gr() * 0.6) * s, y + Math.sin(an + k * 2.1 + gr() * 0.6) * s]);
      R.flat(poly(pts), mixHex('#0c0c0c', '#262626', gr()), 0.4 + gr() * 0.2, 3);
    }
    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.8, spec: 0.3, shin: 18, wrap: 0.2, coat: 0.06, ao: 0.5, rim: 0.15 }),         // soft black plastic
        E.mat({ dif: 0.9, spec: 0.5, shin: 30, coat: 0.2, rim: 0.2 }),                                // (spare)
        E.mat({ dif: 0.6, spec: 1.3, shin: 70, coat: 0.5, rim: 0.4 })                                 // glossy crystals
      ],
      light: [-0.35, 0.55, 0.75], lc: [0.8, 0.8, 0.81], amb: [0.1, 0.1, 0.1],
      envTop: [0.85, 0.85, 0.86], envHor: [0.35, 0.35, 0.36], envBot: [0.05, 0.05, 0.05], envK: [0.2, 0.6, 0.3, 0],
      rimC: [0.35, 0.35, 0.36], rimD: [1, 0.2, 0.7], l2: [1, 0.1, -0.05, 2], l2c: [0.25, 0.25, 0.26],
      r1: 2, r2: 10, k: [0, 0.6, 0.4, 60], shadow: [5, 6, 0.5, 6]
    });

    // glitch extrusions: sharp horizontal slabs stretched to the left
    const gr2 = rng(25);
    for (let i = 0; i < 30; i++) {
      const y = 360 + gr2() * 540, x1 = 150 + gr2() * 230, len = 60 + gr2() * 200, th = 5 + gr2() * 18, sk = (gr2() - 0.5) * 24;
      const top = poly([[x1 - len, y + sk], [x1, y], [x1 + 10, y + th * 0.4], [x1 - len + 6, y + sk + th * 0.4]]);
      const bot = poly([[x1 - len + 6, y + sk + th * 0.4], [x1 + 10, y + th * 0.4], [x1 + 4, y + th], [x1 - len + 10, y + th + sk]]);
      o.fillStyle = mixHex('#1c1c1c', '#383838', gr2()); o.fill(top);
      o.fillStyle = mixHex('#080808', '#141414', gr2()); o.fill(bot);
    }

    // crumpled facets over the body
    o.save(); o.clip(blobP);
    const fr = rng(77);
    for (let i = 0; i < 140; i++) {
      const x = fr() * 470, y = 180 + fr() * 860, s = 20 + fr() * 70, an = fr() * 6.28;
      const pts = [0, 1, 2].map(k => [x + Math.cos(an + k * 2.1 + fr() * 0.8) * s * (0.6 + fr()), y + Math.sin(an + k * 2.1 + fr() * 0.8) * s * 0.7]);
      o.fillStyle = fr() < 0.4 ? `rgba(255,255,255,${0.02 + fr() * 0.05})` : `rgba(0,0,0,${0.1 + fr() * 0.25})`;
      o.fill(poly(pts));
    }
    o.restore();
    // ── holo cluster ──
    const mosaic = E.fx(`vec3 fx(vec2 uv, vec2 px){
      float a = 0.46; mat2 r = mat2(cos(a), -sin(a), sin(a), cos(a));
      vec2 p = r * (px - vec2(590.0, 100.0)) / 15.0;
      vec2 c = floor(p), f = fract(p);
      float half_ = step(f.y, f.x);
      float h = hash(c * 1.37 + half_ * 17.1);
      float t = clamp((px.x - 560.0) / 220.0 + (px.y - 100.0) / 900.0, 0.0, 1.0);
      vec3 org = mix(vec3(1.0, 0.36, 0.02), vec3(1.0, 0.55, 0.05), fract(h * 7.0));
      vec3 col = h < 0.32 ? vec3(0.13) * (0.7 + 0.6 * fract(h * 13.0)) : (h < 0.42 ? vec3(0.95, 0.80, 0.10) : (h < 0.47 ? mix(vec3(0.1, 0.8, 0.6), vec3(0.2, 0.5, 1.0), fract(h * 5.0)) : org));
      col = mix(col, vec3(0.12), smoothstep(0.5, 0.0, t) * 0.75);
      return col;
    }`);
    const holo = E.fx(`vec3 fx(vec2 uv, vec2 px){
      float t = dot(px - vec2(620.0, 470.0), normalize(vec2(0.35, 1.0))) / 300.0;
      float s = dot(px - vec2(620.0, 470.0), normalize(vec2(1.0, -0.35))) / 90.0;
      vec3 c = mix(vec3(1.0, 0.25, 0.05), vec3(1.0, 0.85, 0.1), smoothstep(0.1, 0.45, t + s * 0.2));
      c = mix(c, vec3(0.2, 0.9, 0.9), smoothstep(0.5, 0.75, t - s * 0.4));
      c = mix(c, vec3(1.0, 0.1, 0.7), smoothstep(0.55, 0.0, s) * smoothstep(0.35, 0.8, t));
      return c;
    }`);
    const clipDraw = (pts, cv) => { o.save(); o.clip(poly(pts)); o.drawImage(cv, 0, 0, W, H); o.restore(); };
    const fillP = (pts, fs) => { o.fillStyle = fs; o.fill(poly(pts)); };

    // dark debris mass behind
    fillP([[355, 150], [470, 180], [560, 190], [600, 260], [640, 330], [640, 420], [600, 520], [560, 600], [500, 600], [430, 540], [380, 470], [390, 380], [380, 290], [360, 230]], '#262626');
    fillP([[440, 250], [560, 230], [610, 300], [600, 380], [520, 420], [450, 380]], lin(440, 250, 600, 400, [[0, '#3a3a3a'], [1, '#1c1c1c']]));
    // mosaic plane
    clipDraw([[592, 102], [775, 505], [692, 526], [610, 420], [566, 300], [540, 200], [560, 150]], mosaic);
    fillP([[600, 330], [650, 360], [640, 430], [590, 440]], '#232323');
    // orange triangle
    fillP([[605, 380], [684, 380], [655, 437]], lin(605, 380, 680, 430, [[0, '#ff5a08'], [1, '#ff8a10']]));
    // black top rod
    fillP([[330, 98], [586, 112], [580, 140], [340, 104]], lin(330, 100, 580, 130, [[0, '#101010'], [1, '#2a2a2a']]));
    // dark cylinder with holo stripes
    const cyl = [[355, 150], [395, 128], [500, 178], [500, 245], [420, 252], [376, 212]];
    fillP(cyl, '#2e2e2e');
    o.save(); o.clip(poly([[420, 180], [500, 200], [500, 245], [420, 250]]));
    const hr = rng(3);
    for (let i = 0; i < 26; i++) { const y = 180 + i * 2.8; o.fillStyle = `hsla(${(i * 23 + hr() * 60) % 360},75%,${30 + hr() * 20}%,0.9)`; o.fillRect(420, y, 90, 2.8); }
    o.restore();
    // yellow S blob
    const yb = P([[380, 300], [420, 296], [440, 320], [470, 318], [505, 336], [500, 380], [470, 400], [430, 402], [400, 390], [378, 360]]);
    o.fillStyle = lin(380, 300, 500, 400, [[0, '#7a7018'], [0.5, '#9a8a22'], [1, '#4a5a2a']]); o.fill(yb);
    o.save(); o.clip(yb); o.strokeStyle = 'rgba(40,40,20,0.5)'; o.lineWidth = 1;
    for (let i = 0; i < 40; i++) { o.beginPath(); o.moveTo(370 + i * 4, 300); o.lineTo(330 + i * 4, 410); o.stroke(); }
    o.restore();
    fillP([[436, 318], [470, 318], [480, 360], [450, 372]], '#1f3a44');
    // streaky holographic beams (diagonal)
    o.save(); o.lineCap = 'butt';
    const sr = rng(11);
    for (let i = 0; i < 40; i++) {
      const t = sr(), x0 = 400 + sr() * 60 + t * 30, y0 = 400 + t * 120, x1 = x0 + 220 + sr() * 80, y1 = y0 + 130 + sr() * 70;
      o.strokeStyle = `hsla(${[50, 55, 60, 80, 300, 30, 180][Math.floor(sr() * 7)]},75%,${30 + sr() * 18}%,${0.3 + sr() * 0.35})`;
      o.lineWidth = 0.8 + sr() * 3; o.beginPath(); o.moveTo(x0, y0); o.lineTo(x1, y1); o.stroke();
    }
    for (const [x0, y0, x1, y1, w, c] of [[300, 358, 578, 470, 5, '#c8b428'], [200, 300, 340, 330, 5, '#b0a020'], [330, 470, 600, 580, 3, '#d02090'], [520, 280, 640, 640, 3, '#c8c020']]) {
      o.strokeStyle = c; o.lineWidth = w; o.beginPath(); o.moveTo(x0, y0); o.lineTo(x1, y1); o.stroke();
    }
    o.restore();
    // holo spike
    clipDraw([[622, 478], [696, 520], [716, 600], [662, 770]], holo);
    fillP([[622, 478], [640, 482], [662, 770]], 'rgba(20,20,20,0.85)');
    fillP([[600, 440], [700, 500], [706, 560], [652, 600], [622, 560]], '#1e1e1e');
    // grey crystal lump
    fillP([[332, 452], [372, 440], [384, 478], [360, 520], [330, 500]], lin(330, 450, 380, 520, [[0, '#d0d0d0'], [1, '#6a6a6a']]));

    // ── wireframe filaments over the body ──
    o.save(); o.lineWidth = 0.7;
    const wr = rng(17);
    const wire = (cx, cy, rad, n) => { for (let i = 0; i < n; i++) { o.strokeStyle = `rgba(230,230,230,${0.2 + wr() * 0.35})`; o.beginPath(); o.moveTo(cx + (wr() - 0.5) * rad, cy + (wr() - 0.5) * rad); o.lineTo(cx + (wr() - 0.5) * rad, cy + (wr() - 0.5) * rad); o.stroke(); } };
    wire(150, 230, 180, 30); wire(260, 280, 120, 20); wire(420, 650, 90, 26); wire(360, 800, 60, 14); wire(130, 990, 200, 18); wire(20, 740, 60, 8);
    o.restore();
    // specular glints on the crystalline hair
    o.save();
    for (let i = 0; i < 40; i++) {
      const x = gr() * 360, y = gr() * 190, s = 3 + gr() * 12, an = gr() * 6.28;
      o.strokeStyle = `rgba(255,255,255,${0.2 + gr() * 0.5})`; o.lineWidth = 1 + gr();
      o.beginPath(); o.moveTo(x, y); o.lineTo(x + Math.cos(an) * s, y + Math.sin(an) * s); o.stroke();
    }
    o.restore();
    E.grain(0.03, 4);
  }
});
