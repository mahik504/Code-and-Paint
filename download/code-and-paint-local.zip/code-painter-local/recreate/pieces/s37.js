'use strict';
// s37 — "Zebra dream collage": flat cut-paper collage — a black bushy head over a slate cloak
// with a red-glowing eye, a snowflake-blue wedge with a dashed hem, a salmon fish-shape,
// zebra op-art stripes, striped grey belts, green hills, a lilac fan and a lamp in a blue sky.
REC.register('s37', {
  w: 706, h: 1024,
  draw(E) {
    const o = E.out, S = E.S, r = rng(37);
    const F = (path, c) => { o.fillStyle = c; o.fill(path); };
    const K = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const C = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const softF = (fn, blur, alpha = 1) => { const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x); o.save(); o.setTransform(1, 0, 0, 1, 0, 0); o.globalAlpha = alpha; o.filter = `blur(${blur * S}px)`; o.drawImage(c, 0, 0); o.restore(); };
    const poly = pts => P(pts, true, false);

    // ── textures ──
    const greyBg = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float w = sin((p.y + 6. * sin(p.x * 0.05) + 20. * fbm(p * 0.01)) * 1.6); return vec3(.78,.81,.83) + 0.025 * w; }`));
    const zebra = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 60. * vec2(fbm(p * 0.01), fbm(p * 0.01 + 4.)) ;
      float s = sin((q.x * 0.3 + q.y * 0.95 + 22. * sin(q.x * 0.05 + q.y * 0.03) + 30. * fbm(p * 0.02)) * 0.5);
      return vec3(smoothstep(-0.12, 0.12, s)); }`));
    const belt = (dx, dy, per) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float t = dot(p, vec2(uD.x, uD.y)); float n = fbm(p * vec2(0.02, 0.2));
      float fine = 0.5 + 0.5 * sin(t * 1.9 + 6. * n);
      vec3 c = mix(vec3(.08), vec3(.42), fine * fine);
      float rung = abs(fract(t / uP) - 0.5) * uP;
      c = mix(c, vec3(.97), smoothstep(4.5, 2.5, rung));
      return c; }`, { uD: [dx, dy], uP: per }));
    const wood = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float t = dot(p, vec2(0.91, 0.41)) + 30. * fbm(p * 0.015); float s = sin(t * 0.35);
      return mix(vec3(.40,.28,.12), vec3(.05,.03,.02), smoothstep(0.55, 0.8, s)) * (0.85 + 0.3 * fbm(p * 0.05)); }`));
    const speck = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float h = hash(floor(p * 0.6)); return mix(vec3(.52,.2,.26), vec3(.85,.62,.22), step(0.9, h)) * (0.85 + 0.3 * fbm(p * 0.05)); }`));

    // ── ground layers ──
    F(rrect(0, 0, 706, 1024, 0), greyBg);
    const sky = o.createLinearGradient(0, 0, 300, 260); sky.addColorStop(0, '#7f8ffe'); sky.addColorStop(0.7, '#93a3ff'); sky.addColorStop(1, '#b4c0f4');
    F(poly([[0, 0], [300, 0], [300, 110], [0, 260]]), sky);
    softF(x => { x.fillStyle = '#c6cff2'; x.fill(ellipseP(190, 190, 90, 40, -0.4)); }, 25, 0.8);
    // brown earth + green hill (left)
    F(P([[0, 360], [120, 320], [240, 250], [300, 240], [305, 470], [230, 540], [140, 600], [115, 770], [0, 770]]), '#753803');
    F(P([[0, 245], [60, 215], [110, 190], [150, 160], [195, 125], [215, 100], [265, 90], [292, 96], [296, 175], [270, 190], [280, 230], [240, 260], [200, 262], [150, 300], [140, 330], [100, 345], [60, 380], [44, 430], [0, 445]]), '#0ca10e');
    F(P([[0, 320], [40, 300], [90, 300], [60, 330]]), '#753803');
    F(P([[150, 270], [220, 250], [260, 255], [240, 280], [190, 290]]), '#753803');
    F(P([[80, 240], [130, 215], [150, 222], [110, 250]]), '#050505');
    F(ellipseP(104, 250, 10, 6, 0), '#050505');
    // light green comb strokes on the hill
    for (let k = 0; k < 12; k++) K(P([[200 + k * 5, 160], [215 + k * 5, 230]], false), '#b8a830', 2);
    F(ellipseP(282, 213, 20, 16, 0), '#f5a018');
    // white prism bottom-left
    F(poly([[0, 640], [68, 700], [96, 700], [96, 760], [0, 760]]), '#e2ecf2'); F(poly([[0, 640], [68, 700], [0, 700]]), '#f8fcff');
    // black palms
    const palm = (cx, cy, n, len, a0, a1) => { for (let k = 0; k < n; k++) { const an = a0 + (a1 - a0) * k / n + (r() - 0.5) * 0.1, L = len * (0.6 + r() * 0.5); K(P([[cx, cy], [cx + Math.cos(an) * L * 0.5, cy + Math.sin(an) * L * 0.5 - 6], [cx + Math.cos(an) * L, cy + Math.sin(an) * L]], false), '#040404', 2.2 + r() * 2); } };
    palm(10, 200, 60, 80, -2.4, 1.2); palm(20, 510, 70, 95, -2.6, 1.4);
    F(poly([[0, 500], [25, 500], [30, 760], [0, 760]]), '#6a3002');

    // ── lilac fan + orange shapes ──
    C(circleP(230, 440, 132), () => {
      F(circleP(230, 440, 132), '#8a74a8');
      for (let k = 0; k < 160; k++) { const an = k / 160 * 6.283; K(P([[230, 440], [230 + Math.cos(an) * 135, 440 + Math.sin(an) * 135]], false), k % 2 ? '#a896c4' : '#6f5c90', 1); }
    });
    F(ellipseP(252, 365, 48, 58, 0.1), '#bb6d1c');
    F(circleP(208, 455, 20), '#d8742a'); for (let k = 0; k < 4; k++) F(rrect(190, 446 + k * 6, 36, 2.5, 1), '#6a3a18');
    K(P([[160, 575], [150, 600], [140, 612]], false), '#8a74a8', 5);

    // ── top right: green field, orange sun, pink streak ──
    F(P([[468, 0], [706, 0], [706, 132], [640, 150], [580, 145], [530, 128], [505, 70]]), '#0ea00d');
    F(circleP(626, 110, 23), '#f5901c');
    F(P([[690, 30], [706, 28], [706, 130], [692, 110], [684, 70]]), '#f07cb0');
    F(P([[515, 80], [560, 70], [585, 95], [575, 135], [540, 150], [515, 125]]), '#6a78a6');

    // ── slate cloak + black egg + glow ──
    const cloak = P([[300, 255], [455, 205], [515, 115], [556, 88], [576, 118], [540, 170], [500, 230], [450, 300], [425, 380], [438, 460], [452, 520], [420, 552], [372, 560], [352, 505], [330, 450], [310, 350]]);
    F(cloak, '#4c6989');
    softF(x => { x.fillStyle = '#8898ac'; x.fill(ellipseP(505, 345, 95, 150, 0.25)); x.fillStyle = '#5a7390'; x.fill(ellipseP(420, 470, 60, 90, 0)); }, 22, 0.9);
    softF(x => { x.fillStyle = '#000'; x.fill(ellipseP(510, 335, 62, 96, 0.22)); }, 4, 1);
    softF(x => { x.fillStyle = '#ff1010'; x.fill(circleP(507, 450, 20)); }, 8, 1);
    F(circleP(507, 450, 8), '#ffffff');
    // pink splash + black blob
    F(P([[572, 228], [590, 232], [600, 270], [632, 290], [642, 330], [620, 360], [590, 380], [566, 372], [562, 330], [576, 300], [566, 260]]), '#fd78ae');
    F(P([[580, 262], [612, 230], [650, 226], [690, 232], [706, 240], [706, 290], [670, 300], [640, 290], [620, 310], [598, 300]]), '#030303');

    // ── black bushy head + speckled chin ──
    const headPts = [[268, 212], [252, 152], [262, 92], [284, 42], [318, 12], [360, 0], [482, 0], [500, 28], [512, 92], [502, 160], [470, 210], [448, 232], [400, 250], [330, 262], [298, 250]];
    F(P(ragged(headPts, 0, headPts.length, 10, 5, 7)), '#010101');
    F(P([[305, 262], [335, 255], [405, 250], [442, 232], [462, 202], [472, 215], [452, 262], [422, 292], [380, 302], [340, 330], [312, 322]]), speck);

    // ── lamp ──
    K(P([[62, -5], [112, 100]], false), '#f4f8f0', 30); K(P([[62, -5], [72, 16]], false), '#0a0a0a', 30);
    F(ellipseP(114, 120, 30, 32, 0), '#eef6c0'); F(circleP(125, 147, 8), '#f0901a');

    // ── snowflake wedge + dashed hem ──
    const wedge = P([[300, 250], [330, 440], [352, 490], [358, 560], [350, 592], [300, 625], [250, 680], [200, 750], [150, 772], [165, 700], [200, 560], [245, 420]], true, false);
    F(wedge, '#4ea9fd');
    C(wedge, () => {
      const flake = (x, y, s) => { for (let k = 0; k < 6; k++) { const an = k / 6 * 6.283; K(P([[x, y], [x + Math.cos(an) * s, y + Math.sin(an) * s]], false), '#fff', s * 0.45); K(P([[x + Math.cos(an) * s * 0.6, y + Math.sin(an) * s * 0.6], [x + Math.cos(an + 0.5) * s * 0.9, y + Math.sin(an + 0.5) * s * 0.9]], false), '#fff', s * 0.2); } F(circleP(x, y, s * 0.4), '#fff'); };
      for (const [x, y, s] of [[357, 343, 16], [350, 408, 20], [290, 432, 17], [270, 498, 22], [326, 525, 22], [232, 588, 22], [185, 680, 16], [280, 368, 13], [165, 745, 12], [300, 290, 10], [215, 640, 9]]) flake(x, y, s);
    });
    const hem1 = P([[300, 250], [304, 330], [318, 420], [334, 468], [350, 490]], false), hem2 = P([[352, 545], [354, 588], [300, 624], [248, 680], [196, 752]], false);
    for (const hm of [hem1, hem2]) { K(hm, '#050505', 10); o.save(); o.setLineDash([4, 5]); K(hm, '#f8f8f8', 5); o.restore(); }
    F(circleP(392, 372, 5), '#6ab8f0'); F(circleP(360, 476, 6), '#6ab8f0');
    for (const [x, y, rr] of [[374, 513, 6], [365, 540, 5], [352, 552, 4], [372, 300, 3]]) F(circleP(x, y, rr), '#050505');

    // ── right diagonal stripes (wood / green / blue) ──
    const rightP = poly([[590, 560], [640, 500], [706, 470], [706, 1024], [440, 1024], [490, 880], [545, 760]]);
    C(rightP, () => {
      F(rrect(400, 450, 320, 600, 0), wood);
      F(poly([[706, 600], [706, 780], [610, 905], [640, 760]]), '#1a9a3c');
      F(poly([[706, 780], [706, 832], [610, 960], [578, 1024], [546, 1024], [600, 905]]), '#1242d8');
      F(poly([[706, 860], [706, 1024], [612, 1024], [650, 940]]), '#1c894f');
    });
    // ── salmon fish + blue fin + green patch + eye ──
    const fish = P([[150, 775], [228, 682], [292, 628], [362, 598], [452, 588], [540, 582], [592, 572], [560, 660], [505, 770], [462, 880], [432, 1024], [0, 1024], [0, 760], [100, 770]]);
    const fg = o.createLinearGradient(200, 650, 560, 800); fg.addColorStop(0, '#f494a4'); fg.addColorStop(0.35, '#ee7866'); fg.addColorStop(0.75, '#b0664c'); fg.addColorStop(1, '#8a5a44');
    F(fish, fg);
    C(fish, () => {
      for (let k = 0; k < 900; k++) F(circleP(300 + r() * 300, 620 + r() * 400, 0.7), 'rgba(40,20,10,0.35)');
      softF(x => { x.fillStyle = '#f5a0b0'; x.fill(ellipseP(250, 740, 90, 45, -0.5)); x.fillStyle = '#e97070'; x.fill(ellipseP(100, 990, 140, 50, -0.3)); }, 30, 0.9);
    });
    softF(x => { x.fillStyle = '#6cc4e4'; x.fill(P([[262, 642], [300, 612], [380, 590], [452, 578], [522, 582], [540, 612], [528, 642], [476, 642], [420, 656], [350, 670], [300, 680]])); }, 3, 1);
    softF(x => { x.fillStyle = '#10a018'; x.fill(P([[150, 772], [190, 700], [240, 660], [290, 660], [300, 700], [270, 760], [240, 800], [170, 822]])); }, 3, 1);
    for (const [x, y, rr] of [[437, 601, 5], [452, 595, 5], [467, 595, 4], [520, 628, 3], [430, 750, 9], [505, 664, 6], [412, 797, 3], [395, 700, 3]]) F(circleP(x, y, rr), '#050505');
    softF(x => { x.fillStyle = '#000'; x.fill(ellipseP(318, 716, 34, 38, 0)); x.fillStyle = '#ff1818'; x.fill(circleP(340, 712, 26)); }, 5, 1);
    F(circleP(340, 712, 11), '#ffffff');

    // ── zebra stripes ──
    const zeb = P(ragged([[0, 702], [60, 728], [120, 756], [200, 780], [270, 774], [372, 736], [362, 792], [300, 832], [220, 880], [140, 930], [70, 968], [0, 1002]], 0, 5, 16, 10, 5), true, false);
    F(zeb, zebra);
    // bottom green
    F(P([[90, 1030], [160, 965], [250, 905], [350, 865], [430, 850], [440, 950], [430, 1030]]), '#3f9a2a');
    softF(x => { x.fillStyle = '#2aa018'; x.fill(ellipseP(300, 960, 90, 60, -0.4)); }, 20, 0.8);
    softF(x => { x.fillStyle = '#e88070'; x.fill(ellipseP(120, 1010, 140, 30, 0)); }, 12, 0.9);
    // belts: upper diagonal + long lower
    const beltA = poly([[692, 350], [706, 346], [706, 425], [600, 520], [566, 572], [506, 560], [560, 490], [640, 400]]);
    C(beltA, () => F(rrect(480, 330, 240, 260, 0), belt(0.7, -0.7, 56)));
    const beltL = poly([[506, 560], [592, 566], [640, 520], [602, 640], [548, 770], [490, 900], [452, 1024], [292, 1024], [332, 940], [400, 790], [462, 660]]);
    C(beltL, () => F(rrect(280, 500, 380, 540, 0), belt(0.33, 0.94, 58)));
    const beltB = poly([[640, 520], [706, 482], [706, 562], [652, 640], [592, 780], [532, 900], [500, 1024], [452, 1024], [490, 900], [548, 770], [602, 640]]);
    K(beltL, 'rgba(255,255,255,0.8)', 3); K(beltA, 'rgba(255,255,255,0.8)', 3);


    E.grain(0.04, 37);
  }
});
