'use strict';
// g027 — "Starfield hose relay": in a black starfield a zebra-striped sleeve reaches down past a grey beam and a
// glass jar; orange gloves pass a ringed orange hose to a fluffy black-and-white creature sinking into zebra
// cloth, beside a lattice tower on a white wall and a black synth panel.
REC.register('g027', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const F = (path, c) => { o.fillStyle = c; o.fill(path); };
    const K = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const C = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const L = (pts, c, wd) => K(P(pts, false, false), c, wd);
    const poly = pts => P(pts, true, false);
    const INK = '#080808', WH = '#fdfdfd', OR = '#f57d18', ORD = '#c8601a', BL = '#1c45a8', GR = '#b1b0ae';

    // ── textures ──
    const stars = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float c = 0.;
      for (int k = 0; k < 3; k++) {
        float sc = k == 0 ? 7. : (k == 1 ? 13. : 23.);
        vec2 g = floor(p / sc), f = fract(p / sc) - .5;
        float h = hash(g + float(k) * 17.3);
        vec2 o2 = vec2(hash(g + 3.1), hash(g + 7.7)) - .5;
        float r = (k == 0 ? 0.09 : (k == 1 ? 0.1 : 0.09)) * (0.5 + h);
        float on = step(k == 0 ? 0.78 : (k == 1 ? 0.8 : 0.84), h);
        c = max(c, on * smoothstep(r + 0.05, r - 0.02, length(f - o2 * 0.6)));
      }
      return mix(vec3(.03), vec3(.98), c); }`);
    // sleeve: stripes run along the tube and bunch up towards its silhouette edges
    const sleeveZ = pat(E.fx(`
      float edgeL(float y){ return y < 96. ? mix(62., 68., y / 96.) : y < 150. ? mix(68., 86., (y - 96.) / 54.) : y < 262. ? mix(86., 150., (y - 150.) / 112.) : mix(150., 222., (y - 262.) / 148.); }
      float edgeR(float y){ return y < 130. ? mix(300., 330., y / 130.) : y < 256. ? mix(330., 372., (y - 130.) / 126.) : mix(372., 432., (y - 256.) / 84.); }
      vec3 fx(vec2 uv, vec2 p){
        float u = clamp((p.x - edgeL(p.y)) / (edgeR(p.y) - edgeL(p.y)), -0.2, 1.2);
        float k = uN * u + 0.32 * sin(6.2832 * u) + uTw * p.y + 0.15 * sin(p.y * 0.02);
        float s = cos(6.2832 * (k + uPh));
        return mix(vec3(.02), vec3(.99), smoothstep(-0.1, 0.1, s)); }`, { uN: 14.4, uTw: 0, uPh: 0.3 }));
    const clothZ = pat(E.fx(`
      const vec2 EP[19] = vec2[19](vec2(-20., 972.), vec2(0., 965.), vec2(50., 950.), vec2(100., 927.), vec2(150., 893.), vec2(200., 876.),
        vec2(250., 862.), vec2(300., 847.), vec2(350., 835.), vec2(400., 830.), vec2(440., 837.), vec2(470., 862.), vec2(488., 900.),
        vec2(500., 928.), vec2(528., 902.), vec2(552., 884.), vec2(576., 915.), vec2(592., 965.), vec2(600., 1040.));
      vec3 fx(vec2 uv, vec2 p){
        float d = 1e5;
        for (int i = 0; i < 18; i++) { vec2 a = EP[i], b = EP[i + 1], pa = p - a, ba = b - a;
          float t = clamp(dot(pa, ba) / dot(ba, ba), 0., 1.); d = min(d, length(pa - ba * t)); }
        float per = mix(15., 21., smoothstep(80., 380., p.x)) * mix(1., 0.7, smoothstep(90., 10., length(p - vec2(500., 925.))));
        float ph = d / per + 0.25 * sin(p.x * 0.03 + p.y * 0.02) + 0.3 * (fbm(p * 0.01) - .5);
        float s = sin(6.2832 * (ph + uPh));
        return mix(vec3(.02), vec3(.98), smoothstep(-0.12, 0.12, s)); }`, { uPh: 0.6 }));
    const fur = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = vec2(p.x * 0.6 + p.y * 0.3, p.y);
      float n = fbm(p * 0.02) + 0.18 * (vnoise(q * vec2(0.25, 0.05)) - .5);
      float wht = smoothstep(0.52, 0.6, n);
      float hair = 0.5 + 0.5 * sin(p.x * 1.3 + p.y * 0.4 + 6. * vnoise(p * 0.08));
      return mix(vec3(.04), vec3(.95), wht) * (0.85 + 0.15 * hair); }`));

    // ── black starfield ──
    E.draw(stars);
    const sr = rng(27);
    for (let i = 0; i < 50; i++) { const x = sr() * 726, y = sr() * 1024, r = sr() < 0.85 ? 1.5 + sr() * 2.5 : 5 + sr() * 7; F(circleP(x, y, r), WH); }

    // ── grey wall + blue glove (top left) ──
    F(poly([[0, 0], [64, 0], [66, 118], [44, 140], [0, 172]]), GR);
    for (const x of [14, 30, 48]) L([[x, 0], [x + 2, 140]], '#8c8b89', 1.2);
    L([[0, 128], [60, 108]], '#2a2a2a', 2);
    F(P([[8, 212], [16, 178], [40, 152], [70, 140], [108, 146], [140, 160], [150, 192], [132, 226], [92, 230], [48, 222], [14, 224]]), BL);
    L([[60, 170], [100, 185], [120, 210]], '#0c2050', 2); L([[30, 200], [70, 196]], '#0c2050', 2);

    // ── zebra sleeve ──
    const sleeve = P([[62, -4], [300, -4], [314, 60], [330, 130], [348, 200], [372, 256], [404, 304], [432, 340], [330, 410], [240, 446], [222, 410], [200, 360], [178, 310], [150, 262], [118, 210], [86, 150], [68, 96]]);
    F(sleeve, sleeveZ);
    K(sleeve, INK, 3);
    // white glyphs on the sleeve
    F(poly([[318, 196], [336, 192], [338, 202], [360, 200], [362, 192], [384, 190], [388, 214], [372, 216], [370, 228], [350, 230], [348, 220], [328, 224], [322, 212]]), WH);
    K(P([[340, 250], [330, 270], [340, 300], [370, 318], [395, 312], [402, 296], [384, 288], [366, 296], [352, 280], [360, 262], [352, 246]], false), WH, 9);
    K(P([[340, 250], [330, 270], [340, 300], [370, 318], [395, 312], [402, 296], [384, 288], [366, 296], [352, 280], [360, 262], [352, 246]], false), INK, 1.5);

    // ── synth panel (top right) ──
    const dev = poly([[450, 136], [726, 12], [726, 258], [470, 306]]);
    F(dev, '#262626');
    const devIn = poly([[476, 150], [726, 42], [726, 238], [488, 288]]);
    F(devIn, '#0b0b0b');
    K(dev, '#5a5a5a', 2);
    C(devIn, () => {
      o.save(); o.translate(480, 240); o.rotate(-0.42);
      for (let r = 0; r < 3; r++) for (let i = 0; i < 9; i++) if ((i + r) % 3 !== 1) F(rrect(20 + i * 26, 6 - r * 22, 18, 7, 1), '#2c6ad8');
      for (let i = 0; i < 6; i++) F(rrect(30 + i * 40, -70, 26, 6, 1), '#3a3a3a');
      o.font = 'bold 9px Arial'; o.fillStyle = '#d8d8d8'; o.fillText('WITH NEO SYNTH', 10, 30);
      o.restore();
    });
    F(poly([[646, 136], [662, 130], [664, 140], [676, 136], [674, 126], [690, 122], [694, 150], [680, 154], [682, 164], [664, 168], [662, 158], [648, 162]]), WH);
    for (const [x, y] of [[580, 126], [612, 112], [630, 104], [600, 150], [560, 140]]) F(P(star(x, y, 7, 2, 4, 0)), WH);
    K(circleP(706, 74, 13), WH, 2);
    F(poly([[478, 216], [486, 214], [490, 250], [482, 252]]), WH);
    // antenna rod + cap, orange hand with tool
    L([[536, -4], [536, 96]], '#d0d0d0', 4); F(rrect(526, 90, 20, 14, 4), '#e8e4dc');
    F(poly([[478, 52], [500, 44], [522, 88], [516, 100], [500, 96]]), '#c9c6c0');
    F(P([[444, 10], [452, -4], [500, -4], [504, 20], [498, 46], [488, 62], [470, 70], [456, 56], [442, 38]]), OR);
    for (const pts of [[[456, 40], [458, 64]], [[470, 46], [470, 70]], [[484, 44], [488, 62]]]) L(pts, '#7a3a10', 1.5);

    // ── white wall + lattice tower ──
    const wall = poly([[582, 300], [726, 258], [726, 1030], [500, 1030], [500, 760], [598, 760], [590, 560], [583, 400]]);
    F(wall, WH);
    // zigzags on the wall
    L([[602, 350], [612, 336], [620, 346], [630, 330], [640, 342], [652, 326], [664, 334], [676, 322]], '#333', 1.5);
    L([[596, 612], [604, 596], [614, 606], [618, 590], [628, 598], [632, 580]], '#333', 1.5);
    // tower
    const TX0 = 640, TX1 = 690;
    F(rrect(620, 356, 88, 70, 10), '#a9a8a6'); F(ellipseP(664, 362, 44, 9, 0), '#c8c7c5'); F(ellipseP(664, 418, 44, 9, 0), '#a9a8a6');
    K(ellipseP(664, 362, 44, 9, 0), '#444', 1.5);
    o.save(); o.strokeStyle = '#2e2e2e'; o.lineWidth = 1.7;
    const tl = y => 644 - (y - 430) * 0.02, tr = y => 686 + (y - 430) * 0.02;
    o.beginPath();
    for (const f of [tl, tr]) for (const dx of [0, 4]) { o.moveTo(f(430) + (f === tl ? -dx : dx), 430); o.lineTo(f(1030) + (f === tl ? -dx : dx), 1030); }
    o.moveTo(665, 430); o.lineTo(665, 1030);
    for (let y = 430; y < 1030; y += 24) {
      o.moveTo(tl(y), y); o.lineTo(tr(y + 24), y + 24); o.moveTo(tr(y), y); o.lineTo(tl(y + 24), y + 24);
      o.moveTo(tl(y) - 4, y); o.lineTo(tr(y) + 4, y); o.moveTo(tl(y) - 4, y + 4); o.lineTo(tr(y) + 4, y + 4);
      o.moveTo(tl(y), y + 12); o.lineTo(665, y); o.lineTo(tr(y), y + 12);
    }
    o.stroke(); o.restore();
    for (const [y, c] of [[505, INK], [530, OR], [560, INK], [600, INK], [628, OR], [660, INK], [690, INK], [735, INK], [800, INK], [862, INK], [880, INK], [940, INK]]) { F(circleP(665 + (y % 3) * 4 - 4, y, 7), c); if (c === INK) F(circleP(665 + (y % 3) * 4 - 4, y, 2.5), '#888'); }
    // black slot left of the wall + white zigzags
    F(poly([[514, 330], [582, 318], [584, 400], [590, 560], [598, 762], [516, 762]]), '#050505');
    const zz = poly([[536, 664], [552, 652], [560, 660], [574, 646], [580, 652], [596, 636], [604, 640], [612, 622], [606, 610], [618, 600], [622, 620], [620, 642], [604, 660], [592, 664], [580, 676], [566, 676], [556, 690], [544, 684]]);
    F(zz, WH); K(zz, '#111', 1.5);
    L([[596, 614], [606, 600], [612, 606], [620, 590], [626, 596], [630, 578]], '#222', 1.5);

    // ── grey beam with peach end ──
    F(poly([[188, 458], [582, 302], [586, 330], [204, 488]]), '#c4c3c1');
    F(poly([[204, 488], [586, 330], [586, 340], [210, 498]]), '#8e8d8b');
    F(poly([[500, 334], [582, 302], [586, 330], [506, 362]]), '#fbead4');
    K(poly([[188, 458], [582, 302], [586, 330], [204, 488]]), '#222', 1.5);
    L([[300, 420], [350, 400]], INK, 4);

    // ── glass jar ──
    const jar = P([[266, 456], [300, 430], [380, 404], [440, 400], [462, 420], [472, 520], [476, 610], [460, 640], [400, 655], [340, 652], [310, 630], [292, 560]]);
    F(jar, '#f6f6f6');
    C(jar, () => {
      F(poly([[440, 400], [476, 400], [480, 660], [446, 660]]), '#bdbdbd');
      F(poly([[266, 456], [300, 456], [320, 650], [280, 650]]), '#d8d8d8');
      // dark landscape silhouette
      const sil = [[290, 600]]; const lr = rng(5);
      for (let x = 300; x <= 470; x += 8) sil.push([x, 570 - lr() * 26 - (x > 420 ? 20 : 0)]);
      sil.push([480, 600]);
      F(poly(sil), '#2a2a2a');
      F(ellipseP(392, 618, 74, 22, -0.05), '#d0d0d0'); F(ellipseP(392, 618, 44, 11, -0.05), '#8a8a8a');
      F(ellipseP(400, 470, 50, 46, 0), '#ffffff');
    });
    K(jar, '#2a2a2a', 2);
    K(ellipseP(372, 422, 84, 18, -0.12), '#2a2a2a', 1.5);
    // peach note on a grey card
    F(poly([[350, 452], [370, 446], [392, 556], [374, 562]]), '#9a9a9a');
    F(poly([[272, 470], [350, 452], [380, 568], [302, 586]]), '#fbc898');
    for (let i = 0; i < 9; i++) L([[284 + i * 2, 494 + i * 10], [346 + i * 2, 480 + i * 10]], '#c07040', 1);
    F(poly([[318, 460], [340, 455], [344, 470], [322, 475]]), '#fde8d0');
    L([[382, 420], [384, 470], [396, 490]], '#2a2a2a', 1.5);

    // ── orange hand under the jar ──
    F(P([[222, 488], [252, 478], [262, 512], [300, 510], [320, 520], [310, 540], [270, 552], [268, 590], [310, 612], [322, 626], [300, 632], [290, 660], [262, 662], [240, 640], [232, 590], [226, 540]]), OR);
    for (const pts of [[[240, 520], [262, 520], [268, 545]], [[250, 600], [290, 620]], [[255, 630], [282, 650]], [[230, 560], [250, 580]]]) L(pts, '#7a3a10', 1.5);

    // ── left arm: blue sleeve, grey ribbed cuff, orange glove ──
    F(P([[-4, 518], [30, 528], [60, 545], [78, 575], [74, 610], [40, 640], [-4, 650]]), BL);
    const cuff = P([[18, 610], [50, 588], [90, 592], [106, 625], [96, 664], [60, 684], [30, 680], [18, 650]]);
    F(cuff, '#9a9899');
    C(cuff, () => { for (let i = 0; i < 9; i++) L([[10, 580 + i * 12], [110, 600 + i * 12]], '#5a5858', 1.5); });
    F(P([[44, 668], [86, 648], [130, 650], [178, 660], [192, 678], [176, 696], [150, 700], [168, 730], [150, 750], [110, 748], [70, 738], [46, 712]]), OR);
    for (const pts of [[[100, 700], [150, 700]], [[90, 720], [140, 738]], [[132, 678], [176, 680]]]) L(pts, '#7a3a10', 1.5);

    // ── ringed orange hose ──
    const hose = P([[150, 688], [210, 690], [260, 700], [310, 730], [350, 770], [390, 800], [430, 818], [478, 822]], false, true);
    K(hose, '#7a3a10', 50); K(hose, OR, 46);
    o.save(); o.lineCap = 'butt'; o.lineWidth = 46; o.strokeStyle = WH; o.setLineDash([3, 9]); o.lineDashOffset = 0; o.stroke(hose); o.restore();
    o.save(); o.lineCap = 'butt'; o.lineWidth = 46; o.strokeStyle = '#7a3a10'; o.setLineDash([1, 11]); o.lineDashOffset = -3; o.stroke(hose); o.restore();

    // ── zebra cloth (bottom) ──
    const cloth = P([[-4, 960], [60, 950], [130, 905], [250, 874], [350, 850], [420, 836], [470, 842], [520, 870], [556, 906], [578, 960], [590, 1030], [-4, 1030]]);
    F(cloth, clothZ);
    K(cloth, INK, 2);

    // ── fluffy creature: black fur, white rim + diagonal band, pointed ear, tail sinking into the cloth ──
    F(P([[530, 740], [560, 726], [598, 730], [604, 752], [580, 760], [540, 758]]), WH);
    const furO = [[478, 812], [490, 786], [520, 762], [556, 748], [590, 754], [626, 758], [666, 756], [646, 790], [622, 818], [612, 846], [590, 868], [560, 876], [544, 900], [530, 930], [512, 950], [486, 944], [474, 904], [486, 872], [480, 846]];
    const furP = P(ragged(furO, 0, furO.length, 5, 5, 9), true, false);
    F(furP, '#0a0a0a');
    C(furP, () => {
      F(P(ragged([[476, 830], [492, 790], [520, 766], [556, 750], [590, 756], [570, 770], [530, 780], [505, 800], [492, 830]], 0, 8, 4, 4, 3), true, false), '#f2f2f2');
      F(P(ragged([[556, 752], [592, 752], [596, 780], [612, 820], [624, 850], [606, 870], [584, 858], [578, 820], [562, 784]], 0, 8, 4, 5, 4), true, false), '#f2f2f2');
      const hr = rng(41);
      for (let i = 0; i < 700; i++) {
        const x = 470 + hr() * 200, y = 740 + hr() * 215, a = -1.2 + hr() * 0.8, l = 4 + hr() * 7;
        L([[x, y], [x + Math.cos(a) * l, y + Math.sin(a) * l]], hr() < 0.5 ? 'rgba(255,255,255,0.35)' : 'rgba(0,0,0,0.5)', 0.8);
      }
    });
    // ── white leaves ──
    const leaf = (x, y, l, wd, a) => { F(P([[x - Math.cos(a) * l, y - Math.sin(a) * l], [x - Math.sin(a) * wd, y + Math.cos(a) * wd], [x + Math.cos(a) * l, y + Math.sin(a) * l], [x + Math.sin(a) * wd, y - Math.cos(a) * wd]], true, false), WH); };
    for (const [x, y, l, wd, a] of [[400, 124, 30, 12, 1.2], [140, 400, 36, 12, -0.9], [172, 532, 28, 10, 0.5], [486, 478, 22, 9, -1.1], [436, 682, 26, 9, 1.3], [484, 712, 24, 8, -0.4], [416, 740, 22, 8, -0.9], [118, 806, 34, 12, 0.35], [234, 788, 28, 10, 0.4], [514, 612, 22, 8, -1.2]]) leaf(x, y, l, wd, a);
    for (const [x, y, r] of [[78, 300, 10], [432, 258, 7], [168, 640, 12], [342, 690, 9], [48, 738, 10], [118, 450, 8], [64, 545, 8], [224, 850, 9], [96, 862, 7], [146, 886, 9]]) F(circleP(x, y, r), WH);

    E.grain(0.03, 27);
  }
});
