'use strict';
// g001 — "Crayon starburst salamander": a wavy chrome-zebra puddle on black holding a liquid-silver
// pool, a black starfield burst ringed with rainbow-tipped crayon spikes, and a grey clay salamander.
REC.register('g001', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    // an early read-back keeps the relief buffers in CPU memory (GPU-backed ones can get dropped under heavy stroking)
    R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1);
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };

    // ── textures ──
    const zebra = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 80. * vec2(vnoise(p * 0.005) - .5, vnoise(p * 0.005 + 5.2) - .5);
      q += 14. * vec2(sin(p.y * 0.05 + 2. * sin(p.x * 0.017)), sin(p.x * 0.046 + 2. * sin(p.y * 0.021)));
      vec2 d = (q - vec2(400., 560.)) * vec2(1.0, 0.8);
      float ph = length(d) / 21. + 3.5 * vnoise(p * 0.004 + 3.) + 0.6 * sin(atan(d.y, d.x) * 3.);
      float v = sin(6.2832 * ph);
      float w = smoothstep(-0.12, 0.38, v);
      vec3 col = mix(vec3(0.02, 0.02, 0.03), vec3(0.80, 0.82, 0.87), w);
      col += vec3(0.14) * smoothstep(0.7, 1.0, v);
      col *= 0.92 + 0.12 * vnoise(p * 0.03);
      return col; }`));
    const chrome = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p * 0.008;
      float n = vnoise(q + 1.6 * vec2(vnoise(q * 0.6), vnoise(q * 0.6 + 7.))) * 0.75 + vnoise(q * 1.9 + 3.) * 0.25;
      float b = sin(n * 9. + p.y * 0.004);
      vec3 c = mix(vec3(0.40, 0.47, 0.58), vec3(0.84, 0.88, 0.95), smoothstep(0.15, 0.9, b));
      c = mix(c, vec3(0.97, 0.98, 1.0), smoothstep(0.85, 1.0, b));
      c = mix(c, vec3(0.16, 0.20, 0.28), smoothstep(0.55, 0.98, -b) * 0.85);
      return c; }`));

    // ── black ground + zebra puddle ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#000', 0, 0);
    const OUT = [[175, 95], [215, 55], [280, 40], [350, 32], [420, 28], [455, 12], [490, 28], [515, 60], [570, 62], [640, 82], [690, 110], [735, 150], [735, 880],
      [700, 905], [670, 960], [610, 990], [540, 1005], [460, 1000], [400, 1010], [320, 1012], [250, 1012], [170, 1000], [110, 990], [60, 975], [30, 945], [20, 905],
      [-5, 880], [-5, 400], [10, 340], [30, 290], [60, 250], [100, 210], [140, 140]];
    const outP = P(OUT);
    R.dome(outP, zebra, 0.02, 0.06, 10, 0);
    R.flat(ellipseP(45, 350, 28, 32, 0), '#000', 0.02, 0);

    // ── liquid silver pools ──
    const pools = [
      [[300, 135], [335, 150], [360, 200], [380, 260], [400, 330], [420, 345], [455, 400], [480, 440], [500, 470], [495, 505], [460, 515], [420, 520], [395, 540], [375, 575], [355, 600], [330, 600], [355, 560], [350, 500], [335, 450], [330, 420], [300, 400], [280, 340], [285, 250]],
      [[540, 330], [600, 395], [640, 380], [665, 420], [650, 480], [640, 530], [600, 520], [560, 470], [530, 420]],
      [[440, 580], [520, 560], [620, 570], [660, 620], [650, 720], [600, 730], [560, 700], [480, 690], [450, 650]],
      [[460, 700], [560, 700], [580, 760], [560, 840], [490, 840], [470, 780]],
      [[150, 300], [230, 280], [290, 320], [300, 360], [250, 380], [180, 360]]];
    for (const pl of pools) R.flat(P(pl), chrome, 0.06, 0);

    // ── starfield burst ──
    const SF = [[262, 340], [282, 380], [320, 405], [352, 405], [355, 450], [352, 500], [365, 545], [380, 575], [350, 600], [330, 600], [330, 620], [420, 600], [470, 610], [510, 640],
      [545, 660], [540, 700], [530, 740], [520, 780], [495, 800], [470, 830], [440, 815], [425, 850], [400, 830], [380, 880], [350, 840], [330, 880], [310, 830], [285, 860],
      [260, 830], [230, 840], [210, 880], [195, 830], [175, 830], [160, 810], [200, 780], [170, 760], [130, 740], [165, 700], [120, 660], [150, 630], [130, 600], [165, 575],
      [150, 540], [180, 515], [165, 480], [220, 480], [195, 440], [235, 430], [215, 400]];
    const sfP = P(SF, true, false);
    a.lineJoin = 'round'; a.lineWidth = 16; a.strokeStyle = chrome; a.stroke(sfP);
    R.flat(sfP, '#040406', 0.05, 0);
    clipA(sfP, () => {
      const r = rng(11);
      for (let i = 0; i < 420; i++) { a.fillStyle = `rgba(255,255,255,${0.4 + r() * 0.6})`; a.fill(circleP(120 + r() * 440, 330 + r() * 560, 0.5 + r() * r() * 2.6)); }
      for (const [x, y, rr] of [[305, 660, 6], [242, 646, 4], [288, 640, 3], [267, 735, 5], [243, 785, 5], [207, 657, 4], [440, 714, 4], [500, 780, 3], [318, 571, 3]]) { a.fillStyle = '#fff'; a.fill(circleP(x, y, rr)); }
    });

    // ── crayon spikes ──
    const leaf = (tx, ty, bx, by, w) => {
      const dx = bx - tx, dy = by - ty, L = Math.hypot(dx, dy), ux = dx / L, uy = dy / L, nx = -uy, ny = ux, A = [], B = [];
      for (let i = 0; i <= 24; i++) { const t = i / 24, hw = w * 0.46 * Math.pow(Math.sin(Math.PI * Math.pow(t, 0.75)), 0.6); A.push([tx + ux * L * t + nx * hw, ty + uy * L * t + ny * hw]); B.push([tx + ux * L * t - nx * hw, ty + uy * L * t - ny * hw]); }
      return { path: P([...A, ...B.reverse()]), ux, uy, nx, ny, L };
    };
    const SP = [[325, 125, 395, 300, 40, '#9a3cff', '#1a8cff'], [415, 148, 400, 300, 34, '#fff200', '#ffc800'], [290, 235, 340, 400, 32, '#a8ff20', '#60e000'],
      [568, 75, 520, 220, 40, '#ff8a00', '#ff5000'], [640, 170, 575, 260, 38, '#d0ff30', '#30e040'], [72, 398, 235, 470, 46, '#ff8010', '#ff4000'],
      [45, 470, 235, 480, 46, '#ffe800', '#ffc000'], [28, 520, 200, 565, 46, '#40ff40', '#20e020'], [5, 650, 175, 650, 46, '#d0ff20', '#80ff00'],
      [20, 705, 120, 690, 26, '#ff8020', '#ff6000'], [35, 748, 160, 700, 34, '#d040ff', '#ff30d0'], [15, 790, 170, 710, 48, '#f0ff20', '#c0ff00'],
      [70, 858, 170, 800, 26, '#40ff40', '#40ff40'], [122, 885, 200, 760, 44, '#ffff10', '#f0e000'], [270, 1010, 285, 880, 40, '#ff7010', '#ff5000'],
      [410, 965, 420, 840, 36, '#e8ff20', '#ffff00'], [505, 945, 470, 800, 46, '#ff3090', '#ff6040'], [555, 900, 500, 810, 36, '#40ff60', '#00e080'],
      [640, 895, 605, 830, 34, '#40d8ff', '#4040ff'], [480, 15, 470, 70, 30, '#30ff60', '#60ff40'], [262, 345, 292, 385, 16, '#ffe800', '#ffe000']];
    const sr = rng(5);
    for (const [tx, ty, bx, by, w, c1, c2] of SP) {
      const lf = leaf(tx, ty, bx, by, w);
      a.lineWidth = 12; a.strokeStyle = chrome; a.stroke(lf.path);
      const g = a.createLinearGradient(tx, ty, bx, by); g.addColorStop(0, '#2a2030'); g.addColorStop(0.5, '#141420'); g.addColorStop(1, '#0a0a12');
      R.dome(lf.path, g, 0.1, 0.12, w * 0.35, 2);
      clipA(lf.path, () => {
        for (let k = 0; k < 26; k++) {
          const off = (sr() - 0.5) * w * 0.9, t0 = 0.25 + sr() * 0.2;
          a.lineWidth = 0.8 + sr() * 1.2; a.strokeStyle = sr() < 0.6 ? 'rgba(255,140,40,0.75)' : 'rgba(70,140,255,0.7)';
          a.beginPath(); a.moveTo(tx + lf.ux * lf.L * t0 + lf.nx * off * 0.6, ty + lf.uy * lf.L * t0 + lf.ny * off * 0.6); a.lineTo(bx - lf.nx * off * 0.2, by - lf.ny * off * 0.2); a.stroke();
        }
        // coloured crayon tip with a dripping edge
        const tc = Math.min(0.48, 45 / lf.L + 0.24), pts = [[tx - lf.ux * 5, ty - lf.uy * 5]];
        for (let j = -6; j <= 6; j++) {
          const s = j / 6, tt = tc + (j % 2 ? 0.06 : -0.02) * (0.5 + sr());
          pts.push([tx + lf.ux * lf.L * tt + lf.nx * s * w * 0.6, ty + lf.uy * lf.L * tt + lf.ny * s * w * 0.6]);
        }
        const tg = a.createLinearGradient(tx, ty, tx + lf.ux * lf.L * tc, ty + lf.uy * lf.L * tc); tg.addColorStop(0, c1); tg.addColorStop(1, c2);
        a.fillStyle = tg; a.fill(P(pts, true, false));
      });
    }

    // ── grey tubes ──
    const GREY = '#9a9690';
    const tube = (pts, wd) => { const p = P(pts, false); a.lineCap = 'round'; a.lineWidth = wd + 12; a.strokeStyle = chrome; a.stroke(p); R.pipe(p, wd, GREY, 0.2, 0.2, 1); };
    tube([[52, 170], [62, 150], [88, 140], [108, 148], [116, 170], [118, 200], [126, 230]], 20);
    tube([[150, 240], [140, 265], [120, 285], [95, 300], [60, 305], [30, 320], [12, 345], [8, 390], [15, 420]], 22);
    tube([[152, 335], [150, 315], [165, 300], [200, 294], [240, 304], [265, 325], [282, 350]], 22);
    tube([[-5, 740], [25, 760], [42, 800], [32, 840], [5, 862]], 22);
    tube([[600, 540], [640, 525], [675, 518], [697, 535], [694, 562], [672, 568]], 26);
    tube([[560, 700], [548, 740], [545, 780], [565, 815], [580, 860], [570, 905], [560, 945], [580, 970], [608, 975]], 32);
    tube([[575, 805], [620, 808], [660, 800], [698, 780], [712, 758]], 28);
    tube([[440, 640], [470, 618], [482, 640], [470, 668]], 22);

    // ── clay salamander ──
    const body = (pts, wd) => { const p = P(pts); a.lineJoin = 'round'; a.lineWidth = 14; a.strokeStyle = chrome; a.stroke(p); R.dome(p, GREY, 0.2, 0.3, wd, 1); };
    body([[400, 330], [396, 270], [410, 215], [445, 182], [495, 170], [545, 174], [572, 198], [584, 238], [578, 282], [562, 318], [548, 340], [545, 372], [565, 395], [590, 430], [612, 470],
      [625, 510], [620, 545], [600, 570], [560, 583], [500, 585], [455, 592], [425, 610], [400, 612], [385, 600], [390, 560], [405, 530], [440, 518], [490, 514], [530, 505], [535, 480],
      [515, 455], [485, 425], [455, 390], [430, 348]], 40);
    body([[540, 335], [575, 328], [608, 330], [632, 308], [650, 292], [664, 302], [658, 328], [634, 356], [612, 380], [590, 392], [566, 390], [546, 372]], 22);
    body([[548, 580], [590, 575], [605, 610], [600, 660], [590, 700], [565, 715], [545, 690], [540, 640]], 22);
    body([[325, 640], [330, 615], [350, 600], [385, 598], [420, 600], [445, 612], [455, 640], [440, 680], [415, 700], [385, 712], [355, 708], [335, 690], [322, 665]], 28);
    // eyes
    for (const [x, y, r] of [[372, 693, 7], [590, 382, 5], [596, 648, 7]]) R.flat(circleP(x, y, r), '#050505', 0.5, 0);
    R.dome(circleP(415, 420, 12), '#202430', 0.06, 0.03, 5, 3);
    R.flat(circleP(415, 420, 7), '#000', 0.05, 0);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.7, shin: 45, wrap: 0.45, ao: 0.4, coat: 0.12, rim: 0.25 }),   // 1 grey clay
        E.mat({ dif: 1, spec: 1.1, shin: 70, wrap: 0.3, coat: 0.25, ao: 0.3 }),              // 2 glossy crayon
        E.mat({ dif: 0.5, metal: 0.6, spec: 1.0, shin: 50, rim: 0.3 })                        // 3 chrome ring
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.7, 0.7, 0.72], amb: [0.42, 0.42, 0.44],
      envTop: [1.05, 1.05, 1.08], envHor: [0.55, 0.6, 0.7], envBot: [0.1, 0.1, 0.14], envK: [0.3, 1.0, 0.3, 0],
      rimC: [0.6, 0.65, 0.8], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 6, k: [0, 0.6, 0.4, 90], shadow: [-4, 5, 0.4, 6]
    });
    E.bloom(0.12, 8);
    E.grain(0.03, 1);
  }
});
