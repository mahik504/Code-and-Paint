'use strict';
// g215 — "Lens-eyed flower sphere": a teal-and-cobalt sphere with a glowing camera-lens eye and pink flowers, ringed by
// zebra arcs, ribbed blue hoses, an orange knitted tube and glossy cobalt blobs, over zebra dunes and dusky glitter ground.
REC.register('g215', {
  w: 578, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const Q = (f, sm = true, cl = true) => { const q = []; for (let i = 0; i < f.length; i += 2) q.push([f[i], f[i + 1]]); return P(q, cl, sm); };
    const L = f => Q(f, true, false);
    const img = (cv, alpha = 1, op = 'source-over') => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const lg = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rg = (x0, y0, r0, x1, y1, r1, st) => { const g = a.createRadialGradient(x0, y0, r0, x1, y1, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const soft = (blur, fn, alpha = 1, clipP = null, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clipP) a.clip(clipP); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const along = (f, step) => {
      const c = []; for (let i = 0; i < f.length; i += 2) c.push([f[i], f[i + 1]]);
      const out = []; let carry = 0;
      for (let i = 0; i < c.length - 1; i++) {
        const [x0, y0] = c[i], [x1, y1] = c[i + 1], d = Math.hypot(x1 - x0, y1 - y0);
        for (let t = carry; t < d; t += step) out.push([x0 + (x1 - x0) * t / d, y0 + (y1 - y0) * t / d, (x1 - x0) / d, (y1 - y0) / d]);
        carry = (carry - d) % step; if (carry < 0) carry += step;
      }
      return out;
    };
    const zebra = (path, glsl, h0 = 0.08, dh = 0.12) => { R.dome(path, '#ffffff', h0, dh, 24, 4); clipA(path, () => img(E.fx(glsl + `
      vec3 fx(vec2 uv, vec2 p){ return mix(vec3(0.96, 0.955, 0.95), vec3(0.03, 0.03, 0.035), smoothstep(-0.12, 0.12, ZZ)); }`))); };
    const hose = (f, w, c0, c1) => { R.pipe(L(f), w, c0, 0.2, 0.2, 1); for (const [x, y, dx, dy] of along(f, 6)) R.groove(Q([x - dy * w * 0.5, y + dx * w * 0.5, x + dy * w * 0.5, y - dx * w * 0.5], false, false), 2.2, c1, 0.4, 0.05, 1); };

    // ── 1. backdrop: indigo night, black corner, brown wood, dusky ground ──
    R.flat(rrect(-10, -10, 600, 1050, 0), lg(0, 300, 0, 900, [[0, '#0e0c22'], [1, '#1c1840']]), 0, 0);
    const wood = Q([240, -10, 600, -10, 600, 440, 560, 330, 530, 220, 470, 130, 400, 92, 320, 76, 260, 60], false);
    R.flat(wood, lg(250, 0, 578, 60, [[0, '#08070a'], [0.3, '#3a2226'], [0.7, '#6e4446'], [1, '#86545a']]), 0, 0);
    clipA(wood, () => { img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float g = vnoise(vec2(p.x * 0.09 + 3. * vnoise(p * 0.01), p.y * 0.006)); return vec3(0.5 + (g - 0.5) * 0.35); }`), 1, 'overlay');
      soft(30, x => { fe(x, 560, 260, 60, 120, 0, '#180c14'); fe(x, 420, 130, 120, 50, 0, '#1a0e14'); }, 0.8); });
    const ground = Q([-10, 826, 60, 836, 120, 852, 200, 880, 274, 861, 347, 822, 421, 806, 495, 816, 560, 846, 600, 856, 600, 1040, -10, 1040], false);
    R.dome(ground, lg(0, 0, 578, 0, [[0, '#5e4a56'], [0.4, '#584450'], [0.56, '#30242c'], [1, '#1e161e']]), 0.02, 0.05, 20, 2);
    clipA(ground, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = hash(floor(p * 0.9)); return vec3(0.5 + (n - 0.5) * 0.5 + step(0.96, n) * 0.3); }`), 0.55, 'overlay'));

    // ── 2. small dark planet top-left, upper hose ──
    R.dome(circleP(-10, 150, 80), rg(-20, 130, 10, -10, 150, 80, [[0, '#1c4a78'], [1, '#0c2848']]), 0.04, 0.12, 30, 2);

    // ── 3. the big sphere ──
    const sph = new Path2D(); sph.arc(285, 345, 263, 0.35, Math.PI - 0.6, true);
    for (const [x, y] of [[40, 508], [130, 532], [200, 524], [260, 470], [330, 452], [400, 468], [470, 470], [530, 434]]) sph.lineTo(x, y); sph.closePath();
    R.dome(sph, lg(40, 120, 520, 420, [[0, '#2696c8'], [0.35, '#1a86bc'], [0.55, '#1452b8'], [1, '#2238a0']]), 0.06, 0.2, 60, 2);
    clipA(sph, () => {
      img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = vnoise(p * 0.35); return vec3(0.5 + (n - 0.5) * 0.3); }`), 0.8, 'overlay');
      soft(26, x => { fe(x, 60, 430, 80, 110, 0.3, '#24356e'); fe(x, 470, 420, 60, 60, 0, '#2a3496'); fe(x, 200, 120, 90, 50, -0.4, '#3aa8d8'); fe(x, 70, 230, 50, 70, 0.3, '#0c3a50'); }, 0.9);
    });
    // zebra arcs (behind the flower plate) and the band below the sphere
    zebra(Q([102, 84, 160, 70, 232, 74, 244, 104, 210, 140, 186, 180, 160, 232, 112, 236, 96, 160]), `
      const vec2 ZC[7] = vec2[7](vec2(125., 110.), vec2(185., 110.), vec2(245., 110.), vec2(125., 170.), vec2(185., 170.), vec2(125., 230.), vec2(185., 230.));
const float ZK[42] = float[42](.54, 3.16, 3.57, .73, -1.81, -1.28, 7.79, 1.18, 1.27, .67, .91, -.42, -1.19, 2.34, 2.37, 1.09, 2.26, .09, -.45, .52, .93, 1.89, -.14, -.33, 18.53, -2.34, -1.24, -2.10, -2.68, -.21, -5.03, .71, 1.17, 3.09, 1.71, 1.34, .24, 5.21, .20, 4.23, 2.92, -1.76);
float zv(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 7; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.2178);
    float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }
      #define ZZ zv(p)`);
    // cyan flower plate
    const plate = Q([84, 300, 112, 262, 166, 232, 209, 210, 237, 190, 266, 167, 290, 182, 300, 230, 296, 256, 286, 300, 262, 334, 262, 384, 250, 424, 200, 446, 130, 436, 80, 404, 58, 360]);
    R.dome(plate, lg(60, 200, 280, 440, [[0, '#46bce4'], [1, '#2ea4d4']]), 0.26, 0.04, 6, 1);
    // white veins
    for (const f of [[300, 196, 340, 160, 400, 140, 470, 126], [392, 200, 412, 160, 428, 136], [470, 126, 500, 150, 520, 190, 540, 214], [420, 260, 470, 280, 520, 290], [280, 200, 300, 230],
      [490, 330, 520, 360, 548, 380], [230, 220, 250, 260, 262, 300], [430, 136, 460, 170, 480, 172]])
      R.pipe(L(f), 3.5, '#c8d4f4', 0.3, 0.03, 1);
    R.dome(Q([418, 106, 456, 112, 470, 92, 480, 120, 460, 136, 430, 134]), '#5ab8e8', 0.26, 0.06, 6, 1);

    // ── 4. lens eye ──
    const C = [350, 350];
    { const fr = new Path2D(); for (let i = 0; i <= 22; i++) { const t = 0.15 + i / 22 * 2.9, r0 = 102; fr.addPath(rrect(-5, -7, 10, 14, 4), new DOMMatrix().translate(C[0] + Math.cos(t) * (r0 + 6), C[1] + Math.sin(t) * (r0 + 6)).rotate(t * 57.3 + 90)); }
      R.dome(fr, '#f0f4fa', 0.28, 0.06, 4, 1); }
    R.dome(circleP(C[0], C[1], 104), lg(260, 260, 450, 450, [[0, '#56a8f0'], [0.5, '#2c80e0'], [1, '#2a6ad0']]), 0.26, 0.08, 10, 1);
    R.dome(circleP(C[0], C[1], 86), lg(270, 270, 430, 430, [[0, '#d0d4dc'], [0.5, '#8a8e9a'], [1, '#c4c8d0']]), 0.32, 0.06, 6, 3);
    R.flat(circleP(C[0], C[1], 74), '#14161e', 0.3, 0);
    R.dome(circleP(C[0], C[1], 64), '#fbf6ee', 0.36, 0.04, 4, 0);
    R.dome(circleP(C[0], C[1], 55), rg(C[0], C[1], 10, C[0], C[1], 56, [[0, '#4a4a52'], [0.8, '#6c6c74'], [1, '#3c3c44']]), 0.34, -0.03, 6, 3);
    clipA(circleP(C[0], C[1], 55), () => { a.strokeStyle = 'rgba(30,30,36,0.35)'; a.lineWidth = 0.8; for (let i = 0; i < 90; i++) { const t = i / 90 * 6.283; a.beginPath(); a.moveTo(C[0] + Math.cos(t) * 12, C[1] + Math.sin(t) * 12); a.lineTo(C[0] + Math.cos(t) * 55, C[1] + Math.sin(t) * 55); a.stroke(); } });
    R.flat(circleP(C[0], C[1], 9), '#020203', 0.3, 0);
    for (const f of [[262, 246, 276, 232, 282, 262], [290, 262, 300, 248, 304, 276]]) R.dome(Q(f, false), '#e8ecf8', 0.3, 0.04, 3, 1);

    // ── 5. pink flowers ──
    const flower = (x, y, r0, sd) => { const r = r0 * 1.12;
      const pts = []; for (let i = 0; i < 48; i++) { const t = i / 48 * 6.283 + sd; pts.push([x + Math.cos(t) * r * (0.84 + 0.16 * Math.abs(Math.cos(t * 4))), y + Math.sin(t) * r * (0.84 + 0.16 * Math.abs(Math.cos(t * 4)))]); }
      R.dome(P(pts, true, true), rg(x, y, r * 0.3, x, y, r, [[0, '#f8c8f0'], [1, '#f0b0e4']]), 0.32, 0.08, r * 0.3, 1);
      R.dome(circleP(x + r * 0.05, y, r * 0.52), '#e470cc', 0.36, -0.04, r * 0.2, 1);
      R.flat(circleP(x + r * 0.08, y, r * 0.34), rg(x, y, 2, x + r * 0.08, y, r * 0.34, [[0, '#6a6ad0'], [1, '#2a2a80']]), 0.32, 1);
    };
    flower(180, 275, 40, 0.2); flower(110, 330, 42, 0.5); flower(210, 386, 42, 0.1); flower(450, 246, 26, 0.3); flower(505, 232, 18, 0.0); flower(540, 326, 18, 0.4);
    for (const [x, y, r] of [[118, 258, 9], [205, 165, 7], [232, 148, 5], [95, 290, 6]]) R.bead(x, y, r, '#f0a8e8', 0.32, 0.06, 1);

    // ── 6. lower zebra band, navy yarn, rocks ──
    zebra(Q([123, 418, 200, 426, 262, 432, 316, 452, 316, 517, 240, 520, 150, 508]), `
      const vec2 ZC[8] = vec2[8](vec2(153., 445.), vec2(213., 445.), vec2(273., 445.), vec2(333., 445.), vec2(153., 505.), vec2(213., 505.), vec2(273., 505.), vec2(333., 505.));
const float ZK[48] = float[48](-.02, .86, -1.03, -.92, 1.18, .02, -4.80, -.14, -.36, -1.35, 1.22, .94, -13.06, .46, -1.52, 1.52, -2.22, 2.72, 6.36, .24, -3.54, -.56, -7.37, 2.50, 6.18, -3.04, 3.34, 1.91, -3.44, 2.18, -6.88, 1.19, -1.06, -1.76, 3.96, -2.26, -6.93, -.86, 2.10, 1.49, -2.28, 3.30, 1.94, -.59, 1.16, -1.32, -1.12, 3.34);
float zv(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 8; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.2178);
    float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }
      #define ZZ zv(p)`, 0.04, 0.06);
    const yarn = Q([212, 566, 236, 520, 286, 482, 340, 468, 392, 470, 404, 500, 372, 540, 330, 582, 290, 612, 250, 622, 222, 602]);
    R.dome(yarn, '#2a3274', 0.08, 0.12, 20, 5);
    clipA(yarn, () => { const r = rng(5); a.lineWidth = 1.3; for (let i = 0; i < 160; i++) { const x = 210 + r() * 200, y = 460 + r() * 170; a.strokeStyle = r() < 0.5 ? 'rgba(80,96,180,0.55)' : 'rgba(10,12,40,0.55)'; a.beginPath(); a.moveTo(x, y); a.quadraticCurveTo(x + 14, y - 10, x + 30, y - 22); a.stroke(); } });
    for (const [x, y, r, sd] of [[330, 640, 24, 1], [370, 600, 30, 2], [420, 655, 24, 3], [340, 590, 18, 4], [300, 620, 14, 5], [395, 690, 20, 6]])
      R.dome(P(blob(x, y, r, r * 0.85, sd, 12, 0.25)), '#1c1a3c', 0.08, 0.1, r * 0.6, 5);

    // ── 7. orange knitted tube ──
    const knitP = (f, w0, w1) => {
      const c = []; for (let i = 0; i < f.length; i += 2) c.push([f[i], f[i + 1]]);
      const l = [], r = [], n = c.length;
      c.forEach((p, i) => { const p0 = c[Math.max(0, i - 1)], p1 = c[Math.min(n - 1, i + 1)]; let dx = p1[0] - p0[0], dy = p1[1] - p0[1]; const d = Math.hypot(dx, dy); dx /= d; dy /= d; const w = (w0 + (w1 - w0) * i / (n - 1)) / 2; l.push([p[0] - dy * w, p[1] + dx * w]); r.push([p[0] + dy * w, p[1] - dx * w]); });
      return P(l.concat(r.reverse()), true, true);
    };
    const knit = Q([600, 300, 560, 320, 520, 350, 480, 380, 450, 420, 430, 470, 412, 520, 395, 580, 385, 640, 380, 690, 400, 722, 450, 712, 470, 660, 490, 600, 520, 540, 548, 500, 600, 470], false); void knitP;
    R.dome(knit, lg(560, 320, 400, 700, [[0, '#962a26'], [0.3, '#c43c20'], [0.6, '#e85a2c'], [1, '#e8602e']]), 0.1, 0.3, 40, 6);
    clipA(knit, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float k = sin(p.x * 0.55 + 2. * sin(p.y * 0.25)) * sin(p.y * 0.42 + vnoise(p * 0.05) * 3.);
      return vec3(0.5 + 0.22 * k + (vnoise(p * 0.08) - 0.5) * 0.3); }`), 0.9, 'overlay'));
    const knit2 = Q([424, 1040, 436, 1004, 466, 974, 506, 948, 548, 918, 600, 886, 600, 1040], false);
    R.dome(knit2, lg(470, 920, 578, 1024, [[0, '#e86030'], [1, '#c84822']]), 0.1, 0.2, 30, 6);
    clipA(knit2, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float k = sin(p.x * 0.55 + 2. * sin(p.y * 0.25)) * sin(p.y * 0.42);
      return vec3(0.5 + 0.2 * k); }`), 0.9, 'overlay'));

    // ── 8. zebra dunes and the fold ──
    zebra(Q([-10, 566, 60, 556, 130, 545, 200, 540, 240, 570, 280, 620, 320, 690, 352, 740, 364, 788, 336, 826, 250, 850, 200, 822, 140, 802, 80, 822, -10, 842]), `
      const float ZMC[72] = float[72](-7.20,-5.83,-4.45,-3.51,-3.26,-3.44,-3.90,-4.51,-5.24,-3.81,-3.02,-2.58,-2.74,-3.03,-3.71,-4.50,-3.26,-1.31,-1.77,-2.16,-2.15,-2.61,-3.53,-4.39,-.56,.72,.53,-.16,-1.17,-2.68,-3.30,-3.95,2.15,2.29,1.59,.91,-.06,-1.15,-2.32,-3.04,2.34,3.42,2.91,1.93,.98,-.17,-.98,-1.49,4.27,5.17,3.69,2.78,1.92,1.11,1.04,.40,5.79,5.28,4.22,4.79,2.72,1.97,2.19,2.04,6.91,5.97,5.43,5.12,4.19,3.48,3.29,3.37);
float zm(vec2 p){ vec2 u = clamp((p - vec2(0.0, 520.0)) / vec2(84.0000, 60.0000), vec2(0.), vec2(4.999, 5.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  float f = 0.;
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += ZMC[(i.y + b) * 8 + i.x + a] * bx[a] * by[b];
  return f; }
      #define ZZ (-cos(6.2832 * zm(p)))`, 0.06, 0.2);
    zebra(Q([66, 846, 96, 812, 140, 796, 190, 800, 236, 830, 262, 862, 244, 902, 204, 942, 146, 940, 104, 906, 86, 870]), `
      const vec2 ZC[11] = vec2[11](vec2(100., 830.), vec2(160., 830.), vec2(220., 830.), vec2(280., 830.), vec2(100., 890.), vec2(160., 890.), vec2(220., 890.), vec2(280., 890.), vec2(100., 950.), vec2(160., 950.), vec2(220., 950.));
const float ZK[66] = float[66](-1.07, 1.54, -.46, .05, -1.43, 1.28, .03, -1.83, .66, -.06, .77, .35, .05, -1.20, 1.45, -1.66, 3.47, -1.78, .69, -2.76, 2.40, -.62, 3.28, 1.73, -6.78, -.06, .28, -2.17, 1.99, .56, 6.44, 1.33, -1.21, -.26, -.95, -.54, .07, .74, -1.83, -.54, -1.14, -.32, 5.74, -.66, 4.20, -.77, 3.97, .93, -3.50, -8.21, 6.86, 5.91, -5.64, 4.02, 1.00, -1.21, -.67, .20, -.06, -2.63, -.84, -.31, -3.48, -.04, 1.11, -7.39);
float zv(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 11; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.2178);
    float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }
      #define ZZ zv(p)`, 0.1, 0.14);

    // ── 9. ribbed blue hoses ──
    hose([-12, 186, 40, 180, 90, 168, 125, 140, 150, 100, 175, 62, 210, 46, 240, 58, 255, 95, 262, 132], 40, '#64bcf2', '#3a8ad8');
    R.dome(Q([248, 128, 268, 120, 296, 134, 312, 124, 300, 150, 270, 160, 250, 150]), '#6ac4f0', 0.3, 0.08, 8, 1);
    hose([-12, 524, 60, 510, 120, 512, 180, 532, 230, 570, 270, 620, 300, 680, 322, 718], 34, '#9ab8f6', '#4a6ce0');
    R.dome(Q([24, 252, 36, 262, 46, 258, 44, 276, 30, 282, 18, 274]), '#4a8ae8', 0.2, 0.06, 5, 1);

    // ── 10. cobalt blobs with white-blue frills ──
    const frill = new Path2D(); frill.addPath(P(blob(355, 724, 54, 50, 31, 26, 0.08))); frill.addPath(P(blob(480, 760, 76, 58, 32, 30, 0.07, 0.12))); frill.addPath(Q([360, 690, 420, 712, 430, 790, 380, 770], false));
    R.dome(frill, '#c4ccf4', 0.12, 0.06, 8, 1);
    clipA(frill, () => { a.strokeStyle = 'rgba(70,90,200,0.6)'; a.lineWidth = 1.8; for (let i = 0; i < 64; i++) { const t = i / 64 * 6.283; for (const [cx, cy, rx, ry] of [[355, 724, 56, 52], [480, 760, 78, 60]]) { a.beginPath(); a.moveTo(cx + Math.cos(t) * rx * 0.6, cy + Math.sin(t) * ry * 0.6); a.lineTo(cx + Math.cos(t) * rx, cy + Math.sin(t) * ry); a.stroke(); } } });
    R.dome(circleP(355, 726, 38), rg(345, 712, 4, 355, 726, 40, [[0, '#4a62ff'], [0.7, '#1a34f0'], [1, '#1428c0']]), 0.24, 0.24, 30, 7);
    R.dome(ellipseP(478, 762, 58, 42, 0.12), rg(465, 748, 6, 478, 762, 60, [[0, '#5a6cff'], [0.7, '#3446ea'], [1, '#2234c4']]), 0.24, 0.24, 36, 7);
    // mauve coral at right
    R.pipe(L([486, 900, 500, 868, 516, 842, 536, 818, 556, 796, 580, 776]), 26, '#b898a8', 0.1, 0.12, 1);
    R.pipe(L([520, 836, 540, 846, 560, 842, 580, 850]), 16, '#a88898', 0.1, 0.1, 1);
    R.pipe(L([500, 868, 486, 850, 480, 830, 492, 812]), 14, '#c0a0b0', 0.1, 0.1, 1);
    R.dome(Q([520, 680, 540, 670, 556, 690, 546, 704, 528, 700]), '#e0d0d8', 0.1, 0.06, 6, 1);
    // ── 11. glass bubbles and blue glints ──
    for (const [x, y, r] of [[60, 600, 28], [20, 745, 28], [104, 776, 14], [176, 820, 10], [226, 730, 9], [290, 820, 10], [130, 870, 4], [36, 640, 8], [84, 690, 10], [168, 640, 7],
      [252, 640, 6], [130, 610, 5], [430, 980, 13], [552, 238, 9], [70, 220, 8], [120, 448, 8], [130, 465, 6], [528, 950, 22], [300, 595, 6], [270, 470, 5], [470, 690, 6], [32, 436, 10], [56, 376, 9]])
      R.bead(x, y, r, rg(x - r * 0.3, y - r * 0.4, r * 0.1, x, y, r, [[0, 'rgba(240,244,255,0.9)'], [0.6, 'rgba(150,170,210,0.55)'], [1, 'rgba(220,226,240,0.8)']]), 0.36, Math.min(0.3, r * 0.03), 7);
    { const r = rng(9); for (let i = 0; i < 50; i++) { const x = r() * 578, y = 420 + r() * 600; R.bead(x, y, 1.5 + r() * 2.5, 'rgba(220,226,240,0.8)', 0.36, 0.03, 7); } }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 1.0, shin: 50, wrap: 0.4, ao: 0.3, coat: 0.2, rim: 0.2 }),                  // 1 glossy plastic
        E.mat({ dif: 1, spec: 0.4, shin: 25, wrap: 0.4, ao: 0.4 }),                                        // 2 sphere / ground
        E.mat({ dif: 0.9, spec: 1.3, shin: 60, wrap: 0.3, metal: 0.4, coat: 0.2 }),                        // 3 chrome lens
        E.mat({ dif: 0.8, spec: 0.7, shin: 40, wrap: 0.5, emis: 0.2 }),                                    // 4 zebra
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.5, ao: 0.5 }),                                        // 5 yarn / rocks
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.5, ao: 0.4 }),                                        // 6 knit
        E.mat({ dif: 0.9, spec: 1.6, shin: 90, wrap: 0.3, coat: 0.4 })                                     // 7 glass / gloss blobs
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.75, 0.75, 0.8], amb: [0.4, 0.4, 0.45],
      envTop: [1.05, 1.02, 1.0], envHor: [0.5, 0.55, 0.7], envBot: [0.12, 0.12, 0.25], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.25, 0.3, 0.6], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 80], shadow: [-5, 6, 0.5, 6]
    });
    // glowing lens ring and blue glints
    const gl = E.newCanvas(), gx = gl.getContext('2d'); gx.setTransform(S, 0, 0, S, 0, 0);
    gx.strokeStyle = '#fff4e0'; gx.lineWidth = 8; gx.beginPath(); gx.arc(C[0], C[1], 60, 0, 6.283); gx.stroke();
    for (const [x, y, r] of [[25, 270, 8], [530, 430, 8], [562, 595, 8], [415, 660, 7], [380, 890, 9], [78, 880, 6], [568, 800, 6], [484, 470, 6], [400, 560, 6], [420, 492, 5], [130, 875, 5], [520, 640, 6], [438, 586, 5], [340, 1000, 5], [570, 140, 6]])
      { gx.fillStyle = '#5a6cff'; gx.beginPath(); gx.arc(x, y, r, 0, 6.283); gx.fill(); gx.fillStyle = '#e8ecff'; gx.beginPath(); gx.arc(x, y, r * 0.45, 0, 6.283); gx.fill(); }
    E.draw(E.blur(gl, 6), 0.9, 'screen'); E.draw(E.blur(gl, 1.5), 0.8, 'screen');
  }
});
