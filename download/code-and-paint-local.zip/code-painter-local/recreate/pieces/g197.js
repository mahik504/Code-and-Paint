'use strict';
// g197 — "Lavender gadget, chrome eyes": a tilted lavender clay gadget with an engraved silver plate holding three
// chrome eye-rings, chrome beads and a zebra sleeve, over a flowing zebra cloth, light streaks and rust arcs.
REC.register('g197', {
  w: 1024, h: 726,
  draw(E) {
    const R = E.relief(), a = R.a, hx = R.h, S = E.S, o = E.out;
    const img = (cv, al = 1) => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = al; a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const clipB = (path, fn) => { a.save(); hx.save(); a.clip(path); hx.clip(path); fn(); hx.restore(); a.restore(); };
    const soft = (fn, blur, al = 1, op) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = al; if (op) a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const rad = (x, y, r0, r, st, ctx = a) => { const g = ctx.createRadialGradient(x, y, r0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const lin = (x0, y0, x1, y1, st, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const line = (pts, w, c, ctx = a) => { ctx.lineWidth = w; ctx.strokeStyle = c; ctx.stroke(P(pts, false, true)); };
    const rot = (cx, cy, ang, fn) => { a.save(); hx.save(); for (const c of [a, hx]) { c.translate(cx, cy); c.rotate(ang); c.translate(-cx, -cy); } fn(); hx.restore(); a.restore(); };

    // ── 1. background gradient mesh (fitted control colours) ──
    const BGH = '30377f3d439d4a4fb25556b95d59b96156a76457876756656c4b4a2f38753d3f98464bab4f50a65a56a7655ca4655c856b4c567941382e55753c508f3e4690464888514a825c4e7c634a68743f3e8d3c251c3e493062782f4b6d3b4065483d5f543b535d353e7d3626a03c1a131a20131f27182933302f424030414e2d3463291f87321b9b37170f1015100f121c1c232c252f39262e442322501e11662516802a131111161513181e1b212b20273522263d1f1e3f1a13521d12652010';
    const v3 = []; for (let i = 0; i < BGH.length; i += 6) v3.push(`vec3(${[0, 2, 4].map(k => (parseInt(BGH.substr(i + k, 2), 16) / 255).toFixed(3)).join(',')})`);
    img(E.fx(`const vec3 BG[63] = vec3[63](${v3.join(',')});
      vec3 fx(vec2 uv, vec2 p){ float u = clamp(p.x / 1023. * 8., 0., 7.999), v = clamp(p.y / 725. * 6., 0., 5.999);
        int i = int(u), j = int(v); float fu = u - float(i), fv = v - float(j);
        vec3 c = mix(mix(BG[j * 9 + i], BG[j * 9 + i + 1], fu), mix(BG[(j + 1) * 9 + i], BG[(j + 1) * 9 + i + 1], fu), fv);
        float st = smoothstep(0.6, 1., vnoise(vec2(p.x * .01, p.y * .35))) * smoothstep(330., 120., abs(p.y - 250.)) * smoothstep(260., 0., p.x);
        return c + vec3(.05, .16, .17) * st + (hash(p * .71) - .5) * .025; }`));

    // light streaks
    const S1 = [[-10, 238], [30, 246], [60, 257], [100, 269], [140, 275], [190, 278], [230, 280]];
    soft(x => { line(S1, 34, 'rgba(40,190,200,0.55)', x); }, 14);
    soft(x => { line(S1, 9, 'rgba(120,240,240,0.9)', x); }, 3);
    soft(x => { x.lineWidth = 7; x.strokeStyle = lin(0, 0, 220, 0, [[0, '#ffffff'], [0.55, '#f0ffff'], [1, 'rgba(160,220,230,0)']], x); x.stroke(P(S1, false, true)); }, 1);
    const S2 = [[612, 170], [660, 141], [700, 118], [740, 93], [780, 63], [820, 32], [865, -5]];
    soft(x => { line(S2, 40, 'rgba(90,200,215,0.5)', x); }, 16);
    soft(x => { line(S2, 12, 'rgba(170,240,245,0.9)', x); }, 4);
    soft(x => { x.lineWidth = 5; x.strokeStyle = lin(612, 172, 865, 0, [[0, 'rgba(255,255,255,0.3)'], [0.5, '#ffffff'], [1, '#ffffff']], x); x.stroke(P(S2, false, true)); }, 1);

    // rust arcs, bottom right
    const BANDS = [
      [[[700, 740], [720, 710], [757, 660], [800, 605], [840, 560], [880, 520], [920, 488], [960, 465], [1000, 446], [1030, 435]], 50, 1],
      [[[862, 740], [873, 710], [896, 660], [920, 630], [960, 562], [1000, 522], [1030, 492]], 72, 1],
      [[[1000, 740], [1018, 690], [1035, 650]], 60, 1],
      [[[760, 560], [800, 520], [840, 490], [880, 462], [920, 440], [970, 422], [1030, 405]], 20, 0.4],
      [[[650, 690], [662, 650], [686, 600], [720, 550]], 10, 0.35]];
    for (const [pts, w, al] of BANDS) soft(x => {
      x.lineWidth = w; x.strokeStyle = lin(700, 726, 1024, 420, [[0, `rgba(238,212,196,${al})`], [0.45, `rgba(232,190,165,${al * 0.95})`], [1, `rgba(215,120,80,${al * 0.45})`]], x);
      x.stroke(P(pts, false, true));
      x.lineWidth = 1; x.strokeStyle = `rgba(120,50,30,${al * 0.25})`; for (let k = -w / 2 + 4; k < w / 2; k += 5) { x.save(); x.translate(k * 0.8, -k * 0.6); x.stroke(P(pts, false, true)); x.restore(); }
    }, 1.5);

    // ── 2. zebra cloth (fitted stripe phase field) ──
    const CLOTH = P([[0, 722], [15, 705], [30, 684], [50, 660], [75, 628], [100, 600], [130, 576], [165, 560], [200, 547], [250, 537], [300, 520], [350, 503], [400, 488], [420, 478], [680, 470], [700, 555], [705, 600], [690, 650], [665, 700], [650, 730], [0, 730]], true, true);
    const CLC = E.fx(`const float CLC[96] = float[96](-0.679,-0.576,-0.522,-0.234,0.313,1.415,2.398,4.674,5.721,5.185,3.949,2.561,-0.030,0.544,0.497,-0.811,-0.447,1.198,-0.701,3.233,3.895,4.516,4.541,4.185,0.229,0.987,1.559,-1.815,-0.314,-1.141,0.068,-0.539,0.510,3.707,4.955,5.308,0.024,-0.127,-1.092,-0.461,-0.368,0.193,0.428,1.074,1.703,1.594,4.481,5.342,-0.693,-1.131,-0.670,-0.226,0.203,0.558,1.055,1.431,1.934,2.607,2.407,4.309,-1.178,-0.760,-0.404,-0.010,0.479,0.954,1.367,1.830,2.283,2.555,3.134,4.122,-1.762,-0.597,-0.326,0.242,0.666,1.135,1.605,2.009,2.432,2.989,4.102,4.543,-2.873,-2.153,-0.883,-0.176,0.330,0.875,1.716,2.131,2.632,2.511,3.708,4.932);
float cl(vec2 p){ vec2 u = clamp((p - vec2(0.0, 440.0)) / vec2(80.0000, 57.2000), vec2(0.), vec2(8.999, 4.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  float f = 0.;
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += CLC[(i.y + b) * 12 + i.x + a] * bx[a] * by[b];
  return f; }
      vec3 fx(vec2 uv, vec2 p){ float c = cos(6.2832 * cl(p));
        return mix(vec3(0.045, 0.04, 0.045), vec3(0.95, 0.93, 0.9), smoothstep(-0.12, 0.12, c)); }`);
    clipB(CLOTH, () => { img(CLC); R.dome(CLOTH, null, 0.02, 0.05, 12, 1); });
    line([[700, 555], [705, 600], [690, 650], [665, 700], [650, 730]], 5, 'rgba(235,190,180,0.8)');
    line([[15, 705], [30, 684], [50, 660], [75, 628], [100, 600], [130, 576], [165, 560], [200, 547], [250, 537], [300, 520], [350, 503], [400, 488]], 2.5, 'rgba(140,150,170,0.7)');

    // left bead stick
    R.pipe(P([[96, 410], [180, 468], [268, 528]], false), 9, '#e8e4e0', 0.1, 0.06, 5);
    a.save(); a.setLineDash([7, 9]); line([[196, 478], [268, 528]], 10, '#141214'); a.restore();
    R.bead(180, 466, 15, '#f2eee8', 0.12, 0.12, 5); R.bead(126, 430, 7, '#9a9aa2', 0.12, 0.08, 3);

    // ── 3. lavender pen ──
    R.pipe(P([[312, 42], [352, 95], [388, 140]], false), 42, '#8e8ce0', 0.1, 0.25, 2);
    R.pipe(P([[355, 102], [372, 122]], false), 46, '#c8d4e4', 0.12, 0.27, 3);
    R.pipe(P([[372, 122], [392, 146]], false), 34, '#e0e4ea', 0.12, 0.25, 3);
    a.fillStyle = '#1a1830'; a.fill(ellipseP(346, 92, 5, 3, 0.9));

    // ── 4. lavender gadget slab ──
    const DEV = P([[315, 185], [327, 160], [408, 126], [440, 108], [485, 82], [506, 70], [522, 66], [536, 72], [552, 96], [600, 158], [624, 192], [650, 228], [662, 250], [600, 300], [469, 347], [431, 343], [385, 328], [354, 305], [331, 266], [315, 220]], true, true);
    soft(x => { x.fillStyle = 'rgba(20,16,60,0.6)'; x.translate(10, 14); x.fill(DEV); }, 12);
    R.dome(DEV, '#8280d8', 0.12, 0.07, 14, 2);
    clipA(DEV, () => { a.fillStyle = lin(330, 340, 600, 80, [[0, 'rgba(90,92,200,0.45)'], [0.5, 'rgba(140,135,225,0)'], [1, 'rgba(185,170,235,0.5)']]); a.fill(DEV); });
    R.pipe(P([[318, 205], [327, 162], [408, 128], [440, 110], [485, 84], [506, 72], [522, 68], [536, 74], [552, 97], [600, 158], [626, 194]], false), 7, '#d6d0f4', 0.19, 0.03, 2);
    // face: two eyes, two bars, teeth
    rot(457, 183, -0.5, () => R.dome(ellipseP(457, 183, 28, 34, 0), '#9a90e4', 0.19, 0.16, 18, 2));
    rot(512, 150, -0.45, () => R.dome(ellipseP(512, 150, 30, 38, 0), '#a096e6', 0.19, 0.16, 18, 2));
    R.pipe(P([[452, 245], [512, 212], [572, 177]], false), 26, '#9a90e2', 0.19, 0.14, 2);
    R.pipe(P([[474, 266], [530, 240], [585, 212]], false), 22, '#968ce0', 0.19, 0.12, 2);
    rot(520, 232, -0.5, () => { R.flat(rrect(478, 225, 86, 14, 3), '#3a3460', 0.22, 2); for (let i = 0; i < 6; i++) R.dome(rrect(481 + i * 14, 226, 10, 11, 2), '#c8c6e4', 0.26, 0.02, 2, 2); });
    { const r = rng(197); a.lineCap = 'round';
      for (let k = 0; k < 16; k++) { let x = 340 + r() * 280, y = 120 + r() * 200, ang = r() * 6.28; const pts = [[x, y]];
        for (let s = 0; s < 6; s++) { ang += (r() - 0.5) * 1.6; x += Math.cos(ang) * 12; y += Math.sin(ang) * 12; pts.push([x, y]); }
        clipB(DEV, () => R.pipe(P(pts, false, true), 4, '#a49ae4', 0.19, 0.025, 2)); } }
    R.bead(442, 226, 8, '#c8c8d4', 0.22, 0.08, 3);
    // right lavender tab
    rot(738, 262, 0.55, () => { R.dome(rrect(690, 215, 96, 92, 26), '#b49ae0', 0.08, 0.1, 14, 2); });

    // ── 5. zebra sleeve, black rod, chrome capsule and beads ──
    const ARM = [[296, 276], [322, 318], [360, 352], [404, 386], [446, 420]];
    R.pipe(P(ARM, false, true), 68, '#f2eeea', 0.12, 0.16, 1);
    a.save(); a.setLineDash([16, 18]); a.lineCap = 'butt'; line(ARM, 68, '#0e0c0e'); a.restore();
    R.pipe(P([[222, 307], [262, 322], [300, 338]], false), 34, '#141216', 0.12, 0.16, 3);
    R.pipe(P([[222, 307], [232, 311]], false), 36, '#d8dce4', 0.14, 0.17, 3);
    rot(282, 238, 1.1, () => R.dome(ellipseP(282, 238, 46, 32, 0), '#eceef4', 0.14, 0.24, 30, 3));
    R.pipe(P([[292, 262], [318, 284]], false), 38, '#e6e8ee', 0.16, 0.2, 3);
    for (const [x, y, r] of [[300, 352, 29], [340, 400, 35], [366, 440, 21]]) R.bead(x, y, r, '#eceef4', 0.18, 0.3, 3);

    // ── 6. engraved silver plate with three chrome eye-rings ──
    const PL = P([[423, 343], [454, 331], [523, 289], [585, 258], [631, 243], [677, 243], [723, 251], [754, 282], [762, 343], [758, 405], [731, 451], [662, 474], [546, 489], [454, 489], [423, 474], [415, 420], [419, 366]], true, true);
    soft(x => { x.fillStyle = 'rgba(20,10,30,0.6)'; x.translate(8, 12); x.fill(PL); }, 8);
    R.dome(PL, '#bcaeae', 0.24, 0.06, 12, 4);
    clipA(PL, () => { a.fillStyle = lin(430, 300, 700, 480, [[0, 'rgba(150,160,215,0.45)'], [0.5, 'rgba(190,180,185,0)'], [1, 'rgba(210,170,150,0.35)']]); a.fill(PL); });
    { const r = rng(1197);
      clipB(PL, () => { for (let k = 0; k < 120; k++) { let x = 420 + r() * 345, y = 245 + r() * 245; const pts = [[x, y]];
        for (let s = 0; s < 4; s++) { if (r() < 0.5) x += (r() < 0.5 ? -1 : 1) * (6 + r() * 14); else y += (r() < 0.5 ? -1 : 1) * (6 + r() * 14); pts.push([x, y]); }
        R.groove(P(pts, false, false), 2.2, '#8a8088', 0.3, 0.02, 4, 0.7); } }); }
    R.pipe(PL, 4, '#e2dee2', 0.3, 0.02, 4);
    rot(575, 315, -0.4, () => R.dome(ellipseP(575, 315, 26, 10, 0), '#eef6fc', 0.31, 0.04, 6, 5));
    for (const [x, y] of [[469, 410], [569, 381], [665, 337]]) {
      soft(c => { c.fillStyle = 'rgba(10,6,10,0.7)'; c.fill(circleP(x + 5, y + 7, 48)); }, 5);
      R.dome(circleP(x, y, 47), '#f0f0f4', 0.34, 0.12, 12, 3);
      R.dome(circleP(x, y, 35), '#08080b', 0.36, 0.02, 3, 3);
      R.dome(circleP(x, y, 31), '#c8c4cc', 0.38, 0.06, 4, 3);
      R.bead(x, y, 26, '#f2f0f2', 0.4, 0.26, 3);
    }
    // white knob and striped pins
    rot(748, 424, -0.5, () => R.dome(rrect(712, 398, 74, 52, 22), '#f2ebe6', 0.3, 0.12, 16, 5));
    for (const [pts, w] of [[[[666, 186], [684, 222], [700, 262]], 10], [[[684, 452], [698, 474], [712, 494]], 10]]) {
      R.pipe(P(pts, false), w, '#f0eeea', 0.3, 0.06, 5);
      a.save(); a.setLineDash([5, 5]); line(pts, w, '#141216'); a.restore();
    }

    // bubbles
    for (const [x, y, r] of [[577, 85, 10], [432, 62, 4], [685, 28, 6], [630, 128, 3], [760, 186, 7], [262, 178, 7], [78, 228, 7], [186, 297, 4], [213, 408, 8],
      [295, 477, 10], [160, 518, 8], [82, 598, 14], [815, 407, 15], [870, 290, 6], [753, 572, 8], [818, 676, 6], [805, 345, 3]]) R.bead(x, y, r, '#b8bcc8', 0.2, Math.min(0.3, r * 0.03), 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.12, shin: 30, wrap: 0.5, ao: 0.3 }),                                     // 1 zebra cloth / sleeve
        E.mat({ dif: 1, spec: 0.3, shin: 25, wrap: 0.55, ao: 0.4, rim: 0.3 }),                           // 2 lavender clay
        E.mat({ dif: 0.25, spec: 1.3, shin: 90, metal: 0.85, ao: 0.3, rim: 0.3 }),                       // 3 chrome
        E.mat({ dif: 1, spec: 0.35, shin: 30, wrap: 0.45, ao: 0.6, grain: 0.3 }),                        // 4 engraved silver
        E.mat({ dif: 1, spec: 0.5, shin: 40, wrap: 0.5, ao: 0.3 })                                       // 5 white plastic
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.78, 0.78, 0.8], amb: [0.32, 0.32, 0.36],
      envTop: [1.6, 1.6, 1.65], envHor: [0.62, 0.56, 0.66], envBot: [0.1, 0.08, 0.12], envK: [0.45, 2.0, 0.25, 0],
      rimC: [0.3, 0.5, 0.7], rimD: [-1, 0.3, 0.5], r1: 2.2, r2: 8, k: [0, 0.6, 0.4, 80], shadow: [-6, 6, 0.45, 6]
    });
    E.bloom(0.1, 10);
    E.grain(0.035, 197);
  }
});
