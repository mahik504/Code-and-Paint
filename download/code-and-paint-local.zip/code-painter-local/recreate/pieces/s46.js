'use strict';
// s46 — "Hypno machine": black-and-white hypnotic spirals behind a lavender-grey plastic
// machine (portal ring with a blue eye and chrome ball, blob sculpture, stairs, oval
// porthole, painted screen), liquid chrome on blue, a starburst, a rainbow card and an osprey.
REC.register('s46', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const scallop = (pts, len, amp) => {
      const out = [], n = pts.length; let acc = 0;
      for (let i = 0; i < n; i++) {
        const p0 = pts[i], p1 = pts[(i + 1) % n], L = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]) || 1, k = Math.max(1, Math.round(L / 2));
        const nx = (p1[1] - p0[1]) / L, ny = -(p1[0] - p0[0]) / L;
        for (let j = 0; j < k; j++) { const u = j / k, d = amp * Math.abs(Math.sin(Math.PI * (acc + L * u) / len)); out.push([p0[0] + (p1[0] - p0[0]) * u - nx * d, p0[1] + (p1[1] - p0[1]) * u - ny * d]); }
        acc += L;
      }
      return out;
    };
    const GREY = '#b6b6c2';

    // ── op-art spirals (flat) ──
    const op = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 C[3]; C[0] = vec2(425., 382.); C[1] = vec2(29., 640.); C[2] = vec2(-90., 470.);
      float Pd[3]; Pd[0] = 20.; Pd[1] = 11.; Pd[2] = 13.;
      float Bs[3]; Bs[0] = 0.; Bs[1] = 150.; Bs[2] = 170.;
      float best = 1e9, ph = 0.;
      for (int i = 0; i < 3; i++) {
        vec2 d = p - C[i]; float r = length(d), a = atan(d.y, d.x);
        float sc = r - Bs[i] * 0. + (i == 0 ? 0. : (i == 1 ? 60. : 150.));
        if (sc < best) { best = sc; ph = r / Pd[i] + (i == 2 ? 0. : a / 6.2832); }
      }
      float s = sin(6.2832 * ph);
      return vec3(smoothstep(-0.15, 0.15, s)) * 0.94 + 0.02; }`);
    R.flat(rrect(-10, -10, 746, 1044, 0), '#ffffff', 0, 0);
    img(op);

    // ── top-left: blue sky, liquid chrome, rainbow wedge ──
    const blue = P([[-10, -10], [352, -10], [352, 196], [300, 170], [240, 162], [200, 180], [-10, 180]], true, false);
    R.flat(blue, '#121ce4', 0.02, 0);
    R.flat(P([[44, 58], [70, 0], [140, 0], [100, 40], [70, 64]], true, false), '#f0f0f0', 0.04, 0);
    clipA(P([[44, 58], [70, 0], [140, 0], [100, 40], [70, 64]], true, false), () => {
      const cols = ['#f02020', '#f08020', '#f8e020', '#40d040', '#2080f0', '#8040d0'];
      cols.forEach((c, i) => { a.fillStyle = c; a.fill(P([[20 + i * 16, 80], [60 + i * 16, -10], [76 + i * 16, -10], [36 + i * 16, 80]], true, false)); });
    });
    // chrome rim arc + icicles
    R.pipe(P([[-10, 124], [60, 106], [130, 80], [200, 46], [260, 16], [300, -10]], false), 30, '#f0f0f2', 0.2, 0.2, 7);
    for (const [x, y, L] of [[80, 98, 24], [120, 84, 30], [150, 70, 22], [175, 56, 34], [215, 38, 16]]) R.dome(P([[x - 4, y], [x, y - L], [x + 4, y]], true, false), '#f0f0f2', 0.2, 0.1, 3, 7);
    // chrome blob
    const cb = P([[-10, 104], [60, 122], [140, 122], [200, 104], [232, 120], [240, 170], [228, 230], [238, 280], [222, 314], [170, 318], [110, 302], [40, 252], [-10, 238]]);
    R.dome(cb, '#f2f2f4', 0.1, 0.4, 44, 7);
    clipA(cb, () => soft(x => {
      fe(x, 60, 170, 110, 50, 0, '#ffffff'); fe(x, 206, 236, 30, 70, 0.2, '#101012'); fe(x, 150, 296, 70, 16, -0.2, '#3a3a3e'); fe(x, 10, 236, 30, 16, 0, '#6a6a70');
      fe(x, 120, 200, 60, 30, 0.3, '#eeeeee'); fe(x, 226, 150, 12, 26, 0, '#1a1a1c');
    }, 10, 0.9));
    R.bead(289, 114, 15, '#d8d8e0', 0.1, 0.2, 7);

    // ── top-right: starfield, starburst, spiral disc ──
    const night = P([[352, -10], [736, -10], [736, 262], [548, 268], [520, 262], [352, 262]], true, false);
    R.flat(night, '#0a0a0c', 0.02, 0);
    clipA(night, () => {
      const r = rng(46); a.fillStyle = '#fff';
      for (let i = 0; i < 700; i++) { a.globalAlpha = 0.4 + r() * 0.6; a.beginPath(); a.arc(352 + r() * 380, r() * 270, 0.4 + Math.pow(r(), 3) * 1.8, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
      const sp = rng(7); a.fillStyle = '#ffffff';
      for (let i = 0; i < 46; i++) { const t = i / 46 * 6.283 + sp() * 0.1, up = Math.max(0, -Math.sin(t)), L = 80 + sp() * 70 + up * 60, w = 0.06 + sp() * 0.06;
        a.fill(P([[480 + Math.cos(t - w) * 36, 140 + Math.sin(t - w) * 30], [480 + Math.cos(t) * L, 140 + Math.sin(t) * L * 0.85], [480 + Math.cos(t + w) * 36, 140 + Math.sin(t + w) * 30]], true, false)); }
      soft(x => { fe(x, 482, 146, 80, 64, 0, '#ffffff'); }, 12, 1);
      soft(x => { fe(x, 482, 160, 150, 100, 0, '#ffffff'); }, 30, 0.55);
    });
    const disc = E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 d = p - vec2(650., 61.); float r = length(d), a = atan(d.y, d.x);
      float s = sin(6.2832 * (r / 8.5 + a / 6.2832)); return vec3(smoothstep(-0.2, 0.2, s)) * 0.95 + 0.03; }`);
    clipA(circleP(650, 61, 58), () => img(disc));
    // stamp edge between blue and night
    R.flat(P(scallop([[352, -10], [352, 210]], 18, 7).concat([[340, 210], [340, -10]]), true, false), '#9a9aa2', 0.1, 3);

    // ── rainbow card with waveform ──
    const card = [[282, 211], [507, 182], [511, 282], [276, 298]];
    R.flat(P([[276, 298], [511, 282], [511, 290], [278, 306]], true, false), '#7a7a82', 0.1, 3);
    R.flat(P(card, true, false), '#fff', 0.14, 4);
    clipA(P(card, true, false), () => {
      const cols = ['#0a70f2', '#8a28d4', '#f00808', '#f46a14', '#f8a810', '#f6ec10'];
      cols.forEach((c, i) => { const x0 = 278 + i * 39.5; a.fillStyle = c; a.fill(P([[x0, 150], [x0 + 40, 150], [x0 + 40, 320], [x0, 320]], true, false)); });
      a.strokeStyle = '#141414'; a.lineWidth = 1.4; const w = rng(3), pts = [];
      for (let x = 280; x <= 505; x += 3) { const base = 283 - (x - 280) * 0.07; const spike = (x % 60 < 6) ? -24 * w() : (w() - 0.5) * 3; pts.push([x, base + spike]); }
      a.stroke(P(pts, false, false));
    });

    // ── osprey ──
    R.dome(P([[560, 186], [610, 160], [680, 140], [726, 120], [726, 260], [680, 262], [620, 256], [580, 240]]), '#3a3638', 0.1, 0.2, 20, 5);
    clipA(P([[600, 160], [726, 110], [726, 262], [600, 262]]), () => { a.strokeStyle = 'rgba(160,150,150,0.5)'; a.lineWidth = 2; for (let i = 0; i < 14; i++) { a.beginPath(); a.moveTo(600 + i * 9, 250); a.quadraticCurveTo(640 + i * 7, 200, 700 + i * 4, 140); a.stroke(); } });
    R.dome(P([[528, 196], [546, 178], [576, 170], [604, 178], [616, 204], [606, 238], [584, 252], [556, 248], [534, 232]]), '#e8e4e0', 0.14, 0.2, 18, 5);
    R.paint(P([[536, 190], [556, 176], [590, 172], [606, 184], [600, 196], [572, 196], [548, 204]]), '#6a6060');
    R.paint(P([[560, 196], [600, 190], [616, 204], [590, 212]]), '#4a4040');
    R.dome(P([[534, 196], [510, 202], [506, 222], [516, 232], [520, 216], [540, 212]]), '#2c2a2a', 0.2, 0.08, 5, 5);
    R.bead(560, 188, 5, '#e8c040', 0.3, 0.05, 5); R.bead(560, 188, 2.5, '#101010', 0.34, 0.02, 0);

    // ── grey mottled panel with the black snowflake ──
    const gp = P(scallop([[552, 268], [726, 262], [736, 262], [736, 600], [560, 590], [556, 430]], 22, 8), true, false);
    R.dome(gp, '#a8a8a8', 0.08, 0.06, 6, 3);
    clipA(gp, () => soft(x => { const r = rng(9); for (let i = 0; i < 40; i++) fe(x, 560 + r() * 170, 270 + r() * 330, 10 + r() * 26, 8 + r() * 20, r() * 3, r() < 0.5 ? '#c8c8c8' : '#8a8a8a'); }, 6, 0.8));
    const flake = (cx, cy, sc) => { a.fillStyle = '#121212';
      for (let k = 0; k < 6; k++) { const t = k / 6 * 6.283 + 0.3; a.save(); a.translate(cx, cy); a.rotate(t);
        a.fillRect(0, -4 * sc, 58 * sc, 8 * sc); for (const u of [16, 30, 44]) { a.fillRect(u * sc, -12 * sc, 7 * sc, 24 * sc); } a.restore(); } };
    clipA(gp, () => { flake(622, 440, 1); flake(716, 432, 0.7); });

    // ── portal ring ──
    R.dome(ellipseP(256, 467, 136, 132, 0), GREY, 0.12, 0.22, 20, 1);
    R.flat(circleP(262, 465, 102), '#3a3a40', 0.08, 0);
    const tun = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float lo = 0., hi = 1.;
      for (int i = 0; i < 20; i++) { float m = 0.5 * (lo + hi); vec2 c = mix(vec2(300., 493.), vec2(262., 465.), m); float rr = mix(40., 100., m); if (length(p - c) > rr) lo = m; else hi = m; }
      float t = 0.5 * (lo + hi); float s = sin(6.2832 * (t * 4.2));
      return vec3(smoothstep(-0.2, 0.2, s)) * 0.9 + 0.05; }`);
    clipA(circleP(262, 465, 92), () => img(tun));
    R.dome(ellipseP(300, 493, 38, 46, 0), '#1430e0', 0.14, 0.04, 6, 6);
    R.bead(302, 498, 12, '#d0d0d8', 0.2, 0.16, 2);
    R.groove(circleP(262, 465, 96), 8, '#606068', 0.3, 0.05, 1, 0.6);
    // bracket up to the card
    R.pipe(P([[292, 300], [292, 336]], false), 26, GREY, 0.2, 0.14, 1);
    R.pipe(P([[318, 300], [318, 350], [330, 362]], false), 12, GREY, 0.24, 0.1, 1);
    R.dome(rrect(250, 316, 90, 26, 6), GREY, 0.2, 0.12, 8, 1);

    // ── blob sculpture ──
    R.dome(P([[100, 452], [132, 440], [160, 462], [150, 492], [124, 500], [130, 530], [160, 548], [150, 576], [110, 582], [80, 560], [76, 520], [84, 480]]), GREY, 0.14, 0.24, 14, 1);
    R.dome(P([[152, 520], [200, 506], [250, 510], [290, 534], [300, 580], [280, 610], [230, 614], [180, 604], [150, 580]]), GREY, 0.14, 0.26, 18, 1);
    R.flat(circleP(210, 561, 9), '#34343a', 0.2, 0); R.flat(circleP(172, 536, 4), '#44444a', 0.3, 0);
    R.dome(P([[150, 600], [200, 596], [240, 612], [270, 640], [250, 668], [200, 672], [160, 650]]), GREY, 0.14, 0.22, 14, 1);
    R.dome(P([[180, 640], [210, 640], [214, 700], [182, 704]]), GREY, 0.12, 0.18, 10, 1);

    // ── robot head ──
    R.pipe(P([[508, 480], [488, 432]], false), 7, GREY, 0.2, 0.08, 2);
    R.bead(486, 430, 7, GREY, 0.2, 0.08, 2);
    R.dome(ellipseP(532, 546, 46, 48, 0), '#1a1a1e', 0.14, 0.34, 30, 5);
    R.dome(circleP(516, 526, 17), '#8a8a92', 0.4, 0.06, 5, 2);
    R.dome(circleP(516, 526, 12), '#88dcef', 0.44, 0.04, 6, 6);
    R.pipe(P([[564, 510], [578, 540], [570, 572]], false), 8, '#9a9aa2', 0.4, 0.06, 2);

    // ── machine deck ──
    const deck = P([[-10, 746], [214, 700], [500, 606], [736, 536], [736, 918], [493, 918], [493, 942], [-10, 942]], true, false);
    R.dome(deck, GREY, 0.06, 0.2, 8, 1);
    R.flat(P([[-10, 752], [493, 752], [493, 942], [-10, 942]], true, false), '#9898a8', 0.2, 1);
    R.flat(P([[493, 600], [736, 540], [736, 918], [493, 918]], true, false), '#80808c', 0.2, 1);
    R.flat(P([[0, 746], [214, 702], [500, 610], [493, 752], [0, 752]], true, false), '#acacba', 0.24, 1);
    clipA(P([[0, 746], [214, 702], [500, 610], [493, 752], [0, 752]], true, false), () => { a.strokeStyle = 'rgba(80,80,90,0.35)'; a.lineWidth = 1; for (let i = 0; i < 30; i++) { a.beginPath(); a.moveTo(20 + i * 16, 752); a.lineTo(170 + i * 12, 680); a.stroke(); } });
    // blade edge
    R.pipe(P([[190, 760], [300, 700], [420, 660], [520, 630]], false), 8, '#d0d0da', 0.3, 0.06, 1);
    // red scribble
    a.save(); a.strokeStyle = '#e02818'; a.lineWidth = 1.8; a.stroke(P([[236, 690], [270, 700], [300, 684], [330, 690], [360, 662], [400, 668], [420, 640], [440, 648], [457, 622]], false, false)); a.restore();
    // "4"/"F" posts
    R.dome(P([[376, 480], [400, 480], [400, 540], [440, 540], [440, 480], [468, 480], [468, 560], [440, 560], [440, 640], [410, 640], [410, 560], [376, 560]], true, false), GREY, 0.2, 0.14, 6, 1);
    R.dome(P([[420, 650], [504, 650], [504, 700], [480, 700], [480, 750], [456, 750], [456, 700], [420, 700]], true, false), GREY, 0.3, 0.14, 6, 1);
    // screen
    R.dome(rrect(62, 772, 250, 150, 6), '#6a6a74', 0.24, 0.06, 4, 1);
    R.flat(rrect(86, 778, 208, 128, 3), '#e8e8f0', 0.3, 1);
    R.flat(rrect(92, 784, 196, 116, 2), '#0a0a12', 0.32, 0);
    clipA(rrect(92, 784, 196, 116, 2), () => {
      const g = a.createLinearGradient(0, 784, 0, 850); g.addColorStop(0, '#3a6ad0'); g.addColorStop(1, '#7aa0e8'); a.fillStyle = g;
      a.fill(P([[92, 784], [288, 784], [288, 812], [240, 806], [180, 820], [120, 846], [92, 860]], true, true));
      a.strokeStyle = '#101830'; a.lineWidth = 2; for (let i = 0; i < 6; i++) { a.beginPath(); a.moveTo(100 + i * 20, 880); a.quadraticCurveTo(150 + i * 10, 800, 288, 792 + i * 6); a.stroke(); }
      const r = rng(5); a.fillStyle = '#e04020'; for (let i = 0; i < 30; i++) a.fill(circleP(180 + r() * 110, 846 + r() * 54, 4 + r() * 8));
      a.strokeStyle = '#e04020'; a.lineWidth = 2; a.stroke(P([[110, 890], [130, 860], [150, 866], [170, 846]], false, false));
    });
    R.dome(rrect(50, 798, 20, 44, 3), '#8a8a94', 0.3, 0.06, 4, 1);
    R.dome(circleP(4, 815, 24), '#c02a1a', 0.3, 0.08, 6, 1); R.dome(circleP(4, 815, 14), '#e8e0dc', 0.34, 0.04, 4, 1);
    clipA(rrect(-10, 869, 40, 50, 0), () => { a.fillStyle = '#50505a'; for (let y = 872; y < 918; y += 6) a.fillRect(0, y, 28, 3); });
    // stairs
    R.dome(P([[346, 942], [346, 902], [382, 902], [382, 868], [418, 868], [418, 836], [454, 836], [454, 806], [493, 806], [493, 942]], true, false), '#9a9aaa', 0.3, 0.1, 4, 1);
    for (const [x, y] of [[346, 902], [382, 868], [418, 836], [454, 806]]) R.flat(rrect(x, y, 36, 8, 1), '#c8c8d6', 0.42, 1);
    // porthole
    R.dome(ellipseP(621, 783, 84, 120, 0), '#a8a8b4', 0.24, 0.12, 8, 1);
    R.flat(ellipseP(621, 783, 62, 96, 0), '#3a3a42', 0.2, 0);
    R.dome(ellipseP(640, 783, 56, 90, 0), '#9c9ca8', 0.26, 0.12, 20, 1);
    R.bead(680, 628, 10, '#9a9aa8', 0.3, 0.06, 1); R.bead(706, 690, 12, '#9a9aa8', 0.3, 0.06, 1);
    // tread band
    R.flat(rrect(493, 900, 243, 26, 0), '#0e0e10', 0.1, 0);
    clipA(rrect(493, 900, 243, 26, 0), () => { a.strokeStyle = '#6a6a70'; a.lineWidth = 2; for (let x = 493; x < 740; x += 8) { a.beginPath(); a.moveTo(x, 906); a.lineTo(x + 4, 913); a.lineTo(x, 920); a.stroke(); } });

    // ── zebra floor ──
    const flo = E.fx(`vec3 fx(vec2 uv, vec2 p){ float y = p.y + 3. * sin(p.x * 0.025 + p.y * 0.05) + 1.5 * sin(p.x * 0.07);
      float per = 7.5; float s = sin(6.2832 * y / per);
      float v = smoothstep(-0.2, 0.2, s); v = max(v, smoothstep(985., 1000., p.y));
      return vec3(v) * 0.95 + 0.03; }`);
    const floorP = rrect(-10, 940, 746, 110, 0);
    R.flat(floorP, null, 0.02, 0); clipA(floorP, () => img(flo));

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.55, shin: 30, wrap: 0.4, ao: 0.8, coat: 0.12 }),              // 1 lavender-grey plastic
        E.mat({ metal: 1, spec: 1.0, shin: 70, rim: 0.2, ao: 0.4 }),                        // 2 chrome
        E.mat({ dif: 1, spec: 0.1, shin: 10, wrap: 0.5, grain: 0.1 }),                      // 3 mottled panel / stamp
        E.mat({ dif: 1, spec: 0.2, shin: 20, wrap: 0.5 }),                                  // 4 card
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.4, grain: 0.1 }),                      // 5 bird / robot
        E.mat({ dif: 1, spec: 1.1, shin: 60, wrap: 0.3, coat: 0.2, emis: 0.2 }),             // 6 blue gloss
        E.mat({ dif: 1, spec: 1.2, shin: 80, wrap: 0.4, coat: 0.25, emis: 0.15 })             // 7 bright chrome (painted)
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.62, 0.62, 0.66], amb: [0.4, 0.4, 0.44],
      envTop: [1.1, 1.1, 1.12], envHor: [0.5, 0.5, 0.55], envBot: [0.05, 0.05, 0.06], envK: [0.4, 1.2, 0.4, 0],
      rimC: [0.1, 0.1, 0.12], rimD: [0, 1, 0], r1: 1.5, r2: 6, k: [0, 0.6, 0.4, 110], shadow: [-6, 8, 0.6, 6]
    });
    E.grain(0.04, 46);
  }
});
