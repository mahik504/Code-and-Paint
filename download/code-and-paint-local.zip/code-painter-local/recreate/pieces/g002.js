'use strict';
// g002 — "Clay nose in zebra cream": a terracotta clay face pokes its long nose into a glossy
// white cow-spotted blob, wrapped in rippling black-and-white zebra enamel, a grey slab and blue sky behind.
REC.register('g002', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    // an early read-back keeps the relief buffers in CPU memory (GPU-backed ones can get dropped under heavy stroking)
    R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1);
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };

    // zebra phase: contour lines wrapping around the white blob, wider apart further out
    const ZPH = `
      float zph(vec2 p){
        vec2 q = p + 36. * vec2(vnoise(p * 0.011) - .5, vnoise(p * 0.011 + 4.) - .5);
        q.y += 9. * sin(p.x * 0.017 + 1.3) + 5. * sin(p.x * 0.043 + p.y * 0.01);
        vec2 d = (q - vec2(330., 380.)) * vec2(0.42, 1.0);
        return 2.89 * pow(length(d) + 1., 0.4) + 0.25;
      }`;
    const zAlb = pat(E.fx(ZPH + `vec3 fx(vec2 uv, vec2 p){
      float f = fract(zph(p));
      float blk = smoothstep(0.03, 0.08, f) * smoothstep(0.42, 0.37, f);
      return mix(vec3(0.95, 0.96, 0.97), vec3(0.025, 0.025, 0.03), blk); }`));
    const zH = E.fx(ZPH + `vec3 fx(vec2 uv, vec2 p){
      float f = fract(zph(p));
      float blk = smoothstep(0.02, 0.1, f) * smoothstep(0.43, 0.35, f);
      float hv = 0.08 + 0.05 * (1. - blk) + 0.04 * sin(3.1416 * clamp((f - 0.4) / 0.6, 0., 1.));
      float v = hv * 255., i = floor(v);
      return vec3(i / 255., 5. * 32. / 255., fract(v)); }`);

    // ── black bars + sky + far mountains ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#010101', 0, 0);
    const sky = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float y = p.y;
      vec3 c = mix(vec3(0.19, 0.49, 0.80), vec3(0.40, 0.71, 0.96), smoothstep(40., 320., y));
      c = mix(c, vec3(0.62, 0.86, 0.98), smoothstep(300., 470., y));
      c = mix(c, vec3(0.80, 0.80, 0.82), smoothstep(500., 590., y));
      float ridge = 606. + 7. * sin(p.x * 0.035) + 4. * sin(p.x * 0.11 + 1.);
      c = mix(c, vec3(0.30, 0.38, 0.54), smoothstep(ridge - 2., ridge + 2., y));
      c = mix(c, vec3(0.08, 0.11, 0.19), smoothstep(640., 690., y));
      c = mix(c, vec3(0.01), smoothstep(720., 860., y));
      return c; }`));
    R.flat(rrect(480, 38, 260, 947, 0), sky, 0, 0);
    soft(x => { const g = x.createLinearGradient(690, 300, 726, 262); g.addColorStop(0, 'rgba(255,240,80,0)'); g.addColorStop(0.4, 'rgba(255,230,120,0.8)'); g.addColorStop(0.6, 'rgba(120,230,160,0.8)'); g.addColorStop(1, 'rgba(120,160,255,0.7)');
      x.strokeStyle = g; x.lineWidth = 10; x.beginPath(); x.moveTo(684, 268); x.quadraticCurveTo(706, 276, 730, 300); x.stroke(); }, 3, 0.9);

    // ── zebra enamel ──
    const ZB = [[0, 38], [600, 38], [600, 380], [612, 420], [640, 480], [632, 560], [642, 605], [668, 650], [700, 705], [730, 742], [730, 852], [680, 870], [620, 885],
      [540, 895], [500, 905], [480, 932], [462, 985], [0, 985]];
    const zbP = P(ZB, true, false);
    R.flat(zbP, zAlb, 0.1, 5);
    R.h.save(); R.h.clip(zbP); R.h.setTransform(1, 0, 0, 1, 0, 0); R.h.drawImage(zH, 0, 0); R.h.restore();

    // ── grey slab ──
    const slabTex = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = fbm(p * 0.08) * 0.6 + hash(floor(p * 1.2)) * 0.4;
      return vec3(0.40, 0.46, 0.55) * (0.82 + 0.3 * n) + vec3(0.03) * smoothstep(300., 40., p.y); }`));
    const SLAB = [[425, 38], [626, 38], [630, 80], [645, 120], [652, 170], [662, 210], [665, 262], [652, 300], [640, 340], [616, 372], [600, 380], [588, 300], [598, 230],
      [592, 170], [565, 140], [480, 125], [420, 145], [350, 170], [292, 205], [295, 185], [330, 150], [380, 120], [425, 95], [440, 60]];
    const slabP = P(ragged(SLAB, 1, 11, 6, 2.5, 3), true, false);
    R.flat(slabP, slabTex, 0.12, 4);

    // ── white glossy blob with cow spots ──
    const BLOB = [[60, 470], [66, 425], [95, 388], [150, 368], [250, 368], [330, 370], [395, 368], [420, 340], [410, 300], [370, 268], [300, 245], [235, 222], [190, 205],
      [235, 196], [292, 210], [350, 172], [420, 148], [480, 128], [540, 130], [575, 150], [595, 190], [598, 235], [586, 272], [562, 300], [530, 290], [500, 300],
      [508, 350], [512, 400], [500, 450], [470, 495], [442, 525], [422, 560], [380, 585], [300, 602], [200, 602], [120, 590], [78, 548]];
    const blobP = P(BLOB);
    R.dome(blobP, '#f3f5f7', 0.16, 0.22, 45, 2);
    // grey hole showing the slab
    const HOLE = [[310, 238], [360, 240], [420, 258], [452, 290], [472, 330], [500, 352], [506, 400], [482, 440], [442, 442], [404, 426], [380, 440], [352, 440], [330, 410],
      [328, 372], [300, 360], [292, 300]];
    const holeP = P(HOLE);
    clipA(blobP, () => {
      soft(x => {
        x.fillStyle = '#9a5a1c'; x.fill(holeP);
        fe(x, 245, 490, 42, 68, -0.35, '#a0601c'); fe(x, 384, 482, 24, 48, 0.1, '#a0601c');
        x.fill(P([[370, 190], [420, 172], [470, 186], [520, 186], [560, 210], [566, 262], [530, 262], [500, 232], [450, 220], [400, 222], [372, 212]]));
      }, 12, 0.9);
      soft(x => {
        fe(x, 245, 490, 33, 58, -0.35, '#16171a'); fe(x, 384, 482, 16, 40, 0.1, '#0c0b0a');
        x.fillStyle = '#121214'; x.fill(P([[378, 192], [420, 178], [468, 192], [518, 192], [552, 214], [556, 256], [530, 254], [500, 226], [450, 214], [400, 216], [380, 210]]));
      }, 5, 1);
      soft(x => { fe(x, 250, 500, 18, 34, -0.35, '#3a3d44'); }, 8, 0.6);
    });
    R.flat(holeP, '#4a515e', 0.14, 4);
    soft(x => { x.strokeStyle = '#141416'; x.lineWidth = 8; x.stroke(holeP); }, 4, 0.9);
    clipA(holeP, () => soft(x => { fe(x, 420, 360, 40, 50, 0, '#5a6270'); }, 20, 0.6));

    // ── terracotta clay face + nose ──
    const SKIN = [[-10, 38], [125, 38], [142, 72], [162, 112], [192, 152], [232, 190], [272, 216], [300, 242], [250, 252], [150, 252], [110, 262], [96, 320], [112, 360],
      [90, 384], [70, 422], [60, 470], [50, 510], [20, 538], [-10, 548]];
    const skinP = P(SKIN);
    const sg = a.createRadialGradient(70, 190, 10, 70, 190, 420); [[0, '#e49a88'], [0.25, '#cc7664'], [0.55, '#b45c4a'], [0.8, '#8a3e30'], [1, '#5a2820']].forEach(([t, c]) => sg.addColorStop(t, c));
    R.dome(skinP, sg, 0.2, 0.3, 70, 1);
    soft(x => { fe(x, 250, 228, 45, 16, 0.5, '#f0d0c8'); }, 14, 0.5);
    const NOSE = [[110, 250], [200, 246], [300, 258], [370, 276], [404, 298], [416, 324], [406, 350], [380, 364], [300, 368], [200, 364], [130, 354], [100, 318]];
    const noseP = P(NOSE);
    R.dome(noseP, lin(0, 250, 0, 368, [[0, '#c87060'], [0.45, '#c06454'], [1, '#8c4434']]), 0.32, 0.22, 40, 1);
    soft(x => { x.strokeStyle = 'rgba(80,30,20,0.6)'; x.lineWidth = 10; x.stroke(P([[130, 360], [220, 368], [320, 370], [390, 360]], false)); }, 6, 0.7);
    clipA(skinP, () => soft(x => { fe(x, 40, 470, 50, 70, 0, '#5a3028'); }, 20, 0.8));
    // nostril pit
    R.dome(circleP(60, 262, 15), '#9a9ca2', 0.3, 0.1, 6, 3);
    R.flat(circleP(60, 262, 7), '#101012', 0.3, 0);

    // ── black glass beads ──
    for (const [x, y, r] of [[235, 95, 13], [432, 240, 10], [578, 295, 10], [617, 343, 19], [557, 405, 10], [555, 470, 13], [516, 515, 13], [398, 530, 12], [92, 560, 16],
      [665, 822, 23], [545, 103, 8], [440, 84, 5], [622, 268, 5], [470, 505, 4], [180, 60, 7]]) R.bead(x, y, r, '#0b0b0e', 0.3, 0.14, 3);
    R.dome(circleP(330, 125, 24), '#9a9ca4', 0.25, 0.12, 8, 3);
    R.bead(330, 125, 15, '#0b0b0e', 0.3, 0.12, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.45, shin: 22, wrap: 0.45, ao: 0.4, grain: 0.1, rim: 0.2 }),       // 1 clay skin
        E.mat({ dif: 1, spec: 1.1, shin: 70, wrap: 0.35, ao: 0.35, coat: 0.25 }),               // 2 white enamel
        E.mat({ dif: 1, spec: 1.5, shin: 110, coat: 0.5, ao: 0.2 }),                            // 3 black glass beads
        E.mat({ dif: 1, spec: 0.12, shin: 12, wrap: 0.5, grain: 0.25 }),                        // 4 grey slab
        E.mat({ dif: 1, spec: 1.2, shin: 80, wrap: 0.3, coat: 0.3, ao: 0.4 })                   // 5 zebra enamel
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.75, 0.75, 0.76], amb: [0.36, 0.36, 0.38],
      envTop: [1.05, 1.05, 1.08], envHor: [0.5, 0.55, 0.62], envBot: [0.08, 0.08, 0.1], envK: [0.3, 1.1, 0.3, 0],
      rimC: [0.25, 0.3, 0.4], rimD: [0.3, 0.6, 0.3], r1: 1.4, r2: 6, k: [0, 0.6, 0.4, 70], shadow: [-4, 6, 0.45, 6]
    });
    // letterbox
    const o = E.out; o.fillStyle = '#010101'; o.fillRect(0, 0, 726, 38); o.fillRect(0, 985, 726, 40);
    E.bloom(0.1, 8);
    E.grain(0.03, 2);
  }
});
