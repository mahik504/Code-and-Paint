'use strict';
// u018 — "Pink dome cosmos": a quilted pink dome with a starry navy window sits by a chrome tyre, under a
// television full of nebula, a striped grey ribbon, a blue-pink pool, pine trees, a yellow sun and a starry cave.
REC.register('u018', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a, fx = x, fy = y) => { const g = ctx.createRadialGradient(fx, fy, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false);
    const fillA = (path, col) => { a.fillStyle = col; a.fill(path); };
    const strokeA = (path, col, w) => { a.lineWidth = w; a.strokeStyle = col; a.lineCap = a.lineJoin = 'round'; a.stroke(path); };
    const shadow = (path, dx, dy, b, al) => soft(x => { x.fillStyle = '#000'; x.translate(dx, dy); x.fill(path); }, b, al);
    const stars = (path, n, seed, x0, y0, w, h, big = 0.05) => clipA(path, () => { const g = rng(seed); for (let i = 0; i < n; i++) fillA(circleP(x0 + g() * w, y0 + g() * h, g() < big ? 2.5 + g() * 3 : 0.5 + g() * 1.3), `rgba(250,250,252,${0.6 + g() * 0.4})`); });
    const speck = (path, base, k = 0.5) => clipA(path, () => { a.save(); a.globalCompositeOperation = 'screen'; img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = hash(floor(p * .9)); return vec3(step(.8, n) * ${k.toFixed(2)} * (.4 + .6 * hash(floor(p) + 3.))); }`), a); a.restore(); });

    // ── frame and the white sky ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#ddd0b8', 0, 0);
    R.flat(poly([[-10, -10], [736, -10], [736, 13], [-10, 13]]), '#0c0806', 0, 0);
    R.flat(poly([[-10, 13], [6, 13], [8, 400], [4, 1034], [-10, 1034]]), '#5a4030', 0, 0);
    R.flat(poly([[700, -10], [736, -10], [736, 320], [700, 320]]), '#4a3428', 0, 0);
    R.flat(poly([[-10, 120], [12, 120], [12, 960], [-10, 960]]), '#8a7666', 0, 0);
    const IN = rrect(12, 12, 702, 996, 16);
    R.flat(IN, '#f2f4f8', 0.01, 0);

    // ── top left: stripes, checker strip, pink & blue pool with spirals ──
    // pale waves
    const WV = poly([[12, 150], [300, 140], [300, 300], [12, 300]]);
    clipA(WV, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float y = p.y + 14. * sin(p.x * .018 + 1.) - 165.; float v = sin(y / 21. * 3.1416);
      vec3 c = mix(vec3(.88, .91, .93), vec3(.64, .70, .77), smoothstep(-.1, .1, v));
      return mix(c, vec3(.95, .96, .98), smoothstep(110., 135., y)); }`), a));

    const PINK = sm([[12, 25], [280, 22], [292, 140], [270, 165], [200, 192], [110, 207], [40, 207], [12, 195]]);
    fillA(PINK, '#ec98ae');
    fillA(sm([[190, 28], [244, 28], [250, 62], [252, 100], [270, 110], [275, 130], [262, 150], [230, 160], [195, 170], [170, 182], [150, 192], [110, 197], [60, 193], [34, 182], [50, 172], [90, 166], [96, 140], [98, 104], [120, 98], [160, 98], [182, 92], [186, 62]]), '#1236c8');
    fillA(sm([[106, 28], [146, 28], [148, 50], [140, 62], [110, 62], [104, 45]]), '#1236c8');
    fillA(sm([[250, 26], [280, 26], [292, 60], [286, 100], [262, 104], [254, 70]]), '#d888b0');
    for (const [x, y] of [[48, 145], [258, 60]]) for (let k = 1; k <= 4; k++) strokeA(circleP(x + k * 1.5, y, k * 6.5), '#5a3a8a', 3.5);
    fillA(circleP(154, 152, 14), '#f6f6f8');
    clipA(sm([[12, 14], [100, 14], [120, 40], [110, 80], [70, 110], [30, 112], [12, 100]]), () => { fillA(poly([[12, 12], [130, 12], [130, 130], [12, 130]]), '#f0f0f0'); for (let i = -6; i < 8; i++) fillA(poly([[i * 33 - 20, -20], [i * 33 - 4, -20], [i * 33 + 98, 150], [i * 33 + 82, 150]]), '#0c0a0c'); });
    for (let i = 0; i < 10; i++) fillA(rrect(112 + i * 22, 12, 11, 14, 0), '#0c0a0c');
    // ── pine trees ──
    const tree = (x, y, h, w) => { const pts = [[x, y - h]]; const n = 7; for (let i = 1; i <= n; i++) { const t = i / n, yy = y - h + t * h, ww = w * t; pts.push([x + ww, yy], [x + ww * 0.35, yy - h / n * 0.25]); }
      const L = pts.slice(1).map(([px, py]) => [2 * x - px, py]).reverse(); fillA(poly([...pts, ...L]), '#080608'); fillA(rrect(x - 2, y - 4, 4, 14, 1), '#080608'); };
    tree(50, 470, 160, 42); tree(100, 470, 70, 22); tree(130, 470, 50, 18); tree(22, 470, 80, 18); tree(150, 470, 34, 14);
    { const g = rng(3); clipA(poly([[12, 310], [170, 310], [170, 470], [12, 470]]), () => { for (let i = 0; i < 26; i++) fillA(circleP(14 + g() * 150, 320 + g() * 150, 1 + g() * 2.5), '#f8f8fa'); }); }
    // pink capsule and grey dot
    R.dome(P(lock([[100, 326], [150, 360], [215, 402]], 30, 26)), '#ec9fab', 0.05, 0.04, 12, 2);
    R.bead(195, 438, 10, '#b4c0d0', 0.05, 0.05, 2);

    // ── grey/cream striped ribbon ──
    const RIB = sm([[280, 12], [462, 12], [470, 120], [478, 232], [430, 240], [400, 250], [372, 275], [345, 300], [318, 330], [300, 380], [292, 430], [290, 482], [205, 478], [212, 420], [232, 360], [258, 310], [280, 270], [290, 230], [282, 190], [276, 150], [282, 100], [276, 50]]);
    R.flat(RIB, '#cfc4bc', 0.02, 0);
    clipA(RIB, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float x = p.x - 32. * sin(p.y * .02 + .5) + .45 * max(0., p.y - 240.);
      float v = sin(x / 24. * 3.1416);
      return mix(vec3(.91, .87, .83), vec3(.68, .61, .59), smoothstep(-.2, .2, v)); }`), a));

    // ── night sky top right with an orange edge ──
    const SPACE = poly([[462, 12], [714, 12], [714, 236], [690, 240], [662, 290], [600, 292], [560, 280], [520, 258], [500, 245], [480, 212], [472, 130]]);
    R.flat(SPACE, '#0c0810', 0.01, 0);
    speck(SPACE, 0, 0.35); stars(SPACE, 60, 11, 462, 12, 252, 290);
    R.flat(poly([[456, 12], [455, 95], [475, 205], [484, 213], [497, 287], [512, 297], [519, 315], [526, 315], [539, 284], [560, 280], [550, 264], [522, 258], [497, 243], [471, 130], [464, 77], [466, 12]]), '#de4e19', 0.02, 0);
    for (const [x0, y0, y1] of [[488, 12, 58], [516, 12, 45], [546, 12, 56]]) R.dome(rrect(x0 - 8, y0 - 10, 16, y1 - y0 + 10, 8), '#f0d040', 0.04, 0.04, 6, 2);
    R.pipe(P([[497, 112], [507, 165], [516, 215]], false), 18, '#a8e070', 0.04, 0.06, 2);
    R.pipe(circleP(511, 77, 11), 6, '#3a62e8', 0.04, 0.04, 2);
    R.pipe(P([[590, 90], [652, 56]], false), 6, '#40c0e8', 0.04, 0.03, 2);
    for (const [x, y, rx, ry, r0, c] of [[622, 128, 80, 32, -0.05, '#a89a9a'], [598, 196, 98, 16, 0.18, '#bcaeae']]) {
      const d = ellipseP(x, y, rx, ry, r0); R.dome(d, c, 0.04, 0.05, ry * 0.8, 3);
      clipA(d, () => { for (let i = -10; i < 10; i++) strokeA(P([[x + i * 9, y - ry], [x + i * 9 + 6, y + ry]], false), 'rgba(60,50,50,0.35)', 1); }); }
    R.flat(ellipseP(622, 152, 72, 10, 0), '#8a3a20', 0.06, 0); strokeA(ellipseP(622, 152, 72, 10, 0), '#de4e19', 2);

    // ── lavender strip and brown/orange ground around the TV ──
    const LAV = sm([[700, 230], [714, 230], [714, 1000], [640, 1000], [645, 920], [650, 860], [640, 820], [612, 790], [596, 776], [632, 764], [656, 740], [662, 700], [676, 640], [682, 590], [692, 556], [696, 470], [690, 400], [678, 350], [660, 320], [652, 290], [676, 262], [690, 240]]);
    R.flat(LAV, lin(640, 0, 714, 0, [[0, '#a898d0'], [1, '#9c8cc4']]), 0.02, 0);
    { const g = rng(21); clipA(LAV, () => { for (let i = 0; i < 200; i++) fillA(circleP(600 + g() * 120, 230 + g() * 770, 0.5 + g() * 1.5), 'rgba(255,255,255,0.8)'); }); }
    const BROWN = sm([[300, 236], [330, 224], [380, 228], [430, 240], [470, 236], [498, 268], [560, 282], [610, 296], [648, 300], [656, 330], [650, 480], [646, 560], [600, 566], [560, 600], [500, 640], [460, 610], [420, 580], [380, 540], [330, 500], [300, 470], [306, 400], [326, 340]]);
    R.flat(BROWN, '#8c5a3e', 0.02, 0);
    const ORR = sm([[598, 560], [650, 520], [690, 520], [690, 600], [668, 650], [660, 720], [640, 760], [600, 772], [540, 782], [490, 790], [484, 740], [490, 670], [510, 620], [550, 590]]);
    R.flat(ORR, '#de4a16', 0.02, 0);
    soft(x => { x.fillStyle = '#de4a16'; x.fill(sm([[440, 236], [470, 240], [500, 280], [560, 290], [600, 300], [610, 320], [580, 330], [520, 320], [480, 300], [450, 270]])); }, 1, 1);
    R.flat(circleP(570, 682, 66), '#fbef74', 0.04, 0);

    // ── the TV ──
    const TVF = rrect(386, 306, 246, 242, 26);
    shadow(TVF, 4, 8, 8, 0.6);
    R.dome(TVF, '#b7aba6', 0.06, 0.06, 10, 4);
    const SCR = rrect(396, 318, 224, 218, 18);
    R.flat(SCR, '#07050a', 0.05, 0);
    stars(SCR, 90, 31, 396, 318, 224, 218, 0.12);
    soft(x => { x.fillStyle = '#8a3a78'; x.fill(circleP(486, 444, 62)); x.fillStyle = '#c25a8c'; x.fill(circleP(486, 444, 26)); }, 22, 0.95);
    soft(x => { x.fillStyle = '#3a5ad8'; x.fill(ellipseP(552, 386, 44, 18, 0.35)); x.fillStyle = '#f0d040'; x.fill(ellipseP(570, 398, 20, 12, 0.35)); }, 5, 1);
    R.flat(circleP(522, 375, 8), '#f8e070', 0.06, 0);
    strokeA(rrect(405, 344, 194, 176, 22), '#de4e19', 9);
    // yellow zigzags under the TV
    strokeA(P([[456, 530], [480, 540], [500, 528], [530, 540], [560, 528], [590, 538], [610, 528]], false, false), '#f0d040', 5);
    strokeA(P([[470, 572], [490, 590], [505, 574], [520, 592], [540, 576], [560, 590], [580, 572], [600, 586], [612, 570]], false, false), '#f0d040', 5);
    // grey fibrous creature on the right
    const CR = sm([[634, 300], [660, 292], [682, 316], [684, 360], [676, 400], [688, 440], [680, 500], [668, 560], [654, 620], [646, 580], [640, 520], [626, 470], [630, 420], [622, 360]]);
    R.dome(CR, '#9a8e92', 0.06, 0.05, 10, 3);
    clipA(CR, () => { for (let i = 0; i < 40; i++) strokeA(P([[620, 300 + i * 8], [660, 296 + i * 8 + 6 * Math.sin(i)], [690, 302 + i * 8]], false), 'rgba(50,40,44,0.5)', 1.4); });
    R.dome(sm([[560, 250], [584, 240], [604, 248], [612, 276], [594, 292], [566, 290], [552, 270]]), '#a8a0a4', 0.06, 0.05, 10, 3);
    // green bars, teal dot, blue lens, cyan ring
    R.dome(rrect(350, 300, 150, 22, 11), '#a8e070', 0.06, 0.04, 8, 2);
    R.dome(rrect(290, 440, 60, 14, 7), '#a8e070', 0.06, 0.03, 6, 2);
    R.dome(rrect(362, 340, 22, 120, 10), '#ecc6c8', 0.06, 0.03, 8, 2);
    R.dome(ellipseP(335, 408, 15, 20, 0), '#2238c0', 0.06, 0.04, 8, 2); strokeA(ellipseP(335, 408, 15, 20, 0), '#de4e19', 3);
    R.bead(443, 494, 19, '#64d0d8', 0.08, 0.08, 2);
    R.pipe(circleP(387, 287, 13), 6, '#30b8e0', 0.06, 0.04, 2);
    { const g = rng(5); for (let i = 0; i < 14; i++) fillA(circleP(300 + g() * 360, 250 + g() * 340, 3 + g() * 5), '#f8f8f8'); }
    R.dome(P(lock([[320, 302], [300, 290], [278, 278], [258, 266]], 14, 2)), '#c88a38', 0.06, 0.04, 6, 2);

    // ── the cave ──
    const CAVE = sm([[501, 787], [486, 805], [479, 820], [474, 847], [499, 863], [503, 889], [515, 892], [519, 908], [536, 930], [553, 939], [585, 942], [591, 955], [614, 953], [617, 928], [638, 909], [645, 893], [646, 862], [640, 838], [627, 804], [596, 792], [579, 780], [543, 772], [514, 780]]);
    R.flat(sm([[480, 780], [540, 768], [600, 780], [640, 820], [650, 880], [640, 1000], [470, 1000], [460, 860]]), lin(0, 780, 0, 1000, [[0, '#0e0a12'], [0.6, '#16121a'], [1, '#5a5058']]), 0.02, 0);
    stars(sm([[480, 780], [540, 768], [600, 780], [640, 820], [650, 880], [640, 1000], [470, 1000], [460, 860]]), 120, 41, 460, 768, 190, 232, 0.08);
    soft(x => { x.fillStyle = '#c8c0c8'; x.fill(ellipseP(560, 980, 110, 26, 0)); }, 16, 0.6);

    // ── grey mound with white arcs ──
    const MD = sm([[12, 480], [60, 456], [130, 446], [200, 460], [244, 490], [250, 700], [200, 730], [12, 730]]);
    R.flat(MD, '#aa9a9a', 0.03, 0);
    clipA(MD, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float r = length((p - vec2(215., 760.)) * vec2(1., 1.1)); float v = sin(r / 27. * 3.1416);
      return mix(vec3(.66, .60, .60), vec3(.93, .90, .87), smoothstep(.55, .75, v)); }`), a));
    stars(MD, 30, 9, 12, 446, 240, 284, 0.4);

    // ── the pink dome creature ──
    const DOME = sm([[330, 470], [380, 474], [430, 490], [462, 530], [480, 600], [488, 680], [486, 760], [470, 830], [445, 860], [300, 860], [230, 850], [196, 820], [186, 760], [190, 680], [202, 600], [228, 530], [270, 490]]);
    R.flat(sm([[250, 480], [200, 520], [160, 600], [150, 700], [156, 800], [168, 900], [200, 990], [470, 995], [490, 900], [500, 800], [480, 700]]), '#d84a1c', 0.03, 0);
    const beadsL = []; for (let i = 0; i < 13; i++) { const t = i / 12, y = 486 + t * 370, x = 226 - Math.sin(t * Math.PI) * 52 + (t > 0.8 ? 8 : 0); beadsL.push([x, y]); }
    for (const [x, y] of beadsL) R.dome(ellipseP(x, y, 27, 22, 0), '#d2d2d6', 0.04, 0.08, 16, 5);
    a.save(); a.lineWidth = 18; a.strokeStyle = '#d24e22'; a.lineJoin = 'round'; a.stroke(DOME); a.restore();
    R.dome(DOME, '#f0c4c6', 0.08, 0.1, 40, 6);
    const LB = sm([[208, 624], [190, 681], [190, 700], [202, 712], [216, 750], [205, 800], [206, 825], [255, 840], [313, 848], [363, 840], [413, 812], [460, 806], [462, 746], [430, 756], [401, 752], [370, 790], [338, 796], [326, 808], [275, 780], [262, 740], [232, 722], [219, 707], [214, 662], [230, 639], [224, 618]]);
    R.flat(LB, '#b6c4d6', 0.12, 6);
    strokeA(P([[214, 662], [219, 707], [232, 722], [262, 740], [275, 780], [326, 808], [338, 796], [370, 790], [401, 752], [430, 756], [462, 746]], false), '#c85a3a', 3);
    for (let i = 0; i < 6; i++) strokeA(P([[272, 500 + i * 11], [330, 492 + i * 11 - 4], [400, 494 + i * 11 - 6], [446, 502 + i * 10]], false), '#d24e22', 4.5);
    strokeA(P([[228, 610], [300, 590], [330, 560], [430, 556], [470, 570]], false), '#d24e22', 3);
    const WIN = ellipseP(360, 666, 54, 96, 0.17);
    a.save(); a.lineWidth = 16; a.strokeStyle = '#d24e22'; a.stroke(WIN); a.restore();
    R.flat(WIN, rad(355, 680, 100, [[0, '#0a064a'], [0.6, '#16129a'], [1, '#1a24b0']]), 0.14, 0);
    stars(WIN, 160, 51, 300, 560, 120, 210, 0.02);
    for (const [x, y, r, c] of [[245, 660, 12, '#1a2a9a'], [279, 647, 12, '#1a2a9a'], [263, 698, 15, '#b6c4d6']]) { R.dome(circleP(x, y, r), c, 0.14, 0.03, r * 0.6, 6); strokeA(circleP(x, y, r), '#d24e22', 3); }

    // ── blue cloth, tyre, gravel, striped pouch, balls ──
    R.flat(poly([[150, 1000], [160, 960], [300, 950], [700, 960], [714, 1000]]), '#b0a4a6', 0.02, 0);
    clipA(poly([[150, 1000], [160, 960], [300, 950], [700, 960], [714, 1000]]), () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = hash(floor(p / 1.5)); return vec3(.62, .57, .58) + n * .3; }`), a));
    const CL = sm([[176, 868], [230, 846], [300, 852], [330, 900], [300, 960], [250, 990], [190, 990], [168, 940]]);
    R.dome(CL, '#1428a8', 0.04, 0.05, 20, 3);
    strokeA(P([[190, 870], [215, 885], [200, 900], [235, 915], [210, 935], [250, 950], [230, 975], [270, 985]], false, false), '#f0d84a', 6);
    strokeA(P([[240, 860], [270, 875], [255, 890], [285, 905]], false, false), '#f0d84a', 5);
    const CL2 = sm([[370, 840], [420, 820], [470, 830], [480, 880], [440, 900], [380, 890]]);
    R.dome(CL2, '#1428a8', 0.04, 0.05, 14, 3);
    for (const [x, y, r] of [[395, 832, 8], [422, 822, 6], [447, 850, 6], [415, 860, 5]]) R.flat(circleP(x, y, r), '#f4f4f8', 0.1, 0);
    // chrome tyre
    const TY = ellipseP(353, 927, 98, 76, 0);
    shadow(TY, 3, 8, 8, 0.6);
    R.dome(TY, '#e2e2e8', 0.06, 0.1, 30, 4);
    for (let i = 0; i < 16; i++) { const t = (i / 16) * Math.PI * 2; R.groove(P([[353 + Math.cos(t) * 52, 892 + Math.sin(t) * 24], [353 + Math.cos(t) * 100, 930 + Math.sin(t) * 76]], false), 6, '#7a7682', 0.17, 0.05, 4, 0.5); }
    R.dome(ellipseP(353, 884, 48, 22, 0), '#5a5660', 0.15, 0.03, 6, 4);
    R.flat(ellipseP(353, 886, 36, 14, 0), '#18161c', 0.12, 0);
    // striped pouch
    const PO = sm([[14, 712], [60, 700], [100, 712], [128, 760], [146, 830], [150, 900], [140, 970], [100, 995], [14, 995]]);
    R.dome(PO, '#e8e8ea', 0.04, 0.08, 24, 1);
    clipA(PO, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float x = p.x + 30. * sin(p.y * .018) - .4 * (p.y - 700.); float v = sin(x / 16. * 3.1416);
      return mix(vec3(.04), vec3(.92), smoothstep(.1, .35, v)); }`), a));
    R.dome(sm([[20, 816], [60, 796], [96, 806], [100, 830], [70, 842], [30, 840]]), '#e8a8a0', 0.12, 0.04, 8, 3);
    R.bead(42, 770, 12, '#f4f4f4', 0.1, 0.06, 3); R.bead(72, 832, 7, '#f4f4f4', 0.14, 0.04, 3);
    R.dome(sm([[88, 905], [120, 880], [150, 892], [170, 920], [150, 950], [118, 962], [90, 940]]), '#f2f2f4', 0.14, 0.08, 14, 3);
    for (const [x, y] of [[112, 915], [140, 924], [126, 944]]) R.flat(circleP(x, y, 6), '#101010', 0.2, 0);
    R.bead(156, 880, 18, '#e8902e', 0.12, 0.12, 3); R.bead(144, 990, 20, '#e8902e', 0.06, 0.12, 3);
    // yellow squiggle
    R.pipe(P([[92, 630], [110, 660], [100, 690], [130, 700], [150, 740], [170, 760], [200, 770], [215, 795], [230, 800]], false, false), 5, '#f0d84a', 0.12, 0.03, 2);

    // rusty frame specks
    { const g = rng(18); clipA(poly([[-10, -10], [736, -10], [736, 1034], [-10, 1034], [-10, -10], [12, 12], [12, 1008], [714, 1008], [714, 12], [12, 12]]), () => {
      for (let i = 0; i < 260; i++) { const side = i % 4, t = g(); const x = side === 0 ? t * 726 : side === 1 ? 716 + g() * 10 : side === 2 ? t * 726 : g() * 12, y = side === 0 ? g() * 12 : side === 1 ? t * 1024 : 1010 + g() * 14, y2 = side === 3 ? t * 1024 : y;
        fillA(circleP(x, side === 3 ? y2 : y, 1 + g() * 4), g() < 0.6 ? '#7a4a2a' : '#2a1a12'); } }); }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.4, shin: 24, wrap: 0.5, ao: 0.2, emis: 0.08 }),                  // 1 pouch
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.5, ao: 0.2, emis: 0.05 }),                  // 2 glossy bits
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.5, ao: 0.3 }),                              // 3 cloth / felt
        E.mat({ dif: 0.7, metal: 0.4, spec: 1.2, shin: 60, ao: 0.3, emis: 0.3, wrap: 0.4 }),     // 4 chrome tyre / TV
        E.mat({ dif: 1, spec: 0.4, shin: 24, wrap: 0.5, ao: 0.3, emis: 0.05 }),                  // 5 beads
        E.mat({ dif: 1, spec: 0.2, shin: 16, wrap: 0.6, ao: 0.2, emis: 0.12 }),                  // 6 pink quilt
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.55, 0.55, 0.56], amb: [0.5, 0.5, 0.52],
      envTop: [1.1, 1.1, 1.12], envHor: [0.6, 0.6, 0.62], envBot: [0.12, 0.12, 0.14], envK: [0.4, 0.8, 0, 0],
      r1: 1.6, r2: 7, k: [0, 0.6, 0.4, 100], shadow: [-4, 7, 0.45, 8]
    });
    E.grain(0.03, 18);
  }
});
