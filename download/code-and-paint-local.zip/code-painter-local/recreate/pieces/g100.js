'use strict';
// g100 — "Bubble-helmet goggle girl": a halftone-grey profile in a glass bubble helmet with green goggles, a magenta,
// yellow and cyan paint splash, hot-pink lips, a polka-dot black sleeve, pale hazard bars, a grey sponge and zebra stripes.
REC.register('g100', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, r1, stops) => { const g = o.createRadialGradient(x, y, r0, x, y, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const fill = (path, c) => { o.fillStyle = c; o.fill(path); };
    const stroke = (path, c, wd) => { o.strokeStyle = c; o.lineWidth = wd; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const clip = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const poly = pts => P(pts, true, false);
    const sm = pts => P(pts, true, true);
    const open = pts => P(pts, false, true);
    const K = '#050505', PALE = '#e4f2aa', W = '#f8f8f4';
    const r = rng(100);
    // halftone / crosshatch textures
    const hatch = (base, line, per, wdt) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float a = abs(fract((p.x + p.y) / ${per.toFixed(1)}) - .5), b = abs(fract((p.x - p.y) / ${per.toFixed(1)}) - .5);
      float m = max(smoothstep(${wdt.toFixed(3)}, ${(wdt - 0.08).toFixed(3)}, a), smoothstep(${wdt.toFixed(3)}, ${(wdt - 0.08).toFixed(3)}, b)) * 0.0;
      float l = min(a, b);
      float k = smoothstep(${(0.5 - wdt).toFixed(3)}, ${(0.5 - wdt + 0.1).toFixed(3)}, 0.5 - l);
      return mix(vec3(${base.join(',')}), vec3(${line.join(',')}), 1. - k + m); }`));
    const dots = (base, dot, per, rr) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = fract(p / ${per.toFixed(1)}) - .5; float d = length(q);
      return mix(vec3(${dot.join(',')}), vec3(${base.join(',')}), smoothstep(${rr.toFixed(3)} - .08, ${rr.toFixed(3)} + .04, d)); }`));

    // ── black ground + pale wave bands (top left) ──
    fill(rrect(-10, -10, 746, 1044, 0), K);
    for (const pts of [[[80, -20], [62, 40], [40, 90], [24, 122]], [[138, -20], [146, 45], [132, 100], [95, 150], [62, 195]], [[196, -20], [214, 50], [205, 100], [178, 150], [140, 200], [100, 245], [84, 290]],
      [[262, 30], [240, 110], [226, 160], [206, 210], [170, 262], [134, 300], [112, 330]], [[262, 190], [236, 248], [204, 290], [170, 322], [146, 346]], [[262, 300], [226, 336], [190, 366], [166, 388]]])
      stroke(open(pts), PALE, 36);
    stroke(open([[176, 40], [196, 26]]), '#e83070', 4);
    stroke(open([[22, 236], [56, 200]]), '#e83070', 4);
    for (let i = 0; i < 60; i++) { const x = r() * 260, y = r() * 900; if (x > 150 && y > 300 && y < 850) continue; fill(circleP(x, y, 2 + r() * (r() < 0.2 ? 14 : 5)), W); }
    for (const [x, y, rr] of [[72, 58, 16], [36, 365, 15], [38, 572, 20], [124, 420, 10], [168, 618, 14], [200, 180, 9], [124, 285, 8], [414, 740, 9]]) fill(circleP(x, y, rr), W);

    // ── hair, ear, headband (right) ──
    fill(sm([[470, -10], [736, -10], [736, 720], [640, 700], [600, 640], [640, 480], [650, 300], [600, 160], [520, 110]]), '#1c1a26');
    clip(sm([[560, 100], [736, 100], [736, 700], [600, 650]]), () => { for (let i = 0; i < 26; i++) stroke(open([[560 + r() * 160, 100 + r() * 100], [600 + r() * 140, 300 + r() * 400]]), '#3a3850', 2); });
    fill(poly([[470, -10], [736, -10], [736, 80], [680, 66], [620, 54], [560, 46], [480, 44]]), '#030303');
    fill(sm([[468, -10], [548, -10], [544, 30], [520, 44], [480, 44]]), '#fac306');
    fill(poly([[478, 44], [560, 44], [620, 52], [680, 62], [736, 76], [736, 142], [680, 132], [620, 116], [560, 108], [500, 104]]), '#082a6c');
    fill(poly([[480, 54], [560, 54], [620, 62], [680, 76], [736, 86], [736, 132], [680, 124], [620, 108], [560, 102], [500, 96]]), '#e2eef6');
    stroke(open([[620, -10], [650, 40], [662, 90]]), '#e83070', 4);
    // ear with teal splash
    const ear = sm([[656, 150], [700, 140], [736, 160], [736, 350], [700, 360], [670, 330], [650, 260]]);
    fill(ear, '#f0a080');
    stroke(open([[690, 170], [672, 200], [676, 240], [700, 260]]), K, 6);
    fill(sm([[648, 270], [680, 246], [700, 266], [720, 240], [736, 250], [736, 320], [714, 340], [690, 330], [662, 340], [644, 310]]), '#17f6ac');
    stroke(ellipseP(672, 410, 10, 32, -0.1), '#c8c8d0', 3);
    fill(circleP(697, 362, 6), '#40e0f0');
    // neck skin
    fill(sm([[460, 640], [560, 600], [610, 540], [650, 560], [660, 640], [640, 690], [470, 700]]), '#f2a688');
    clip(sm([[460, 640], [560, 600], [560, 700], [460, 700]]), () => { for (let y = 600; y < 700; y += 5) for (let x = 460; x < 560; x += 5) fill(circleP(x, y, 1.4 * (1 - (x - 460) / 120)), '#a04020'); });
    // yellow stroke right
    stroke(open([[650, 470], [690, 440], [736, 428]]), '#f8e020', 10);

    // ── collar + mesh ──
    const mesh = poly([[456, 760], [736, 720], [736, 880], [600, 900], [470, 900]]);
    fill(mesh, hatch([0.62, 0.62, 0.64], [0.2, 0.2, 0.22], 6, 0.22));
    stroke(open([[580, 800], [650, 790], [736, 760]]), '#f8f020', 14);
    fill(poly([[455, 686], [736, 670], [736, 728], [460, 774]]), '#082a6c');
    stroke(open([[455, 686], [736, 670]]), '#d0e0f0', 4);
    stroke(open([[460, 772], [736, 726]]), '#d0e0f0', 5);
    fill(poly([[516, 690], [528, 690], [532, 760], [520, 762]]), '#4060b0');

    // ── helmet glass + face ──
    const helm = sm([[166, 400], [172, 260], [196, 130], [240, 50], [310, 6], [420, -6], [520, 10], [590, 80], [636, 200], [652, 330], [650, 460], [630, 570], [592, 640], [500, 690], [380, 694], [300, 664], [240, 610], [196, 530]]);
    // dark cap under the glass
    fill(sm([[236, 60], [300, 14], [420, 2], [500, 30], [520, 110], [440, 96], [360, 104], [300, 150], [260, 150]]), '#4a4454');
    for (const [x0, y0, x1, y1] of [[300, 40], [330, 70], [290, 90], [350, 34]].map(([x, y]) => [x, y, x + 26, y - 10])) stroke(open([[x0, y0], [x1, y1]]), '#c0bcc8', 5);
    // face
    const face = sm([[256, 112], [330, 96], [420, 92], [500, 100], [560, 140], [610, 240], [640, 350], [644, 460], [620, 540], [580, 600], [520, 648], [440, 672], [384, 666], [346, 640], [330, 600], [324, 572], [306, 540], [300, 500], [304, 470], [290, 446], [252, 432], [236, 412], [242, 372], [238, 334], [226, 296], [222, 236], [234, 164]]);
    fill(face, hatch([0.62, 0.61, 0.66], [0.26, 0.25, 0.30], 7, 0.2));
    clip(face, () => {
      fill(sm([[600, 420], [650, 420], [650, 620], [560, 660], [590, 560]]), 'rgba(40,36,48,0.55)');
      fill(sm([[540, 470], [600, 450], [610, 530], [570, 560]]), 'rgba(40,36,48,0.6)');
      fill(circleP(574, 488, 8), W); fill(circleP(584, 528, 7), W);
    });
    stroke(face, W, 3);
    // nose shading
    stroke(open([[300, 400], [318, 430], [300, 450], [268, 440]]), K, 5);
    // splash: magenta, yellow, cyan + dots
    fill(sm([[588, 240], [630, 300], [642, 400], [600, 444], [560, 452], [480, 442], [452, 412], [470, 380], [520, 360], [574, 330]]), '#f8c608');
    fill(sm([[500, 190], [556, 186], [590, 256], [576, 330], [520, 362], [480, 410], [430, 404], [414, 372], [440, 340], [482, 322], [500, 270], [494, 214]]), '#d808f6');
    fill(sm([[364, 372], [392, 360], [418, 374], [414, 400], [380, 406], [362, 394]]), '#06eef8');
    fill(sm([[530, 204], [548, 200], [560, 214], [548, 228], [532, 222]]), '#30b0f8');
    for (const [x, y, rr] of [[476, 406, 13], [546, 400, 16], [590, 380, 7], [610, 300, 5], [598, 330, 4], [568, 312, 3], [520, 440, 5], [604, 410, 4]]) fill(circleP(x, y, rr), '#c010e0');
    for (const [x, y, rr] of [[540, 300, 5], [560, 350, 3], [600, 280, 3]]) fill(circleP(x, y, rr), '#f8e0f8');
    // lips
    fill(sm([[300, 506], [330, 490], [370, 494], [410, 488], [440, 490], [420, 520], [380, 540], [350, 566], [330, 572], [316, 556], [324, 530]]), '#f04680');
    fill(sm([[334, 516], [380, 506], [420, 498], [404, 518], [370, 530], [340, 532]]), '#f0d8a8');
    stroke(open([[330, 515], [380, 504], [430, 494]]), '#801030', 3);
    fill(sm([[318, 520], [330, 530], [326, 548], [314, 540]]), '#ffb0c8');
    // goggles
    for (const [x, y, ro, ri] of [[395, 215, 72, 60], [245, 275, 50, 38]]) {
      fill(circleP(x, y, ro + 4), K);
      fill(circleP(x, y, ro), rad(x - ro * 0.3, y - ro * 0.3, 0, ro, [[0, '#f0f0f4'], [0.5, '#9a9aa4'], [1, '#3a3a44']]));
      fill(circleP(x, y, ri + 3), K);
      fill(circleP(x, y, ri), rad(x - ri * 0.2, y - ri * 0.2, 0, ri, [[0, '#8cb080'], [0.7, '#7aa071'], [1, '#5a7a54']]));
    }
    fill(circleP(410, 213, 12), W); fill(circleP(440, 240, 4), W);
    stroke(open([[226, 290], [264, 266]]), W, 6);
    fill(circleP(300, 190, 6), W);
    // glass: tint + outline + highlights
    clip(helm, () => { fill(helm, 'rgba(220,226,240,0.10)'); });
    stroke(helm, W, 3.5);
    o.save(); o.translate(10, 6); stroke(open([[176, 400], [182, 270], [206, 140], [250, 60], [316, 16]]), 'rgba(255,255,255,0.7)', 2); o.restore();
    fill(circleP(214, 170, 22), 'rgba(230,236,240,0.35)');
    fill(circleP(484, 110, 18), 'rgba(240,240,244,0.85)');
    fill(sm([[210, 76], [232, 60], [240, 80], [222, 108], [206, 100]]), '#2050e0');

    // ── pale hazard bars (inside a diagonal strip) ──
    const strip = poly([[156, 450], [230, 420], [350, 720], [280, 770]]);
    clip(strip, () => { for (let k = -2; k < 14; k++) { const x = 170 + k * 15, y = 450 + k * 26; fill(poly([[x, y + 40], [x + 60, y - 20], [x + 74, y - 6], [x + 14, y + 54]]), PALE); } });

    // ── polka-dot dark sleeve (left) ──
    const sleeve = sm([[-10, 482], [60, 462], [130, 470], [180, 500], [220, 560], [262, 640], [306, 720], [340, 800], [320, 840], [240, 850], [160, 860], [80, 840], [-10, 800]]);
    fill(sleeve, '#1f1d29');
    clip(sleeve, () => {
      stroke(open([[44, 500], [120, 540], [170, 590], [190, 630]]), W, 16);
      stroke(open([[16, 704], [60, 760], [120, 810], [160, 840]]), W, 14);
      stroke(open([[0, 510], [40, 490], [80, 486]]), '#5a5868', 6);
      for (const [x, y, rr] of [[26, 556, 22], [95, 626, 22], [160, 662, 25], [76, 690, 20], [136, 726, 32], [190, 760, 8], [40, 610, 6], [250, 760, 5]]) fill(circleP(x, y, rr), W);
    });
    fill(circleP(148, 545, 16), '#e03060'); fill(circleP(148, 545, 8), '#f8a0c0'); fill(circleP(148, 545, 4), '#e03060');
    for (const [x, y, rr] of [[264, 724, 6], [290, 768, 10]]) fill(circleP(x, y, rr), '#f03070');
    // red object far left
    fill(sm([[-10, 780], [30, 790], [50, 860], [48, 960], [30, 1000], [-10, 1004]]), '#c44941');
    clip(sm([[-10, 780], [30, 790], [50, 860], [48, 960], [30, 1000], [-10, 1004]]), () => { for (let y = 780; y < 1010; y += 6) for (let x = -6; x < 52; x += 6) fill(circleP(x + (y / 6 % 2) * 3, y, 1.3), '#f08070'); });

    // ── zebra stripes (bottom) ──
    const zone = sm([[80, 1034], [96, 930], [140, 872], [260, 846], [320, 860], [470, 900], [600, 900], [736, 870], [736, 1034]]);
    fill(zone, pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float u = p.x * 0.4455 + p.y * 0.8953, w = (-p.x * 0.8953 + p.y * 0.4455) / 100.;
      float f = u / 74.35 + 4.2951 + 0.08633 * w * w - 0.03945 * w - 0.01769 * w * w * w;
      float v = sin(f * 6.2832); return mix(vec3(.02), vec3(.99), smoothstep(-.1, .1, v)); }`)));
    stroke(open([[620, 960], [700, 900], [736, 880]]), '#e03060', 4);

    // ── grey sponge cluster ──
    const sp = rng(7);
    for (let i = 0; i < 60; i++) {
      const t = sp(), x = 316 + t * 200 + (sp() - 0.5) * 60, y = 770 + t * 170 + (sp() - 0.5) * 70, rr = 8 + sp() * 14;
      fill(circleP(x, y, rr + 1.5), '#2a2a30');
      fill(circleP(x, y, rr), rad(x - rr * 0.3, y - rr * 0.3, 0, rr, [[0, '#b8b8c0'], [0.6, '#8a8a94'], [1, '#5a5a64']]));
      fill(circleP(x - rr * 0.35, y - rr * 0.35, rr * 0.18), '#e8e8f0');
    }

    E.grain(0.035, 100);
  }
});
