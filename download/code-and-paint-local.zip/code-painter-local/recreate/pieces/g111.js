'use strict';
// g111 — "Mirrored clay reacher": a pale-blue clay figure reaches across a black void of green pools,
// zebra swirls and a striped halo above; below a shelf line its mirror world — sunset, yellow moon, clay blobs.
REC.register('g111', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipBoth = (path, fn) => { a.save(); R.h.save(); a.clip(path); R.h.clip(path); fn(); a.restore(); R.h.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, r1, stops, x1 = x, y1 = y) => { const g = a.createRadialGradient(x, y, r0, x1, y1, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const stroke = (path, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.lineCap = a.lineJoin = 'round'; a.stroke(path); };
    const fill = (path, c) => { a.fillStyle = c; a.fill(path); };

    // ── GLSL fields ──
    const sky = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float y = p.y;
      vec3 c = mix(vec3(.05,.03,.02), vec3(.14,.08,.13), smoothstep(0., 30., y));
      c = mix(c, vec3(.29,.22,.41), smoothstep(30., 60., y));
      c = mix(c, vec3(.41,.34,.72), smoothstep(60., 90., y));
      c = mix(c, vec3(.53,.46,.93), smoothstep(90., 150., y));
      c = mix(c, vec3(.62,.58,.97), smoothstep(150., 250., y));
      c = mix(c, vec3(.40,.25,.30), smoothstep(300., 400., y));
      c = mix(c, vec3(.22,.10,.10), smoothstep(380., 440., y));
      float s = step(.997, hash(floor(p / 2.))) * (1. - smoothstep(40., 120., y));
      return c + s * .7; }`));
    const space = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(.025, .022, .025);
      float s = step(.993, hash(floor(p / 2.))) * (.4 + .6 * hash(floor(p / 2.) + 3.1));
      return c + s * .75; }`));
    // upper-right swirl: vertical stripes bending to a downhill diagonal on the right
    // stripe phase fields: low-order polynomials whose coefficients were fitted offline to the stripe flow
    const zebT = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 n = (p - vec2(550., 150.)) / vec2(180., 150.); float X = n.x, Y = n.y;
      float X2 = X * X, Y2 = Y * Y, X3 = X2 * X, Y3 = Y2 * Y;
      float f = 0.1870 + 5.7424*Y - 4.8851*X - 1.5607*Y2 + 5.5666*X*Y + 1.8045*X2 - 10.9339*Y3 + 8.9215*X*Y2 - 8.1264*X2*Y - 8.6631*X3
        - 3.2600*Y2*Y2 + 7.3979*X*Y3 - 9.5931*X2*Y2 - 7.6891*X3*Y - 1.4142*X2*X2 + 10.0873*Y3*Y2 - 16.6293*X*Y2*Y2 + 25.2832*X2*Y3
        - 11.9641*X3*Y2 + 3.7744*X2*X2*Y + 6.0526*X3*X2 + 5.2319*Y3*Y3 - 12.4089*X*Y3*Y2 + 24.3435*X2*Y2*Y2 - 23.3858*X3*Y3
        + 21.4905*X2*X2*Y2 + 4.5245*X3*X2*Y + 0.0357*X3*X3;
      float v = cos(6.2832 * f);
      return mix(vec3(.02), vec3(.95, .94, .92), smoothstep(-.12, .12, v)); }`));
    const zebB = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 n = (p - vec2(300., 890.)) / vec2(300., 130.); float X = n.x, Y = n.y;
      float X2 = X * X, Y2 = Y * Y, X3 = X2 * X, Y3 = Y2 * Y;
      float f = 0.3441 + 4.2880*Y - 13.2460*X + 1.1301*Y2 + 2.8482*X*Y - 2.3904*X2 - 1.2608*Y3 + 0.8945*X*Y2 - 3.5325*X2*Y + 7.6531*X3
        - 2.2317*Y2*Y2 - 0.3452*X*Y3 - 1.6509*X2*Y2 - 6.8391*X3*Y + 8.0292*X2*X2 - 0.7452*Y3*Y2 - 0.6167*X*Y2*Y2 + 3.7088*X2*Y3
        - 1.7500*X3*Y2 + 2.4029*X2*X2*Y - 5.4100*X3*X2 + 1.7602*Y3*Y3 - 0.3323*X*Y3*Y2 - 1.4784*X2*Y2*Y2 + 2.6572*X3*Y3
        + 1.3529*X2*X2*Y2 + 6.0401*X3*X2*Y - 5.8076*X3*X3;
      float v = cos(6.2832 * f);
      if (p.x < 60. && p.y < 745.) {
        n = (p - vec2(25., 630.)) / vec2(30., 140.); X = n.x; Y = n.y;
        f = -0.0164 + 4.9423*Y + 1.1574*X - 0.9435*Y*Y - 0.0795*X*Y - 0.0550*X*X - 1.3595*Y*Y*Y + 0.4094*X*Y*Y - 0.3763*X*X*Y + 0.0125*X*X*X
          - 0.3596*Y*Y*Y*Y + 0.2331*X*Y*Y*Y + 0.5817*X*X*Y*Y + 0.1822*X*X*X*Y - 0.0723*X*X*X*X;
        v = cos(6.2832 * f);
      }
      return mix(vec3(.02), vec3(.95, .94, .92), smoothstep(-.12, .12, v)); }`));
    // concentric halo arch
    const rings = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = vec2(p.x - 187.91, max(p.y - 37.73, 0.) * 1.0414);   // concentric U-shaped arches (fitted)
      float v = cos(6.2832 * (length(d) / 41.566 + .8963 + .00531 * p.y));
      return mix(vec3(.03), vec3(.95, .94, .92), smoothstep(-.15, .15, v)); }`));
    const fur = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(8., 148.);
      float an = atan(d.y, d.x), r = length(d);
      float n = vnoise(vec2(an * 60., r * .04)) * .6 + vnoise(vec2(an * 140., r * .1)) * .4;
      vec3 c = mix(vec3(.09, .10, .11), vec3(.30, .32, .33), n * n);
      return c * (1. - .5 * smoothstep(60., 110., r)); }`));
    const lace = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * .05), m = vnoise(p * .25);
      vec3 c = vec3(.10, .09, .09);
      c = mix(c, vec3(.42, .36, .30), smoothstep(.55, .62, n) * smoothstep(.3, .7, m));
      c = mix(c, vec3(.12, .11, .12), 1. - smoothstep(.0, .1, abs(n - .5)));
      return c; }`));

    // ════════ backgrounds (flat, unlit) ════════
    R.flat(rrect(-10, -10, 746, 480, 0), sky, 0, 0);
    R.flat(rrect(-10, 470, 746, 570, 0), space, 0, 0);

    // top-right zebra swirl, orange sun, pink blob
    const zTop = P([[436, -10], [736, -10], [736, 470], [560, 470], [470, 330], [420, 240], [392, 182], [376, 130], [384, 96], [400, 48]], true, false);
    R.flat(zTop, zebT, 0, 0);
    R.flat(circleP(745, 42, 104), '#5a3a20', 0.01, 0);
    R.flat(circleP(745, 42, 98), rad(720, 20, 10, 110, [[0, '#ff9a10'], [1, '#fc8c06']]), 0.02, 0);
    const pink = P([[736, 246], [690, 250], [656, 266], [638, 298], [630, 360], [620, 420], [606, 470], [736, 470]]);
    R.flat(pink, lin(0, 250, 0, 470, [[0, '#fda6fc'], [0.55, '#fdb0ec'], [1, '#fdc8c0']]), 0.02, 0);

    // striped halo arch behind the head
    const halo = ellipseP(188, -12, 138, 145);
    R.flat(halo, '#5a4848', 0.02, 0);
    R.flat(ellipseP(188, -12, 132, 139), '#050505', 0.03, 0);
    R.flat(ellipseP(188, -12, 124, 131), rings, 0.04, 0);

    // black furry blob with an eye (top-left)
    const fb = P([[-10, 76], [40, 74], [80, 84], [102, 108], [110, 150], [106, 192], [86, 220], [50, 230], [12, 228], [-10, 214]]);
    R.dome(fb, '#6e6266', 0.02, 0.05, 6, 3);
    const fbIn = P([[-10, 84], [38, 82], [74, 92], [94, 112], [101, 150], [98, 188], [80, 212], [48, 221], [12, 220], [-10, 206]]);
    R.flat(fbIn, fur, 0.03, 0);
    for (const [x0, y0, x1, y1] of [[36, 92, 38, 112], [52, 96, 52, 118], [66, 102, 62, 122], [80, 116, 72, 130], [88, 134, 78, 140], [92, 156, 80, 158]]) R.pipe(P([[x0, y0], [x1, y1]], false, false), 4, '#c8c4a0', 0.06, 0.04, 2);
    R.dome(circleP(8, 148, 9), '#e8e8e8', 0.04, 0.04, 4, 3);
    R.dome(circleP(8, 148, 5), '#080808', 0.06, 0.02, 3, 3);

    // ════════ upper void with green pools ════════
    const voidT = P([[150, 300], [215, 262], [228, 180], [262, 160], [300, 150], [340, 148], [378, 138], [392, 182], [405, 215], [430, 250], [472, 262], [482, 330], [500, 400], [540, 470], [140, 470], [140, 380]], true, true);
    R.flat(voidT, '#060706', 0.02, 0);
    const pool = (x, y, rx, ry, ang) => {
      R.dome(ellipseP(x, y, rx + 4, ry + 4, ang), '#6a6460', 0.03, 0.03, 4, 2);
      R.dome(ellipseP(x, y, rx, ry, ang), rad(x - rx * .2, y - ry * .2, 0, Math.max(rx, ry) * 1.1, [[0, '#70fa66'], [0.75, '#62f058'], [1, '#4ea848']]), 0.05, 0.03, Math.min(rx, ry) * 0.5, 2);
    };
    const poolsT = [[360, 179, 22, 20, 2.16], [306, 187, 20, 10, -2.75], [247, 252, 8, 7, 2.4], [406, 267, 12, 8, -3.0], [322, 266, 45, 30, -2.93], [248, 294, 21, 19, 2.46],
      [432, 300, 21, 20, 2.95], [383, 300, 12.5, 12, 2.26], [292, 314, 9, 9, 0], [365, 329, 14.5, 13.6, 1.2], [322, 335, 19, 16.5, -2.48], [271, 340, 19.5, 17.5, -2.57],
      [347, 363, 11, 10, 2.1], [336, 391, 9.5, 7.6, 1.6], [221, 412, 70, 54, -3.0], [336, 431, 13, 8.6, 1.37], [425, 436, 32, 20, -2.57]];
    for (const p of poolsT) pool(...p);
    const br = rng(5);
    for (let i = 0; i < 40; i++) { const x = 150 + br() * 330, y = 160 + br() * 300; if (!a.isPointInPath(voidT, x * S, y * S)) continue; R.bead(x, y, 1.5 + br() * 3, br() < 0.5 ? '#9a70d8' : '#8a8888', 0.05, 0.02, 2); }

    // ════════ upper clay figures ════════
    const BL = '#b8daf0';
    // small glove hand top-left
    for (const f of [[[24, 18], [14, -6]], [[18, 30], [2, 44]], [[24, 34], [16, 58]], [[32, 32], [38, 58]], [[34, 20], [54, 16]]]) R.pipe(P(f, false, false), 12, BL, 0.06, 0.08, 1);
    R.dome(ellipseP(26, 25, 15, 13, 0), BL, 0.06, 0.1, 9, 1);

    // reaching figure: one silhouette for torso, neck, shoulder and arm
    const body = P([[-10, 264], [60, 262], [98, 246], [124, 218], [138, 182], [152, 156], [178, 140], [206, 128], [240, 128], [262, 150], [258, 166], [252, 176], [300, 192], [360, 210],
      [420, 230], [466, 246], [474, 258], [468, 274], [420, 264], [360, 250], [300, 238], [252, 234], [228, 240], [220, 266], [208, 292], [188, 314], [160, 340], [142, 366], [134, 400],
      [132, 462], [30, 462], [28, 420], [20, 398], [-10, 392]]);
    R.dome(body, lin(40, 160, 200, 460, [[0, '#cdeafb'], [0.45, '#b6d8ee'], [0.8, '#9cb6cc'], [1, '#86788a']]), 0.08, 0.22, 42, 1);
    // hand with fingers down
    const hand = P([[452, 246], [474, 234], [490, 238], [488, 252], [496, 266], [502, 296], [501, 322], [489, 327], [481, 312], [479, 296], [468, 300], [458, 324], [446, 332], [449, 300], [446, 272]]);
    R.dome(hand, '#b2d2ea', 0.14, 0.12, 10, 1);
    // head
    const head = P([[205, 60], [230, 44], [262, 48], [284, 70], [290, 96], [297, 114], [289, 124], [286, 138], [266, 152], [240, 150], [217, 138], [199, 116], [196, 86]]);
    R.dome(head, lin(200, 50, 290, 150, [[0, '#d0ecfb'], [0.6, '#bcdcf0'], [1, '#a4c2da']]), 0.2, 0.16, 34, 1);
    R.dome(ellipseP(233, 102, 5, 9, 0.1), '#a8c8e0', 0.3, 0.03, 4, 1);
    R.groove(P([[272, 99], [281, 98]], false, false), 2, '#8aa2b8', 0.34, 0.01, 1, 0.4);
    // tiny figurine above the arm
    R.dome(P([[433, 173], [445, 177], [449, 189], [444, 195], [453, 200], [454, 207], [467, 204], [463, 215], [455, 217], [442, 234], [429, 231], [436, 206]]), BL, 0.1, 0.08, 6, 1);
    // colourful petals
    for (const [x, y, c] of [[497, 190, '#ff8a20'], [500, 212, '#ff5a1a'], [520, 190, '#30d0a0'], [532, 182, '#ffc020'], [494, 200, '#ffd040']]) R.dome(ellipseP(x, y, 6, 4, 0.6), c, 0.1, 0.05, 3, 2);

    // big thumb blob (right): lit on the left, mauve shadow on the right + arch tube
    const thumb = P([[486, 252], [520, 214], [556, 180], [586, 152], [606, 158], [618, 200], [627, 270], [632, 350], [626, 400], [612, 440], [600, 470], [530, 470], [508, 430], [474, 382], [440, 360], [470, 345], [490, 322], [482, 290]]);
    R.dome(thumb, lin(500, 0, 630, 0, [[0, '#b4d2e6'], [0.3, '#a6c2d8'], [0.62, '#867e8c'], [1, '#64505a']]), 0.08, 0.2, 40, 1);
    R.dome(ellipseP(545, 272, 14, 10, 0.4), '#8a8494', 0.22, -0.06, 8, 1);
    const tube = P([[374, 470], [368, 420], [376, 376], [404, 352], [440, 354], [470, 376], [500, 414], [520, 470]], false, true);
    R.pipe(tube, 38, lin(350, 0, 520, 0, [[0, '#bcdcf0'], [0.6, '#a8c4da'], [1, '#8a8c9a']]), 0.1, 0.14, 1);

    // ════════ lower world (below the shelf) ════════
    clipBoth(rrect(-10, 486, 746, 560, 0), () => {
    // sunset in the gap
    const sunGap = P([[100, 486], [240, 486], [228, 560], [224, 650], [232, 710], [248, 780], [100, 780]], true, false);
    R.flat(sunGap, lin(0, 490, 0, 760, [[0, '#a68ad8'], [0.2, '#e0a0c8'], [0.4, '#f0a4a8'], [0.55, '#f07040'], [0.68, '#f42818'], [1, '#d01020']]), 0, 0);
    a.save(); a.clip(sunGap);
    for (let y = 662; y < 760; y += 9) stroke(P([[100, y], [240, y]], false, false), 'rgba(255,170,60,0.55)', 2.5);
    a.restore();
    R.flat(circleP(173, 608, 54), rad(173, 608, 40, 56, [[0, 'rgba(255,240,230,0.9)'], [1, 'rgba(255,200,200,0)']]), 0, 0);
    R.flat(circleP(173, 608, 44.5), '#fffcfa', 0, 0);

    // zebra below
    const zBot = P([[-10, 486], [44, 486], [42, 600], [48, 690], [80, 745], [130, 770], [200, 776], [250, 780], [280, 830], [320, 862], [400, 856], [460, 820], [470, 700], [492, 700], [520, 800], [560, 828], [604, 870], [624, 918], [604, 962], [550, 992], [470, 1012], [430, 1034], [-10, 1034]], true, true);
    R.flat(zBot, zebB, 0, 0);

    // yellow moon with a black peanut
    R.flat(circleP(606, 473, 198), '#4a3020', 0.01, 0);
    R.flat(circleP(606, 473, 194), rad(720, 490, 10, 230, [[0, '#fcd4a6'], [0.35, '#fbe894'], [0.7, '#fbfa86'], [1, '#fbfd80']]), 0.02, 0);
    R.dome(P([[580, 545], [592, 528], [612, 530], [628, 545], [644, 534], [668, 530], [690, 545], [684, 566], [664, 576], [640, 566], [620, 574], [596, 572]]), '#060505', 0.03, 0.02, 4, 0);
    R.flat(ellipseP(720, 496, 14, 6, 0), '#70e8f8', 0.03, 0);

    // lower void
    const voidB = P([[222, 486], [480, 486], [482, 600], [470, 700], [486, 750], [478, 800], [446, 830], [400, 850], [340, 864], [298, 852], [268, 815], [248, 772], [232, 700], [222, 620]], true, true);
    R.flat(voidB, '#050505', 0.02, 0);
    R.flat(P(blob(290, 560, 58, 70, 7, 16, 0.18)), lace, 0.025, 0);
    const poolsB = [[448, 524, 27, 24, -2.66], [354, 527, 16, 11, 1.68], [419, 545, 10, 4, 1.44], [339, 556, 13, 12, 2.05], [352, 597, 9, 5, 1.61], [258, 634, 30, 26, 0.89],
      [326, 675, 18, 15.6, 2.8], [239, 682, 12, 11, 2.7], [333, 706, 14, 10.8, 2.6], [296, 707, 12.8, 12, -2.39], [260, 723, 17, 16, 2.47], [320, 735, 12.3, 10, -2.37],
      [381, 737, 35, 22, -2.54], [289, 757, 16.8, 15, 2.86], [445, 777, 30, 11.5, 2.21], [411, 777, 12, 11.4, 1.8], [317, 783, 11.3, 10.7, 2.62], [361, 790, 25, 20, 2.47],
      [284, 806, 24.5, 15.8, 1.69], [403, 816, 17.8, 15.8, 2.38], [319, 820, 18, 12.7, 1.13], [299, 842, 9, 7.5, 0]];
    for (const p of poolsB) pool(...p);
    R.dome(P([[268, 690], [290, 676], [306, 668], [296, 690], [276, 700]]), '#f01c18', 0.06, 0.04, 4, 2);
    for (let i = 0; i < 50; i++) { const x = 225 + br() * 255, y = 490 + br() * 360; if (!a.isPointInPath(voidB, x * S, y * S)) continue; R.bead(x, y, 1.5 + br() * 3, br() < 0.5 ? '#9a70d8' : '#8a8888', 0.05, 0.02, 2); }

    // left boot blob (mirror of the leg)
    const boot = P([[30, 486], [180, 486], [182, 502], [178, 515], [166, 535], [149, 556], [126, 579], [114, 605], [113, 634], [122, 667], [139, 695], [176, 738], [182, 762], [170, 770], [135, 766], [95, 750], [64, 719], [50, 670], [46, 600], [44, 550], [36, 515]]);
    R.dome(boot, lin(40, 0, 180, 0, [[0, '#66525c'], [0.35, '#8a8c9c'], [0.7, '#b4d4e8'], [1, '#c8e8f8']]), 0.08, 0.2, 36, 1);
    // vase blob with a cup
    const vase = P([[372, 490], [394, 490], [396, 508], [411, 512], [416, 552], [423, 568], [450, 572], [470, 556], [474, 520], [470, 490], [540, 490], [541, 535], [532, 570], [517, 594], [492, 619], [490, 672], [480, 700], [465, 718], [440, 726], [410, 716], [380, 700], [362, 680], [354, 650], [356, 606], [364, 570], [364, 515]]);
    R.dome(vase, lin(370, 700, 520, 520, [[0, '#64505a'], [0.3, '#8a8a98'], [0.55, '#b4d4e8'], [1, '#c0e2f4']]), 0.08, 0.2, 34, 1);
    R.dome(rrect(370, 492, 24, 28, 4), '#e4ecf2', 0.2, 0.06, 6, 4);
    R.dome(ellipseP(382, 516, 13, 5, 0), '#c8d0d8', 0.24, 0.04, 4, 4);
    // creature with a lilac ball and pink lump
    const crit = P([[476, 680], [478, 692], [515, 691], [514, 706], [478, 740], [476, 777], [483, 791], [498, 804], [510, 808], [535, 802], [555, 804], [572, 817], [585, 834], [609, 804], [630, 800], [626, 772], [613, 779], [594, 776], [586, 764], [586, 748], [600, 698], [621, 675], [630, 657], [626, 630], [612, 622], [591, 628], [554, 668], [540, 667], [529, 640], [513, 632], [511, 669], [491, 673]]);
    R.dome(crit, lin(480, 800, 620, 640, [[0, '#8a909e'], [0.35, '#a8c4d8'], [0.7, '#c0e0f2'], [1, '#b4d2e6']]), 0.08, 0.2, 26, 1);
    R.dome(ellipseP(566, 722, 12, 16, 0.3), '#a8c0d6', 0.24, 0.06, 9, 1);
    R.dome(circleP(645, 776, 22), rad(638, 768, 2, 26, [[0, '#c8a8fc'], [1, '#9070e8']]), 0.1, 0.18, 20, 5);
    R.dome(ellipseP(508, 783, 24, 14, 0.05), '#d090e8', 0.12, 0.12, 12, 5);

    });

    // ════════ the shelf bar ════════
    R.flat(rrect(-10, 462, 746, 30, 0), '#040302', 0.1, 0);
    R.pipe(P([[-10, 465.5], [736, 465.5]], false, false), 5, '#c8a88c', 0.12, 0.04, 6);
    R.pipe(P([[-10, 487.5], [736, 487.5]], false, false), 5, '#d0ae88', 0.12, 0.04, 6);
    R.flat(rrect(340, 466, 72, 20, 2), '#1a1a1a', 0.12, 4);
    for (const x of [348, 366, 384, 402]) R.dome(ellipseP(x, 476, 6, 7, 0), '#d0d4d8', 0.13, 0.04, 3, 4);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 30, wrap: 0.6, ao: 0.6, coat: 0.12, rim: 0.15 }),      // 1 blue clay
        E.mat({ dif: 1, spec: 0.6, shin: 50, wrap: 0.5, ao: 0.4, coat: 0.15 }),                  // 2 green pools
        E.mat({ dif: 1, spec: 0.3, shin: 30, wrap: 0.6, ao: 0.4 }),                              // 3 fur blob
        E.mat({ dif: 0.6, spec: 1, shin: 60, metal: 0.6, ao: 0.4, coat: 0.3 }),                  // 4 chrome bits
        E.mat({ dif: 1, spec: 0.7, shin: 45, wrap: 0.5, ao: 0.4, coat: 0.15 }),                  // 5 lilac
        E.mat({ dif: 1, spec: 0.6, shin: 40, wrap: 0.4, ao: 0.3, coat: 0.1 })                    // 6 shelf
      ],
      light: [-0.45, 0.55, 0.7], lc: [0.48, 0.55, 0.55], amb: [0.6, 0.52, 0.56],
      envTop: [1, 1, 1], envHor: [0.6, 0.55, 0.65], envBot: [0.2, 0.15, 0.2], envK: [0.2, 0.8, 0.3, 0],
      r1: 2.5, r2: 9, k: [0, 0.6, 0.4, 60], shadow: [4, 6, 0.5, 6]
    });
    E.grain(0.03, 111);
  }
});
