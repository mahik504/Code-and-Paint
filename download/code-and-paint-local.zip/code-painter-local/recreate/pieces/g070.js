'use strict';
// g070 — "Kintsugi porcelain muse": a glossy grey porcelain bust whose face is half sheathed in a
// cracked gold mask with three black-bead eyes, a coiled gold ear cuff and black lips, over a zebra-
// striped ruffled gown studded with amber, pearls and speckled stones, against blue light and grey.
REC.register('g070', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    keep();
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const himg = (path, cv) => { R.h.save(); R.h.clip(path); R.h.setTransform(1, 0, 0, 1, 0, 0); R.h.drawImage(cv, 0, 0); R.h.restore(); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const GOLD = '#e6cb92', POR = '#c4bfb2';

    // ── backdrop: blue light strip fading to white, dark grey studio on the right ──
    R.flat(rrect(-10, -10, 746, 1044, 0), lin(0, 0, 330, 0, [[0, '#0a6cb5'], [0.1, '#0b72bb'], [0.2, '#3a8ac8'], [0.32, '#9cbbdc'], [0.45, '#dfe6ef'], [0.6, '#fdfcf8'], [1, '#fefefe']]), 0, 0);
    R.flat(rrect(326, -10, 420, 1044, 0), '#444445', 0, 0);
    soft(x => { x.fillStyle = '#5a5a5c'; x.fill(ellipseP(560, 300, 160, 260, 0)); }, 60, 0.6);

    // ── zebra gown (right) ──
    const ZB = `
      float zl(vec2 p, float thd, float P, float ph){ float th = radians(thd); return cos(6.2832 * (p.x * cos(th) + p.y * sin(th)) / P - ph); }
      float zs(vec2 p){
        float ruf = smoothstep(700., 560., p.y) * smoothstep(470., 560., p.x);
        vec2 q = p + ruf * vec2(10. * sin(p.y * 0.06), 34. * sin(p.x * 0.045 + 1.));
        float bx = smoothstep(480., 520., p.x + 12. * sin(p.y * 0.04)), by = smoothstep(805., 845., p.y + 12. * sin(p.x * 0.05));
        float top = mix(zl(q, -9., 56., -2.165), zl(q, -57., 45.5, -2.918), bx);
        float bot = mix(zl(q, -30., 54.5, -0.538), zl(q, -45., 62., -0.266), bx);
        return mix(top, bot, by);
      }`;
    const zAlb = pat(E.fx(ZB + `vec3 fx(vec2 uv, vec2 p){ float s = zs(p);
      return mix(vec3(0.03), vec3(0.96, 0.94, 0.86), smoothstep(-0.12, 0.12, s)); }`));
    const gown = P([[372, 650], [430, 606], [500, 560], [520, 480], [548, 420], [584, 400], [612, 440], [650, 470], [740, 446], [740, 1044], [430, 1044], [400, 920], [384, 800]]);
    R.dome(gown, zAlb, 0.12, 0.14, 60, 4);
    // shadowed gap under the arm
    R.flat(P([[330, 800], [390, 790], [410, 900], [430, 1044], [330, 1044]], true, false), lin(330, 800, 420, 1044, [[0, '#2a2828'], [1, '#6a6668']]), 0.08, 0);
    clipA(P([[330, 800], [390, 790], [410, 900], [430, 1044], [330, 1044]], true, false), () => { a.fillStyle = 'rgba(230,226,215,0.5)'; for (let i = 0; i < 6; i++) a.fill(P([[330 + i * 22, 1044], [344 + i * 22, 1044], [362 + i * 16, 790], [350 + i * 16, 790]], true, false)); });
    keep();

    // ── neck, shoulder, gold rim ──
    const neck = P([[240, 560], [290, 598], [380, 598], [436, 556], [456, 640], [430, 720], [404, 800], [398, 900], [430, 1044], [220, 1044], [250, 900], [270, 780], [272, 680]]);
    R.dome(neck, lin(200, 600, 440, 900, [[0, '#d2cdc2'], [0.5, '#b4ae9f'], [1, '#9a9488']]), 0.2, 0.2, 70, 1);
    const sh = P([[-10, 850], [50, 812], [130, 800], [200, 812], [250, 860], [290, 940], [310, 1044], [-10, 1044]]);
    R.dome(sh, '#d6d1c6', 0.22, 0.24, 90, 1);
    R.pipe(P([[-10, 880], [40, 900], [80, 940], [106, 990], [114, 1044]], false), 34, '#e3c58a', 0.4, 0.12, 2);
    keep();

    // ── the head: grey shell, gold mask, face ──
    const head = P([[96, 430], [86, 300], [88, 200], [110, 120], [160, 60], [230, 24], [310, 10], [392, 18], [452, 50], [494, 100], [522, 180], [548, 258], [578, 330], [582, 420], [562, 500], [522, 550],
      [462, 572], [420, 578], [380, 602], [330, 608], [280, 602], [230, 576], [190, 532], [160, 476]]);
    R.dome(head, '#c8c3b6', 0.3, 0.2, 60, 1);
    const gold = P([[106, 340], [100, 250], [116, 170], [160, 100], [232, 58], [312, 44], [392, 52], [450, 84], [484, 142], [506, 212], [542, 272], [570, 340], [574, 420], [554, 490], [514, 540], [466, 560],
      [428, 552], [416, 500], [420, 440], [412, 362], [384, 322], [342, 300], [300, 298], [268, 310], [242, 350], [216, 386], [196, 420], [172, 410], [140, 384], [118, 362]], true, true);
    R.dome(gold, lin(120, 60, 560, 520, [[0, '#d6b77a'], [0.35, '#f2e3bd'], [0.6, '#ecd6a4'], [1, '#d8b878']]), 0.34, 0.22, 70, 2);
    // brushed swirl on the forehead
    for (let i = 0; i < 18; i++) R.groove(P([[120 + i * 4, 170 + i * 5], [180 + i * 3, 140 + i * 4], [260 + i * 2, 150 + i * 3], [330, 170 + i * 2]], false), 2, '#b8955a', 0.48, 0.015, 2, 0.5);
    // kintsugi cracks
    for (const c of [[[340, 120], [370, 150], [420, 170], [450, 210], [470, 260], [452, 300], [462, 360], [440, 420], [420, 470]], [[452, 300], [500, 290], [540, 310]], [[470, 260], [500, 240], [508, 200]], [[214, 386], [210, 430], [196, 450]]])
      R.groove(P(c, false), 3, '#8a6a2a', 0.5, 0.04, 2, 0.9);
    // face plane, nose, lips
    R.dome(P([[200, 420], [240, 360], [290, 316], [350, 312], [400, 340], [414, 420], [410, 520], [380, 580], [320, 598], [260, 580], [214, 530]]), '#cbc6ba', 0.3, 0.1, 60, 1);
    R.dome(P([[292, 318], [330, 300], [356, 330], [372, 380], [366, 410], [336, 422], [298, 412], [276, 384], [282, 350]]), '#d0cbbf', 0.42, 0.14, 26, 1);
    R.dome(P([[280, 500], [300, 480], [330, 472], [362, 474], [384, 482], [368, 506], [332, 520], [298, 516]]), '#0e0c0e', 0.44, 0.06, 12, 3);
    keep();

    // ── eyes and beads ──
    const hole = (x, y, rr, rim) => { R.dome(circleP(x, y, rr + 8), rim, 0.42, 0.06, 8, rim === GOLD ? 2 : 1); R.flat(circleP(x, y, rr), '#050505', 0.3, 0); };
    hole(237, 318, 28, '#d0cbbf'); hole(380, 233, 30, GOLD);
    R.dome(circleP(325, 86, 40), '#d8d4ca', 0.4, 0.06, 10, 1); R.bead(325, 86, 32, '#0a0a0c', 0.44, 0.2, 3);
    for (const [x, y, w, h] of [[404, 66, 22, 18], [398, 98, 10, 8], [420, 92, 8, 8]]) R.dome(rrect(x - w / 2, y - h / 2, w, h, 2), '#f4f2ee', 0.5, 0.02, 2, 1);
    R.bead(520, 400, 18, '#d8bc80', 0.44, 0.08, 2); R.bead(520, 400, 13, '#0a0a0c', 0.5, 0.12, 3);
    R.bead(546, 376, 15, '#e89a20', 0.48, 0.12, 5);
    R.bead(576, 370, 11, '#0a0a0c', 0.46, 0.1, 3); R.bead(580, 318, 9, '#0a0a0c', 0.46, 0.1, 3); R.bead(560, 296, 6, '#0a0a0c', 0.46, 0.08, 3);
    R.bead(420, 540, 20, '#d8bc80', 0.44, 0.06, 2); R.bead(420, 540, 13, '#0a0a0c', 0.48, 0.04, 3);
    R.bead(464, 512, 11, '#f2f0ea', 0.5, 0.08, 1); R.bead(502, 494, 9, '#f2f0ea', 0.5, 0.08, 1);
    // ear + gold coil cuff + earring
    R.dome(P([[120, 440], [160, 432], [196, 470], [196, 520], [170, 530], [140, 500]]), '#c8c3b6', 0.32, 0.12, 20, 1);
    R.flat(circleP(166, 514, 8), '#050505', 0.3, 0);
    const coil = new Path2D(); coil.addPath(rrect(-66, -32, 132, 64, 30), new DOMMatrix().translate(98, 408).rotate(-18));
    R.dome(coil, '#e0bf7a', 0.4, 0.2, 26, 2);
    for (let i = 0; i < 9; i++) { const t = -40 + i * 9; R.groove(P([[98 + t * 0.96 - 10, 410 - t * 0.28 - 24], [98 + t * 0.96 + 8, 410 - t * 0.28 + 26]], false), 3, '#9a7230', 0.62, 0.04, 2, 0.7); }
    for (const [x, y, rr] of [[214, 548, 16], [224, 576, 18], [218, 604, 14], [232, 598, 10]]) R.bead(x, y, rr, '#d8b46c', 0.4, 0.12, 2);
    keep();

    // ── gems on the gown ──
    const amber = (x, y, rx, ry, rot) => R.dome(ellipseP(x, y, rx, ry, rot), '#e88a10', 0.4, 0.14, Math.min(rx, ry), 5);
    amber(690, 480, 40, 22, -0.3); amber(672, 700, 58, 28, -0.1); amber(700, 806, 34, 24, -0.4);
    for (const [x, y, rx, ry, rot] of [[700, 742, 28, 20, -0.3], [662, 884, 30, 18, -0.2], [698, 516, 20, 16, 0], [714, 870, 16, 12, 0]]) R.dome(ellipseP(x, y, rx, ry, rot), '#f6f4ee', 0.38, 0.12, 16, 1);
    for (const [x, y, rr] of [[650, 478, 12], [680, 536, 15], [716, 620, 17], [700, 870, 8]]) R.bead(x, y, rr, '#0a0a0c', 0.4, 0.14, 3);
    R.dome(ellipseP(686, 578, 34, 26, 0.3), '#d8d2c4', 0.38, 0.12, 20, 1);
    clipA(ellipseP(686, 578, 34, 26, 0.3), () => { const sr = rng(70); a.fillStyle = '#4a4440'; for (let i = 0; i < 70; i++) a.fill(circleP(650 + sr() * 72, 550 + sr() * 56, 0.6 + sr() * 1.6)); });
    R.dome(ellipseP(652, 622, 20, 30, 0.2), '#d8b46c', 0.4, 0.14, 16, 2);
    R.bead(626, 600, 15, '#3a3440', 0.4, 0.12, 3); R.bead(662, 600, 9, '#5a4a60', 0.42, 0.08, 3);
    R.bead(718, 500, 10, '#e8c890', 0.4, 0.1, 2);
    // gold ornament top right
    R.pipe(P([[660, -10], [672, 30], [690, 60], [716, 80]], false), 7, '#c8a050', 0.4, 0.06, 2);
    R.dome(P([[676, 70], [700, 60], [722, 80], [720, 120], [700, 136], [682, 120]]), '#d8b06a', 0.4, 0.16, 20, 2);
    R.dome(ellipseP(712, 20, 30, 34, 0), '#e2c27e', 0.4, 0.16, 22, 2);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.95, spec: 1.2, shin: 80, wrap: 0.3, ao: 0.6, coat: 0.3, rim: 0.3 }),                          // 1 porcelain
        E.mat({ dif: 0.8, metal: 0.4, spec: 1.3, shin: 50, ao: 0.6, rim: 0.3, tint: [1.2, 1.04, 0.76], emis: 0.12, coat: 0.15 }),  // 2 gold
        E.mat({ dif: 0.8, spec: 1.4, shin: 90, ao: 0.4, coat: 0.4, rim: 0.2 }),                                       // 3 black gloss
        E.mat({ dif: 1, spec: 0.9, shin: 50, wrap: 0.3, ao: 0.6, coat: 0.2, rim: 0.15 }),                              // 4 zebra satin
        E.mat({ dif: 0.7, spec: 1.3, shin: 90, emis: 0.3, coat: 0.3, ao: 0.3 })                                        // 5 amber
      ],
      light: [-0.35, 0.55, 0.76], lc: [0.82, 0.82, 0.82], amb: [0.32, 0.32, 0.33],
      envTop: [1.05, 1.05, 1.05], envHor: [0.5, 0.52, 0.56], envBot: [0.14, 0.14, 0.15], envK: [0.25, 1.2, 0.3, 0],
      rimC: [0.25, 0.4, 0.7], rimD: [-1, 0, 0.6],
      r1: 4.5, r2: 11, k: [0, 0.6, 0.4, 140], shadow: [5, 7, 0.55, 7]
    });
    E.grain(0.02, 70);
  }
});
