'use strict';
// g101 — "Seal of bubbles": a lilac-to-cobalt seal head rising out of a sky-blue pool, a chain of clay
// pearls, a red tongue, a fringe of cream clay tubes, zebra sheets, a black sphere and soap bubbles in space.
REC.register('g101', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const strokeA = (path, c, wd, ctx = a) => { ctx.save(); ctx.lineCap = ctx.lineJoin = 'round'; ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.stroke(path); ctx.restore(); };

    // ── space: black with golden nebula corners and stars ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#060606', 0, 0);
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.035), n2 = fbm(p * 0.09 + 7.);
      float vein = smoothstep(0.08, 0.0, abs(n - 0.5)) * 0.8 + smoothstep(0.06, 0.0, abs(n2 - 0.52)) * 0.5;
      float tl = exp(-length(p - vec2(0., 20.)) / 70.), tr = exp(-length(p - vec2(700., 0.)) / 90.);
      vec3 c = vec3(.03) + vec3(.95, .82, .55) * tl * 1.1 + vec3(.55, .42, .3) * vein * (tl * 1.6 + tr * 1.2);
      c += vec3(.3, .22, .15) * tr * 0.5;
      return c; }`));

    // ── the sky-blue pool ──
    const pool = P([[150, 104], [205, 90], [260, 80], [320, 70], [380, 60], [440, 55], [500, 52], [640, 60], [640, 480], [380, 480], [0, 480], [0, 300], [60, 260], [120, 200]], true, true);
    R.flat(pool, '#0ba2ee', 0.02, 0);
    clipA(pool, () => {
      soft(x => { x.fillStyle = '#20b4f6'; x.fill(ellipseP(300, 200, 160, 90, -0.2)); x.fillStyle = '#0590e2'; x.fill(ellipseP(40, 360, 60, 80, 0)); }, 40, 0.8);
    });
    strokeA(P([[150, 104], [205, 90], [260, 80], [320, 70], [380, 60], [440, 55], [500, 52]], false, true), '#f4fbff', 4);

    // ── zebra blob, top left (with the pink nub) ──
    R.dome(P([[0, 84], [24, 86], [44, 94], [40, 110], [22, 122], [0, 126]], true, true), '#f4a6a2', 0.05, 0.08, 12, 1);
    const zb = P([[0, 128], [40, 122], [80, 116], [120, 112], [150, 103], [168, 110], [180, 134], [177, 164], [164, 186], [140, 198], [110, 205], [90, 220], [78, 246], [66, 280], [52, 302], [28, 314], [0, 312]], true, true);
    R.dome(zb, null, 0.04, 0.06, 14, 3);
    clipA(zb, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p - vec2(260., 330.);
      float s = length(q * vec2(1., 0.8)) / 30. + 0.05 * sin(p.y * 0.04);
      float v = sin(6.2832 * s);
      return mix(vec3(.02), vec3(.97, .96, .94), smoothstep(-0.12, 0.12, v)); }`)));
    strokeA(zb, '#f6f6f2', 3);

    // white star + dots on the pool
    const starP = P(star(253, 265, 52, 24, 5, -Math.PI / 2 - 0.2), true, false);
    R.dome(P(star(253, 265, 52, 24, 5, -Math.PI / 2 - 0.2), true, true), null, 0.05, 0.05, 8, 1);
    a.fillStyle = '#f6f2ea'; a.fill(starP);
    for (const [x, y, r] of [[205, 131, 12], [292, 186, 12], [332, 196, 6], [323, 237], [133, 287, 5], [162, 314, 12]].map(v => v.length === 2 ? [v[0], v[1], 12] : v))
      R.bead(x, y, r, '#f4f0ea', 0.05, 0.05, 1);

    // ── pearl chain bounds ──
    const U = [[-10, 414], [100, 393], [200, 340], [300, 322], [350, 305], [400, 258], [450, 232], [495, 216]];
    const L = [[-10, 535], [100, 525], [200, 480], [300, 436], [350, 412], [380, 392], [415, 352], [465, 302], [497, 268]];
    const at = (T, x) => { if (x <= T[0][0]) return T[0][1]; for (let i = 1; i < T.length; i++) if (x <= T[i][0]) { const t = (x - T[i - 1][0]) / (T[i][0] - T[i - 1][0]); return T[i - 1][1] + t * (T[i][1] - T[i - 1][1]); } return T[T.length - 1][1]; };

    // ── tube field (black backing, mint glow at the bottom) ──
    const tubeBack = P([[-10, 500], [100, 500], [200, 470], [300, 425], [372, 398], [380, 450], [440, 470], [440, 500], [432, 760], [500, 830], [420, 950], [370, 1030], [-10, 1030]], true, false);
    R.flat(tubeBack, '#0b0a0c', 0.02, 0);
    clipA(tubeBack, () => soft(x => {
      x.fillStyle = '#86c4b4'; x.fill(ellipseP(450, 900, 90, 110, 0.5)); x.fill(ellipseP(270, 1020, 90, 40, 0));
      x.fillStyle = '#e8f0ec'; x.fill(ellipseP(415, 945, 45, 55, 0.4)); x.fill(ellipseP(250, 1030, 50, 25, 0));
    }, 22, 1));
    const tr = rng(1011);
    // tubes share one sheared flow: steep down-left under the pearls, upright lower down, leaning right at the bottom
    const slope = y => y < 560 ? -0.5 : y < 800 ? -0.5 + 0.5 * (y - 560) / 240 : 0.16 * (y - 800) / 200;
    const XS = []; { let X = 0; for (let y = 300; y <= 1080; y += 10) { XS.push(X); X += slope(y) * 10; } }
    const Xat = y => XS[Math.max(0, Math.min(XS.length - 1, Math.round((y - 300) / 10)))];
    const tipY = x => x > 380 ? 930 - (x - 380) * 1.4 : 930 + (380 - x) * 0.75;
    R.a.save(); R.h.save(); R.a.clip(tubeBack); R.h.clip(tubeBack);
    for (let k = 0; k < 30; k++) {
      const x0 = 60 + k * 33 + tr() * 5, ph = tr() * 6, amp = 3 + tr() * 4;
      const pts = [];
      for (let y = 330; y < 1070; y += 10) {
        const x = x0 + Xat(y) + amp * Math.sin(y * 0.022 + ph);
        pts.push([x, y]);
        if (y > tipY(x)) { pts.push([x + 6, y + 10], [x + 16, y + 13]); break; }
      }
      R.pipe(P(pts, false, true), 30 + tr() * 4, '#d8c6bf', 0.06, 0.2, 2);
    }
    R.a.restore(); R.h.restore();

    // ── pearl chain ──
    const chainPts = [...U, [505, 240], ...L.slice().reverse()];
    const chain = P(chainPts, true, true);
    const beads = [], br = rng(77);
    for (let k = 0; k < 9000 && beads.length < 320; k++) {
      const x = -20 + br() * 520, u = at(U, x), l = at(L, x), r = 14 + br() * 11 + (l - u) * 0.04;
      const y = u + r * 0.8 + br() * Math.max(1, l - u - r * 1.6);
      if (beads.every(b => Math.hypot(b[0] - x, b[1] - y) > (b[2] + r) * 0.78)) beads.push([x, y, r]);
    }
    soft(x => { x.lineWidth = 10; x.strokeStyle = '#ffffff'; for (const [bx, by, r] of beads) x.stroke(circleP(bx, by, r)); }, 1.5, 1);
    R.dome(chain, '#c6bab6', 0.06, 0.06, 20, 1);
    beads.sort((p, q) => p[1] - q[1]);
    for (const [x, y, r] of beads) R.dome(ellipseP(x, y, r * 1.06, r * 0.96, 0), rad(x - r * 0.3, y - r * 0.35, r * 1.4, [[0, '#ebe0dc'], [1, '#d2c5c1']]), 0.12, 0.32, r * 0.9, 1);

    // ── the seal: lilac head flowing into a cobalt body ──
    const seal = P([[398, 126], [408, 102], [440, 86], [480, 62], [515, 40], [560, 30], [620, 40], [680, 52], [740, 58], [740, 420], [714, 440], [710, 580], [672, 662], [612, 716], [572, 746], [530, 758], [488, 758], [452, 732], [430, 690], [425, 610], [430, 530], [446, 488], [500, 466], [566, 458], [574, 420], [572, 370], [556, 322], [528, 292], [500, 282], [486, 246], [470, 218], [436, 214], [410, 196], [400, 162]], true, true);
    R.dome(seal, null, 0.1, 0.5, 70, 4);
    clipA(seal, () => {
      a.fillStyle = lin(700, 60, 470, 640, [[0, '#928e9e'], [0.22, '#8c88b0'], [0.45, '#6a70c8'], [0.7, '#2a48dc'], [1, '#1238e2']]); a.fillRect(380, 20, 360, 760);
      soft(x => {
        x.fillStyle = '#a6a2c4'; x.fill(ellipseP(690, 260, 60, 200, 0));
        x.fillStyle = '#a4a0b4'; x.fill(ellipseP(600, 80, 120, 50, 0));
        x.fillStyle = '#6c78d4'; x.fill(ellipseP(450, 150, 50, 60, 0));
        x.fillStyle = '#4a5cd8'; x.fill(ellipseP(545, 270, 45, 120, 0.75));
        x.fillStyle = '#1442e6'; x.fill(ellipseP(505, 600, 90, 150, 0));
        x.fillStyle = '#d4d0e6'; x.fill(ellipseP(655, 560, 40, 150, 0.15));
        x.fillStyle = '#1838e0'; x.fill(ellipseP(398, 185, 14, 46, 0));
      }, 30, 0.9);
      // stippled beard
      soft(x => { const sr = rng(9); x.fillStyle = '#c8c8e0'; for (let i = 0; i < 900; i++) { const t = sr(), y = 190 + t * 110, xx = 470 + sr() * 50 + t * 10; if (Math.hypot((xx - 495) / 30, (y - 240) / 60) < 1) x.fill(circleP(xx, y, 0.9 + sr())); } }, 0.6, 0.85);
    });
    strokeA(seal, 'rgba(240,244,255,0.85)', 3);
    // cyan hole in the body
    R.flat(ellipseP(540, 580, 36, 60, 0), '#0e9aee', 0.12, 0);
    a.fillStyle = rad(548, 590, 60, [[0, '#12aaf4'], [0.75, '#10a2f0'], [1, '#0a70d8']]); a.fill(ellipseP(540, 580, 34, 58, 0));
    strokeA(ellipseP(540, 580, 36, 60, 0), 'rgba(220,240,255,0.8)', 2);
    // eye + nostril dot
    R.flat(circleP(550, 88, 21), '#f8f8fa', 0.4, 0);
    R.flat(circleP(549, 92, 13), '#060608', 0.4, 0);
    R.flat(circleP(680, 176, 6), '#08080c', 0.35, 0);

    // ── red tongue ──
    const tongue = P([[556, 452], [540, 442], [490, 432], [430, 432], [370, 445], [320, 470], [284, 505], [262, 548], [250, 600], [258, 628], [276, 626], [290, 590], [310, 548], [345, 508], [400, 480], [460, 466], [520, 462], [556, 462]], true, true);
    strokeA(tongue, '#f8f8fa', 8);
    R.dome(tongue, '#f20c0c', 0.3, 0.06, 10, 5);

    // ── zebra sheet, lower right ──
    const sheet = P([[740, 380], [726, 392], [702, 440], [700, 580], [662, 658], [604, 710], [562, 776], [520, 840], [476, 900], [432, 960], [400, 1030], [740, 1030]], true, true);
    R.flat(sheet, '#f5f1e8', 0.08, 0);
    clipA(sheet, () => {
      img(E.fx(`vec3 fx(vec2 uv, vec2 p){
        float X = (p.x - 600.) / 100., Y = (p.y - 850.) / 100.;
        float f = 7.72683 + 1.85572 * Y - 0.25525 * Y * Y + 0.06835 * Y * Y * Y - 0.62529 * X - 0.50839 * X * Y + 0.28894 * X * Y * Y
                - 0.31091 * X * X + 0.35653 * X * X * Y + 0.11579 * X * X * X;
        float v = abs(fract(f + 0.5) - 0.5);
        float k = smoothstep(0.235, 0.215, v);
        float m = smoothstep(400., 420., p.y);
        vec3 cream = vec3(.96, .945, .91);
        return mix(cream, vec3(.03), k * m); }`));
      soft(x => { x.fillStyle = '#b0aecc'; x.fill(ellipseP(700, 410, 60, 40, 0)); x.fillStyle = '#d8d6e2'; x.fill(ellipseP(672, 500, 30, 60, 0)); }, 24, 0.85);
    });

    // ── black glass sphere, bottom left ──
    R.dome(circleP(-137, 945, 265), '#050506', 0.3, 0.5, 120, 6);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 26, wrap: 0.45, ao: 0.6, coat: 0.05 }),          // 1 clay pearls / white dots
        E.mat({ dif: 1, spec: 0.45, shin: 30, wrap: 0.45, ao: 0.5, coat: 0.06 }),          // 2 clay tubes
        E.mat({ dif: 0.9, spec: 0.4, shin: 40, wrap: 0.6, emis: 0.15 }),                   // 3 zebra blob
        E.mat({ dif: 0.85, spec: 0.25, shin: 18, wrap: 0.7, emis: 0.1, ao: 0.3 }),         // 4 seal skin
        E.mat({ dif: 0.9, spec: 0.5, shin: 40, wrap: 0.5, emis: 0.15 }),                   // 5 red tongue
        E.mat({ dif: 1, spec: 1.6, shin: 90, coat: 0.6 })                                  // 6 black glass
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.75, 0.74, 0.74], amb: [0.42, 0.42, 0.45],
      envTop: [1, 1, 1], envHor: [0.55, 0.55, 0.6], envBot: [0.08, 0.08, 0.1], envK: [0.3, 1.0, 0.3, 0],
      rimC: [0.15, 0.15, 0.2], rimD: [0, 1, 0], r1: 2.2, r2: 8, k: [0, 0.6, 0.4, 55], shadow: [-5, 7, 0.45, 6]
    });

    // ── sky sparkles ──
    const sr = rng(5);
    for (let i = 0; i < 40; i++) {
      const x = sr() * 726, y = sr() * 70;
      if (y > 50 + x * 0.0 && x > 140 && x < 500 && y > 60 - (x - 140) * 0.02) continue;
      o.fillStyle = `rgba(255,255,255,${0.4 + sr() * 0.6})`; o.fill(circleP(x, y, 0.6 + sr() * 1.6));
    }
    for (const [x, y, r] of [[143, 41, 4], [182, 13, 2], [290, 10, 4], [360, 30, 2.5], [375, 30, 2]]) { o.fillStyle = '#e8e8ec'; o.fill(circleP(x, y, r)); }

    // ── soap bubbles ──
    const bubble = (x, y, r, dark) => {
      o.save(); o.clip(circleP(x, y, r));
      if (dark) { o.fillStyle = rad(x, y, r, [[0, 'rgba(20,16,40,0.85)'], [0.7, 'rgba(60,40,90,0.6)'], [1, 'rgba(120,90,160,0.3)']], o); o.fill(circleP(x, y, r)); }
      else { o.fillStyle = 'rgba(220,230,255,0.12)'; o.fill(circleP(x, y, r)); }
      const cg = o.createConicGradient(0.6, x, y);
      [['#ff40c8', 0], ['#40e0ff', 0.17], ['#ffe060', 0.33], ['#60ff90', 0.45], ['#7060ff', 0.6], ['#ff60a0', 0.75], ['#40c0ff', 0.9], ['#ff40c8', 1]].forEach(([c, t]) => cg.addColorStop(t, c));
      o.globalAlpha = dark ? 0.75 : 0.55; o.lineWidth = r * 0.35; o.strokeStyle = cg; o.filter = `blur(${r * 0.12 * S}px)`; o.stroke(circleP(x, y, r * 0.88));
      if (dark) { o.globalAlpha = 0.6; o.fillStyle = cg; o.fill(ellipseP(x + r * 0.1, y + r * 0.15, r * 0.35, r * 0.3, 0)); }
      o.filter = 'none'; o.globalAlpha = 1;
      o.fillStyle = 'rgba(255,255,255,0.9)'; o.fill(ellipseP(x - r * 0.35, y - r * 0.4, r * 0.22, r * 0.12, -0.6));
      o.restore();
      o.lineWidth = Math.max(1, r * 0.05); o.strokeStyle = 'rgba(235,240,255,0.7)'; o.stroke(circleP(x, y, r - 0.5));
    };
    for (const [x, y, r] of [[120, 357, 14], [61, 535, 22], [198, 692, 18], [692, 678, 22], [333, 935, 21], [469, 958, 21], [170, 978, 15]]) bubble(x, y, r, true);
    bubble(543, 787, 55, false);

    // black sphere: rim reflection band + outer ring
    o.save(); o.clip(circleP(-137, 945, 258));
    soft(x => { x.lineWidth = 26; x.strokeStyle = lin(0, 720, 130, 960, [[0, 'rgba(255,255,255,0.15)'], [0.6, 'rgba(240,240,244,0.85)'], [1, 'rgba(255,255,255,0.95)']], x); x.stroke(circleP(-137, 945, 250)); }, 9, 0.9, 'source-over', o);
    o.restore();
    o.lineWidth = 5; o.strokeStyle = '#050506'; o.stroke(circleP(-137, 945, 263));
    o.lineWidth = 1.5; o.strokeStyle = 'rgba(200,200,205,0.7)'; o.stroke(circleP(-137, 945, 259));

    E.grain(0.03, 101);
  }
});
