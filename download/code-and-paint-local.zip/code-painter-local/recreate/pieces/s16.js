'use strict';
// s16 — "Neon jelly garden under a deep field": a Hubble-style black deep field (stars with
// spikes, amber galaxies, red lensed arcs, cyan filaments) above glowing pink / violet / lime
// jelly blobs with black-magenta veins and a tangle of milky lavender tubes.
REC.register('s16', {
  w: 575, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, W = 575, H = 1024;
    const layer = (fn, blur = 0, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; if (blur) a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fillPts = (x, pts, col) => { x.fillStyle = col; x.fill(P(pts)); };
    const line = (x, pts, w, col) => { x.strokeStyle = col; x.lineWidth = w; x.stroke(P(pts, false)); };
    const r = rng(16);

    // ── deep field ──
    R.flat(rrect(-10, -10, W + 20, H + 20, 0), '#020203', 0, 0);
    layer(x => { const g = x.createRadialGradient(30, 30, 0, 30, 30, 110); g.addColorStop(0, 'rgba(120,40,20,0.8)'); g.addColorStop(1, 'rgba(60,20,10,0)'); x.fillStyle = g; x.fillRect(0, 0, 200, 200);
      const g2 = x.createRadialGradient(290, 300, 0, 290, 300, 160); g2.addColorStop(0, 'rgba(60,55,50,0.35)'); g2.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = g2; x.fillRect(100, 120, 380, 360); }, 10);
    // cyan filaments
    layer(x => {
      for (const pts of [[[140, 380], [180, 425], [215, 470]], [[185, 300], [188, 350], [183, 395]], [[320, 340], [300, 400], [282, 460]], [[420, 300], [445, 318], [470, 330]],
        [[130, 540], [70, 546], [8, 552]], [[215, 470], [240, 440], [262, 420]], [[300, 480], [330, 500], [360, 470]], [[440, 470], [470, 440], [500, 430]], [[330, 510], [390, 540]],
        [[60, 470], [40, 440], [30, 410]], [[470, 520], [520, 500]]]) line(x, pts, 1.3, 'rgba(60,190,210,0.7)');
    }, 0.6);
    // stars
    layer(x => {
      for (let i = 0; i < 900; i++) {
        const sx = r() * W, sy = r() * H, rad = 0.4 + Math.pow(r(), 4) * 1.8, t = r();
        x.fillStyle = t < 0.2 ? `rgba(255,190,150,${0.4 + r() * 0.6})` : `rgba(255,250,240,${0.3 + r() * 0.7})`;
        x.beginPath(); x.arc(sx, sy, rad, 0, 6.283); x.fill();
      }
    });
    layer(x => { for (let i = 0; i < 260; i++) { const sx = r() * W, sy = r() * 640, rad = 1 + r() * 2.2; x.fillStyle = r() < 0.5 ? 'rgba(230,150,90,0.55)' : 'rgba(240,230,215,0.5)'; x.beginPath(); x.ellipse(sx, sy, rad, rad * (0.5 + r() * 0.5), r() * 3, 0, 6.283); x.fill(); } }, 0.8);
    // amber galaxies (blurred glowing ellipses)
    layer(x => {
      for (const [gx, gy, rx, ry, rot, k] of [[405, 378, 40, 24, 0.55, 1], [78, 345, 20, 17, 0, 0.9], [4, 314, 16, 16, 0, 0.8], [35, 40, 26, 12, -0.6, 0.6], [520, 90, 8, 5, 0.3, 0.5],
        [250, 500, 6, 4, 0, 0.5], [150, 200, 6, 4, 0.5, 0.5]]) {
        const g = x.createRadialGradient(gx, gy, 0, gx, gy, rx);
        g.addColorStop(0, `rgba(255,245,220,${k})`); g.addColorStop(0.3, `rgba(230,170,110,${0.8 * k})`); g.addColorStop(1, 'rgba(120,60,30,0)');
        x.save(); x.translate(gx, gy); x.rotate(rot); x.scale(1, ry / rx); x.translate(-gx, -gy); x.fillStyle = g; x.beginPath(); x.arc(gx, gy, rx, 0, 6.283); x.fill(); x.restore();
      }
    }, 2);
    // red lensed arcs
    layer(x => {
      for (const [gx, gy, len, rot, bend] of [[62, 305, 26, 1.2, 0.5], [256, 215, 24, 1.0, 0.4], [318, 395, 22, 1.4, 0.3], [437, 112, 18, -0.8, 0.4], [306, 150, 16, 0.3, 0.3],
        [360, 150, 14, -0.2, 0.3], [122, 280, 12, 0.6, 0.3], [520, 462, 20, 0.9, 0.3], [455, 162, 10, 0.2, 0.3], [200, 98, 12, 0.5, 0.3], [546, 425, 14, 1.3, 0.3],
        [482, 345, 10, 0.4, 0.3], [298, 10, 14, 0.4, 0.4], [540, 130, 12, 1.0, 0.3], [132, 238, 10, 0.2, 0.3], [440, 90, 12, -0.5, 0.3], [250, 262, 10, 1.4, 0.3], [100, 543, 10, 0.3, 0.3]]) {
        x.save(); x.translate(gx, gy); x.rotate(rot);
        x.strokeStyle = 'rgba(235,70,30,0.95)'; x.lineWidth = 3.2; x.beginPath(); x.moveTo(-len / 2, 0); x.quadraticCurveTo(0, -len * bend, len / 2, 0); x.stroke();
        x.strokeStyle = 'rgba(255,190,140,0.8)'; x.lineWidth = 1.2; x.stroke(); x.restore();
      }
    }, 0.8);
    // bright stars with diffraction spikes
    layer(x => {
      for (const [sx, sy, k] of [[350, 320, 1.2], [500, 272, 1], [545, 490, 1], [265, 105, 0.8], [290, 185, 0.8], [215, 42, 0.7], [125, 45, 0.6], [138, 100, 0.6],
        [230, 315, 0.7], [540, 410, 0.8], [500, 420, 0.7], [470, 365, 0.6], [535, 382, 0.7], [520, 160, 0.6], [115, 405, 0.6], [372, 640, 0.9], [288, 905, 0.7], [110, 870, 0.6]]) {
        const g = x.createRadialGradient(sx, sy, 0, sx, sy, 9 * k); g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.25, 'rgba(255,245,235,0.7)'); g.addColorStop(1, 'rgba(255,240,230,0)');
        x.fillStyle = g; x.beginPath(); x.arc(sx, sy, 9 * k, 0, 6.283); x.fill();
        x.strokeStyle = 'rgba(255,245,235,0.75)'; x.lineWidth = 1;
        for (let i = 0; i < 6; i++) { const an = i * Math.PI / 3 + 0.26, L = 14 * k; x.beginPath(); x.moveTo(sx, sy); x.lineTo(sx + Math.cos(an) * L, sy + Math.sin(an) * L); x.stroke(); }
      }
    });

    // ── jelly blobs: lime glow rim, colour body, lighter core ──
    const LIME = '#dcef8a';
    const blobDraw = (pts, body, rimCol = LIME, rimW = 12) => {
      layer(x => { x.strokeStyle = rimCol; x.lineWidth = rimW * 1.5; x.stroke(P(pts)); }, rimW * 0.45, 0.4);
      layer(x => { x.fillStyle = body; x.fill(P(pts)); x.strokeStyle = rimCol; x.lineWidth = rimW; x.stroke(P(pts)); }, 3);
      layer(x => { x.save(); x.clip(P(pts)); x.strokeStyle = 'rgba(245,235,245,0.4)'; x.lineWidth = rimW * 1.6; x.stroke(P(pts)); x.restore(); }, rimW * 0.35, 0.5);
    };
    const pinkA = [[-10, 1034], [-10, 740], [20, 660], [60, 610], [120, 588], [175, 595], [212, 632], [232, 700], [228, 770], [200, 810], [160, 830], [110, 850], [70, 880], [55, 960], [60, 1034]];
    const pinkJ = [[222, 930], [300, 922], [360, 912], [420, 922], [446, 980], [436, 1034], [330, 1034], [262, 990]];
    const gA = a.createLinearGradient(0, 600, 300, 1000); gA.addColorStop(0, '#ea7ed2'); gA.addColorStop(0.5, '#e070c8'); gA.addColorStop(1, '#d05ab8');
    blobDraw(pinkA, gA); blobDraw(pinkJ, '#e060c8', '#e8a0e0', 8);
    const pinkD = [[352, 480], [372, 458], [410, 455], [438, 474], [440, 520], [432, 580], [440, 640], [462, 700], [470, 760], [462, 800], [445, 812], [420, 780], [395, 730], [372, 680], [355, 610], [345, 540]];
    const gD = a.createLinearGradient(350, 460, 470, 840); gD.addColorStop(0, '#f08ad0'); gD.addColorStop(0.5, '#f05ab8'); gD.addColorStop(1, '#e84aa8');
    blobDraw(pinkD, gD);
    const pinkE = [[452, 530], [482, 506], [520, 508], [556, 530], [580, 560], [580, 700], [562, 760], [530, 800], [500, 792], [470, 740], [455, 680], [448, 600]];
    const gE = a.createLinearGradient(450, 510, 575, 800); gE.addColorStop(0, '#f08ac8'); gE.addColorStop(1, '#ee3a8a');
    blobDraw(pinkE, gE);
    // violet body + mushroom
    const violet = [[172, 660], [200, 612], [242, 600], [292, 610], [332, 640], [352, 690], [350, 750], [340, 810], [320, 850], [290, 872], [252, 866], [218, 836], [196, 782], [178, 722]];
    const gV = a.createRadialGradient(290, 760, 10, 280, 740, 150); gV.addColorStop(0, '#a070d8'); gV.addColorStop(0.6, '#9050c8'); gV.addColorStop(1, '#c060d0');
    layer(x => { x.fillStyle = gV; x.fill(P(violet)); }, 10, 0.95);
    blobDraw([[196, 520], [200, 482], [228, 462], [270, 458], [306, 470], [322, 500], [312, 532], [290, 548], [300, 600], [322, 660], [290, 690], [250, 684], [232, 620], [222, 550]],
      (() => { const g = a.createLinearGradient(0, 460, 0, 690); g.addColorStop(0, '#b884e0'); g.addColorStop(0.3, '#8a4ac8'); g.addColorStop(1, '#4a1a98'); return g; })(), LIME, 12);
    // lime ribbons + big lime blob + cream blob
    layer(x => {
      line(x, [[562, 592], [522, 556], [472, 560], [452, 600], [470, 642], [432, 682], [382, 702]], 40, LIME);
      line(x, [[470, 642], [510, 662], [540, 702], [522, 742], [482, 762]], 30, LIME);
      line(x, [[400, 470], [390, 500], [396, 540]], 16, LIME);
    }, 3, 0.95);
    const limeG = [[334, 900], [360, 866], [400, 852], [440, 842], [470, 812], [505, 792], [534, 770], [555, 780], [562, 830], [566, 880], [585, 900], [585, 1034], [330, 1034], [318, 970], [326, 930]];
    blobDraw(limeG, (() => { const g = a.createLinearGradient(330, 800, 575, 1024); g.addColorStop(0, '#e8f0a0'); g.addColorStop(0.5, '#e4e896'); g.addColorStop(1, '#c8e878'); return g; })(), '#c8f080', 12);
    const creamH = [[58, 1034], [54, 962], [70, 902], [110, 872], [170, 862], [232, 882], [282, 922], [322, 962], [340, 1034]];
    blobDraw(creamH, (() => { const g = a.createLinearGradient(60, 870, 330, 1024); g.addColorStop(0, '#e2c0b0'); g.addColorStop(0.5, '#dcaab0'); g.addColorStop(1, '#e4b8b8'); return g; })(), '#e8e8a8', 10);

    // ── veins: black core with magenta / red glow ──
    const vein = (pts, w, glow, gw) => {
      layer(x => line(x, pts, w + gw * 2.2, glow), gw * 0.5, 0.7);
      layer(x => line(x, pts, w + gw, glow), gw * 0.25, 1);
      layer(x => line(x, pts, w, '#08000a'), 2, 1);
    };
    const jag = (pts, amp, seed) => { const q = rng(seed), o = []; for (let i = 0; i < pts.length - 1; i++) for (let k = 0; k < 4; k++) { const t = k / 4, px = pts[i][0] + (pts[i + 1][0] - pts[i][0]) * t, py = pts[i][1] + (pts[i + 1][1] - pts[i][1]) * t; o.push([px + (q() - 0.5) * amp, py + (q() - 0.5) * amp * 0.4]); } o.push(pts[pts.length - 1]); return o; };
    vein(jag([[152, 618], [146, 640], [136, 670], [128, 700], [116, 730], [100, 770], [84, 810], [66, 850], [48, 896], [38, 944], [50, 990]], 18, 3), 14, '#d41ee6', 12);
    vein([[204, 652], [230, 666], [252, 684]], 10, '#d41ee6', 10);
    vein(jag([[416, 520], [410, 560], [405, 600], [402, 650], [410, 700], [430, 742], [452, 776]], 10, 5), 11, '#f01048', 10);
    vein([[540, 628], [546, 660], [532, 692], [522, 722]], 9, '#f01048', 10);
    vein([[232, 934], [282, 956], [332, 962], [382, 952], [420, 930]], 16, '#e020d0', 12);
    layer(x => { x.fillStyle = '#3a0a80'; x.fill(P([[235, 550], [282, 548], [296, 610], [312, 660], [282, 680], [255, 668], [242, 610]])); }, 8, 0.8);

    // sparkles on the pale blobs
    layer(x => {
      for (let i = 0; i < 700; i++) {
        const sx = 50 + r() * 525, sy = 800 + r() * 224;
        const inL = x.isPointInPath(P(limeG), sx, sy), inC = x.isPointInPath(P(creamH), sx, sy);
        if (!inL && !inC) continue;
        x.fillStyle = `rgba(255,255,240,${0.4 + r() * 0.6})`; x.beginPath(); x.arc(sx, sy, 0.5 + r() * 1.2, 0, 6.283); x.fill();
      }
    });

    // ── milky lavender tubes (relief) ──
    const tubes = [
      [[214, 522], [238, 508], [268, 518], [286, 540], [272, 560], [250, 552]], [[290, 520], [318, 528], [332, 546], [312, 558]],
      [[168, 640], [198, 700], [228, 760], [248, 820], [258, 870]], [[158, 672], [168, 722], [198, 790], [228, 840]],
      [[220, 650], [262, 640], [302, 652], [322, 700], [312, 760], [292, 810], [272, 860], [252, 900]],
      [[270, 640], [276, 700], [282, 760], [272, 800], [250, 830]], [[310, 640], [332, 662], [336, 722], [322, 780], [302, 820]],
      [[98, 802], [140, 790], [170, 800], [166, 822]], [[158, 862], [200, 880], [250, 890], [300, 872], [330, 842]],
      [[340, 720], [380, 700], [420, 690], [442, 702]], [[250, 830], [290, 860], [330, 870], [362, 860]], [[160, 700], [150, 742], [160, 782]],
      [[282, 590], [300, 620], [296, 650]], [[340, 640], [352, 610], [370, 600]], [[372, 650], [360, 700], [350, 760]], [[210, 560], [232, 590], [250, 630]]
    ];
    for (const t of tubes) R.pipe(P(t, false), 15, '#bcaed4', 0.2, 0.2, 1);
    // lime rings on the lime blob / cream blob
    R.pipe(ellipseP(462, 930, 20, 16, 0.3), 7, '#eef8b0', 0.2, 0.12, 1);
    R.pipe(ellipseP(188, 1004, 26, 10, 0), 6, '#f0e8c8', 0.2, 0.1, 1);
    R.pipe(ellipseP(240, 1010, 20, 8, 0), 6, '#f0e8c8', 0.2, 0.1, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.8, spec: 0.35, shin: 20, wrap: 0.6, emis: 0.3, rim: 0.4, ao: 0.3 })     // milky tube
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.8, 0.8, 0.85], amb: [0.35, 0.33, 0.4], rimC: [0.6, 0.5, 0.7], rimD: [0, 1, 0],
      r1: 1.5, r2: 5, k: [0, 0.6, 0.4, 60], shadow: [0, 0, 0, 0]
    });
    E.bloom(0.18, 8, 'brightness(0.9) contrast(1.5)');
    E.grain(0.03, 16);
  }
});
