'use strict';
// g094 — "Gilded profile, pearl S": a gold relief head with curled hair and a gold moon, a pearl-silver tongue
// and S-curve, spiral discs and beads, before a zebra fingerprint sky, a green glow and black starry space.
REC.register('g094', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const spiralDisc = (cx, cy, rx, ry, rot, turns, wd, seed) => {
      const path = ellipseP(cx, cy, rx, ry, rot);
      R.dome(path, '#f6f4ee', 0.22, 0.1, Math.min(rx, ry) * 0.5, 4);
      clipA(path, () => {
        const pts = [], rr = rng(seed);
        for (let i = 0; i <= turns * 60; i++) { const t = i / 60, ang = t * 6.2832 + seed, k = t / turns; pts.push([cx + Math.cos(ang) * rx * k * (1 + (rr() - 0.5) * 0.01), cy + Math.sin(ang) * ry * k]); }
        a.lineWidth = wd; a.strokeStyle = '#0a0a0a'; a.lineCap = 'round'; a.stroke(P(pts, false, false));
      });
      a.lineWidth = 3; a.strokeStyle = '#6a5a5a'; a.stroke(path);
    };

    // ── background: blurry light columns at left, green glow, black space at right ──
    const bg = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float x = p.x, y = p.y;
      vec3 cream = vec3(.99, .97, .9);
      vec3 colA = cream * (0.9 + 0.1 * smoothstep(.2, .9, abs(sin(y * 0.04)))) ;
      vec3 colB = mix(vec3(.02, .33, .67), vec3(.36, .52, .71), smoothstep(80., 230., y));
      colB = mix(colB, vec3(.6, .63, .7), smoothstep(230., 420., y));
      colB = mix(colB, vec3(.71, .71, .7), smoothstep(420., 700., y));
      vec3 colC = mix(colB, vec3(.3, .5, .48), smoothstep(360., 420., y) * (1. - smoothstep(680., 760., y)));
      vec3 colD = mix(vec3(.12, .42, .72), cream, smoothstep(300., 460., y));
      vec3 c = mix(colA, colB, smoothstep(40., 55., x));
      c = mix(c, colC, smoothstep(105., 118., x));
      c = mix(c, colD, smoothstep(160., 172., x));
      // green-gold glow behind the gap and purple space
      vec3 glow = mix(vec3(.95, .94, .75), vec3(.52, .66, .58), smoothstep(400., 520., y));
      glow = mix(glow, vec3(.55, .42, .78), smoothstep(470., 560., y) * smoothstep(430., 480., x));
      c = mix(c, glow, smoothstep(360., 380., x));
      vec3 sp = vec3(.02, .015, .03) + vec3(.16, .07, .26) * smoothstep(.45, .8, fbm(p * 0.006 + 3.)) ;
      float spaceM = max(smoothstep(560., 590., x) * smoothstep(300., 340., y), smoothstep(425., 445., x) * smoothstep(690., 740., y));
      spaceM = max(spaceM, smoothstep(40., 20., length((p - vec2(548., 525.)) * vec2(1., 1.3))) * .8);
      c = mix(c, sp, spaceM);
      return c; }`);
    R.flat(rrect(-10, -10, 746, 1044, 0), '#101018', 0, 0);
    img(bg);
    // stars
    { const r = rng(94); a.fillStyle = '#ffffff';
      for (let i = 0; i < 320; i++) { const x = 400 + r() * 326, y = 330 + r() * 694; a.globalAlpha = 0.4 + r() * 0.6; a.beginPath(); a.arc(x, y, 0.5 + r() * 1.2, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
      for (const [x, y, rr] of [[685, 510, 12], [575, 772, 9], [475, 773, 9], [488, 922, 6], [700, 890, 6], [558, 393, 5], [450, 795, 4], [717, 620, 5], [700, 580, 3], [668, 670, 3], [548, 856, 3], [610, 850, 3], [520, 830, 3], [420, 960, 3], [640, 760, 3], [700, 830, 3]])
        a.fill(circleP(x, y, rr)); }
    // faint glass outline at the left
    a.save(); a.strokeStyle = 'rgba(150,150,150,0.5)'; a.lineWidth = 2.5; a.stroke(P([[0, 690], [40, 668], [90, 680], [118, 730], [128, 820], [126, 930]], false)); a.restore();

    // ── zebra fingerprint field (top right) ──
    const zeb = P([[205, -12], [746, -12], [746, 374], [690, 362], [640, 340], [600, 320], [560, 306], [500, 298], [470, 302], [463, 262], [458, 228], [440, 213], [418, 217], [404, 240], [398, 282], [370, 310], [205, 200]], true, false);
    R.dome(zeb, null, 0.04, 0.05, 8, 1);
    // stripe flow fitted per 75-px tile (quadratic phase each), blended
    clipA(zeb, () => img(E.fx(`const vec2 ZC[28] = vec2[28](vec2(242., 38.), vec2(318., 38.), vec2(392., 38.), vec2(468., 38.), vec2(542., 38.), vec2(618., 38.), vec2(692., 38.), vec2(242., 112.), vec2(318., 112.), vec2(392., 112.), vec2(468., 112.), vec2(542., 112.), vec2(618., 112.), vec2(692., 112.), vec2(392., 188.), vec2(468., 188.), vec2(542., 188.), vec2(618., 188.), vec2(692., 188.), vec2(392., 262.), vec2(468., 262.), vec2(542., 262.), vec2(618., 262.), vec2(692., 262.), vec2(468., 338.), vec2(542., 338.), vec2(618., 338.), vec2(692., 338.));
const float ZK[168] = float[168](5.7202, -2.0971, -4.2112, 1.0201, 2.1708, 2.0789, 6.2960, 0.8702, 2.3994, 0.0067, -0.2806, 0.0989, -1.0912, 2.7884, 2.1925, 0.1984, 0.2266, 0.2067, -0.0001, 1.8755, 1.7782, -1.9667, -1.0936, 0.4286, 5.5726, -3.6728, 1.7452, -0.8623, 4.6168, 1.2072, -0.9672, -1.8352, 5.4821, 2.6935, 4.5937, -0.7380, 1.2582, 2.5861, 2.5400, -0.1621, -2.0993, 0.4586, 2.6200, -0.5736, -1.6751, 1.0786, 2.0645, 1.4007, -0.4480, -1.0026, -3.4685, 0.0110, -0.3304, -0.8193, 5.5431, 3.4068, 2.3379, -0.4234, -0.5077, -0.4388, 10.4469, -0.9748, -2.2722, -0.1344, -0.6585, 0.4555, 0.6426, -0.8035, -2.9538, 0.5686, -1.2621, 0.3693, -2.3529, 0.4788, 3.3735, 0.3568, 0.1424, 0.2538, 4.3479, 1.3705, 3.0132, 0.2459, -0.9707, 0.4154, -0.9330, 3.2288, 1.6927, -1.2330, -1.3582, -0.8647, -0.0782, 1.8608, 1.2005, -0.6707, 0.0244, -1.1870, -2.2799, -1.6623, -2.3806, 0.4212, -0.9809, 0.0971, 1.2390, 0.7767, 2.9010, -0.2413, 0.5644, -0.7338, -1.3309, 0.5798, 2.7211, 0.2899, -1.2368, -0.6047, 1.1302, -2.7458, -0.5511, 2.9715, 1.7170, 0.8103, 3.7742, 2.2029, -0.4525, 0.6164, 0.3453, -0.2473, 2.6421, 2.3330, -0.3113, -0.2741, 0.4267, -0.6167, -4.1187, -0.8896, 2.4339, -0.2117, -0.3139, -0.1503, 1.5614, -0.3006, -2.2094, -1.2696, 0.3323, 0.3809, -0.9917, 2.2723, 0.8752, -1.0003, -1.7627, 0.1637, 0.7583, -0.6809, 3.9940, 0.7038, 2.5954, 2.9439, 1.5816, -1.4480, 1.8090, -0.3338, -1.0594, -0.6952, -1.0700, -0.4890, -2.2323, -1.5625, -0.3089, -0.0031);
float zv(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 28; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.3403);
    float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }
      vec3 fx(vec2 uv, vec2 p){ return mix(vec3(.97, .95, .88), vec3(.03), smoothstep(-.18, .18, zv(p))); }`)));
    a.save(); a.lineWidth = 4; a.strokeStyle = '#b08870'; a.stroke(zeb); a.restore();
    // purple wire along the gap
    R.pipe(P([[396, 300], [400, 260], [410, 228], [432, 212], [452, 220], [462, 250], [466, 300]], false), 5, '#6a64c8', 0.2, 0.06, 3);
    // amber gems + spotted bead on the zebra
    const gem = (x, y, rx, ry, rot) => { R.dome(ellipseP(x, y, rx, ry, rot), '#f0a018', 0.12, 0.1, Math.min(rx, ry) * 0.8, 6); };
    gem(462, 45, 13, 19, -0.6); gem(655, 64, 15, 23, 0.5); gem(462, 232, 11, 19, -0.35); gem(640, 362, 22, 12, 0.1); gem(370, 2, 18, 9, 0);
    R.bead(712, 322, 17, '#e8e0d4', 0.15, 0.15, 4);
    { const dr = rng(5); for (let i = 0; i < 8; i++) R.flat(circleP(704 + dr() * 18, 312 + dr() * 20, 1.5 + dr() * 2), '#2a2420', 0.32, 4); }
    R.pipe(circleP(722, 180, 16), 5, '#9a6a50', 0.15, 0.06, 2);

    // ── gold head ──
    const gold = P([[218, 100], [300, 72], [400, 52], [394, 130], [388, 200], [392, 272], [375, 305], [372, 360], [382, 420], [392, 470], [400, 520], [412, 558], [450, 574], [470, 600], [452, 700], [420, 742],
      [380, 752], [350, 700], [300, 666], [270, 646], [190, 622], [166, 560], [160, 490], [150, 420], [146, 350], [142, 280], [150, 200], [170, 140], [195, 110]], true, true);
    const GOLD = lin(160, 60, 420, 700, [[0, '#ecd8a6'], [0.5, '#dec490'], [1, '#ceb07a']]);
    R.dome(gold, GOLD, 0.1, 0.1, 10, 2);
    a.save(); a.lineWidth = 2.5; a.strokeStyle = '#9a7a6a'; a.stroke(gold); a.restore();
    // hair: overlapping gold curls down the left edge
    { const hr = rng(41);
      for (let i = 0; i < 34; i++) {
        const t = i / 33, y = 30 + t * 480, x = 140 + 70 * Math.pow(1 - t, 4) - 18 * Math.sin(t * 3.1) + 10 * Math.sin(t * 11) + (hr() - 0.5) * 12;
        const curl = ellipseP(x + 14, y, 36, 17, -0.5 + (hr() - 0.5) * 0.6);
        R.dome(curl, '#d8bc80', 0.12 + t * 0.02, 0.12, 9, 2);
        R.groove(P([[x - 6, y + 4], [x + 10, y + 12], [x + 30, y + 6]], false, true), 5, '#6a4c20', 0.24, 0.08, 2, 0.9);
      } }
    R.pipe(P([[108, 142], [140, 152], [168, 160]], false), 13, '#d8bc80', 0.2, 0.1, 2);
    R.bead(108, 142, 6, '#3a3020', 0.3, 0.05, 5);
    R.bead(330, 220, 52, '#e6d29a', 0.2, 0.3, 2);
    // cracks
    a.save(); a.strokeStyle = 'rgba(60,40,20,0.75)'; a.lineWidth = 1.4; a.lineCap = 'round';
    for (const c of [[[346, 110], [360, 150], [372, 196], [380, 250], [366, 290], [340, 330], [330, 360]], [[288, 266], [300, 296], [320, 312]], [[350, 120], [372, 90], [384, 78]], [[372, 196], [386, 182]]]) a.stroke(P(c, false, true));
    a.restore();
    // eye at the gold edge
    R.bead(400, 287, 17, '#d8b870', 0.2, 0.1, 2);
    R.bead(400, 287, 9, '#080808', 0.3, 0.06, 5);
    R.bead(386, 428, 15, '#060606', 0.25, 0.1, 5);

    // ── pearl tongue ──
    const PEARL = '#cdc4cc';
    const tongue = P([[150, 268], [172, 250], [205, 252], [240, 280], [268, 320], [290, 365], [315, 400], [345, 422], [375, 432], [388, 450], [372, 470], [340, 500], [300, 515], [265, 500], [232, 465], [200, 420], [172, 370], [155, 320]], true, true);
    R.dome(tongue, lin(150, 260, 380, 500, [[0, '#d6d2da'], [1, '#c4c0c8']]), 0.2, 0.25, 26, 3);

    // ── pearl S ──
    const sPath = P([[465, 322], [490, 300], [530, 292], [566, 300], [592, 318], [604, 340], [601, 357], [586, 354], [566, 344], [548, 352], [590, 420], [623, 478], [640, 545], [636, 620], [615, 670],
      [573, 712], [507, 737], [440, 748], [420, 760], [402, 760], [430, 640], [470, 585], [515, 568], [548, 560], [572, 536], [566, 500], [535, 496], [512, 520], [500, 538], [478, 500], [463, 440]], true, true);
    R.dome(sPath, lin(460, 300, 640, 740, [[0, '#dcdae2'], [0.5, '#d0ced6'], [1, '#c4c2ca']]), 0.12, 0.35, 40, 3);
    // stem
    const stem = P([[372, 1040], [378, 900], [380, 800], [374, 752], [400, 742], [440, 744], [424, 790], [420, 900], [424, 1040]], true, true);
    R.dome(stem, '#cecbd2', 0.12, 0.25, 22, 3);

    // ── spirals, beads, black bits ──
    spiralDisc(230, 593, 45, 47, 0, 9, 3.4, 1.3);
    spiralDisc(484, 645, 64, 64, 0, 11, 4.4, 2.1);
    spiralDisc(212, 786, 72, 86, 0.12, 9, 5.4, 0.7);
    R.dome(P([[292, 642], [330, 628], [350, 650], [346, 684], [330, 694], [304, 680]], true, true), '#060606', 0.25, 0.12, 10, 5);
    R.bead(446, 586, 20, '#060606', 0.24, 0.14, 5);
    R.dome(P([[356, 540], [384, 530], [400, 548], [394, 586], [376, 616], [352, 640], [336, 628], [342, 590]], true, true), '#e8e2cc', 0.2, 0.15, 14, 4);
    R.dome(ellipseP(368, 580, 14, 24, 0.4), '#f0ecd8', 0.3, 0.08, 8, 4);
    for (const [x, y, r] of [[392, 707, 11], [433, 713, 11], [397, 750, 12]]) R.bead(x, y, r, '#e4e8e6', 0.32, 0.14, 4);

    // grey oval in space
    R.dome(ellipseP(665, 796, 30, 52, -0.05), '#9a9aa2', 0.1, 0.06, 10, 4);

    // ── bottom-left gold dish ──
    const dish = P([[-12, 962], [60, 945], [140, 940], [220, 948], [270, 966], [296, 1000], [300, 1040], [-12, 1040]], true, true);
    R.dome(dish, lin(0, 940, 0, 1024, [[0, '#ead8a6'], [1, '#c8a870']]), 0.1, 0.2, 24, 2);
    R.pipe(P([[-10, 988], [60, 980], [130, 984], [200, 990], [240, 1000]], false), 14, '#141414', 0.3, 0.04, 5);
    R.dome(P([[190, 1004], [210, 996], [232, 1002], [240, 1016], [220, 1024], [196, 1020]], true, true), '#d8a890', 0.3, 0.1, 6, 4);
    gem(274, 1016, 16, 10, 0.2);

    // ── bottom-right bead cluster ──
    R.dome(P([[530, 1040], [536, 980], [560, 940], [600, 922], [650, 910], [700, 896], [740, 900], [740, 1040]], true, true), '#5a3010', 0.1, 0.1, 20, 6);
    R.bead(588, 975, 46, '#ec9220', 0.15, 0.3, 6); R.bead(690, 1000, 44, '#e88a18', 0.15, 0.3, 6);
    R.bead(560, 1004, 30, '#f0f0ea', 0.3, 0.2, 4);
    for (const [x, y, r, c, m] of [[628, 924, 17, '#ece6da', 4], [664, 912, 19, '#e8d4a8', 2], [700, 944, 19, '#f2f0ec', 4], [658, 944, 15, '#080808', 5], [620, 958, 18, '#f0eee8', 4],
      [690, 990, 18, '#ece6da', 4], [646, 1000, 22, '#f2f0ec', 4], [720, 990, 16, '#e88a18', 6], [598, 1016, 18, '#ece6da', 4], [705, 1020, 14, '#ece6da', 4]]) R.bead(x, y, r, c, 0.4, 0.2, m);
    { const dr = rng(7); for (const [x, y, r] of [[628, 924, 17], [690, 990, 18], [598, 1016, 18], [705, 1020, 14]]) for (let i = 0; i < 7; i++) R.flat(circleP(x + (dr() - 0.5) * r * 1.4, y + (dr() - 0.5) * r * 1.4, 1.5 + dr() * 2), '#2a2420', 0.62, 4); }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.15, shin: 20, wrap: 0.5 }),                                                    // 1 zebra
        E.mat({ dif: 0.85, metal: 0.3, spec: 0.8, shin: 26, rim: 0.3, ao: 0.5, tint: [1.08, 1.0, 0.82], grain: 0.03, emis: 0.2 }), // 2 gold
        E.mat({ dif: 0.95, spec: 0.7, shin: 34, wrap: 0.45, rim: 0.3, ao: 0.4, coat: 0.12, iri: 0.03 }),       // 3 pearl silver
        E.mat({ dif: 1, spec: 0.7, shin: 50, wrap: 0.3, coat: 0.15, ao: 0.3 }),                                 // 4 glossy white
        E.mat({ dif: 1, spec: 1.2, shin: 90, coat: 0.25 }),                                                      // 5 gloss black
        E.mat({ dif: 0.9, spec: 1.0, shin: 60, emis: 0.35, coat: 0.15 })                                        // 6 amber
      ],
      light: [-0.5, 0.55, 0.65], lc: [0.85, 0.83, 0.8], amb: [0.36, 0.35, 0.36],
      envTop: [1.05, 1.02, 1.0], envHor: [0.62, 0.6, 0.62], envBot: [0.2, 0.18, 0.22], envK: [0.25, 1.0, 0.35, 0],
      rimC: [0.45, 0.42, 0.55], rimD: [0, 0, 0], r1: 1.5, r2: 8, k: [0, 0.6, 0.4, 110], shadow: [-6, 8, 0.55, 6]
    });
    E.grain(0.035, 94);
  }
});
