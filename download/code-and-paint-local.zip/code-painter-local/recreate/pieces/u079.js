'use strict';
// u079 — "Caulk-gun madonna": a hooded grey chrome statue cradles a giant caulk tube among white clay coils,
// red and blue collage panels, a zebra swoosh, a stone beam and a starfield strewn with gem pebbles.
REC.register('u079', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };

    // ── black starfield with a warm haze under the light beam ──
    const SKY = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        vec3 c = vec3(.055, .05, .06) + .03 * (fbm(p * .01) - .5);
        c += vec3(.30, .20, .16) * exp(-pow(length((p - vec2(215., 70.)) / vec2(110., 45.)), 2.));
        c += vec3(.45, .44, .46) * exp(-pow(length((p - vec2(140., 140.)) / vec2(45., 28.)), 2.));
        vec2 gc = floor(p / 7.), f = fract(p / 7.) - .5; float h = hash(gc);
        vec2 off = vec2(hash(gc + 3.1), hash(gc + 7.7)) - .5;
        c += step(.9, h) * smoothstep(.2, .04, length(f - off * .5)) * (.4 + .6 * hash(gc + 9.)) * vec3(.9);
        return c; }`);
    img(SKY);
    // gem pebbles and bokeh
    const gem = (x, y, rx, ry, c, rot = 0) => { fill(ellipseP(x, y, rx, ry, rot), rad(x - rx * .3, y - ry * .3, Math.max(rx, ry) * 1.3, [[0, '#fff4e8'], [0.25, c], [1, mixHex(c, '#000000', 0.6)]])); };
    const bok = (x, y, r, c) => fill(circleP(x, y, r), rad(x, y, r, [[0, '#ffffff'], [0.3, c], [1, 'rgba(0,0,0,0)']]));
    for (const [x, y, r, c] of [[12, 170, 6, '#3a6cff'], [20, 365, 7, '#3a70ff'], [65, 345, 9, '#3060f0'], [32, 382, 6, '#ff8a30'], [713, 118, 11, '#3a70ff'], [693, 325, 9, '#2840c0'], [706, 385, 7, '#ff60c0'],
      [718, 440, 5, '#ff3030'], [705, 470, 7, '#ffb040'], [720, 640, 22, '#2a5ae0'], [696, 525, 6, '#30d0c0'], [535, 912, 10, '#30c8c0'], [625, 955, 8, '#3a70ff'], [718, 958, 14, '#3a6cff'],
      [577, 1002, 13, '#ff60c0'], [448, 955, 11, '#2a40c0'], [25, 930, 9, '#3a70ff'], [10, 955, 6, '#ff60c0'], [40, 1000, 6, '#3a70ff'], [30, 690, 7, '#ff60c0'], [20, 640, 5, '#40d0c0'], [557, 1000, 6, '#3a70ff'], [680, 905, 5, '#ff8040'], [160, 930, 5, '#ffd040'], [700, 590, 5, '#ff4060']])
      bok(x, y, r, c);
    for (const [x, y, rx, ry, c, rt] of [[65, 668, 16, 10, '#e0a040', -0.4], [90, 660, 8, 6, '#c08040', 0], [10, 612, 10, 14, '#d09040', 0], [60, 700, 12, 9, '#c04050', 0.3], [110, 860, 16, 22, '#d06070', 0.3],
      [50, 955, 22, 13, '#d08a30', -0.4], [590, 935, 12, 14, '#c04030', 0], [662, 958, 15, 12, '#e0a830', 0.4], [513, 990, 9, 12, '#d0a050', 0], [698, 345, 14, 6, '#e05030', 0.2], [500, 680, 9, 14, '#c07040', 0]])
      gem(x, y, rx, ry, c, rt);
    // pearl bubble top left, gold rings left
    fill(circleP(45, 45, 19), rad(38, 38, 24, [[0, '#ffffff'], [0.3, '#b8b0d0'], [0.7, '#685a80'], [1, '#30283a']]));
    for (const [x, y, r] of [[34, 296, 20], [14, 330, 16], [52, 316, 12]]) stroke(circleP(x, y, r), 'rgba(240,190,90,0.9)', 2.5);
    soft(x => { fill(circleP(28, 310, 30), 'rgba(255,200,110,0.35)', x); }, 12, 1);

    // ── light beam ──
    soft(x => { fill(poly([[-10, 104], [300, -14], [312, 8], [-10, 136]]), 'rgba(255,240,215,0.55)', x); }, 14, 1);
    fill(poly([[-10, 104], [300, -4], [304, 10], [-10, 128]]), '#efe6d6');

    // ── collage panels ──
    fill(poly([[470, 0], [706, 0], [706, 220], [470, 220]]), '#dd3016');
    const GR = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float n = fbm(p * vec2(.09, .05)) * .6 + fbm(p * .3) * .4;
        float sp = step(.68, fbm(p * .14 + 3.)) + step(.83, hash(floor(p / 2.)));
        float sc = step(.92, vnoise(vec2(p.x * .6, p.y * .02))) * .7;
        float b = .64 + .14 * (n - .5);
        b *= 1. - .85 * clamp(sp + sc, 0., 1.);
        return vec3(b * 1.0, b * .9, b * .95); }`);
    const grP = poly([[455, 92], [545, 92], [600, 150], [705, 214], [705, 312], [664, 312], [664, 330], [545, 332], [520, 330], [455, 330]]);
    clipA(grP, () => img(GR));
    fill(poly([[545, 332], [664, 332], [664, 448], [576, 449], [560, 420], [534, 379]]), '#e4dad9');
    fill(circleP(622, 372, 24), '#c6bebe');
    // cream middle field
    fill(sm([[390, 430], [470, 340], [534, 379], [560, 422], [575, 450], [598, 470], [598, 600], [480, 610], [385, 600], [360, 520]]), '#e2d9d8');
    fill(poly([[585, 450], [692, 452], [690, 605], [592, 604], [598, 488]]), '#de3d1f');
    // blue panels
    fill(poly([[0, 717], [6, 722], [14, 710], [22, 722], [30, 708], [38, 722], [46, 708], [54, 720], [62, 708], [70, 720], [90, 749], [83, 818], [69, 879], [49, 891], [26, 877], [0, 877]]), lin(0, 720, 90, 880, [[0, '#2850a8'], [0.6, '#2050b8'], [1, '#183a80']]));
    fill(poly([[46, 368], [108, 380], [118, 444], [56, 432]]), '#3666b0');
    fill(poly([[125, 718], [190, 712], [180, 800], [150, 960], [126, 958]]), '#1c2a78');
    for (let i = 0; i < 9; i++) { const x = 130 + i * 7; stroke(line([[x + 6, 720], [x - 4, 840], [x - 10, 955]]), i % 2 ? '#3050c8' : '#121c60', 3); }

    // black ink splash with the yellow feather
    fill(sm([[404, 210], [430, 196], [452, 230], [462, 300], [478, 380], [470, 450], [455, 478], [436, 462], [420, 420], [404, 380], [398, 300]]), '#0c0a0c');
    { const r = rng(7); for (let i = 0; i < 26; i++) fill(circleP(395 + r() * 110, 200 + r() * 290, 2 + r() * 6), '#0c0a0c'); }
    fill(sm([[436, 218], [458, 226], [486, 276], [510, 336], [526, 410], [512, 424], [488, 370], [460, 310], [440, 260]]), '#e8c040');
    fill(sm([[456, 262], [470, 280], [488, 336], [500, 380], [494, 382], [478, 336], [460, 290]]), '#3a2a10');

    // ── diagonal zebra wedge and stone beam ──
    const ZW = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float ph = dot(p, normalize(vec2(-.42, .91))) / 23. + .15 * sin(p.x * .01);
        float v = smoothstep(-.12, .12, sin(6.2832 * ph));
        return mix(vec3(.06, .05, .06), vec3(.91, .88, .89), v); }`);
    const zwP = sm([[318, 648], [400, 690], [500, 750], [600, 790], [660, 805], [580, 835], [480, 832], [380, 800], [310, 760]]);
    clipA(zwP, () => img(ZW));
    const ST = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float n = fbm(p * .08) * .5 + fbm(p * .35) * .3 + hash(floor(p)) * .2;
        float b = .70 + .25 * (n - .5) - .25 * step(.8, fbm(p * .2 + 9.));
        return vec3(b * .99, b * .94, b * .99); }`);
    const stP = sm([[360, 664], [470, 700], [560, 742], [640, 768], [730, 790], [730, 905], [640, 862], [560, 826], [470, 795], [400, 742]]);
    R.flat(stP, null, 0.06, 0); clipA(stP, () => img(ST));

    // ── zebra swoosh (bottom left): white with grey waves, a darker striped band on its right ──
    const SW = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float ph = (p.x + 16. * sin(p.y * .016) + 9. * sin(p.y * .043 + 1.)) / 30.;
        float s = .5 + .5 * sin(6.2832 * ph);
        float dk = smoothstep(250., 268., p.x - .1 * (p.y - 800.));
        vec3 c = mix(vec3(.87, .84, .87), vec3(.44, .41, .45), smoothstep(.72, .82, s));
        vec3 d = mix(vec3(.50, .45, .49), vec3(.07, .06, .07), smoothstep(.45, .6, s));
        return mix(c, d, dk); }`);
    const swP = sm([[176, 1030], [190, 900], [205, 800], [228, 700], [262, 652], [300, 642], [320, 680], [314, 780], [306, 880], [310, 1030]]);
    R.flat(swP, null, 0.1, 0); clipA(swP, () => img(SW));
    fill(poly([[310, 775], [449, 823], [494, 850], [500, 995], [324, 917], [308, 863]]), '#d94024');
    // ── middle shadows ──
    fill(sm([[300, 470], [360, 470], [420, 610], [520, 640], [600, 680], [560, 730], [420, 700], [330, 660], [300, 600]]), '#4a4248');
    fill(sm([[380, 640], [470, 640], [520, 690], [440, 700], [380, 690]]), '#6e666c');
    // grey chrome cluster behind the top tubes, warm haze over the head
    fill(sm([[395, 96], [440, 86], [472, 128], [482, 196], [462, 216], [420, 206], [398, 190]]), '#8e8286');
    fill(sm([[90, 150], [140, 128], [200, 132], [250, 150], [240, 178], [170, 176], [110, 178]]), '#7e6e6a');

    // ── relief objects ──
    const CLAY = '#e2dde0';
    // left white clay coils
    R.dome(sm([[-10, 420], [40, 410], [110, 430], [180, 420], [230, 470], [236, 560], [230, 640], [200, 700], [150, 730], [110, 720], [90, 660], [40, 630], [-10, 610]]), '#d4cfd3', 0.02, 0.12, 30, 1);
    for (const [x, y, rx, ry] of [[30, 440, 40, 32], [100, 470, 45, 34], [170, 460, 40, 34], [210, 520, 34, 30], [40, 520, 36, 30], [190, 600, 44, 38], [150, 660, 46, 40], [120, 720, 34, 26], [80, 600, 40, 30]])
      R.dome(ellipseP(x, y, rx, ry, 0.2), CLAY, 0.06, 0.18, Math.min(rx, ry) * 0.9, 1);
    for (const pts of [[[-10, 540], [30, 520], [70, 530], [100, 565], [140, 552], [180, 560]], [[0, 590], [40, 612], [80, 610], [110, 580]], [[10, 470], [60, 490], [100, 500], [150, 495], [200, 505]],
      [[60, 760], [100, 712], [150, 690], [195, 660]], [[150, 620], [180, 640], [215, 630]]])
      R.pipe(line(pts), 38, CLAY, 0.14, 0.2, 1);

    // grey chrome statue head
    const HEAD = sm([[98, 250], [108, 208], [140, 182], [192, 174], [242, 188], [276, 216], [294, 262], [302, 320], [300, 420], [288, 500], [250, 525], [200, 505], [160, 470], [128, 430], [104, 380], [94, 320]]);
    R.dome(HEAD, lin(100, 180, 300, 500, [[0, '#a29aa0'], [0.5, '#847c82'], [1, '#6a6268']]), 0.12, 0.2, 40, 2);
    const FACE = sm([[112, 270], [140, 248], [190, 252], [230, 270], [250, 310], [248, 380], [230, 420], [190, 440], [150, 420], [125, 380], [110, 320]]);
    R.dome(FACE, lin(110, 250, 250, 440, [[0, '#c4bec4'], [0.6, '#9e989e'], [1, '#7c767c']]), 0.22, 0.1, 30, 2);
    // sculpted 3/4 face looking left: brow, closed eye, nose, lips, cheek, chin
    R.dome(sm([[150, 262], [200, 258], [240, 272], [236, 284], [196, 276], [154, 276]]), '#cac4ca', 0.3, 0.06, 8, 2);
    R.dome(sm([[176, 282], [200, 278], [218, 286], [212, 298], [186, 300]]), '#5a545a', 0.28, 0.02, 4, 2);
    R.pipe(line([[176, 296], [196, 300], [216, 294]]), 3, '#1e1a1e', 0.31, 0.01, 0);
    R.dome(sm([[160, 282], [172, 290], [160, 320], [150, 340], [136, 346], [124, 336], [140, 312]]), '#bab4ba', 0.3, 0.1, 10, 2);
    R.flat(sm([[126, 322], [144, 318], [152, 334], [146, 348], [130, 344]]), '#100e10', 0.32, 0);
    R.dome(sm([[176, 304], [224, 300], [246, 330], [240, 384], [214, 410], [184, 396], [172, 350]]), '#aaa4aa', 0.26, 0.08, 22, 2);
    R.dome(sm([[140, 356], [158, 350], [176, 358], [170, 380], [146, 382]]), '#9e989e', 0.3, 0.05, 6, 2);
    R.pipe(line([[142, 368], [160, 366], [174, 370]]), 2.5, '#2a262a', 0.33, 0.01, 0);
    R.dome(sm([[150, 390], [186, 396], [200, 420], [178, 438], [152, 424]]), '#a8a2a8', 0.26, 0.06, 12, 2);
    { const r = rng(31); for (let i = 0; i < 22; i++) R.bead(130 + r() * 150, 260 + r() * 200, 1.5 + r() * 3, '#f4f0f4', 0.36, 0.04, 1); }
    for (const pts of [[[100, 252], [118, 214], [160, 196], [220, 200], [262, 228], [284, 266]], [[104, 262], [124, 226], [164, 210], [218, 214], [256, 240], [280, 284]], [[118, 420], [128, 452], [152, 480]]])
      R.pipe(line(pts), 3.5, '#d84a2a', 0.36, 0.03, 3);

    // white pole end under the tube, grey chrome loop over the ink
    R.dome(sm([[188, 630], [262, 648], [256, 700], [246, 770], [214, 770], [200, 700]]), '#dcd8dc', 0.2, 0.14, 16, 1);
    R.pipe(line([[408, 300], [436, 330], [446, 380], [428, 420], [404, 400]]), 16, '#8a8286', 0.3, 0.12, 2);
    // the caulk tube
    const TUBE = poly([[285, 382], [372, 398], [302, 664], [174, 636]]);
    R.dome(TUBE, lin(184, 520, 330, 560, [[0, '#ecebee'], [0.18, '#d0ced2'], [0.3, '#9c9aa0'], [0.75, '#8a888e'], [1, '#626066']]), 0.3, 0.16, 26, 3);
    R.flat(poly([[236, 424], [286, 434], [276, 470], [226, 460]]), '#e04a28', 0.47, 0);
    R.flat(poly([[226, 462], [276, 472], [270, 494], [220, 484]]), '#ece6e6', 0.47, 0);
    R.pipe(line([[200, 630], [230, 600], [250, 572]]), 9, '#d63a28', 0.5, 0.05, 3);
    // nozzle / grey arm above the tube
    R.dome(sm([[282, 385], [300, 300], [318, 220], [330, 140], [338, 104], [356, 92], [394, 98], [400, 130], [398, 220], [388, 300], [372, 396]]), lin(300, 100, 400, 400, [[0, '#c8c4ca'], [1, '#8e8a90']]), 0.26, 0.18, 22, 2);
    // chrome tubes at the top
    for (const [pts, wd] of [[[[378, 18], [388, 60], [405, 110], [430, 150], [470, 180], [500, 205]], 18], [[[442, 38], [432, 80], [440, 128], [462, 164]], 13], [[[250, 128], [272, 158], [300, 176], [340, 172]], 14],
      [[[318, 170], [322, 120], [330, 70], [342, 20]], 12], [[[500, 205], [520, 240], [520, 290]], 14]])
      R.pipe(line(pts), wd, '#d8d4da', 0.4, 0.14, 2);
    // white bird / feather in the red field
    R.dome(sm([[492, 92], [520, 72], [540, 70], [546, 96], [600, 152], [652, 160], [650, 178], [600, 182], [576, 174]]), CLAY, 0.3, 0.12, 14, 1);
    for (let i = 0; i < 9; i++) { const an = -1.9 + i * 0.16; R.pipe(line([[536, 80], [536 + Math.cos(an) * 46, 80 + Math.sin(an) * 46]]), 3, '#f0eaea', 0.36, 0.04, 1); }
    // white clay snake
    R.pipe(line([[500, 300], [510, 360], [525, 420], [548, 465], [568, 520], [572, 575], [585, 615], [612, 642], [648, 648], [668, 630], [670, 605], [685, 598], [702, 615], [690, 650], [672, 680], [655, 712], [672, 740], [700, 738], [730, 712]]), 30, CLAY, 0.3, 0.22, 1);
    R.pipe(line([[692, 618], [730, 620]]), 26, CLAY, 0.3, 0.2, 1);
    R.bead(505, 316, 20, '#e8e0de', 0.4, 0.12, 1); R.bead(500, 318, 11, '#9a5a40', 0.52, 0.04, 3);
    // clay puffs right of the tube
    for (const [x, y, r] of [[360, 430, 26], [395, 445, 28], [380, 410, 22], [415, 460, 20]]) R.dome(circleP(x, y, r), CLAY, 0.2, 0.16, r * 0.8, 1);
    // glass bowl, blue sphere, ring
    R.dome(ellipseP(440, 612, 74, 36, 0), lin(370, 580, 510, 650, [[0, '#d8d4d8'], [0.5, '#6a6468'], [1, '#2a262a']]), 0.2, 0.12, 22, 4);
    R.flat(ellipseP(440, 606, 52, 22, 0), '#1e1a1e', 0.26, 4);
    R.bead(560, 672, 30, '#2c3c80', 0.2, 0.2, 4);
    R.dome(ellipseP(548, 738, 46, 30, -0.1), '#e8e4e8', 0.2, 0.12, 14, 1); R.flat(ellipseP(548, 738, 26, 15, -0.1), '#8a868a', 0.26, 0);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.2, shin: 18, wrap: 0.5, ao: 0.5 }),                         // 1 white clay
        E.mat({ dif: 1, spec: 0.8, shin: 30, wrap: 0.3, ao: 0.4, coat: 0.25 }),             // 2 grey chrome statue
        E.mat({ dif: 1, spec: 0.6, shin: 40, wrap: 0.3, ao: 0.3, coat: 0.15 }),             // 3 glossy plastic
        E.mat({ dif: 1, spec: 1.0, shin: 80, wrap: 0.2, ao: 0.2, coat: 0.3 })               // 4 glass / gloss
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.62, 0.6, 0.62], amb: [0.42, 0.4, 0.42],
      envTop: [1, 0.98, 0.98], envHor: [0.5, 0.48, 0.5], envBot: [0.1, 0.09, 0.1], envK: [0.2, 0.8, 0.2, 0],
      r1: 2, r2: 9, k: [0, 0.6, 0.4, 80], shadow: [-5, 6, 0.45, 8]
    });

    // highlight glints
    soft(x => { for (const [px, py, r] of [[430, 285, 10], [588, 315, 7], [367, 116, 6], [215, 140, 8], [302, 155, 6]]) fill(circleP(px, py, r), 'rgba(255,255,255,0.9)', x); }, 2, 1, 'source-over', o);
    E.grain(0.035, 7);
  }
});
