'use strict';
// s21 — "Speckled urchin, candy cones": a lumpy black-speckled body bristling with
// glossy black tubes capped by rainbow-gradient cones, on pure black.
REC.register('s21', {
  w: 859, h: 1024,
  draw(E) {
    const W = 859, H = 1024, CX = 452, CY = 575;
    // spikes: [tipX, tipY, baseX, baseY, baseWidth, baseColour, tipColour, tubeLen]
    const SP = [
      [400, 62, 420, 140, 32, '#ff6a10', '#ff8a20', 110],
      [316, 190, 342, 298, 44, '#58e078', '#3aa8ff', 70],
      [252, 282, 330, 332, 46, '#b8c030', '#d8c848', 60],
      [390, 252, 424, 322, 40, '#a8e858', '#58e080', 70],
      [375, 292, 418, 365, 50, '#ff6010', '#ff7a20', 80],
      [420, 318, 460, 382, 40, '#ffa818', '#ffd040', 70],
      [150, 322, 238, 353, 46, '#8a78ff', '#58d0f0', 80],
      [175, 396, 285, 416, 42, '#6c78ff', '#40d0d0', 70],
      [545, 302, 602, 385, 40, '#7070ff', '#e040a8', 60],
      [546, 337, 586, 410, 48, '#ff6a18', '#ff8a28', 70],
      [634, 316, 692, 405, 50, '#e050d8', '#ff5a18', 60],
      [634, 347, 645, 440, 34, '#50e0a8', '#40c0f0', 60],
      [540, 380, 540, 480, 42, '#ff7818', '#ff8c28', 50],
      [557, 392, 562, 480, 20, '#f0c030', '#f8e050', 40],
      [614, 430, 660, 490, 38, '#d8f048', '#f0f070', 50],
      [688, 418, 680, 508, 48, '#ff9020', '#ffb038', 50],
      [700, 462, 704, 526, 24, '#e8e040', '#f0f060', 40],
      [712, 412, 706, 440, 12, '#40d0a0', '#40d0a0', 30],
      [272, 448, 322, 475, 30, '#40d0a0', '#48d8b0', 50],
      [255, 472, 345, 505, 46, '#e0f040', '#f8f870', 60],
      [195, 470, 242, 500, 26, '#40c0b0', '#48c8c0', 60],
      [146, 486, 214, 536, 40, '#e0f040', '#c8c838', 70],
      [100, 508, 160, 532, 24, '#ffa028', '#ffc040', 70],
      [128, 536, 180, 566, 26, '#ff7020', '#ff9030', 70],
      [200, 618, 246, 626, 26, '#f05818', '#f07028', 60],
      [808, 660, 736, 590, 56, '#ff6a20', '#ff7428', 50],
      [800, 543, 728, 540, 14, '#f0f040', '#f8f860', 50],
      [770, 660, 742, 648, 12, '#e060d0', '#e070d8', 40],
      [175, 662, 268, 690, 54, '#e060d0', '#50a0ff', 60],
      [168, 768, 262, 728, 50, '#30d0a0', '#d8f040', 60],
      [205, 778, 342, 772, 46, '#40e0b0', '#e8f058', 60],
      [283, 812, 357, 818, 32, '#b8f058', '#e0f870', 50],
      [167, 873, 210, 852, 32, '#ff5a20', '#e050d0', 80],
      [192, 944, 255, 928, 30, '#e070d0', '#5090ff', 110],
      [472, 924, 486, 872, 22, '#e0e040', '#f0f060', 50],
      [494, 884, 552, 830, 46, '#40a0f0', '#50e070', 60],
      [433, 848, 482, 852, 18, '#60e070', '#68e878', 40],
      [598, 842, 562, 836, 14, '#e050c0', '#e060d0', 30],
      [411, 628, 444, 618, 16, '#f0e040', '#f8f060', 60],
      [517, 657, 538, 645, 14, '#f0e040', '#f8f060', 60],
      [678, 652, 656, 636, 15, '#40c0a0', '#48c8a8', 30],
      [660, 690, 654, 700, 12, '#40d8f0', '#40d8f0', 30]
    ];
    const R = E.relief(), a = R.a, hx = R.h;
    R.flat(rrect(-10, -10, W + 20, H + 20, 0), '#030303', 0, 0);

    // ── speckled body: silhouette + fat horns radiating toward each spike ──
    const BODY = [[428, 226], [468, 222], [500, 250], [512, 300], [522, 370], [560, 420], [610, 470], [660, 500], [700, 545], [690, 600],
      [676, 650], [652, 700], [640, 760], [610, 826], [560, 852], [500, 862], [430, 860], [350, 852], [292, 842], [258, 818], [246, 770],
      [238, 700], [228, 640], [222, 566], [240, 520], [288, 450], [318, 390], [348, 332], [392, 300], [418, 262]];
    const bodyP = P(BODY);
    R.dome(bodyP, '#222222', 0.05, 0.22, 90, 1);
    const hr = rng(21), horns = [];
    for (const s of SP) {
      const [tx, ty, bx, by, bw, , , tl] = s;
      let dx = tx - bx, dy = ty - by; const L = Math.hypot(dx, dy); dx /= L; dy /= L;
      const ex = bx - dx * tl * 0.35, ey = by - dy * tl * 0.35;         // horn end (sheath top)
      const rx = ex - CX, ry = ey - CY, rl = Math.hypot(rx, ry);
      if (rl < 60 || bw < 20) continue;
      const sx = CX + rx * 0.25, sy = CY + ry * 0.25;
      const mx = (sx + ex) / 2 + (hr() - 0.5) * 30, my = (sy + ey) / 2 + (hr() - 0.5) * 30;
      horns.push(lock([[sx, sy], [mx, my], [ex, ey]], Math.min(130, bw * 2.4), bw * 1.25, 1.0));
    }
    // extra inner lumps
    const lumps = [[470, 300, 40, 90, 0.1], [455, 440, 70, 60, 0], [560, 560, 80, 70, 0.4], [360, 600, 90, 70, -0.3], [470, 700, 90, 80, 0.2],
      [580, 720, 60, 90, 0.5], [360, 760, 80, 60, 0.1], [300, 520, 60, 70, 0], [620, 620, 50, 70, 0.3], [430, 810, 90, 45, 0]];
    let hi = 0;
    for (const [x, y, rx2, ry2, rot] of lumps) R.dome(ellipseP(x, y, rx2, ry2, rot), '#242424', 0.18 + (hi++ % 3) * 0.03, 0.2, Math.min(rx2, ry2), 1);
    horns.forEach((hp, i) => R.dome(P(hp), '#222222', 0.22 + (i % 4) * 0.04, 0.16, 26, 1));

    // ── speckles on the body (albedo, under the tubes) ──
    const bodyAll = new Path2D(); bodyAll.addPath(bodyP);
    for (const hp of horns) bodyAll.addPath(P(hp));
    for (const [x, y, rx2, ry2, rot] of lumps) bodyAll.addPath(ellipseP(x, y, rx2, ry2, rot));
    a.save(); a.clip(bodyAll);
    const sr = rng(5);
    for (let i = 0; i < 9000; i++) {
      const x = 150 + sr() * 580, y = 200 + sr() * 700, r = 0.45 + Math.pow(sr(), 5) * 3.6;
      a.fillStyle = `rgba(255,255,255,${0.6 + sr() * 0.4})`;
      a.beginPath(); a.ellipse(x, y, r, r * (0.7 + sr() * 0.3), sr() * 3, 0, 7); a.fill();
    }
    a.restore();
    // ── black glossy tubes ──
    for (const s of SP) {
      const [tx, ty, bx, by, bw, , , tl] = s;
      let dx = tx - bx, dy = ty - by; const L = Math.hypot(dx, dy); dx /= L; dy /= L;
      const tube = P([[bx - dx * tl * 1.6, by - dy * tl * 1.6], [bx + dx * 2, by + dy * 2]], false, false);
      R.pipe(tube, bw * 0.86, '#050505', 0.36, 0.16, 2);
    }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.05, shin: 8, grain: 0.3, wrap: 0.4, ao: 0.7, emis: 0.05 }),                                   // speckled body
        E.mat({ metal: 1, spec: 1.2, shin: 90, rim: 0.6, coat: 0.25, iri: 0.08, tint: [0.35, 0.35, 0.38] })          // glossy black tube
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.95, 0.95, 1.0], amb: [0.12, 0.12, 0.13],
      envTop: [0.9, 0.9, 0.95], envHor: [0.18, 0.18, 0.2], envBot: [0.0, 0.0, 0.0], envK: [0.3, 1.2, 0.3, 0],
      rimC: [0.15, 0.15, 0.18], rimD: [1, -1, 0.5], l2: [1, -0.3, -0.1, 3], l2c: [0.4, 0.25, 0.1],
      r1: 2, r2: 8, k: [0, 0.6, 0.4, 70], shadow: [6, 8, 0.5, 5]
    });

    const o = E.out;
    // ── rainbow cones ──
    for (const s of SP) {
      const [tx, ty, bx, by, bw, cb, ct] = s;
      let dx = tx - bx, dy = ty - by; const L = Math.hypot(dx, dy); dx /= L; dy /= L;
      const nx = -dy, ny = dx, wt = Math.max(3, bw * 0.36), hb = bw / 2, rt = wt / 2;
      const ex = tx - dx * rt, ey = ty - dy * rt;
      const p = new Path2D();
      p.moveTo(bx + nx * hb, by + ny * hb);
      p.lineTo(ex + nx * rt, ey + ny * rt);
      p.arc(ex, ey, rt, Math.atan2(ny, nx), Math.atan2(ny, nx) + Math.PI, true);
      p.lineTo(bx - nx * hb, by - ny * hb);
      p.ellipse(bx, by, hb, hb * 0.28, Math.atan2(ny, nx), Math.PI, 0, true);
      p.closePath();
      const g = o.createLinearGradient(bx, by, tx, ty);
      g.addColorStop(0, cb); g.addColorStop(1, ct);
      o.fillStyle = g; o.fill(p);
      // cross shading: light from upper-left
      const sgn = (nx * -0.5 + ny * -0.6) > 0 ? 1 : -1;
      const g2 = o.createLinearGradient(bx + nx * hb * sgn, by + ny * hb * sgn, bx - nx * hb * sgn, by - ny * hb * sgn);
      g2.addColorStop(0, 'rgba(255,255,255,0.22)'); g2.addColorStop(0.45, 'rgba(255,255,255,0)'); g2.addColorStop(1, 'rgba(0,0,0,0.18)');
      o.fillStyle = g2; o.fill(p);
    }
    E.grain(0.02, 3);
  }
});
