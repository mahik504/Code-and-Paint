'use strict';
// g222 — "Jellyfish dome summit": a pale sculpted slope under blue sky and pines, airbrushed with black zebra waves and a
// spiral, a glass dome with an orange jellyfish on top, striped soles in the snow and a spiky blue octopus below.
REC.register('g222', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipAH = (path, fn) => { a.save(); R.h.save(); a.clip(path); R.h.clip(path); fn(); a.restore(); R.h.restore(); };
    const soft = (fn, blur, alpha = 1, clipP = null, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); if (clipP) a.clip(clipP); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st, fx = x, fy = y, r0 = 0) => { const g = a.createRadialGradient(fx, fy, r0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const pts = f => { const q = []; for (let i = 0; i < f.length; i += 2) q.push([f[i], f[i + 1]]); return q; };
    const sm = f => P(pts(f), true, true), ln = f => P(pts(f), false, true), poly = f => P(pts(f), true, false);
    const hfx = (body, m) => E.fx(`${body}
      vec3 fx(vec2 uv, vec2 p){ float h = clamp(hgt(p), 0., 1.) * 255.; return vec3(floor(h) / 255., ${(m * 32 / 255).toFixed(5)}, fract(h)); }`);
    const ball = (x, y, r, c0, c1, c2, m = 5, h0 = 0.3) => R.dome(circleP(x, y, r), rad(x, y, r, [[0, c0], [0.7, c1], [1, c2]], x - r * 0.3, y - r * 0.35), h0, Math.min(0.3, r * 0.01 + 0.06), r, m);
    // pine silhouette: jagged tiers of drooping branch tips
    const pine = (x, top, bot, wMax, seed) => {
      const r = rng(seed), L = [], Rr = [];
      for (let y = top, k = 0; y < bot; y += 7 + r() * 5, k++) {
        const t = Math.min(1, (y - top) / Math.min(300, bot - top)), w = wMax * Math.pow(t, 0.6) * (0.6 + 0.4 * ((k % 3) / 2)) * (0.75 + r() * 0.5);
        L.push([x - w, y + 6 + r() * 6], [x - w * 0.35, y - 2]); Rr.push([x + w, y + 6 + r() * 6], [x + w * 0.35, y - 2]);
      }
      return P([[x, top - 6], ...Rr, [x + 4, bot], [x - 4, bot], ...L.reverse()], true, false);
    };

    // ── 1. frame and sky ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#120605', 0, 0);
    const IN = rrect(16, 15, 696, 988, 0);
    clipAH(IN, () => {
      R.flat(IN, lin(0, 15, 0, 560, [[0, '#86a0e2'], [0.45, '#a2b8ec'], [1, '#bccdf2']]), 0, 0);
      soft(x => { x.fillStyle = rad(590, 30, 110, [[0, 'rgba(240,180,80,1)'], [0.5, 'rgba(226,170,90,0.6)'], [1, 'rgba(200,150,140,0)']]); x.fillRect(420, -60, 330, 220); }, 6);
      // pines behind
      soft(x => {
        x.fillStyle = '#0e0e14';
        // measured silhouettes, feathered with short drooping needle strokes along their free edges
        const TL = [52, 222, 60, 245, 70, 262, 80, 278, 76, 292, 100, 306, 95, 322, 118, 336, 112, 352, 102, 367, 98, 382, 80, 396, 150, 410, 168, 425, 160, 460, 150, 485, 140, 515, 130, 545, 120, 600, 100, 650, 80, 720, 66, 780, 16, 780, 16, 272, 34, 260, 45, 244];
        x.fill(poly(TL));
        const r = rng(21); x.lineWidth = 1.8; x.strokeStyle = '#0e0e14';
        for (const [T, free] of [[TL, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 26, 27]]]) for (const e of free) {
          const n = T.length / 2, x0 = T[e * 2], y0 = T[e * 2 + 1], x1 = T[(e + 1) % n * 2], y1 = T[(e + 1) % n * 2 + 1], L = Math.hypot(x1 - x0, y1 - y0);
          for (let k = 0; k < L / 1.5; k++) { const u = r(), px = x0 + (x1 - x0) * u, py = y0 + (y1 - y0) * u, sd = px < (T === TL ? 70 : 690) ? -1 : 1;
            x.beginPath(); x.moveTo(px - sd * 4, py - 2); x.lineTo(px + sd * (3 + r() * 9), py + 3 + r() * 8); x.stroke(); } }
      }, 1.6);
      // white tube with a lemon end cap
      R.pipe(ln([-20, 0, 40, 40, 100, 86]), 62, lin(20, 60, 60, 0, [[0, '#cfd0cc'], [0.5, '#f6f6f2'], [1, '#c0c2be']]), 0.3, 0.2, 2);
      R.dome(ellipseP(121, 106, 30, 31, -0.5), rad(118, 104, 34, [[0, '#f4f4b4'], [1, '#d4d47c']]), 0.4, 0.06, 10, 2);
      R.bead(124, 108, 4, '#a0a070', 0.42, -0.02, 2);
    });

    // ── 2. the sculpture ──
    const SK = [466, 15, 448, 40, 433, 60, 418, 80, 402, 100, 388, 120, 372, 140, 355, 160, 335, 180, 318, 200, 300, 225, 287, 250, 270, 275, 255, 300, 240, 320, 225, 340, 212, 360, 198, 380, 183, 400, 168, 425,
      152, 460, 140, 500, 128, 545, 115, 600, 100, 650, 88, 700, 78, 750, 70, 778];
    const body = poly([...SK, 16, 765, 16, 1003, 712, 1003, 712, 15]);
    R.dome(body, '#d6d4da', 0.1, 0.1, 30, 1);
    // upper lavender slope (above the ridge)
    const top = sm([...SK.slice(0, 40), 250, 350, 330, 316, 400, 301, 470, 296, 560, 288, 640, 230, 712, 150, 712, 15]);
    clipAH(body, () => {
      R.dome(top, lin(520, 20, 230, 380, [[0, '#9a8aa8'], [0.3, '#8682ac'], [0.6, '#767aa2'], [1, '#5c6aa0']]), 0.12, 0.08, 40, 1);
      soft(x => { x.strokeStyle = 'rgba(80,100,170,0.7)'; x.lineWidth = 22; x.stroke(ln(SK.slice(0, 40))); }, 5, 1, top);
      soft(x => { x.fillStyle = rad(590, 30, 150, [[0, 'rgba(236,170,90,0.75)'], [1, 'rgba(236,170,90,0)']]); x.fillRect(400, 0, 320, 200); }, 4, 1, top);
      // lower facet shading: grey towards the left edge, white in the middle, pink glow low left
      soft(x => {
        x.fillStyle = rad(330, 560, 260, [[0, 'rgba(232,230,234,1)'], [0.6, 'rgba(220,219,225,0.8)'], [1, 'rgba(200,200,210,0)']]); x.fillRect(0, 300, 726, 700);
        x.fillStyle = 'rgba(160,163,178,0.8)'; x.fill(sm([170, 420, 230, 390, 240, 520, 200, 650, 120, 700, 110, 560]));
        x.fillStyle = 'rgba(230,190,200,0.6)'; x.fill(ellipseP(160, 760, 120, 70, -0.5));
        x.fillStyle = 'rgba(110,128,150,0.75)'; x.fill(ellipseP(470, 560, 60, 70, 0.3));
      }, 30, 1, body);
    });

    // the right pine stands in front of the upper slope
    soft(x => { const TR = [695, 58, 705, 70, 712, 72, 712, 250, 644, 250, 644, 130, 666, 115, 671, 100, 681, 85]; x.fillStyle = '#0e0e14'; x.fill(poly(TR));
      const r = rng(22); x.lineWidth = 1.8; x.strokeStyle = '#0e0e14';
      for (const e of [0, 5, 6, 7, 8]) { const n = 9, x0 = TR[e * 2], y0 = TR[e * 2 + 1], x1 = TR[(e + 1) % n * 2], y1 = TR[(e + 1) % n * 2 + 1], L = Math.hypot(x1 - x0, y1 - y0);
        for (let k = 0; k < L / 1.5; k++) { const u = r(), px = x0 + (x1 - x0) * u, py = y0 + (y1 - y0) * u; x.beginPath(); x.moveTo(px + 4, py - 2); x.lineTo(px - 3 - r() * 9, py + 3 + r() * 8); x.stroke(); } } }, 1.6, 1, IN);
    // zebra waves on the lower facet: soft airbrushed black bands traced from the jellyfish base, plus a spiral
    const facet = poly([183, 400, 250, 350, 330, 316, 400, 301, 470, 296, 560, 288, 590, 330, 560, 420, 520, 480, 470, 520, 430, 560, 360, 610, 300, 650, 240, 700, 170, 760, 120, 760, 110, 650, 140, 500]);
    soft(x => {
      x.strokeStyle = '#121218';
      // tapered ribbons: thin where they leave the jellyfish, wider down the slope
      const rs = f => { const q = pts(f), o = [], g = i => q[Math.max(0, Math.min(q.length - 1, i))];
        for (let i = 0; i < q.length - 1; i++) { const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2), n = Math.max(1, Math.round(Math.hypot(p2[0] - p1[0], p2[1] - p1[1]) / 4));
          for (let k = 0; k < n; k++) { const t = k / n, t2 = t * t, t3 = t2 * t, cr = (a0, a1, a2, a3) => 0.5 * (2 * a1 + (a2 - a0) * t + (2 * a0 - 5 * a1 + 4 * a2 - a3) * t2 + (3 * a1 - a0 - 3 * a2 + a3) * t3);
            o.push([cr(p0[0], p1[0], p2[0], p3[0]), cr(p0[1], p1[1], p2[1], p3[1])]); } }
        o.push(q[q.length - 1]); return o; };
      x.fillStyle = '#121218';
      for (const [w0, w1, f] of [
        [16, 30, [452, 298, 429, 308, 400, 328, 354, 340, 332, 360, 294, 381, 282, 396, 272, 428, 277, 456, 261, 471, 253, 484, 194, 502, 153, 527, 110, 552]],
        [10, 26, [468, 312, 430, 336, 388, 353, 332, 413, 317, 477, 317, 525, 315, 555, 304, 577, 262, 588, 222, 614, 190, 642]],
        [8, 22, [482, 316, 450, 329, 391, 390, 373, 417, 362, 445, 356, 480, 357, 510, 354, 535, 344, 554, 309, 594, 279, 610, 260, 635, 246, 662]],
        [7, 14, [492, 312, 457, 340, 446, 369, 436, 375]], [8, 14, [500, 320, 478, 341, 465, 353, 464, 368, 506, 380, 524, 404, 528, 432, 520, 452]],
        [14, 16, [508, 463, 507, 485, 486, 509, 462, 507, 430, 512]], [18, 20, [236, 538, 194, 555, 154, 576, 128, 604]],
        [5, 9, [510, 318, 490, 335, 488, 350, 525, 361, 545, 380]], [4, 8, [520, 316, 505, 330, 540, 345, 560, 360]], [4, 8, [500, 300, 520, 330, 540, 335]]])
        x.fill(P(lock(rs(f), w0, w1, 1), true, false));
      // spiral: one arm winding out from the centre
      x.lineWidth = 8; const q = []; for (let t = 0.5; t < 4.6 * 6.283; t += 0.15) { const r = 2 + t * 2.2; q.push(440 + Math.cos(t + 1) * r, 443 + Math.sin(t + 1) * r * 0.93); } x.stroke(ln(q));
    }, 2.4, 1, facet);
    // embossed spiral low left
    R.groove(ln((() => { const q = []; for (let t = 0; t < 4.2 * 6.283; t += 0.2) { const r = 3 + t * 1.55; q.push(140 + Math.cos(-t) * r, 688 + Math.sin(-t) * r * 0.95); } return q; })()), 5, '#9a9aa8', 0.21, 0.04, 1, 0.6);

    // ── 3. glass dome with the jellyfish ──
    const dome = P([[402, 300], [400, 250], [412, 200], [440, 160], [480, 132], [525, 122], [570, 128], [612, 150], [640, 185], [652, 230], [648, 285], [640, 300]], true, true);
    R.dome(dome, rad(520, 230, 140, [[0, '#8a8cb8'], [0.7, '#8088b8'], [1, '#a0aad6']], 470, 170), 0.2, 0.04, 24, 3);
    soft(x => { x.strokeStyle = 'rgba(210,225,255,0.8)'; x.lineWidth = 3; x.stroke(ln([410, 262, 412, 210, 438, 166, 482, 136, 528, 125])); }, 1.5, 1);
    soft(x => { x.strokeStyle = 'rgba(70,80,130,0.8)'; x.lineWidth = 1.2; const r = rng(4); for (let i = 0; i < 10; i++) { let px = 560 + r() * 60, py = 150 + r() * 50; x.beginPath(); x.moveTo(px, py); for (let k = 0; k < 6; k++) { px += (r() - 0.5) * 8; py += 4 + r() * 3; x.lineTo(px, py); } x.stroke(); } }, 0.3, 1);
    // tentacles: orange, flowing down into the zebra lines
    soft(x => {
      const r = rng(8);
      for (let i = 0; i < 40; i++) { const x0 = 484 + i * 1.6, sw = (i - 20) / 20; x.strokeStyle = ['#e8a060', '#c8703a', '#f4d0b0'][i % 3]; x.lineWidth = 1.8;
        x.stroke(ln([x0, 215, x0 + sw * 10 + 4 * Math.sin(i), 240, x0 + sw * 30 + 6 * Math.sin(i * 1.7), 270, x0 + sw * 60 - 8, 300])); }
    }, 0.4, 1);
    R.dome(sm([470, 222, 472, 200, 485, 182, 505, 172, 528, 172, 548, 182, 560, 200, 562, 222, 540, 230, 515, 232, 490, 230]), rad(510, 180, 60, [[0, '#ffb878'], [0.6, '#f4904a'], [1, '#dc6a2c']]), 0.3, 0.16, 18, 3);
    for (let i = 0; i < 5; i++) R.groove(ln([474 + i * 5, 218 - i * 9, 515, 214 - i * 10, 558 - i * 5, 218 - i * 9]), 3, '#c8602a', 0.44, 0.03, 3, 0.6);
    R.dome(ellipseP(441, 270, 30, 22, 0.35), rad(436, 262, 34, [[0, '#3a3a44'], [0.7, '#0c0c10'], [1, '#040406']]), 0.25, 0.14, 14, 4);
    R.bead(424, 260, 9, '#f08a30', 0.36, 0.04, 3);
    R.dome(P(star(583, 210, 15, 6, 5, -0.3), true, false), '#3a3e50', 0.3, 0.05, 4, 4);
    R.dome(P([[598, 150], [636, 112], [628, 150], [640, 172], [608, 168]], true, true), lin(600, 110, 640, 170, [[0, '#d0d4e0'], [1, '#606478']]), 0.3, 0.1, 8, 4);

    // ── 4. snow drift on the right ──
    const snow = sm([712, 172, 690, 166, 660, 172, 630, 192, 618, 205, 588, 240, 562, 278, 548, 330, 556, 380, 540, 440, 505, 500, 474, 548, 452, 600, 446, 650, 480, 670, 712, 670]);
    R.dome(snow, lin(560, 150, 700, 500, [[0, '#d8d8e2'], [0.5, '#d4d4de'], [1, '#c0c2d2']]), 0.14, 0.14, 40, 2);
    clipAH(snow, () => img(hfx(`float hgt(vec2 p){ float n = fbm(p * vec2(0.018, 0.03)) + 0.25 * fbm(p * 0.07 + 3.); return 0.22 + 0.06 * n; }`, 2), R.h));
    soft(x => { x.fillStyle = 'rgba(120,135,170,0.6)'; x.fill(ellipseP(575, 390, 30, 70, 0.4)); x.fill(ellipseP(500, 560, 40, 60, 0.4)); }, 16, 1, snow);

    // ── 5. striped soles ──
    const sole = (cx, cy, rx, ry, rot, bands, seed) => {
      const o = ellipseP(cx, cy, rx + 9, ry + 9, rot), i = ellipseP(cx, cy, rx, ry, rot);
      R.dome(o, '#2a2a32', 0.22, 0.08, 10, 4);
      R.dome(i, '#26252c', 0.28, 0.04, 16, 4);
      clipAH(i, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 d = p - vec2(${cx}., ${cy}.); float c = cos(${rot}), s = sin(${rot});
        vec2 q = vec2(c * d.x + s * d.y, -s * d.x + c * d.y);
        float st = vnoise(vec2(q.x * 0.08, q.y * 1.4 + ${seed}.)) * 0.6 + vnoise(vec2(q.x * 0.02, q.y * 0.6)) * 0.4;
        vec3 col = vec3(0.12, 0.12, 0.14) + 0.14 * st;
        float b = 0.; ${bands.map(([y0, w]) => `b = max(b, smoothstep(${(w / 2 + 2).toFixed(1)}, ${(w / 2 - 2).toFixed(1)}, abs(q.y - (${y0}.))));`).join(' ')}
        col = mix(col, vec3(0.78, 0.78, 0.8) * (0.7 + 0.5 * st), b * (0.6 + 0.4 * step(0.35, vnoise(vec2(q.x * 0.15, q.y * 2.)))));
        return col; }`)));
    };
    sole(650, 632, 66, 226, -0.2, [[-180, 18], [-120, 14], [-60, 22], [40, 30], [190, 18]], 3);
    sole(549, 670, 66, 142, -0.12, [[-95, 26], [-35, 12], [55, 18], [70, 10]], 7);
    sole(718, 415, 38, 78, -0.15, [[-40, 14], [10, 16]], 9);
    R.dome(ellipseP(690, 712, 31, 56, -0.18), '#3a3a44', 0.34, 0.03, 6, 4);
    R.dome(ellipseP(690, 712, 25, 49, -0.18), rad(690, 700, 50, [[0, '#c4c2cc'], [1, '#9e9cac']]), 0.3, 0.04, 14, 2);
    R.pipe(ln([520, 548, 512, 600, 516, 660, 524, 720, 530, 780]), 3, '#c8c8cc', 0.34, 0.01, 4);
    for (const [x, y] of [[512, 552], [532, 606], [587, 774], [664, 563], [694, 624], [655, 649], [682, 773]]) R.bead(x, y, 4, '#d8a858', 0.4, 0.04, 3);

    // ── 6. low glow floor, red band, cyan pool ──
    const floor = poly([16, 765, 70, 778, 130, 790, 250, 720, 300, 780, 280, 1003, 16, 1003]);
    R.flat(floor, lin(16, 780, 120, 1000, [[0, '#ebdcdc'], [0.4, '#e8cdd2'], [1, '#6a5a72']]), 0.1, 0);
    soft(x => { x.strokeStyle = '#f53a5c'; x.lineWidth = 46; x.stroke(ln([0, 905, 120, 840, 260, 755])); }, 8, 1, floor);
    soft(x => { x.strokeStyle = 'rgba(255,120,150,0.7)'; x.lineWidth = 110; x.stroke(ln([0, 905, 120, 840, 260, 755])); }, 30, 0.6);
    const pool = sm([440, 780, 520, 800, 600, 830, 712, 860, 712, 1003, 440, 1003]);
    R.flat(pool, lin(440, 800, 712, 1003, [[0, '#a2c0cc'], [0.5, '#8ab8c8'], [1, '#86a0bc']]), 0.12, 2);
    soft(x => { x.fillStyle = 'rgba(150,226,226,0.9)'; x.fill(ellipseP(500, 960, 130, 80, 0)); x.fillStyle = 'rgba(100,130,170,0.6)'; x.fill(ellipseP(680, 880, 60, 60, 0)); }, 40, 1, pool);
    soft(x => { x.fillStyle = '#141820'; x.fill(sm([440, 690, 490, 690, 520, 790, 500, 860, 455, 860])); }, 14, 0.9);

    // ── 7. the octopus ──
    R.dome(ellipseP(382, 575, 30, 21, -0.1), '#e8e4ec', 0.2, 0.06, 6, 3);
    R.dome(ellipseP(382, 575, 23, 15, -0.1), rad(378, 570, 26, [[0, '#ff9a8a'], [0.4, '#f02818'], [1, '#c01010']]), 0.24, 0.06, 10, 3);
    const tent = [[245, 740, 190, 800, 132, 862, 96, 925, 74, 1000], [272, 755, 225, 828, 180, 900, 158, 1003], [300, 760, 276, 850, 254, 930, 242, 1003],
      [332, 750, 322, 850, 312, 1003], [362, 742, 372, 850, 372, 1003], [395, 732, 412, 850, 424, 1003]];
    const TB = lin(0, 720, 0, 1003, [[0, '#9cb8e0'], [0.5, '#88a8d6'], [1, '#7a9cd0']]);
    for (const [k, t] of tent.entries()) {
      R.pipe(ln(t), 50 - k * 1.5, TB, 0.25, 0.14, 6);
      // spiky bumps along both sides
      const q = pts(t), r = rng(30 + k);
      for (let i = 0; i < q.length - 1; i++) { const [x0, y0] = q[i], [x1, y1] = q[i + 1], L = Math.hypot(x1 - x0, y1 - y0), nx = -(y1 - y0) / L, ny = (x1 - x0) / L;
        for (let s = 10; s < L; s += 22) { for (const sd of [-1, 1]) { const u = s / L, px = x0 + (x1 - x0) * u + nx * sd * 22, py = y0 + (y1 - y0) * u + ny * sd * 22;
          R.dome(P(star(px, py, 9 + r() * 3, 4, 3, r() * 6), true, true), '#a8c4ec', 0.33, 0.06, 4, 6); }
          R.dome(P(star(x0 + (x1 - x0) * (s + 11) / L, y0 + (y1 - y0) * (s + 11) / L, 8, 3.5, 3, r() * 6), true, true), '#b4ccf0', 0.38, 0.05, 3, 6); } }
    }
    // crown, eye, spiral disc, black bead
    R.dome(P(star(352, 684, 66, 50, 22, 0.1), true, true), '#9cb4d8', 0.3, 0.12, 14, 6);
    { const r = rng(17); for (let i = 0; i < 22; i++) { const t = i / 22 * 6.283, rr = 46 + r() * 12; R.dome(P(star(352 + Math.cos(t) * rr, 684 + Math.sin(t) * rr, 9, 4, 3, r() * 6), true, true), '#b8cce8', 0.42, 0.06, 4, 6); } }
    R.dome(circleP(332, 686, 27), '#e4e8f0', 0.44, 0.06, 6, 3);
    R.dome(circleP(332, 686, 19), rad(328, 680, 22, [[0, '#ffc0b0'], [0.3, '#ff3020'], [1, '#c01008']]), 0.5, 0.06, 10, 3);
    R.dome(circleP(262, 671, 34), '#5a6c90', 0.34, 0.12, 14, 6);
    for (let i = 1; i <= 6; i++) R.groove(circleP(262, 671, i * 5), 2.5, '#2a3858', 0.46, 0.04, 6, 0.7);
    ball(432, 665, 27, '#7a7c88', '#16161c', '#060608', 4, 0.3);
    R.dome(ellipseP(418, 660, 10, 16, 0.2), '#e88a40', 0.5, 0.04, 6, 3);
    R.pipe(ln([396, 722, 410, 745, 432, 760, 440, 790, 460, 805, 470, 830, 482, 850]), 3, '#e8e8ec', 0.45, 0.01, 3);

    // droplets on the slope
    for (const [x, y, r] of [[300, 278, 10], [345, 293, 9], [262, 320, 6], [248, 352, 8], [233, 422, 5], [183, 455, 13], [228, 430, 6], [265, 535, 10], [237, 550, 7], [140, 625, 5], [160, 627, 7],
      [215, 740, 7], [150, 770, 9], [100, 755, 6], [367, 188, 4], [392, 199, 4], [358, 210, 3], [196, 760, 4], [118, 735, 4], [332, 365, 4], [318, 415, 4]])
      R.dome(circleP(x, y, r), rad(x, y, r, [[0, '#ffffff'], [0.5, '#c4c8d8'], [1, '#8a90a8']], x - r * 0.3, y - r * 0.4), 0.3, 0.05, r * 0.8, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 30, wrap: 0.6, ao: 0.3, coat: 0.05 }),                    // 1 sculpture
        E.mat({ dif: 1, spec: 0.2, shin: 20, wrap: 0.6, ao: 0.5 }),                                // 2 snow / tube
        E.mat({ dif: 1, spec: 1.2, shin: 70, wrap: 0.4, ao: 0.3, coat: 0.2 }),                     // 3 glossy
        E.mat({ dif: 1, spec: 0.5, shin: 40, wrap: 0.4, ao: 0.4, coat: 0.1 }),                     // 4 soles / black
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.4, ao: 0.3, coat: 0.15 }),                    // 5 beads
        E.mat({ dif: 1, spec: 0.5, shin: 36, wrap: 0.5, ao: 0.5, coat: 0.08 }),                    // 6 octopus
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.7, 0.7, 0.72], amb: [0.42, 0.42, 0.46],
      envTop: [1.2, 1.25, 1.35], envHor: [0.6, 0.62, 0.7], envBot: [0.15, 0.15, 0.2], envK: [0.3, 1.0, 0.3, 0],
      r1: 1.5, r2: 8, k: [0, 0.6, 0.4, 70], shadow: [-4, 6, 0.5, 6]
    });
    // yellow light beam across the slope
    { const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = 'round';
      x.filter = `blur(${10 * S}px)`; x.strokeStyle = 'rgba(250,220,150,0.8)'; x.lineWidth = 34; x.stroke(ln([16, 588, 300, 505, 575, 425]));
      x.filter = `blur(${3 * S}px)`; x.strokeStyle = 'rgba(255,248,220,0.9)'; x.lineWidth = 10; x.stroke(ln([16, 588, 300, 505, 575, 425]));
      E.draw(c, 1, 'screen'); }
    // frame on top
    { const o = E.out; o.save(); o.fillStyle = '#120605'; const fr = new Path2D(); fr.rect(-5, -5, 736, 1034); fr.rect(16, 15, 696, 988); o.fill(fr, 'evenodd'); o.restore(); }
  }
});
