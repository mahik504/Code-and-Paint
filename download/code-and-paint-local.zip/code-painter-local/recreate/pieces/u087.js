'use strict';
// u087 — "Plaster moon mask": crumpled grey plaster lumps and a gold eye-mask burst through a white-rimmed
// disc of colour fields — striped sky, red sun, green and blue panels, purple tiles — on speckled concrete.
REC.register('u087', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const inside = (path, fn) => { a.save(); R.h.save(); a.clip(path); R.h.clip(path); fn(); R.h.restore(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };
    const pf = q => { const r = []; for (let i = 0; i < q.length; i += 2) r.push([q[i], q[i + 1]]); return r; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const pg = (q, s = false) => P(pf(q), true, s);

    const CREAM = '#d9d5d4', CONC = '#979394', GREEN = '#1a7c1a', BLUE = '#2c84b8', PURP = '#6e4a96', SKY = '#7092b2';
    const RIMB = [], RIMT = [[560, -30], [600, 0], [650, 35], [700, 85], [726, 115], [760, 160]];

    // ── speckled concrete ground ──
    const CON = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float n = fbm(p * .05) * .5 + fbm(p * .5) * .3 + hash(floor(p)) * .2;
        float b = .58 + .1 * (n - .5) - .18 * step(.93, hash(floor(p / 1.5) + 2.)) + .1 * step(.95, hash(floor(p / 1.5) + 9.));
        return vec3(b * 1.01, b * .99, b * 1.0); }`);
    img(CON);
    // the striped sky band along the top, red hairline
    fill(poly([[0, 0], [540, 0], [540, 182], [0, 182]]), '#d8dbe0');
    for (const [y0, y1] of [[10, 17], [29, 37], [51, 62], [72, 84], [97, 116], [132, 149], [160, 170]]) fill(poly([[0, y0], [540, y0 + 1], [540, y1 + 1], [0, y1]]), SKY);
    fill(poly([[0, 0], [540, 0], [540, 5], [0, 5]]), '#c8382c');

    // ── the disc: cream field (wrapping the sun's rim), ring, colour panels ──
    for (let t = 0.62; t <= 2.86; t += 0.08) RIMB.push([408 + 467 * Math.cos(t), 506 + 467 * Math.sin(t)]);
    const DISC = P([[-30, -30], ...RIMT, ...RIMB], true, true);
    clipA(DISC, () => { R.flat(P([[0, 183], [100, 182], [170, 178], [205, 150], [560, 150], [560, 600], [0, 600]], true, false), CREAM, 0.06, 1); R.flat(circleP(335, 178, 146), CREAM, 0.06, 1); });
    // grey concrete tiles on the left of the disc, with paler and black squares
    const GIN = sm([[0, 335], [55, 335], [72, 348], [92, 382], [130, 412], [175, 452], [250, 462], [272, 520], [300, 560], [238, 602], [180, 650], [150, 720], [132, 790], [136, 850], [152, 886], [60, 840], [0, 730]]);
    clipA(DISC, () => clipA(GIN, () => img(CON)));
    for (const [x, y, w, h] of [[60, 335, 70, 65], [178, 455, 66, 62], [110, 580, 90, 62], [0, 470, 60, 70]]) fill(poly([[x, y], [x + w, y + 2], [x + w - 2, y + h], [x, y + h - 2]]), 'rgba(175,172,174,0.55)');
    for (const q of [[51, 542, 0, 543, 0, 678, 68, 675, 61, 556], [0, 339, 0, 467, 47, 465, 53, 459, 49, 414, 31, 390, 20, 359]]) R.flat(pg(q), '#151416', 0.06, 0);
    // purple tiles
    for (const q of [[73, 678, 79, 812, 140, 857, 177, 873, 170, 833, 157, 824, 125, 778, 126, 762, 164, 676], [725, 236, 679, 241, 704, 365, 725, 364],
      [287, 574, 249, 589, 200, 588, 188, 605, 188, 624, 179, 640, 188, 643, 211, 621, 272, 595, 287, 581], [615, 48, 629, 105, 676, 102, 654, 74, 623, 48]])
      R.flat(pg(q), PURP, 0.06, 0);
    // green panel (with its oval holes) and blue panels
    R.flat(pg([534, 0, 528, 103, 559, 102, 573, 116, 576, 133, 570, 142, 556, 145, 539, 138, 527, 115, 521, 115, 514, 148, 546, 160, 570, 187, 587, 237, 585, 297, 615, 333, 617, 368, 696, 366, 694, 345, 667, 352, 644, 334, 646, 318, 657, 309, 687, 317, 673, 241, 643, 244, 617, 237, 602, 220, 601, 201, 629, 165, 656, 152, 675, 151, 690, 157, 710, 185, 708, 206, 691, 233, 725, 232, 725, 159, 683, 106, 625, 108, 608, 40, 546, 0]), GREEN, 0.06, 0);
    fill(poly([[608, 40], [700, 20], [726, 30], [726, 160], [683, 106], [625, 108]]), GREEN);
    fill(poly([[615, 48], [629, 105], [676, 102], [654, 74], [623, 48]]), PURP);
    R.flat(pg([553, 412, 553, 429, 560, 438, 671, 508, 703, 540, 725, 542, 725, 522, 705, 510, 706, 495, 725, 487, 725, 365, 618, 373, 599, 399], true), BLUE, 0.06, 0);
    R.flat(pg([688, 719, 645, 738, 618, 730, 608, 762, 585, 764, 578, 745, 567, 744, 498, 781, 491, 914, 557, 904, 619, 886, 617, 856, 652, 830, 657, 806, 668, 805, 681, 788, 694, 782]), BLUE, 0.06, 0);
    fill(poly([[440, 840], [500, 780], [498, 920], [440, 925]]), '#141315');
    for (const q of [[493, 784, 421, 800, 381, 838, 323, 913, 323, 922, 486, 914], [725, 651, 697, 657, 693, 689, 666, 708, 666, 714, 691, 718, 696, 791, 704, 793, 704, 802, 692, 803, 690, 809, 682, 802, 658, 809, 655, 831, 619, 858, 623, 879, 673, 859, 725, 822]])
      R.flat(pg(q), '#121113', 0.06, 0);
    // the white rim of the disc, with a black hairline on its upper right
    R.pipe(line(RIMB), 28, '#dedad8', 0.08, 0.06, 1); R.pipe(line(RIMT), 18, '#dedad8', 0.08, 0.06, 1);
    R.pipe(line([[600, 6], [628, 20], [650, 44], [664, 40], [684, 66], [706, 96], [726, 120]]), 3, '#18181a', 0.12, 0.02, 0);
    // outside the disc again: concrete over the overshoot, dark brushed slab bottom right
    { const out = new Path2D(); out.rect(-10, -10, 746, 1044); out.addPath(circleP(408, 506, 479)); a.save(); a.clip(out, 'evenodd'); a.clip(P([[-10, 300], [760, 300], [760, 1040], [-10, 1040]], true, false)); img(CON); a.restore(); }
    { const TR = poly([[640, 0], [726, 0], [726, 92], [690, 52]]); fill(TR, '#3c3b40'); clipA(TR, () => { const r = rng(5); for (let i = 0; i < 30; i++) { const x = 640 + r() * 90; stroke(line([[x, 0], [x + 30, 100]]), 'rgba(170,170,175,0.35)', 0.8); } }); }
    const SLAB = pg([600, 1024, 726, 1024, 726, 870, 690, 890, 640, 905, 600, 915]);
    fill(SLAB, '#2f2e33'); clipA(SLAB, () => { const r = rng(3); for (let i = 0; i < 40; i++) { const y = 880 + r() * 150; stroke(line([[600, y], [726, y + (r() - 0.5) * 4]]), `rgba(${120 + r() * 80 | 0},${120 + r() * 80 | 0},${125 + r() * 80 | 0},0.5)`, 0.6 + r() * 1.5); } });

    // ── red sun in its white ring ──
    const SUNC = poly([[150, 0], [540, 0], [540, 205], [150, 205]]);
    clipA(SUNC, () => {
      R.flat(circleP(335, 178, 146), '#dcd8d6', 0.08, 1);
      fill(circleP(335, 178, 131), lin(230, 70, 440, 230, [[0, '#ec6a1c'], [0.35, '#d83a1e'], [1, '#c4201e']]));
    });
    // grey ovals and the pale sprayed halo
    soft(x => fill(circleP(520, 214, 78), 'rgba(170,180,170,0.95)', x), 10);
    soft(x => { fill(ellipseP(115, 225, 62, 36, 0.12), '#8e8d90', x); fill(ellipseP(252, 352, 50, 62, -0.15), '#959497', x); }, 5);
    for (const [x, y, rx, ry, rt, c] of [[548, 121, 22, 20, 0, '#a8a8aa'], [655, 196, 52, 41, -0.15, '#a9a9ab'],
      [665, 327, 20, 19, 0, '#a5a5a7'], [355, 470, 12, 11, 0, '#8a8a8c']]) {
      soft(xx => fill(ellipseP(x + 5, y + 6, rx, ry, rt), 'rgba(40,40,40,0.5)', xx), 5);
      R.dome(ellipseP(x, y, rx, ry, rt), c, 0.08, 0.08, Math.min(rx, ry) * 0.6, 2);
    }
    // the white-and-grey ring eye on the left edge
    R.dome(circleP(18, 150, 34), '#d8d6d6', 0.08, 0.08, 10, 2); R.dome(circleP(14, 150, 18), '#8c8c8e', 0.1, 0.04, 6, 2); R.flat(circleP(10, 152, 7), '#121212', 0.14, 0);

    // ── crumpled plaster lumps ──
    const crumple = (path, seed, n, ang, len, amp, col) => inside(path, () => {
      const r = rng(seed);
      for (let i = 0; i < n; i++) {
        const x0 = r() * 726, y0 = r() * 1024, pts = [];
        for (let k = 0; k <= 8; k++) { const t = k / 8; pts.push([x0 + Math.cos(ang) * len * t + Math.sin(t * 3 + i) * amp * 0.3, y0 + Math.sin(ang) * len * t + Math.sin(t * 4 + i * 1.7) * amp]); }
        const w = 2 + r() * 5;
        if (r() < 0.6) R.pipe(line(pts), w, r() < 0.6 ? col : null, 0.3, 0.08 + r() * 0.1, 2);
        else R.groove(line(pts), w, '#5e5e62', 0.32, 0.08, 2, 0.45);
      }
    });
    // plaster streak relief: an anisotropic noise added into the height map (red channel) and into the albedo
    const plaster = (path, ang, fx_, fy_, amt, dark) => {
      const cv = E.fx(`
        vec3 fx(vec2 uv, vec2 p){
          float c = cos(${ang.toFixed(3)}), s = sin(${ang.toFixed(3)});
          vec2 q = vec2(c * p.x + s * p.y, -s * p.x + c * p.y);
          q.y += 14. * fbm(p * .01);
          float n = fbm(vec2(q.x * ${fx_.toFixed(4)}, q.y * ${fy_.toFixed(4)})) * .65 + fbm(vec2(q.x * ${(fx_ * 3).toFixed(4)}, q.y * ${(fy_ * 3).toFixed(4)})) * .35;
          float r = abs(fract(n * 5.) - .5) * 2.;
          return vec3(r); }`);
      const hc2 = E.fx(`
        vec3 fx(vec2 uv, vec2 p){
          float c = cos(${ang.toFixed(3)}), s = sin(${ang.toFixed(3)});
          vec2 q = vec2(c * p.x + s * p.y, -s * p.x + c * p.y);
          q.y += 14. * fbm(p * .01);
          float n = fbm(vec2(q.x * ${fx_.toFixed(4)}, q.y * ${fy_.toFixed(4)})) * .65 + fbm(vec2(q.x * ${(fx_ * 3).toFixed(4)}, q.y * ${(fy_ * 3).toFixed(4)})) * .35;
          float r = abs(fract(n * 5.) - .5) * 2.;
          return vec3(r * ${amt.toFixed(3)}, 0., 0.); }`);
      a.save(); a.clip(path); a.globalCompositeOperation = 'multiply'; a.globalAlpha = dark; img(cv); a.restore();
      R.h.save(); R.h.clip(path); R.h.globalCompositeOperation = 'lighter'; img(hc2, R.h); R.h.restore();
    };
    const UP = sm([[180, 160], [222, 182], [262, 196], [300, 190], [342, 180], [400, 186], [452, 196], [505, 200], [540, 212], [545, 242], [520, 262], [470, 272], [405, 282], [372, 318], [340, 342], [318, 330], [302, 292], [270, 272], [238, 250], [208, 220], [186, 192]]);
    R.dome(UP, lin(180, 160, 540, 330, [[0, '#8c8b90'], [0.5, '#77767b'], [1, '#5c5b60']]), 0.2, 0.16, 26, 2);
    plaster(UP, 0.4, 0.012, 0.035, 0.08, 0.28); crumple(UP, 4, 60, 0.15, 60, 10, '#a8a7ac');
    // gold eye-mask
    const MASK = sm([[372, 312], [420, 300], [480, 296], [540, 300], [590, 306], [614, 330], [612, 372], [590, 392], [540, 398], [500, 404], [450, 410], [400, 410], [378, 392], [370, 352]]);
    R.dome(MASK, lin(380, 300, 610, 410, [[0, '#ae9464'], [0.5, '#a08656'], [1, '#86703f']]), 0.36, 0.08, 14, 3);
    { const r = rng(8); for (let i = 0; i < 160; i++) R.paint(circleP(380 + r() * 230, 300 + r() * 108, 0.7 + r() * 0.8), r() < 0.5 ? '#4a3a1e' : '#d6c08a'); }
    for (const [x, y, rx, ry] of [[440, 356, 33, 15], [555, 348, 31, 16], [501, 358, 7, 7]]) R.flat(ellipseP(x, y, rx, ry, -0.05), '#0c0b0a', 0.3, 0);
    stroke(line([[392, 268], [430, 276], [470, 284]]), '#b8e040', 3.5);
    // the big lower lump with its smooth cap and the brown crust on the right
    const LOW = sm([[130, 775], [150, 720], [180, 680], [230, 620], [290, 560], [330, 520], [380, 490], [430, 470], [480, 460], [530, 468], [580, 480], [630, 500], [670, 515], [726, 538],
      [726, 700], [690, 722], [650, 742], [600, 762], [560, 780], [520, 790], [470, 802], [430, 814], [396, 834], [360, 862], [320, 892], [282, 922], [250, 942], [220, 930], [190, 892], [168, 850], [142, 812]]);
    R.dome(LOW, lin(140, 480, 700, 900, [[0, '#b6b5b9'], [0.45, '#a2a1a5'], [1, '#86858a']]), 0.18, 0.2, 40, 2);
    plaster(LOW, -0.2, 0.005, 0.03, 0.07, 0.16); crumple(LOW, 7, 70, -0.18, 110, 12, '#c0bfc3');
    R.dome(sm([[420, 500], [470, 488], [530, 494], [560, 530], [556, 600], [520, 650], [470, 676], [425, 660], [404, 610], [404, 548]]), lin(410, 490, 560, 680, [[0, '#b0afb3'], [1, '#929196']]), 0.32, 0.06, 40, 2);
    const CRUST = sm([[600, 510], [650, 512], [700, 528], [726, 540], [726, 700], [690, 712], [660, 690], [620, 650], [600, 600]]);
    R.dome(CRUST, '#6e6862', 0.3, 0.1, 16, 2);
    inside(CRUST, () => { const r = rng(12); for (let i = 0; i < 260; i++) R.dome(circleP(600 + r() * 126, 505 + r() * 210, 1.5 + r() * 4), r() < 0.5 ? '#3a2e26' : '#a09080', 0.36, 0.05, 2, 2); });
    // holes in the plaster
    for (const [x, y, r] of [[300, 560, 12], [460, 506, 10], [286, 716, 7], [366, 398, 6]]) R.flat(circleP(x, y, r), '#0e0e0e', 0.1, 0);
    // tin-foil wrap at the top left of the lump
    R.dome(sm([[180, 160], [200, 152], [216, 168], [228, 196], [210, 204], [190, 186]]), '#c8c8cc', 0.3, 0.06, 6, 2);
    // black wire and yellow ribbon
    R.pipe(line([[384, 0], [392, 40], [408, 84], [428, 130], [438, 168], [440, 204]]), 4.5, '#141414', 0.5, 0.04, 3);
    R.dome(P(lock([[426, 800], [392, 840], [350, 885], [306, 930], [262, 975], [226, 1030]], 22, 12), true, true), lin(220, 800, 430, 1024, [[0, '#d8b04a'], [1, '#b08a2c']]), 0.4, 0.06, 6, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.1, shin: 14, wrap: 0.5, ao: 0.4 }),                      // 1 paper / paint
        E.mat({ dif: 1, spec: 0.35, shin: 26, wrap: 0.35, ao: 0.6, grain: 0.06 }),         // 2 plaster
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.3, ao: 0.4 })                         // 3 gold paint / ribbon
      ],
      light: [-0.5, 0.55, 0.66], lc: [0.6, 0.6, 0.6], amb: [0.5, 0.5, 0.5],
      envTop: [1, 1, 1], envHor: [0.5, 0.5, 0.5], envBot: [0.1, 0.1, 0.1], envK: [0.2, 0.8, 0.2, 0],
      r1: 1.4, r2: 7, k: [0, 0.6, 0.4, 90], shadow: [-6, 7, 0.6, 8]
    });
    E.grain(0.05, 87);
  }
});
