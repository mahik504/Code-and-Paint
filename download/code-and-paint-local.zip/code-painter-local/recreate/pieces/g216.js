'use strict';
// g216 — "Chrome fish on a zebra capsule": a puffy silver fish head with a white comb collar tops a diagonal
// zebra capsule armoured with chrome bubbles; a black glass ball on a syringe, a gold swirl plate, mint glow, black void.
REC.register('g216', {
  w: 578, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const Q = (f, sm = true, cl = true) => { const q = []; for (let i = 0; i < f.length; i += 2) q.push([f[i], f[i + 1]]); return P(q, cl, sm); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', clipP = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clipP) a.clip(clipP); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const lg = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rg = (x0, y0, r0, x1, y1, r1, stops) => { const g = a.createRadialGradient(x0, y0, r0, x1, y1, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const CHR = '#eaeaee', CHM = 1, GOLD = 2, BLK = 3, ZEB = 4, CLAY = 5, GLASS = 6, PL = 7;

    // ── 1. black void + back panels ──
    R.flat(rrect(-10, -10, 600, 1050, 0), '#040404', 0, 0);
    // pale sponge slab (left / middle), greenish felt at the bottom left
    const slab = Q([-10, 142, 40, 122, 70, 100, 100, 70, 220, 30, 300, 15, 400, 14, 450, 22, 500, 46, 500, 110, 578, 290, 578, 640, 470, 700, 380, 760, 320, 820, 285, 900, 255, 1040, -10, 1040], true, false);
    R.flat(slab, '#c9ccb4', 0.02, CLAY);
    // mint glow + greens
    soft(x => {
      fe(x, 260, 420, 130, 150, 0, '#d4ebdf'); fe(x, 330, 340, 90, 60, 0, '#d6e6d6');
      fe(x, 90, 640, 90, 130, 0.2, '#5f8452'); fe(x, 40, 720, 60, 90, 0, '#8ea458'); fe(x, 130, 560, 50, 40, 0, '#6a9a74');
      fe(x, 95, 530, 30, 20, 0, '#8cc0a4'); fe(x, 20, 790, 40, 30, 0, '#6c8360'); fe(x, 300, 385, 40, 30, 0, '#9aae92');
      fe(x, 150, 1000, 140, 50, 0, '#8c9888'); fe(x, 70, 1010, 60, 30, 0, '#6e7967');
      fe(x, 540, 330, 30, 30, 0, '#72aa92');
    }, 26, 1);
    // dark slate fin, top right
    const fin1 = Q([470, 95, 500, 66, 540, 42, 578, 24, 578, 335, 560, 300, 545, 230, 530, 170, 500, 120]);
    R.flat(fin1, lg(470, 60, 578, 300, [[0, '#4a6a76'], [0.5, '#335463'], [1, '#2e5262']]), 0.03, 0);
    clipA(fin1, () => { a.strokeStyle = 'rgba(120,160,170,0.35)'; a.lineWidth = 1; for (let i = 0; i < 9; i++) { a.beginPath(); a.moveTo(480 + i * 4, 100 + i * 4); a.quadraticCurveTo(540 + i * 2, 80 + i * 25, 578, 40 + i * 34); a.stroke(); } });
    // maroon fin, right edge
    const fin2 = Q([520, 352, 550, 332, 578, 318, 578, 600, 550, 575, 530, 520, 528, 420]);
    R.flat(fin2, lg(520, 300, 578, 600, [[0, '#9a4a5c'], [0.5, '#873248'], [1, '#7a2c40']]), 0.03, 0);
    clipA(fin2, () => { a.strokeStyle = 'rgba(200,120,140,0.4)'; a.lineWidth = 1.2; for (let i = 0; i < 12; i++) { a.beginPath(); a.moveTo(520, 330 + i * 22); a.lineTo(578, 300 + i * 26); a.stroke(); } });
    // teal-grey textured patch behind the leg + cream band
    const tealP = Q([420, 600, 520, 560, 578, 540, 578, 650, 500, 700, 430, 745, 410, 700], true, false);
    R.flat(tealP, '#405e66', 0.03, CLAY);
    R.pipe(Q([290, 850, 340, 810, 400, 770, 470, 730, 530, 690, 590, 655], true, false), 24, '#d4d4bc', 0.04, 0.05, CLAY);
    // black void below right
    R.flat(Q([300, 860, 350, 815, 420, 772, 500, 725, 590, 668, 590, 1040, 245, 1040, 262, 960], true, false), '#040404', 0, 0);
    // cream rim of the slab bottom
    R.pipe(Q([300, 845, 280, 900, 262, 960, 250, 1030], true, false), 16, '#d8d6bc', 0.04, 0.05, CLAY);

    // ── 2. gold swirl plate ──
    const gold = Q([-10, 142, 40, 122, 70, 100, 100, 70, 160, 50, 220, 32, 260, 28, 300, 16, 350, 14, 400, 14, 450, 22, 482, 40, 498, 60, 496, 90, 470, 200, 400, 280, 300, 292, 220, 296, 150, 280, 90, 262, 40, 252, -10, 258]);
    R.dome(gold, '#f2eccc', 0.03, 0.06, 10, CLAY);
    const goldI = Q([-10, 156, 40, 136, 74, 114, 104, 84, 160, 64, 222, 46, 262, 42, 302, 30, 350, 30, 400, 30, 444, 36, 470, 52, 482, 70, 482, 92, 460, 195, 396, 268, 300, 280, 220, 284, 150, 268, 90, 250, 40, 240, -10, 244]);
    R.dome(goldI, lg(0, 40, 300, 300, [[0, '#d8a432'], [0.5, '#d49c2a'], [1, '#c89430']]), 0.06, 0.03, 6, GOLD);
    clipA(goldI, () => {
      const r = rng(2161);
      for (let i = 0; i < 260; i++) {
        const x = r() * 490, y = 30 + r() * 270, rr = 2.5 + r() * 7;
        if (r() < 0.7) R.pipe(circleP(x, y, rr), 2.2, '#e4b444', 0.1, 0.04, GOLD);
        else R.bead(x, y, rr * 0.5, '#e0ae40', 0.1, 0.04, GOLD);
      }
      for (let i = 0; i < 30; i++) {
        const x = r() * 490, y = 30 + r() * 270, an = r() * 6.28, pts = [];
        for (let k = 0; k < 6; k++) pts.push(x + Math.cos(an + k * 0.9) * (6 + k * 3), y + Math.sin(an + k * 0.9) * (6 + k * 3));
        R.pipe(Q(pts, true, false), 2.5, '#e8b848', 0.1, 0.04, GOLD);
      }
      // vertical grooves near the tube
      for (let i = 0; i < 6; i++) R.pipe(Q([232 + i * 7, 130, 230 + i * 7, 175], true, false), 3, '#e4b040', 0.1, 0.04, GOLD);
    });

    // ── 3. grey blob, left ──
    const gb = Q([-10, 498, 30, 488, 58, 505, 62, 548, 82, 580, 100, 600, 116, 622, 108, 650, 82, 658, 52, 642, 30, 612, -10, 622]);
    R.dome(gb, '#e2dcc0', 0.04, 0.04, 6, CLAY);
    const gbi = Q([-10, 508, 28, 498, 50, 512, 52, 552, 74, 586, 92, 604, 106, 624, 100, 642, 82, 648, 56, 634, 34, 604, -10, 612]);
    R.flat(gbi, '#b2b2b0', 0.06, CLAY);
    for (const [x, y, rr] of [[37, 578, 4], [80, 612, 3], [52, 620, 2], [102, 635, 3], [40, 535, 2], [60, 590, 2]]) R.flat(circleP(x, y, rr), '#141414', 0.07, 0);

    // ── 4. syringe tube, bead brush, bone ──
    const bone = Q([178, 128, 196, 90, 208, 70, 226, 60, 246, 66, 250, 84, 236, 96, 220, 98, 206, 130]);
    R.dome(bone, CHR, 0.12, 0.12, 12, CHM);
    const br = rng(2162);
    const beads = [];
    for (let i = 0; i < 70; i++) {
      const t = br(), ang = -1.57 + (t - 0.5) * 1.6, d = 25 + br() * 105;
      const x = 138 + Math.cos(ang) * d * 0.95, y = 135 + Math.sin(ang) * d;
      if (y < -5 || y > 120) continue;
      beads.push([x, y, 5 + br() * 4]);
    }
    beads.sort((p, q) => p[1] - q[1]);
    R.dome(Q([108, 128, 92, 90, 70, 60, 80, 20, 120, 0, 170, 0, 210, 20, 212, 60, 186, 100, 170, 128]), '#a8a8ae', 0.1, 0.04, 8, CHM);
    for (const [x, y, rr] of beads) R.dome(ellipseP(x, y, rr * 0.8, rr * 1.15, (x - 138) * 0.01), CHR, 0.14, 0.1, rr, CHM);
    // tube
    const tube = Q([108, 150, 172, 150, 160, 282, 86, 282], false, true);
    R.dome(tube, lg(86, 0, 172, 0, [[0, '#9a9aa0'], [0.3, '#f0f0f2'], [0.6, '#b8b8c0'], [1, '#e8e8ec']]), 0.1, 0.14, 26, CHM);
    clipA(Q([128, 160, 165, 160, 154, 272, 116, 272], false, true), () => { for (let y = 162; y < 272; y += 3.2) R.pipe(Q([118 + (272 - y) * 0.09, y, 162 - (y - 160) * 0.09, y + 1.5], true, false), 1.6, '#e8e8ec', 0.26, 0.03, CHM); });
    R.dome(Q([96, 124, 182, 124, 182, 156, 96, 156], false, true), '#cfcfd4', 0.12, 0.12, 12, CHM);
    R.dome(Q([74, 270, 168, 270, 166, 300, 72, 300], false, true), '#cfcfd4', 0.12, 0.12, 12, CHM);
    R.dome(ellipseP(122, 302, 50, 8, 0), '#1a1a1e', 0.2, 0.02, 3, BLK);

    // ── 5. black glass ball + little chrome legs ──
    for (const L of [[30, 460, 16, 492, 8, 488], [100, 470, 104, 500, 100, 515], [130, 470, 138, 498, 150, 510], [118, 470, 120, 500, 118, 520]]) R.pipe(Q(L, true, false), 7, CHR, 0.12, 0.08, CHM);
    const ball = circleP(102, 382, 96);
    R.dome(circleP(102, 382, 100), '#e8e4cc', 0.05, 0.05, 5, CLAY);
    R.dome(ball, rg(80, 360, 10, 102, 382, 96, [[0, '#101012'], [0.8, '#08080a'], [1, '#1a1c22']]), 0.1, 0.4, 70, BLK);
    clipA(ball, () => {
      soft(x => { x.fillStyle = '#5a4850'; for (const [cx, cy, rr] of [[160, 400, 8], [150, 420, 8], [138, 438, 9], [120, 448, 8], [100, 452, 8], [168, 382, 6], [175, 362, 5]]) x.fill(circleP(cx, cy, rr)); }, 2, 0.9);
      soft(x => { x.strokeStyle = '#dde4e8'; x.lineWidth = 3; x.beginPath(); x.arc(102, 382, 92, 0.2, 1.4); x.stroke(); }, 2, 0.6);
    });
    R.paint(circleP(66, 352, 8), '#ffffff'); R.paint(circleP(112, 318, 6), '#ffffff'); R.paint(circleP(118, 404, 3), '#e8e8f0');

    // ── 6. bubbles ──
    for (const [x, y, rr] of [[15, 78, 15], [55, 115, 17], [37, 200, 25], [262, 18, 5], [550, 22, 6], [25, 156, 3], [458, 370, 4], [228, 368, 4]]) {
      R.dome(circleP(x, y, rr), rg(x - rr * 0.3, y - rr * 0.3, 0, x, y, rr, [[0, '#2a3038'], [0.75, '#141820'], [1, '#a8c0c8']]), 0.2, Math.min(0.25, rr * 0.012), rr, BLK);
      if (rr > 10) { R.paint(circleP(x + rr * 0.35, y - rr * 0.3, rr * 0.18), '#f4f0ff'); R.paint(circleP(x - rr * 0.4, y + rr * 0.35, rr * 0.13), '#e8e0ff'); R.paint(circleP(x - rr * 0.2, y - rr * 0.5, rr * 0.11), '#e8e0ff'); }
    }

    // ── 7. chrome side fin + dorsal fin + fish head ──
    const sfin = Q([198, 300, 230, 285, 262, 276, 300, 270, 310, 300, 300, 330, 280, 332, 268, 310, 245, 302, 222, 302]);
    R.dome(sfin, CHR, 0.12, 0.08, 8, CHM);
    for (let i = 0; i < 4; i++) R.pipe(Q([214 + i * 8, 298, 260 + i * 10, 284 + i * 5, 280 + i * 5, 300 + i * 6], true, false), 3, '#e8e8ec', 0.2, 0.04, CHM);
    const dfin = Q([300, 64, 330, 66, 372, 78, 410, 92, 426, 104, 380, 112, 345, 132, 316, 152, 304, 118]);
    R.dome(dfin, '#c4c4ca', 0.12, 0.08, 10, CHM);
    for (let i = 0; i < 5; i++) R.pipe(Q([306 + i * 4, 72 + i * 4, 340 + i * 6, 84 + i * 8, 360 + i * 8, 108 + i * 6], true, false), 3, '#e0e0e6', 0.2, 0.04, CHM);
    const head = Q([350, 116, 395, 98, 445, 90, 492, 90, 524, 102, 548, 132, 563, 172, 568, 215, 565, 262, 550, 292, 520, 312, 480, 322, 430, 326, 380, 326, 344, 316, 310, 296, 290, 262, 284, 224, 292, 186, 314, 150]);
    R.dome(head, rg(430, 150, 20, 425, 210, 160, [[0, '#f4f4f6'], [0.6, '#d8d8dc'], [1, '#c0c0c6']]), 0.12, 0.3, 85, 6);
    // wrap bands across the lower face
    for (const [y, d] of [[208, 0], [240, 4], [270, 8], [298, 12]]) R.groove(Q([292 + d, y, 360, y + 4, 430, y + 6, 500, y + 4, 562 - d * 1.5, y - 4], true, false), 9, '#b4b4bc', 0.42, 0.05, 6);
    // brows, eyes, nose
    R.pipe(Q([366, 152, 384, 140, 404, 146, 414, 162], true, false), 7, '#c8c8ce', 0.42, 0.06, CHM);
    R.pipe(Q([466, 158, 482, 146, 502, 148, 516, 162], true, false), 7, '#c8c8ce', 0.42, 0.06, CHM);
    R.dome(ellipseP(392, 162, 14, 7, 0.1), '#c8c4a8', 0.4, 0.03, 4, PL); R.dome(circleP(394, 162, 5), '#2a2420', 0.42, 0.02, 2, BLK);
    R.dome(ellipseP(490, 166, 14, 8, -0.1), '#e88a6a', 0.4, 0.03, 4, PL); R.dome(circleP(488, 166, 5), '#3a2018', 0.42, 0.02, 2, BLK);
    R.dome(ellipseP(432, 180, 12, 18, 0), '#e0e0e4', 0.42, 0.06, 8, CHM);
    R.bead(408, 178, 7, '#d8d8de', 0.42, 0.05, CHM); R.bead(458, 182, 7, '#d8d8de', 0.42, 0.05, CHM);
    soft(x => { fe(x, 300, 240, 30, 70, 0, '#8a8a92'); fe(x, 560, 230, 20, 70, 0, '#8a8a92'); fe(x, 330, 175, 25, 30, 0.5, '#a0a0a8'); }, 14, 0.8, 'source-over', head);
    clipA(head, () => { const r = rng(5); for (let i = 0; i < 220; i++) R.paint(circleP(330 + r() * 220, 225 + r() * 60, 0.5 + r() * 0.7), 'rgba(255,255,255,0.8)'); });

    // ── 8. white comb collar ──
    const comb = Q([350, 318, 420, 328, 500, 320, 504, 376, 430, 386, 356, 380], false, true);
    R.flat(comb, '#5a5a62', 0.12, 0);
    for (let x = 354; x < 502; x += 6.2) R.pipe(Q([x, 322 + Math.abs(x - 426) * 0.03, x + 0.5, 380], true, false), 5.4, '#f0f0f2', 0.18, 0.05, CHM);

    // ── 9. the capsule ──
    const cap = Q([354, 391, 380, 388, 440, 384, 500, 388, 535, 405, 550, 440, 552, 500, 545, 555, 520, 610, 482, 664, 432, 724, 372, 785, 302, 845, 232, 905, 162, 950, 100, 975, 55, 970, 30, 940, 22, 880, 30, 830, 54, 794, 97, 737, 140, 680, 183, 609, 219, 551, 276, 473, 320, 425]);
    R.dome(Q([276, 455, 250, 450, 225, 460, 205, 484, 198, 506, 216, 500, 240, 492, 266, 490]), CHR, 0.1, 0.08, 8, CHM);
    R.dome(cap, '#0a0a0c', 0.1, 0.18, 30, ZEB);
    const ZF = E.fx(`
      // <zph>
const float ZPHC[99] = float[99](-3.734,-4.029,-4.340,-4.616,-4.692,-4.411,-4.376,-5.081,-5.311,-2.772,-3.251,-3.649,-3.949,-4.293,-4.947,-4.708,-4.845,-3.885,-1.674,-2.447,-3.006,-3.239,-3.112,-3.520,-3.806,-3.923,-2.887,-0.293,-1.459,-2.257,-2.294,-1.955,-2.720,-2.936,-3.351,-4.064,1.369,0.026,-1.147,0.052,-0.960,-1.615,-2.146,-2.204,-4.381,2.981,2.317,1.438,0.682,-0.048,-0.700,-1.280,-1.004,-2.988,4.066,3.771,2.278,1.374,0.765,0.121,-0.350,-1.176,-1.964,4.365,3.536,2.924,2.024,1.490,1.105,0.785,-0.264,-1.103,4.298,4.105,3.409,2.695,2.192,1.841,1.316,0.565,-0.240,4.709,4.587,3.967,3.470,3.285,2.545,1.939,1.288,0.576,5.128,4.940,4.746,4.608,4.196,3.455,2.691,1.999,1.343);
float zph(vec2 p){ vec2 u = clamp((p - vec2(30.0, 380.0)) / vec2(87.5000, 74.3750), vec2(0.), vec2(5.999, 7.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  float f = 0.;
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += ZPHC[(i.y + b) * 9 + i.x + a] * bx[a] * by[b];
  return f; }
      // </zph>
      vec3 fx(vec2 uv, vec2 p){
        float s = cos(6.2832 * zph(p));
        return mix(vec3(0.035, 0.035, 0.04), vec3(0.94, 0.91, 0.84), smoothstep(-0.1, 0.1, s)); }`);
    clipA(cap, () => { img(ZF); a.lineWidth = 16; a.strokeStyle = '#060607'; a.stroke(cap); });
    // the black tie with a cream edge and teal glint
    const tie = Q([427, 392, 454, 392, 450, 400, 430, 450, 410, 500, 397, 550, 387, 600, 380, 650, 375, 712, 348, 712, 355, 650, 362, 600, 375, 550, 387, 500, 407, 450, 425, 400], false, true);
    R.flat(tie, '#050506', 0.3, ZEB);
    R.pipe(Q([422, 396, 403, 450, 383, 500, 371, 550, 358, 600, 351, 650, 345, 712], true, false), 4, '#e8e4d0', 0.3, 0.03, ZEB);
    R.paint(Q([372, 560, 380, 560, 368, 650, 360, 650], false, true), '#38b0a8');
    // white dots on the black
    for (const [x, y, rr] of [[442, 472, 6], [489, 489, 5], [475, 407, 4], [460, 412, 3], [513, 486, 4], [300, 647, 10], [255, 700, 6], [146, 836, 7], [111, 928, 5], [395, 455, 4]]) R.flat(circleP(x, y, rr), '#f4f0e6', 0.31, ZEB);
    // chrome bubble armour column
    const col = Q([354, 391, 276, 473, 219, 551, 183, 609, 140, 680, 97, 737, 54, 794, 90, 809, 119, 780, 169, 730, 226, 680, 276, 630, 326, 580, 376, 523, 411, 423, 408, 398], true, true);
    R.dome(col, '#a4a4ac', 0.12, 0.06, 10, CHM);
    const cr = rng(2163);
    for (let i = 0; i < 15; i++) {
      const u = (i + 0.35) / 14.4, lx = 382 + (72 - 382) * u, ly = 410 + (801 - 410) * u;
      for (let v = 0; v < 3; v++) {
        const off = -32 + v * 32 + (i % 2 ? 8 : -5) + (cr() - 0.5) * 6;
        const x = lx + 0.784 * off + (cr() - 0.5) * 5, y = ly + 0.621 * off + (cr() - 0.5) * 5, rr = 18 + cr() * 4;
        if (!a.isPointInPath(col, x * S, y * S)) continue;
        R.dome(P(blob(x, y, rr, rr * 0.9, 50 + i * 3 + v, 10, 0.08, -0.9)), lg(x - rr, y - rr, x + rr, y + rr, [[0, '#f4f4f6'], [0.6, '#d0d0d6'], [1, '#9a9aa2']]), 0.16, 0.16, rr * 0.9, CHM);
      }
    }
    // pink coral beads
    for (const [x, y] of [[505, 375], [515, 368], [524, 378], [533, 388], [512, 386], [528, 548], [536, 560], [522, 560], [530, 572]]) R.bead(x, y, 6, '#f2b8c4', 0.3, 0.05, PL);

    // ── 10. chrome loop around the capsule end ──
    const capEnd = Q([28, 812, 45, 795, 60, 800, 66, 850, 70, 910, 72, 955, 50, 960, 30, 940, 22, 900, 20, 860]);
    R.dome(capEnd, lg(20, 800, 100, 960, [[0, '#f4eedc'], [1, '#e6dcc4']]), 0.18, 0.1, 20, ZEB);
    R.pipe(Q([110, 972, 170, 962, 230, 930, 280, 890, 320, 852], true, false), 6, '#8ccab8', 0.12, 0.02, ZEB);
    const PC = '#d6d6dc';
    R.pipe(Q([48, 782, 22, 800, 9, 860, 11, 920, 26, 960, 50, 982, 78, 986], true, false), 16, PC, 0.3, 0.12, CHM);
    R.pipe(Q([50, 782, 72, 800, 90, 850, 100, 910, 104, 960, 106, 984], true, false), 14, PC, 0.3, 0.12, CHM);
    R.pipe(Q([108, 986, 160, 980, 220, 958, 270, 920, 302, 880, 340, 834], true, false), 14, PC, 0.3, 0.12, CHM);

    // ── 11. chrome leg + claw ──
    R.pipe(Q([478, 584, 490, 640, 498, 698], true, false), 40, CHR, 0.3, 0.22, CHM);
    R.bead(498, 700, 21, CHR, 0.32, 0.2, CHM);
    R.pipe(Q([498, 702, 470, 742, 434, 776, 414, 798], true, false), 30, CHR, 0.32, 0.18, CHM);
    R.bead(412, 800, 13, CHR, 0.34, 0.14, CHM);
    R.pipe(Q([412, 800, 406, 836, 402, 860], true, false), 20, CHR, 0.32, 0.14, CHM);
    for (let i = 0; i < 6; i++) R.pipe(Q([388, 856 + i * 4.5, 412, 858 + i * 4.5], true, false), 4.5, '#e8e8ec', 0.36, 0.05, CHM);
    for (const F of [[398, 884, 376, 912, 348, 942, 318, 975], [402, 886, 380, 922, 352, 954, 322, 986], [404, 886, 398, 918, 384, 950]]) R.pipe(Q(F, true, false), 13, CHR, 0.32, 0.12, CHM);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.25, spec: 1.3, shin: 70, metal: 1, ao: 0.3, coat: 0.05, tint: [1.22, 1.22, 1.26] }),          // 1 chrome
        E.mat({ dif: 0.9, spec: 0.7, shin: 30, metal: 0.35, wrap: 0.4, ao: 0.4, tint: [1.2, 0.95, 0.5] }),     // 2 gold
        E.mat({ dif: 1, spec: 1.6, shin: 90, coat: 0.3, ao: 0.2 }),                                           // 3 black glass
        E.mat({ dif: 0.55, spec: 0.9, shin: 60, wrap: 0.5, emis: 0.5, coat: 0.12 }),                          // 4 zebra gloss
        E.mat({ dif: 0.55, spec: 0.1, shin: 10, wrap: 0.6, emis: 0.45, grain: 0.5 }),                         // 5 sponge / clay
        E.mat({ dif: 0.85, spec: 1.0, shin: 50, metal: 0.45, wrap: 0.7, ao: 0.3, tint: [1.2, 1.2, 1.24] }),    // 6 satin silver
        E.mat({ dif: 1, spec: 0.8, shin: 40, wrap: 0.5, emis: 0.2, coat: 0.1 })                               // 7 plastic
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.75, 0.75, 0.78], amb: [0.4, 0.4, 0.42],
      envTop: [1.15, 1.15, 1.17], envHor: [0.8, 0.81, 0.84], envBot: [0.18, 0.18, 0.2], envK: [0.4, 0.8, 0, 0],
      rimC: [0.15, 0.18, 0.2], rimD: [0, 1, 0], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 90], shadow: [-4, 5, 0.4, 6]
    });
  }
});
