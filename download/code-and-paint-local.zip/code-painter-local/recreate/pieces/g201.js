'use strict';
// g201 — "Lavender heart grin": a grinning lavender clay heart with a spiked tube arc and a melting white skull
// rides a glossy zebra wave under a periwinkle sky, with a cyan halo, orange drops and a rusty dust cloud.
REC.register('g201', {
  w: 1024, h: 726,
  draw(E) {
    const W = 1024, H = 726, R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const lin = (x0, y0, x1, y1, st, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st, ctx = a, x0 = x, y0 = y) => { const g = ctx.createRadialGradient(x0, y0, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), line = pts => P(pts, false, true);
    const strokeA = (p, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.stroke(p); };

    // ── background: periwinkle sky, cyan halo, grey hill, sandy ground, fog, rust cloud, speckles ──
    R.flat(rrect(-10, -10, W + 20, H + 20, 0), null, 0, 0);
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 sky = vec3(.384, .412, .686);
      float hr = length((p - vec2(515., 340.)) / vec2(320., 225.));
      vec3 c = mix(sky, vec3(.56, .72, .80), smoothstep(1.08, 0.55, hr));
      float gh = length((p - vec2(578., 530.)) / vec2(160., 292.));
      c = mix(c, vec3(.54, .58, .65), smoothstep(1.02, 0.96, gh));
      float hz = 442. + 10. * sin(p.x * 0.011 + 1.3);
      vec3 gc = mix(vec3(.595, .585, .62), vec3(.56, .61, .675), smoothstep(620., 760., p.x) * smoothstep(580., 470., p.y));
      c = mix(c, gc, smoothstep(hz - 14., hz + 14., p.y));
      c = mix(c, vec3(.47, .54, .69), smoothstep(200., 0., p.x) * smoothstep(600., 450., p.y) * smoothstep(hz - 30., hz + 10., p.y) * .8);
      float fy = 448. + (p.x - 120.) * 0.2 + 9. * sin(p.x * 0.028) + (fbm(p * 0.02) - .5) * 14.;
      float fog = abs(p.y - fy) / 20. + pow(abs(p.x - 235.) / 125., 4.);
      c = mix(c, vec3(.84, .9, .94), smoothstep(1.0, 0.25, fog));
      float fog2 = length((p - vec2(90., 458.)) / vec2(110., 18.));
      c = mix(c, vec3(.6, .66, .78), 0.6 * smoothstep(1.0, 0.3, fog2));
      float pl = length(p - vec2(-1400., 120.)) - 1422.;
      c = mix(c, vec3(.71, .67, .675) + (hash(p * .7) - .5) * .08, smoothstep(1.5, -1.5, pl));
      float bc = length(p - vec2(52., 522.));
      c = mix(c, vec3(.37, .52, .71), smoothstep(54., 38., bc));
      float n = fbm(p * 0.014 + 3.);
      float bd = length((p - vec2(215., 685.)) / vec2(175., 125.)) - (n - .5) * 1.1;
      vec3 rust = mix(vec3(.50, .32, .25), vec3(.36, .215, .21), smoothstep(0.8, 0.45, bd));
      c = mix(c, rust, smoothstep(1.0, 0.8, bd));
      float sk = length((p - vec2(560., 440.)) / vec2(100., 105.)) + (fbm(p * 0.025) - .5) * .9;
      float sk2 = length((p - vec2(372., 528.)) / vec2(48., 30.)) + (fbm(p * 0.03 + 7.) - .5) * .8;
      float dots = smoothstep(0.55, 0.68, vnoise(p * 0.3)) * max(smoothstep(1.0, 0.75, sk), smoothstep(1.0, 0.7, sk2));
      c = mix(c, vec3(.33, .33, .38), dots * .75);
      c += (hash(p) - .5) * 0.07;
      return c; }`));

    // ── zebra wave (fitted stripe phase) ──
    const zebra = sm([[262, 640], [290, 600], [340, 565], [400, 532], [450, 515], [500, 511], [550, 516], [600, 531], [650, 551], [700, 579], [740, 607], [780, 628], [830, 638], [880, 629], [940, 618], [1000, 611], [1040, 608], [1040, 740], [390, 740], [350, 692], [300, 669], [270, 656]]);
    const zcv = E.fx(`
const float ZBC[128] = float[128](7.217,4.897,2.722,0.930,0.214,0.606,0.344,-1.207,-3.755,-5.703,-6.929,-7.692,-8.278,-8.874,-9.569,-10.380,7.191,5.436,3.587,2.646,1.783,0.665,-1.261,-1.293,-3.634,-5.045,-6.040,-6.678,-7.139,-7.650,-8.421,-9.425,6.952,5.845,3.979,3.393,2.467,1.506,0.283,-1.153,-2.005,-3.924,-5.013,-5.666,-6.029,-6.473,-7.420,-8.405,6.340,4.937,4.288,3.595,2.925,1.996,1.010,0.070,-1.237,-2.160,-3.527,-4.560,-4.954,-5.611,-6.908,-7.006,5.943,5.113,4.300,3.852,3.112,2.368,1.458,0.687,-0.049,-1.374,-1.781,-3.023,-3.926,-4.652,-5.352,-4.805,5.682,5.193,4.748,4.031,3.480,2.723,2.250,1.627,0.967,0.117,-0.958,-1.547,-2.762,-3.601,-4.507,-4.807,5.568,5.517,5.548,5.665,3.548,3.809,3.109,3.162,3.268,0.696,0.423,-0.851,-1.696,-2.754,-3.786,-2.482,5.575,5.967,6.211,6.014,5.206,4.891,3.399,3.660,5.087,2.683,1.130,0.629,-0.511,-2.637,-2.921,-1.653);
float zb(vec2 p){ vec2 u = clamp((p - vec2(255.0, 500.0)) / vec2(59.1538, 45.2000), vec2(0.), vec2(12.999, 4.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  float f = 0.;
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += ZBC[(i.y + b) * 16 + i.x + a] * bx[a] * by[b];
  return f; }
      vec3 fx(vec2 uv, vec2 p){
        float v = cos(6.2832 * zb(p));
        vec3 cr = mix(vec3(.93, .925, .9), vec3(.88, .89, .87), smoothstep(600., 900., p.x));
        return mix(vec3(.11, .1, .11), cr, smoothstep(-.12, .12, v)); }`);
    clipA(zebra, () => img(zcv));
    R.dome(zebra, null, 0.04, 0.16, 22, 4);

    // ── tube arc with copper spikes ──
    const arc = line([[492, 282], [540, 262], [595, 254], [650, 264], [690, 290], [711, 330], [712, 390], [700, 440], [680, 482], [662, 516], [655, 528]]);
    const spikes = [[500, 195, 515, 244], [560, 163, 562, 226], [627, 163, 625, 226], [691, 183, 678, 238], [757, 250, 724, 284]];
    for (const [tx, ty, bx, by] of spikes) R.pipe(line([[bx, by], [bx + (tx - bx) * 0.32, by + (ty - by) * 0.32]]), 14, '#c9b4d2', 0.3, 0.12, 1);
    for (const [tx, ty, bx, by] of spikes) {
      const dx = tx - bx, dy = ty - by, L = Math.hypot(dx, dy), ux = dx / L, uy = dy / L, nx = -uy, ny = ux;
      const b0x = bx + dx * 0.3, b0y = by + dy * 0.3, wd = 11;
      const cone = sm([[tx, ty], [b0x + ux * L * 0.35 + nx * wd * 0.9, b0y + uy * L * 0.35 + ny * wd * 0.9], [b0x + nx * wd, b0y + ny * wd], [b0x - ux * 4, b0y - uy * 4], [b0x - nx * wd, b0y - ny * wd], [b0x + ux * L * 0.35 - nx * wd * 0.9, b0y + uy * L * 0.35 - ny * wd * 0.9]]);
      R.dome(cone, lin(b0x - nx * wd, b0y - ny * wd, b0x + nx * wd, b0y + ny * wd, [[0, '#fff4f0'], [0.45, '#f6c8b8'], [1, '#d09484']]), 0.32, 0.18, 9, 2);
    }
    R.pipe(arc, 58, '#d4bccf', 0.18, 0.36, 1);

    // ── melting white skull ──
    const skull = sm([[330, 395], [338, 425], [356, 443], [384, 451], [418, 457], [446, 454], [468, 468], [492, 470], [500, 486], [494, 500], [512, 494], [520, 478], [538, 472], [552, 470], [548, 456], [526, 450], [506, 438], [498, 414], [490, 392], [482, 360], [478, 335], [462, 345], [440, 356], [410, 364], [380, 364], [352, 372]]);
    R.dome(skull, '#efebe6', 0.14, 0.2, 13, 3);
    R.flat(sm([[350, 398], [366, 386], [392, 382], [418, 388], [432, 396], [446, 391], [450, 400], [442, 407], [426, 405], [408, 414], [380, 418], [358, 412]]), '#383848', 0.12, 3);
    R.flat(circleP(339, 416, 6), '#2a2a36', 0.1, 3); R.flat(circleP(456, 422, 6), '#2a2a36', 0.12, 3);
    for (const [x, y, r] of [[478, 470, 4], [520, 456, 3], [458, 448, 3]]) R.bead(x, y, r, '#f6f2ee', 0.3, 0.04, 3);

    // ── lavender heart face ──
    const heart = sm([[283, 262], [292, 231], [315, 216], [342, 215], [366, 225], [386, 240], [403, 230], [428, 225], [455, 229], [478, 241], [492, 262], [492, 292], [482, 316], [470, 336], [452, 350], [425, 360], [400, 363], [375, 362], [352, 370], [334, 390], [318, 408], [298, 405], [286, 390], [281, 340]]);
    R.dome(heart, rad(340, 260, 210, [[0, '#d6c0d4'], [0.6, '#ccb4cc'], [1, '#b096b4']]), 0.2, 0.22, 24, 1);
    // spots
    for (const [x, y, rx, ry, r0] of [[306, 233, 8, 7, 0], [331, 241, 10, 8, 0.4], [300, 288, 10, 10, 0], [307, 331, 13, 12, 0], [300, 378, 7, 6, 0], [346, 362, 9, 8, 0], [321, 360, 6, 6, 0], [312, 254, 6, 5, 0], [460, 257, 9, 7, 0.3], [476, 281, 6, 6, 0], [459, 290, 5, 5, 0], [420, 237, 6, 4, 0], [334, 393, 6, 5, 0]])
      R.dome(ellipseP(x, y, rx, ry, r0), '#d2c0d8', 0.42, 0.05, Math.min(rx, ry) * 0.8, 1);
    R.groove(line([[376, 243], [378, 256]]), 5, '#9070b0', 0.42, 0.06, 1, 1); R.groove(line([[384, 241], [387, 255]]), 5, '#9070b0', 0.42, 0.06, 1, 1);
    // eye sockets with closed lids
    for (const [x, y, rx, ry, rot] of [[350, 280, 27, 18, 0.12], [423, 262, 26, 19, -0.08]]) {
      R.groove(ellipseP(x, y, rx, ry, rot), 7, '#8a68b4', 0.42, 0.08, 1, 1);
      R.dome(ellipseP(x, y, rx - 3, ry - 3, rot), rad(x - 6, y - 8, rx * 1.4, [[0, '#ddd0e2'], [1, '#bca6cc']]), 0.38, 0.06, 8, 1);
    }
    a.lineCap = 'round';
    strokeA(line([[334, 292], [348, 283], [364, 284], [372, 291]]), '#1e1424', 4.5);
    strokeA(line([[404, 272], [418, 265], [432, 266], [442, 273]]), '#1e1424', 4.5);
    R.dome(ellipseP(383, 298, 17, 8, 0), '#cbb4d4', 0.42, 0.05, 6, 1);
    // grin with teeth ticks
    const grin = line([[337, 319], [352, 330], [376, 337], [402, 338], [427, 332], [448, 318], [461, 300], [466, 284]]);
    R.groove(grin, 9, '#1c1222', 0.42, 0.14, 1, 1);
    for (const [x, y, dx, dy] of [[357, 332, -1, 9], [371, 336, 0, 9], [386, 338, 0, 9], [401, 338, 0, 9], [416, 335, 1, 9], [430, 330, 2, 9], [443, 322, 5, 7], [453, 311, 7, 5]])
      R.groove(line([[x, y], [x + dx, y + dy]]), 3.5, '#1c1222', 0.4, 0.08, 1, 1);
    // little purple heart + side loop + copper drips
    R.dome(sm([[436, 351], [446, 346], [452, 354], [460, 347], [468, 352], [462, 364], [449, 372], [438, 362]]), '#9a74cc', 0.42, 0.06, 5, 1);
    R.pipe(circleP(266, 349, 10), 6, '#c0aad0', 0.2, 0.08, 1);
    R.pipe(line([[292, 396], [290, 426]]), 9, '#b06a50', 0.2, 0.1, 2);
    R.bead(320, 432, 5, '#9a5a44', 0.2, 0.06, 2);

    // ── coil disc and clear disc ──
    R.dome(circleP(488, 508, 22), '#c8ccd4', 0.2, 0.14, 10, 5);
    clipA(circleP(488, 508, 21), () => { for (let r = 21; r > 1; r -= 3.4) { a.lineWidth = 1.6; a.strokeStyle = '#1a1a20'; a.stroke(circleP(488, 508, r)); } });
    R.dome(circleP(577, 483, 30), rad(570, 474, 34, [[0, '#e8f0f8'], [0.6, '#c4d0e0'], [1, '#8a9ac0']]), 0.18, 0.12, 9, 6);
    clipA(circleP(577, 483, 26), () => { a.lineWidth = 1.2; a.strokeStyle = '#7e8cb0'; a.stroke(circleP(577, 483, 20)); a.stroke(circleP(577, 483, 10)); a.fillStyle = '#f4f8fc'; a.fill(circleP(577, 483, 6)); });

    // ── orange drops ──
    for (const [x, y, rx, ry, rot] of [[781, 180, 20, 30, 0.25], [881, 142, 9, 11, 0.9], [869, 215, 7, 9, 0.6], [820, 300, 16, 20, 0.35]]) {
      const c = Math.cos(rot), s = Math.sin(rot), pt = (u, v) => [x + u * c - v * s, y + u * s + v * c];
      const drop = sm([pt(0, -ry * 1.35), pt(rx * 0.75, -ry * 0.25), pt(rx, ry * 0.45), pt(0, ry), pt(-rx, ry * 0.45), pt(-rx * 0.75, -ry * 0.25)]);
      R.dome(drop, '#f4b088', 0.2, 0.2, Math.min(rx, ry) * 0.9, 1);
    }
    // ── white droplets ──
    const dr = rng(201);
    for (const [x, y, r] of [[729, 105, 5], [808, 413, 11], [857, 403, 5], [840, 378, 3], [808, 523, 11], [882, 582, 10], [232, 637, 7], [40, 645, 7], [330, 538, 4], [380, 487, 4], [362, 506, 4], [455, 535, 5], [962, 548, 5], [990, 510, 3], [928, 698, 4], [900, 560, 3]])
      R.bead(x, y, r, '#eef0f4', 0.2, 0.08, 7);
    for (let i = 0, n = 0; i < 400 && n < 60; i++) {
      const x = 290 + dr() * 740, y = 505 + dr() * 220, r = 1.5 + dr() * dr() * 4.5;
      if (!a.isPointInPath(zebra, x * S, y * S)) continue;
      R.bead(x, y, r, '#e8ecf0', 0.3, 0.05, 7); n++;
    }
    for (let i = 0; i < 14; i++) R.bead(dr() * W, 420 + dr() * 300, 1 + dr() * 2, '#e4e8f0', 0.05, 0.03, 7);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.55, shin: 40, wrap: 0.45, coat: 0.12, rim: 0.5, ao: 0.4 }),       // 1 lavender plastic
        E.mat({ dif: 1, spec: 1.2, shin: 70, metal: 0.1, coat: 0.2, wrap: 0.5, emis: 0.15, tint: [1, 0.85, 0.8] }),  // 2 copper
        E.mat({ dif: 1, spec: 0.5, shin: 50, wrap: 0.5, coat: 0.1, rim: 0.4, ao: 0.4 }),          // 3 white skull
        E.mat({ dif: 0.9, spec: 0.45, shin: 40, wrap: 0.6, coat: 0.06, emis: 0.2 }),             // 4 zebra
        E.mat({ dif: 0.8, spec: 1.2, shin: 80, metal: 0.3, coat: 0.3 }),                          // 5 chrome coil
        E.mat({ dif: 0.8, spec: 1.2, shin: 90, wrap: 0.5, coat: 0.3, rim: 0.8 }),                 // 6 glass disc
        E.mat({ dif: 0.9, spec: 1, shin: 60, wrap: 0.5, coat: 0.2, emis: 0.05 })                  // 7 droplets
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.8, 0.78, 0.8], amb: [0.33, 0.32, 0.34],
      envTop: [0.95, 0.95, 1.05], envHor: [0.55, 0.62, 0.82], envBot: [0.32, 0.32, 0.42], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.25, 0.35, 0.75], rimD: [0, 0, 0],
      r1: 1.6, r2: 9, k: [0, 0.6, 0.4, 60], shadow: [-6, 7, 0.55, 6]
    });
    E.grain(0.04, 201);
  }
});
