'use strict';
// g212 — "Cog-eye slate medallion": a sky-blue jelly with a lilac-and-orange cog eye inside a white cloud collar,
// a zebra pillow and glass drips, on a dark slate disc embossed with ticks, a ladder and glyphs, over violet.
REC.register('g212', {
  w: 578, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const Q = (f, sm = true, cl = true) => { const q = []; for (let i = 0; i < f.length; i += 2) q.push([f[i], f[i + 1]]); return P(q, cl, sm); };
    const L = f => Q(f, true, false);
    const img = (cv, alpha = 1, op = 'source-over') => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const lg = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rg = (x0, y0, r0, x1, y1, r1, st) => { const g = a.createRadialGradient(x0, y0, r0, x1, y1, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const soft = (blur, fn, alpha = 1, clipP = null, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clipP) a.clip(clipP); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const xf = (p, tx, ty, deg) => { const q = new Path2D(); q.addPath(p, new DOMMatrix().translate(tx, ty).rotate(deg)); return q; };
    const ribbon = (f, w0, w1 = w0) => {
      const c = []; for (let i = 0; i < f.length; i += 2) c.push([f[i], f[i + 1]]);
      const n = c.length, l = [], r = [];
      for (let i = 0; i < n; i++) {
        const p0 = c[Math.max(0, i - 1)], p1 = c[Math.min(n - 1, i + 1)];
        let dx = p1[0] - p0[0], dy = p1[1] - p0[1]; const d = Math.hypot(dx, dy) || 1; dx /= d; dy /= d;
        const w = (w0 + (w1 - w0) * i / (n - 1)) / 2;
        l.push([c[i][0] - dy * w, c[i][1] + dx * w]); r.push([c[i][0] + dy * w, c[i][1] - dx * w]);
      }
      return P(l.concat(r.reverse()), true, true);
    };
    // sample points along a smooth polyline
    const along = (f, step) => {
      const c = []; for (let i = 0; i < f.length; i += 2) c.push([f[i], f[i + 1]]);
      const out = []; let carry = 0;
      for (let i = 0; i < c.length - 1; i++) {
        const [x0, y0] = c[i], [x1, y1] = c[i + 1], d = Math.hypot(x1 - x0, y1 - y0);
        for (let t = carry; t < d; t += step) out.push([x0 + (x1 - x0) * t / d, y0 + (y1 - y0) * t / d, (x1 - x0) / d, (y1 - y0) / d]);
        carry = (carry - d) % step; if (carry < 0) carry += step;
      }
      return out;
    };

    // ── 1. violet backdrop fading to black ──
    R.flat(rrect(-10, -10, 600, 1050, 0), null, 0, 0);
    img(E.fx(`
      const vec3 BGC[88] = vec3[88](vec3(.41,.41,.66),vec3(.39,.39,.65),vec3(.37,.38,.64),vec3(.35,.35,.62),vec3(.34,.34,.61),vec3(.32,.33,.59),vec3(.30,.30,.57),vec3(.28,.28,.57),vec3(.39,.39,.65),vec3(.37,.37,.65),vec3(.36,.35,.66),vec3(.34,.33,.67),vec3(.33,.32,.67),vec3(.32,.31,.63),vec3(.29,.29,.59),vec3(.27,.27,.56),vec3(.36,.36,.63),vec3(.35,.34,.65),vec3(.34,.32,.69),vec3(.37,.37,.74),vec3(.33,.32,.73),vec3(.31,.30,.68),vec3(.29,.28,.62),vec3(.26,.25,.55),vec3(.32,.31,.60),vec3(.34,.32,.68),vec3(.35,.33,.74),vec3(.44,.48,.79),vec3(.38,.41,.75),vec3(.31,.31,.69),vec3(.28,.26,.61),vec3(.24,.22,.51),vec3(.24,.23,.49),vec3(.31,.29,.66),vec3(.33,.32,.71),vec3(.36,.38,.68),vec3(.34,.37,.64),vec3(.29,.30,.59),vec3(.24,.23,.52),vec3(.20,.18,.44),vec3(.13,.11,.26),vec3(.16,.15,.33),vec3(.20,.20,.41),vec3(.23,.24,.45),vec3(.24,.26,.45),vec3(.22,.23,.43),vec3(.19,.18,.38),vec3(.15,.13,.33),vec3(.04,.02,.04),vec3(.02,.02,.01),vec3(.07,.06,.10),vec3(.12,.12,.21),vec3(.14,.14,.25),vec3(.14,.14,.25),vec3(.12,.12,.23),vec3(.10,.09,.21),vec3(.02,.01,-.00),vec3(.03,.03,.01),vec3(.04,.03,.03),vec3(.05,.05,.07),vec3(.06,.06,.09),vec3(.06,.06,.09),vec3(.06,.05,.09),vec3(.06,.05,.10),vec3(.02,.01,.00),vec3(.04,.03,.03),vec3(.03,.02,.03),vec3(.03,.02,.02),vec3(.03,.02,.02),vec3(.03,.02,.02),vec3(.03,.02,.02),vec3(.03,.03,.03),vec3(.02,.02,.01),vec3(.03,.02,.03),vec3(.03,.02,.03),vec3(.03,.02,.03),vec3(.03,.02,.03),vec3(.03,.02,.03),vec3(.03,.02,.02),vec3(.02,.01,.01),vec3(.02,.02,.02),vec3(.02,.02,.02),vec3(.02,.02,.02),vec3(.03,.03,.03),vec3(.03,.03,.03),vec3(.03,.03,.03),vec3(.02,.02,.02),vec3(.01,.01,-.00));
vec3 bg(vec2 p){ vec2 u = clamp(p / vec2(115.6000, 128.0000), vec2(0.), vec2(4.999, 7.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  vec3 f = vec3(0.);
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += BGC[(i.y + b) * 8 + i.x + a] * bx[a] * by[b];
  return f; }
      vec3 fx(vec2 uv, vec2 p){ return bg(p) + (hash(p) - 0.5) * 0.015; }`));

    // ── 2. slate disc ──
    const disc = ellipseP(367, 541, 324, 353, 7.7 * Math.PI / 180);
    R.dome(disc, '#7e94aa', 0.04, 0.1, 9, 2);
    const discIn = ellipseP(367, 541, 318, 347, 7.7 * Math.PI / 180);
    clipA(discIn, () => img(E.fx(`
      const vec3 DSCC[90] = vec3[90](vec3(.45,.66,.87),vec3(.42,.62,.80),vec3(.38,.56,.72),vec3(.34,.49,.62),vec3(.27,.40,.50),vec3(.19,.28,.34),vec3(.09,.15,.17),vec3(.00,.01,-.00),vec3(-.09,-.11,-.16),vec3(.40,.58,.75),vec3(.38,.53,.69),vec3(.34,.49,.63),vec3(.31,.44,.56),vec3(.26,.38,.48),vec3(.20,.29,.36),vec3(.11,.17,.20),vec3(.01,.02,.01),vec3(-.08,-.11,-.16),vec3(.37,.49,.63),vec3(.34,.45,.58),vec3(.31,.42,.53),vec3(.28,.39,.49),vec3(.25,.35,.44),vec3(.21,.30,.37),vec3(.13,.20,.24),vec3(.03,.04,.04),vec3(-.08,-.12,-.17),vec3(.34,.43,.53),vec3(.30,.39,.48),vec3(.27,.35,.44),vec3(.24,.32,.40),vec3(.22,.29,.37),vec3(.19,.27,.35),vec3(.18,.25,.32),vec3(.08,.10,.12),vec3(-.09,-.14,-.19),vec3(.33,.38,.45),vec3(.28,.33,.41),vec3(.24,.29,.36),vec3(.21,.26,.33),vec3(.18,.23,.30),vec3(.19,.24,.31),vec3(.25,.33,.42),vec3(.14,.19,.24),vec3(-.11,-.16,-.22),vec3(.33,.35,.40),vec3(.28,.30,.36),vec3(.23,.26,.32),vec3(.19,.22,.28),vec3(.17,.21,.27),vec3(.20,.26,.34),vec3(.27,.37,.46),vec3(.12,.17,.21),vec3(-.13,-.19,-.25),vec3(.34,.33,.36),vec3(.29,.29,.33),vec3(.24,.25,.29),vec3(.19,.22,.26),vec3(.16,.20,.25),vec3(.21,.28,.34),vec3(.25,.33,.42),vec3(.09,.12,.15),vec3(-.13,-.19,-.24),vec3(.36,.33,.34),vec3(.31,.29,.31),vec3(.26,.25,.28),vec3(.21,.22,.25),vec3(.16,.19,.23),vec3(.16,.20,.25),vec3(.15,.19,.23),vec3(.04,.04,.06),vec3(-.10,-.15,-.18),vec3(.38,.33,.33),vec3(.32,.29,.29),vec3(.27,.25,.26),vec3(.21,.21,.22),vec3(.16,.16,.18),vec3(.11,.12,.13),vec3(.06,.06,.07),vec3(-.00,-.02,-.02),vec3(-.08,-.13,-.14),vec3(.40,.34,.32),vec3(.34,.30,.28),vec3(.28,.25,.24),vec3(.21,.19,.18),vec3(.14,.12,.11),vec3(.06,.03,.02),vec3(-.00,-.04,-.05),vec3(-.05,-.09,-.10),vec3(-.08,-.12,-.12));
vec3 dsc(vec2 p){ vec2 u = clamp(p / vec2(96.3333, 146.2857), vec2(0.), vec2(5.999, 6.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  vec3 f = vec3(0.);
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += DSCC[(i.y + b) * 9 + i.x + a] * bx[a] * by[b];
  return f; }
      vec3 fx(vec2 uv, vec2 p){ vec3 c = dsc(p);
        c *= 0.92 + 0.16 * vnoise(p * 0.9) ; return c; }`)));
    soft(18, x => { fe(x, 470, 860, 140, 30, -0.1, '#0a0c10'); fe(x, 300, 880, 120, 30, 0.1, '#0a0c10'); }, 0.7, discIn);

    // embossed ticks
    for (const [x0, y0, x1, y1] of [[407, 216, 413, 252], [437, 221, 448, 262], [468, 236, 482, 273], [496, 252, 514, 292], [520, 280, 542, 313], [538, 312, 563, 340], [548, 350, 572, 370]])
      R.pipe(L([x0, y0 - 3, x1, y1 + 3]), 14, '#8a9cb0', 0.12, 0.12, 3);
    // fish glyph
    const fish = Q([446, 514, 456, 489, 485, 479, 510, 486, 524, 511, 517, 536, 528, 557, 546, 568, 546, 582, 528, 579, 510, 575, 503, 596, 481, 600, 492, 571, 467, 557, 446, 543]);
    R.dome(fish, '#6a7c90', 0.1, 0.12, 9, 3);
    R.dome(ellipseP(496, 512, 7, 14, 0.2), '#26303c', 0.12, -0.06, 4, 3);
    // ladder
    {
      const fr = xf(rrect(-29, 0, 58, 262, 22), 392, 598, 30.3);
      R.pipe(xf(rrect(-30, 6, 60, 250, 20), 396, 596, 30.3), 15, '#6c7c90', 0.12, 0.1, 3);
      R.paint(xf(rrect(-24, 12, 48, 238, 14), 396, 596, 30.3), 'rgba(30,38,48,0.6)');
      R.pipe(xf(Q([0, 12, 0, 252], false, false), 396, 596, 30.3), 12, '#6c7c90', 0.12, 0.09, 3);
      for (const y of [96, 136, 176, 214]) R.pipe(xf(Q([-28, y, 28, y], false, false), 396, 596, 30.3), 13, '#6c7c90', 0.12, 0.09, 3);
      void fr;
    }
    // S and comb-C glyphs
    R.pipe(L([507, 696, 474, 694, 450, 706, 442, 724, 450, 738, 436, 752, 419, 746]), 22, '#6e8094', 0.12, 0.12, 3);
    R.pipe(L([500, 734, 520, 768, 516, 812, 484, 842, 444, 844, 418, 822]), 30, '#6e8094', 0.12, 0.13, 3);
    for (const [x, y, dx, dy] of along([500, 734, 520, 768, 516, 812, 484, 842, 444, 844, 428, 834], 6.5)) {
      const nx = -dy, ny = dx; R.groove(Q([x + nx * 2, y + ny * 2, x - nx * 13, y - ny * 13], false, false), 2.5, '#202830', 0.24, 0.1, 3);
    }
    // bumps
    { const B = [[424, 557, 9], [407, 578, 6], [479, 603, 7], [528, 607, 9], [537, 474, 9], [530, 508, 5], [548, 640, 6], [500, 655, 5], [462, 640, 5], [442, 676, 6], [400, 735, 4], [296, 693, 11],
      [358, 833, 6], [375, 826, 5], [400, 818, 5], [456, 330, 8], [478, 360, 6], [520, 400, 7], [542, 432, 6], [500, 432, 5], [548, 482, 8], [468, 448, 5], [520, 690, 4], [545, 700, 7], [555, 760, 7], [470, 790, 4], [440, 806, 5], [540, 810, 3], [470, 860, 5], [330, 862, 5]];
      for (const [x, y, r] of B) R.bead(x, y, r, '#7e90a4', 0.1, r * 0.014, 3);
      const rr = rng(212); for (let i = 0; i < 40; i++) { const x = 380 + rr() * 180, y = 300 + rr() * 540; if (Math.hypot((x - 367) / 315, (y - 541) / 345) > 0.95) continue; R.bead(x, y, 1.5 + rr() * 2, '#8090a4', 0.1, 0.03, 3); }
    }

    // ── 3. zebra pillow ──
    const zp = Q([92, 386, 125, 382, 146, 414, 188, 498, 254, 548, 331, 571, 366, 560, 336, 616, 300, 682, 240, 772, 200, 815, 165, 768, 131, 690, 100, 621, 81, 546, 78, 465]);
    R.dome(zp, '#ffffff', 0.12, 0.2, 40, 4);
    clipA(zp, () => img(E.fx(`
      const vec2 ZC[22] = vec2[22](vec2(114., 417.), vec2(178., 417.), vec2(114., 481.), vec2(178., 481.), vec2(114., 545.), vec2(178., 545.), vec2(242., 545.), vec2(306., 545.), vec2(114., 609.), vec2(178., 609.), vec2(242., 609.), vec2(306., 609.), vec2(370., 609.), vec2(114., 673.), vec2(178., 673.), vec2(242., 673.), vec2(306., 673.), vec2(178., 737.), vec2(242., 737.), vec2(306., 737.), vec2(178., 801.), vec2(242., 801.));
const float ZK[132] = float[132](1.49, 1.76, 3.76, -1.72, .08, -.59, .76, -.84, 4.11, -1.94, .86, -.57, 2.62, 1.57, 3.13, -.53, .52, -.15, 6.46, -.68, .23, .29, -1.25, 1.25, 2.40, 1.94, 2.00, -.08, 1.14, -1.47, -1.35, 1.94, 2.74, .02, 1.08, -1.54, 1.90, 2.00, 3.36, .07, .33, -2.07, .96, 1.99, 3.97, .67, 1.73, -1.46, 1.30, 2.12, .99, .40, .16, -.79, -5.16, 2.41, 1.22, -.10, .37, -.79, -1.22, -2.20, -1.43, -.36, -.19, .43, -.14, 3.13, 2.24, .96, 1.48, -.91, -.03, 6.75, 6.11, 2.75, 7.24, 1.03, 1.78, 1.65, .84, 2.11, 1.47, .97, 1.57, 2.74, 1.44, -.58, .67, .62, 6.13, 2.56, 1.89, .62, .93, .68, .78, -4.46, -2.69, -2.00, -1.39, -.93, -5.41, 3.05, 1.50, -.29, .64, .01, -5.50, -3.32, -2.18, -.59, -1.52, -.21, 1.45, 2.00, 2.87, -1.93, 1.55, -.46, 23.39, -3.74, -2.30, -.58, -2.13, -1.32, -.89, 4.03, 3.17, .30, 1.14, 1.05);
float zv(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 22; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.2478);
    float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }
      vec3 fx(vec2 uv, vec2 p){ float v = zv(p);
        return mix(vec3(0.97, 0.95, 0.9), vec3(0.03, 0.03, 0.035), smoothstep(-0.15, 0.15, v)); }`)));

    // ── 4. sky-blue jelly ──
    R.dome(ellipseP(244, 212, 46, 32, -0.1), rg(238, 196, 4, 244, 212, 48, [[0, '#c8e4f4'], [1, '#86aacc']]), 0.14, 0.12, 16, 1);
    const pool = Q([156, 380, 160, 430, 172, 480, 204, 514, 250, 536, 300, 550, 345, 540, 380, 516, 418, 476, 450, 426, 476, 390, 470, 340, 420, 320, 300, 300, 200, 320]);
    R.flat(pool, '#20364a', 0.12, 2);
    soft(3, x => { const r = rng(31); for (let i = 0; i < 40; i++) { x.fillStyle = r() < 0.5 ? '#2e5a68' : '#264858'; x.fill(P(blob(170 + r() * 270, 400 + r() * 130, 6 + r() * 8, 5 + r() * 6, i, 9, 0.35))); } }, 0.9, pool);
    { const r = rng(8); for (let i = 0; i < 30; i++) { const x = 160 + r() * 280, y = 380 + r() * 150; if (!a.isPointInPath(pool, x * S, y * S)) continue; R.bead(x, y, 1.5 + r() * 3.5, '#8ab4cc', 0.16, 0.04, 7); } }
    const jelly = Q([115, 345, 131, 322, 160, 290, 185, 250, 194, 232, 240, 226, 288, 229, 354, 237, 404, 248, 427, 275, 440, 314, 442, 360, 436, 405, 420, 430, 400, 410, 380, 330, 300, 296, 215, 320, 196, 360, 176, 384, 150, 392, 124, 384]);
    R.dome(jelly, lg(130, 230, 430, 440, [[0, '#6aaed0'], [0.5, '#5c9ec2'], [1, '#5494b8']]), 0.16, 0.16, 26, 1);
    soft(16, x => { fe(x, 320, 262, 30, 22, 0, '#7a8cf0'); fe(x, 268, 255, 24, 20, 0, '#8a70e0'); fe(x, 220, 300, 30, 18, 0, '#7aa8d8'); }, 0.75, jelly);
    // eye
    R.dome(circleP(268, 255, 13), '#7a5ce0', 0.3, 0.04, 4, 5);
    R.flat(circleP(268, 255, 9), '#0a0812', 0.3, 0);
    R.paint(circleP(265, 252, 2.5), '#e8e0ff');
    // holes and bubbles in the jelly
    for (const [x, y, r] of [[211, 315, 11], [201, 340, 8], [148, 333, 5]]) { R.dome(circleP(x, y, r + 2), '#8ab8d4', 0.24, 0.02, 2, 1); R.flat(circleP(x, y, r), '#18242e', 0.2, 0); }
    { const r = rng(7); for (let i = 0; i < 60; i++) { const x = 130 + r() * 300, y = 240 + r() * 150; if (!a.isPointInPath(jelly, x * S, y * S) || Math.hypot(x - 294, y - 380) < 95) continue; R.bead(x, y, 1.2 + r() * 2.8, '#b8dcee', 0.3, 0.03, 7); } }
    // navy ring round the cog
    R.dome(circleP(292, 380, 94), rg(292, 380, 50, 292, 380, 94, [[0, '#1c2244'], [1, '#2c3a64']]), 0.16, 0.03, 8, 2);

    // ── 5. the cog eye ──
    const cogC = [294, 372];
    { const teeth = new Path2D(); const n = 14; teeth.moveTo(cogC[0] + 62, cogC[1]);
      for (let i = 0; i < n; i++) { const t0 = i / n * 6.283, t1 = (i + 0.3) / n * 6.283, t2 = (i + 0.7) / n * 6.283;
        for (const [t, r] of [[t0, 62], [t1, 62], [t1, 74], [t2, 74], [t2, 62]]) teeth.lineTo(cogC[0] + Math.cos(t) * r, cogC[1] + Math.sin(t) * r); }
      teeth.closePath();
      R.dome(teeth, lg(240, 300, 340, 450, [[0, '#d8d4f0'], [0.6, '#a49ccc'], [1, '#8a84b8']]), 0.22, 0.06, 4, 6);
      const hole = new Path2D(); for (let i = 0; i < n; i++) { const t = (i + 0.5) / n * 6.283; hole.addPath(rrect(-3.5, -3.5, 7, 7, 1.5), new DOMMatrix().translate(cogC[0] + Math.cos(t) * 62, cogC[1] + Math.sin(t) * 67).rotate(t * 57.3)); }
      R.flat(hole, '#2a2c50', 0.24, 0);
    }
    R.dome(circleP(cogC[0], cogC[1], 60), lg(240, 310, 340, 440, [[0, '#d4cef0'], [1, '#9890c4']]), 0.26, 0.03, 4, 6);
    R.dome(circleP(cogC[0], cogC[1], 53), '#8e88bc', 0.28, 0.02, 3, 6);
    { const seg = new Path2D(); for (let i = 0; i < 8; i++) { const t0 = (i + 0.08) / 8 * 6.283, t1 = (i + 0.92) / 8 * 6.283; seg.moveTo(cogC[0] + Math.cos(t0) * 49, cogC[1] + Math.sin(t0) * 49); seg.arc(cogC[0], cogC[1], 49, t0, t1); seg.arc(cogC[0], cogC[1], 33, t1, t0, true); seg.closePath(); }
      R.dome(seg, '#f09a62', 0.3, 0.03, 3, 6); }
    R.dome(circleP(cogC[0], cogC[1], 29), '#9c96c4', 0.3, 0.02, 3, 6);
    R.dome(circleP(cogC[0], cogC[1], 13), '#2e98dc', 0.32, 0.03, 3, 5);
    R.flat(circleP(cogC[0], cogC[1], 6), '#06080e', 0.35, 0);
    soft(6, x => { fe(x, 288, 398, 16, 13, 0, '#fff4a0'); fe(x, 288, 398, 9, 8, 0, '#ffffff'); }, 1);
    // lilac bar and blades
    R.dome(xf(rrect(-64, -8, 128, 17, 4), 286, 415, 5), lg(0, 405, 0, 425, [[0, '#d0c8f0'], [1, '#9890cc']]), 0.3, 0.05, 4, 6);
    R.dome(Q([264, 428, 276, 428, 266, 492, 258, 500], false, false), '#8a78e8', 0.3, 0.04, 3, 6);
    R.dome(Q([284, 426, 296, 428, 278, 498, 270, 496], false, false), '#9a8af0', 0.3, 0.04, 3, 6);
    // orange hook
    R.pipe(L([210, 388, 210, 414, 222, 440, 236, 456]), 11, '#f29a1e', 0.3, 0.08, 5);
    R.bead(240, 462, 11, '#f08c18', 0.3, 0.1, 5);
    // white bone, antler and fan
    R.dome(ribbon([392, 268, 396, 300, 396, 330, 392, 362, 388, 400, 378, 432, 358, 456, 330, 468, 300, 476, 282, 478], 20, 30), lg(300, 280, 400, 470, [[0, '#ece6d2'], [1, '#d8d2bc']]), 0.3, 0.1, 12, 5);
    R.dome(ellipseP(390, 272, 13, 16, 0), '#f4f0e6', 0.36, 0.06, 6, 5);
    for (let y = 290; y < 440; y += 7) R.groove(L([386 + (y - 290) * -0.03, y, 398, y + 1]), 2, '#c4c0b0', 0.42, 0.03, 5);
    R.pipe(L([392, 330, 374, 336, 362, 322, 356, 312]), 4, '#e8e4d4', 0.34, 0.04, 5);
    R.pipe(L([374, 336, 380, 350]), 3, '#e8e4d4', 0.34, 0.04, 5);
    for (let i = 0; i < 11; i++) { const t = 2.4 + i * 0.13; R.pipe(L([370, 366, 370 + Math.cos(t) * 28, 366 + Math.sin(t) * 26]), 2.2, '#e8f0f4', 0.32, 0.03, 5); }
    // black feathers at the top
    for (let i = 0; i < 14; i++) { const t = -2.4 + i * 0.09; a.strokeStyle = '#141820'; a.lineWidth = 1.4; a.beginPath(); a.moveTo(380, 238); a.lineTo(380 + Math.cos(t) * 40, 238 + Math.sin(t) * 36); a.stroke(); }

    // ── 6. white cloud collar with orange edge ──
    const cl = [156, 398, 160, 430, 170, 480, 200, 514, 250, 540, 300, 554, 345, 546, 380, 520, 418, 480, 450, 430, 474, 396, 492, 380, 504, 370];
    { const pts = along(cl, 2), lft = [], rgt = [], n0 = pts.length;
      pts.forEach(([x, y, dx, dy], i) => { const wv = 13 + 6 * Math.min(1, Math.min(i, n0 - i) / 60), s1 = wv + 7 * Math.pow(Math.abs(Math.sin(i * 2 / 21 * Math.PI + 0.3 * Math.sin(i * 0.05))), 0.6), s2 = wv + 7 * Math.pow(Math.abs(Math.sin((i * 2 + 9) / 23 * Math.PI)), 0.6); lft.push([x - dy * s1, y + dx * s1]); rgt.push([x + dy * s2, y - dx * s2]); });
      const n = pts.length, [ex, ey, edx, edy] = pts[n - 1], [sx, sy, sdx, sdy] = pts[0], cap = [], cap0 = [];
      for (let k = 1; k < 12; k++) { const t = k / 12 * Math.PI; cap.push([ex + (-edy * Math.cos(t) + edx * Math.sin(t)) * 23, ey + (edx * Math.cos(t) + edy * Math.sin(t)) * 23]);
        cap0.push([sx + (sdy * Math.cos(t) - sdx * Math.sin(t)) * 23, sy + (-sdx * Math.cos(t) - sdy * Math.sin(t)) * 23]); }
      const cloud = P(lft.concat(cap, rgt.reverse(), cap0), true, false);
      R.pipe(L(cl), 50, '#f08a2c', 0.12, 0.1, 5);
      R.dome(cloud, rg(300, 420, 60, 300, 420, 200, [[0, '#f4f8fa'], [1, '#dce6ee']]), 0.18, 0.2, 18, 1);
    }
    // ── 7. glass drips ──
    const drip = (f, w, b0, b1) => {
      R.pipe(L(f), w * 1.45, 'rgba(214,228,242,0.9)', 0.3, 0.16, 7);
      R.pipe(L(f), w * 0.35, 'rgba(255,176,96,0.6)', 0.4, 0.02, 7);
      if (b0) R.bead(f[0], f[1], b0, 'rgba(206,222,238,0.9)', 0.3, 0.12, 7);
      if (b1) R.bead(f[f.length - 2], f[f.length - 1], b1, 'rgba(206,222,238,0.9)', 0.3, 0.12, 7);
    };
    drip([81, 370, 90, 392, 103, 418], 12, 10, 7);
    drip([103, 471, 80, 486, 62, 504, 48, 528, 41, 540], 10, 8, 7);
    drip([134, 527, 118, 566, 100, 612, 80, 664, 60, 708, 34, 740], 11, 9, 9);
    drip([169, 618, 152, 656, 128, 708, 104, 756, 80, 802, 59, 834], 11, 9, 9);
    drip([181, 784, 172, 808, 166, 834], 8, 6, 5);
    for (const [x, y, r] of [[70, 610, 9], [100, 715, 10], [124, 714, 6], [205, 694, 9], [168, 772, 10], [180, 800, 6], [90, 640, 4], [76, 580, 4], [140, 760, 5], [150, 748, 4], [190, 812, 4], [62, 560, 4]])
      R.bead(x, y, r, 'rgba(206,222,238,0.85)', 0.3, Math.min(0.2, r * 0.03), 7);

    // ── 8. black frame ──
    const fr = new Path2D(); fr.rect(-10, -10, 600, 1050); fr.addPath(rrect(12, 5, 554, 1060, 12));
    a.save(); a.fillStyle = '#070607'; a.fill(fr, 'evenodd'); a.restore();
    R.h.save(); R.h.fillStyle = '#000'; R.h.fill(fr, 'evenodd'); R.h.restore();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.4, ao: 0.3, coat: 0.25, rim: 0.2 }),                  // 1 jelly / cloud
        E.mat({ dif: 1, spec: 0.3, shin: 25, wrap: 0.3, ao: 0.4 }),                                        // 2 slate disc
        E.mat({ dif: 1, spec: 0.9, shin: 45, wrap: 0.3, ao: 0.4, coat: 0.1 }),                             // 3 embossed glyphs
        E.mat({ dif: 0.7, spec: 0.6, shin: 40, wrap: 0.5, emis: 0.3 }),                                    // 4 zebra
        E.mat({ dif: 0.9, spec: 0.7, shin: 40, wrap: 0.5, emis: 0.15 }),                                   // 5 bone / hook
        E.mat({ dif: 0.8, spec: 0.6, shin: 40, wrap: 0.5, emis: 0.2 }),                                    // 6 cog
        E.mat({ dif: 0.9, spec: 1.5, shin: 90, wrap: 0.3, coat: 0.35, emis: 0.1 })                         // 7 glass
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.75, 0.75, 0.8], amb: [0.42, 0.42, 0.46],
      envTop: [1.05, 1.02, 1.0], envHor: [0.55, 0.6, 0.66], envBot: [0.15, 0.18, 0.24], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.2, 0.3, 0.45], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 80], shadow: [-5, 6, 0.5, 6]
    });
  }
});
