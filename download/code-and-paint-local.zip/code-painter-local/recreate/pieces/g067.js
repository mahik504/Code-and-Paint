'use strict';
// g067 — "Grinning porcelain zebra": a glossy grey enamel face with a brown-rimmed black mouth full of
// pale-blue gum-drop teeth, cyan paint dripping from the top, grey pebble ovals on a brown cheek, and a
// raised black-and-white zebra relief below, edged by a glowing white rim on black.
REC.register('g067', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    keep();
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const himg = (path, cv) => { R.h.save(); R.h.clip(path); R.h.setTransform(1, 0, 0, 1, 0, 0); R.h.drawImage(cv, 0, 0); R.h.restore(); };

    // ── black ground ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#030303', 0, 0);

    const rimPts = [[668, -20], [672, 0], [697, 64], [708, 128], [710, 192], [705, 256], [695, 320], [685, 384], [670, 448], [652, 512], [637, 576], [626, 640], [625, 704], [628, 768], [640, 832], [650, 896], [650, 960], [648, 1044]];
    const inRim = d => rimPts.map(([x, y]) => [x - d, y]);
    // ── zebra relief (concentric folds round a point below the frame) ──
    const ZPH = `
      // per-zone concentric folds (centre, period, phase), seams wobble like the fingerprint's
      const vec4 ZC[6] = vec4[6](vec4(360., 950., 41.5, 0.296), vec4(1650., 1950., 34., 1.065), vec4(670., 850., 33.5, 1.269),
                                 vec4(780., 1140., 46., 2.906), vec4(870., 1100., 46., 0.407), vec4(1650., 2200., 42.75, 1.068));
      float zph(vec2 p){
        float xs = p.x + 18. * sin(p.y * 0.031), ys = p.y + 16. * sin(p.x * 0.027 + 1.);
        int c = xs < 210. ? 0 : (xs < 420. ? 1 : 2);
        int k = c + (ys < 780. ? 0 : 3);
        vec4 Z = ZC[k];
        return length(p - Z.xy) / Z.z - Z.w / 6.2832 + 0.29;
      }`;
    const zAlb = pat(E.fx(ZPH + `vec3 fx(vec2 uv, vec2 p){
      float f = fract(zph(p));
      float w = smoothstep(0.02, 0.07, f) * smoothstep(0.56, 0.51, f);
      float sh = smoothstep(0.56, 0.7, f) * smoothstep(0.95, 0.8, f);
      vec3 c = mix(vec3(0.07), vec3(0.97, 0.97, 0.95), w);
      return mix(c, vec3(0.30), sh * 0.5); }`));
    const zH = E.fx(ZPH + `vec3 fx(vec2 uv, vec2 p){
      float f = fract(zph(p));
      float t = clamp((f - 0.02) / 0.54, 0., 1.);
      float hv = 0.05 + 0.10 * sqrt(max(0., 1. - pow(2. * t - 1., 2.))) * step(f, 0.56);
      float v = hv * 255., i = floor(v);
      return vec3(i / 255., 4. * 32. / 255., fract(v)); }`);
    const zone = P([[-10, 650], [60, 640], [160, 610], [250, 560], [300, 520], [420, 560], [540, 520], [640, 470], ...inRim(4).filter(q => q[1] > 470), [-10, 1044]], true, false);
    R.flat(zone, zAlb, 0.05, 4);
    himg(zone, zH);
    keep();

    // ── glowing white rim on the right + brown lining ──
    R.pipe(P(inRim(16), false), 16, '#7a4e38', 0.12, 0.05, 3);
    R.pipe(P(rimPts, false), 18, '#fefdfb', 0.16, 0.08, 6);

    // ── grey enamel face plate ──
    const plate = P([[-10, -10], ...inRim(4).filter(q => q[1] < 470), [600, 492], [540, 520], [420, 556], [300, 520], [250, 560], [160, 610], [60, 640], [-10, 650]], true, false);
    R.dome(plate, '#c4c2c3', 0.1, 0.1, 30, 1);
    // dark recess lower left
    const rec = P([[-10, 548], [80, 556], [180, 556], [250, 548], [250, 566], [160, 612], [60, 640], [-10, 650]]);
    R.flat(rec, '#4a4849', 0.1, 1);
    R.pipe(P([[-10, 646], [60, 636], [160, 606], [250, 556], [290, 528]], false), 12, '#82553c', 0.14, 0.06, 3);

    // ── brown cheek on the right ──
    const cheek = P([[392, 40], [340, 96], [318, 150], [326, 210], [436, 214], [472, 280], [446, 384], [330, 420], [292, 470], [290, 530], [400, 560], [520, 545], [600, 512], ...inRim(6).filter(q => q[1] < 500 && q[1] > 20).reverse(), [680, 30]], true, false);
    R.dome(cheek, '#7d5038', 0.16, 0.06, 10, 3);
    R.dome(circleP(540, 300, 78), '#7e693c', 0.2, 0.02, 6, 3);
    // dark socket
    R.dome(ellipseP(400, 150, 72, 58, 0.1), '#3d3b3c', 0.12, 0.03, 10, 1);
    for (const [x, y] of [[372, 152], [384, 146], [396, 158]]) R.groove(P([[x, y], [x + 6, y - 3]], false), 2, '#9a9898', 0.16, 0.02, 1);

    // ── mouth: brown lip ring, black hole, pale-blue teeth ──
    const lip = P([[96, 236], [126, 212], [200, 214], [286, 200], [348, 164], [404, 168], [462, 192], [494, 236], [476, 304], [446, 372], [410, 398], [300, 404], [200, 392], [132, 346], [100, 292]]);
    R.dome(lip, '#7d5038', 0.2, 0.08, 8, 3);
    const hole = P([[118, 244], [150, 232], [220, 236], [300, 226], [360, 196], [410, 196], [452, 216], [472, 248], [458, 300], [428, 356], [400, 378], [300, 384], [210, 372], [146, 334], [120, 292]]);
    R.flat(hole, '#020202', 0.06, 0);
    // upper teeth: one bumpy band of gum drops; lower teeth: a smaller band
    const TU = P([[92, 192], [110, 168], [150, 172], [190, 148], [216, 128], [252, 140], [282, 168], [322, 176], [362, 182], [402, 198], [444, 212], [482, 230], [496, 262], [482, 290], [450, 296],
      [420, 282], [400, 270], [370, 268], [340, 264], [310, 256], [286, 250], [258, 242], [228, 232], [196, 224], [160, 220], [130, 222], [104, 216]]);
    const TL = P([[122, 286], [150, 280], [172, 298], [202, 314], [240, 328], [280, 334], [320, 336], [360, 332], [400, 324], [430, 312], [448, 300], [452, 330], [440, 352], [400, 372], [350, 388],
      [300, 392], [250, 386], [200, 372], [160, 350], [130, 322]]);
    const grow = (path, w) => { R.pipe(path, w, '#f2ecc8', 0.24, 0.02, 5); };
    grow(TU, 9); R.dome(TU, '#9ddde9', 0.24, 0.05, 10, 5);
    grow(TL, 9); R.dome(TL, '#a4e2ec', 0.22, 0.05, 10, 5);
    const lumpsU = [[124, 196, 26, 22], [196, 186, 40, 40], [262, 202, 34, 40], [324, 214, 34, 38], [388, 228, 36, 38], [452, 250, 36, 38]];
    const lumpsL = [[148, 306, 24, 22], [200, 340, 28, 28], [258, 358, 30, 28], [318, 362, 30, 26], [376, 352, 30, 26], [424, 330, 24, 24]];
    for (const [x, y, rx, ry] of lumpsU) { R.dome(rrect(x - rx, y - ry, 2 * rx, 2 * ry, 20), null, 0.28, 0.09, 16, 5); }
    for (const [x, y, rx, ry] of lumpsL) { R.dome(rrect(x - rx, y - ry, 2 * rx, 2 * ry, 16), null, 0.26, 0.08, 14, 5); }
    keep();

    // ── left eye: black opening with vertical zebra bars ──
    const eyeO = ellipseP(158, 16, 112, 80, 0.06), eyeI = ellipseP(158, 14, 104, 72, 0.06);
    R.dome(eyeO, '#8a5a40', 0.14, 0.03, 4, 3);
    R.flat(eyeI, '#030303', 0.07, 4);
    clipA(eyeI, () => { a.fillStyle = '#f8f8f6'; for (const x0 of [14, 106, 198]) a.fill(P([[x0 - 22, -20], [x0 + 22, -20], [x0 + 60, 110], [x0 + 16, 110]], true, false)); });
    // button
    R.dome(circleP(306, 48, 28), '#cac8c9', 0.18, 0.06, 10, 1);
    R.dome(circleP(306, 48, 16), '#d6d4d5', 0.24, 0.03, 4, 1);
    R.flat(circleP(308, 48, 7), '#050505', 0.2, 0);

    // ── cyan drips ──
    const dripT = P([[360, -10], [672, -10], [672, 40], [660, 70], [628, 84], [596, 90], [566, 112], [552, 150], [530, 166], [500, 150], [480, 106], [452, 92], [428, 98], [400, 70], [376, 52], [362, 26]]);
    R.dome(dripT, '#129cdb', 0.2, 0.12, 22, 2);
    const dripL = P([[-10, 104], [30, 98], [56, 116], [74, 150], [92, 170], [90, 206], [66, 224], [36, 210], [14, 230], [-10, 236]]);
    R.dome(dripL, '#0f93d1', 0.2, 0.12, 20, 2);
    R.dome(P([[-10, -10], [60, -10], [70, 30], [52, 70], [20, 80], [-10, 76]]), '#a2e0ec', 0.2, 0.1, 18, 5);
    R.dome(P([[-10, 624], [30, 630], [50, 664], [44, 700], [64, 730], [56, 772], [24, 790], [-10, 786]]), '#9dddea', 0.16, 0.1, 18, 5);
    R.dome(P([[-10, 296], [20, 300], [36, 320], [22, 344], [-10, 340]]), '#c8c6c7', 0.2, 0.05, 10, 1);

    // ── pale-blue drip with a grey pebble (below the mouth, right) ──
    const blueD = P([[290, 470], [320, 430], [380, 410], [470, 412], [560, 400], [630, 404], [646, 426], [620, 460], [584, 476], [560, 506], [530, 530], [500, 520], [470, 520], [430, 540], [380, 556], [320, 550], [292, 520]]);
    R.dome(blueD, '#f0ead0', 0.2, 0.04, 4, 5);
    R.dome(P([[300, 470], [328, 438], [384, 420], [470, 422], [560, 410], [624, 414], [632, 430], [612, 456], [576, 470], [552, 500], [528, 518], [500, 508], [466, 510], [428, 530], [380, 544], [324, 540], [302, 516]]), '#9edeea', 0.22, 0.1, 20, 5);
    // grey pebbles with cream rims
    const peb = (path, rimPath) => { R.dome(rimPath, '#f2eccc', 0.24, 0.04, 4, 1); R.dome(path, '#c6c4c5', 0.26, 0.16, 30, 1); };
    peb(ellipseP(366, 498, 66, 44, -0.05), ellipseP(366, 498, 74, 52, -0.05));
    peb(circleP(592, 218, 46), circleP(592, 218, 54));
    peb(ellipseP(556, 358, 82, 38, 0), ellipseP(556, 358, 90, 46, 0));
    // big left pebble + lilac shadow
    soft(x => { x.fillStyle = '#867983'; x.fill(ellipseP(212, 458, 80, 44, 0.2)); }, 6, 0.9);
    R.dome(ellipseP(104, 500, 116, 68, -0.05), '#c4c2c3', 0.2, 0.18, 44, 1);
    R.dome(ellipseP(146, 730, 18, 30, 0.3), '#d4d2d3', 0.12, 0.1, 14, 1);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.95, spec: 0.9, shin: 60, wrap: 0.3, ao: 0.5, coat: 0.25, rim: 0.2 }),             // 1 grey enamel
        E.mat({ dif: 1, spec: 1.0, shin: 70, wrap: 0.3, ao: 0.4, coat: 0.25, rim: 0.2 }),                // 2 cyan paint
        E.mat({ dif: 0.95, spec: 0.7, shin: 50, wrap: 0.3, ao: 0.5, coat: 0.15 }),                         // 3 brown
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.3, ao: 0.6, coat: 0.15 }),                            // 4 zebra relief
        E.mat({ dif: 1, spec: 1.0, shin: 70, wrap: 0.4, ao: 0.4, coat: 0.2, rim: 0.2 }),                 // 5 pale-blue teeth
        E.mat({ dif: 0.5, emis: 0.7, spec: 0.4, shin: 30, wrap: 0.5 })                                    // 6 glowing rim
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.75, 0.75, 0.75], amb: [0.45, 0.45, 0.46],
      envTop: [1.0, 1.0, 1.0], envHor: [0.55, 0.55, 0.56], envBot: [0.15, 0.15, 0.16], envK: [0.2, 1.0, 0.3, 0],
      r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 120], shadow: [-4, 6, 0.6, 7]
    });

    // rim glow + a dark scribble
    { const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.strokeStyle = '#ffffff'; x.lineWidth = 16; x.lineCap = 'round'; x.stroke(P(rimPts, false));
      E.draw(E.blur(c, 16), 0.9, 'screen'); E.draw(E.blur(c, 5), 0.5, 'screen'); }
    { const sr = rng(9), pts = []; for (let i = 0; i < 18; i++) pts.push([528 + i * 4 + sr() * 4, 992 - i * 1.2 + (i % 2 ? -10 : 6) * sr()]);
      o.lineWidth = 2; o.strokeStyle = '#0a0a0a'; o.lineCap = o.lineJoin = 'round'; o.stroke(P(pts, false)); }
    E.grain(0.03, 67);
  }
});
