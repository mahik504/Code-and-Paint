'use strict';
// s03 — "Resin night tile": a ragged square slab of poured resin on a starry navy ground —
// cream/mint rippled border over an orange backing sheet, a black speckled cosmos inside,
// glossy orange bead-chains, a yellow sun, a pale translucent face-blob and pools of cobalt blue.
REC.register('s03', {
  w: 1024, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fillE = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    // ragged rectangle: walk the perimeter, push each point along its normal by noise
    const ragRect = (x0, y0, x1, y1, seed, amp, freq = 0.02, step = 8) => {
      const pts = [], per = [[x0, y0, x1, y0, 0, -1], [x1, y0, x1, y1, 1, 0], [x1, y1, x0, y1, 0, 1], [x0, y1, x0, y0, -1, 0]];
      let s = 0;
      for (const [ax, ay, bx, by, nx, ny] of per) {
        const L = Math.hypot(bx - ax, by - ay), k = Math.max(2, Math.round(L / step));
        for (let i = 0; i < k; i++) {
          const u = i / k, d = (noise2(s * freq + seed, seed * 1.7) - 0.5) * 2 * amp + (noise2(s * freq * 4 + seed, 3.3) - 0.5) * amp * 0.5;
          pts.push([ax + (bx - ax) * u + nx * d, ay + (by - ay) * u + ny * d]); s += L / k;
        }
      }
      return pts;
    };

    // ── starry navy ground ──
    R.flat(rrect(-10, -10, 1044, 1044, 0), '#1d2a33', 0, 0);
    { const r = rng(3); for (let i = 0; i < 260; i++) { const x = r() * 1024, y = r() * 1024, rr = 1.5 + r() * r() * 6; a.fillStyle = 'rgba(245,245,240,' + (0.7 + r() * 0.3) + ')'; a.fill(circleP(x, y, rr)); } }

    // ── orange backing sheet ──
    const back = P(ragRect(8, 4, 1010, 1004, 11, 10, 0.015), true, false);
    const bg = a.createLinearGradient(0, 0, 1024, 1024); bg.addColorStop(0, '#e46a1c'); bg.addColorStop(0.5, '#d8581a'); bg.addColorStop(1, '#8a2c16');
    R.dome(back, bg, 0.02, 0.08, 20, 1);
    // ── cream slab ──
    const slab = P(ragRect(20, 36, 994, 1000, 5, 14, 0.02), true, false);
    R.dome(slab, '#e2dcc0', 0.08, 0.1, 30, 1);
    // top-left cream corner rising over the orange
    R.dome(P(ragRect(12, 12, 260, 300, 8, 8)), '#e6e0c4', 0.08, 0.1, 24, 1);
    // inner pale bands (mint -> light blue)
    const band1 = P(ragRect(46, 64, 968, 972, 17, 18, 0.018), true, false);
    const b1g = a.createLinearGradient(0, 0, 1024, 0); b1g.addColorStop(0, '#c8d8cc'); b1g.addColorStop(0.5, '#b4ccc8'); b1g.addColorStop(1, '#b0c4cc');
    R.dome(band1, b1g, 0.14, 0.05, 20, 1);
    const band2 = P(ragRect(90, 86, 950, 950, 23, 22, 0.02), true, false);
    const b2g = a.createLinearGradient(0, 0, 1024, 600); b2g.addColorStop(0, '#8cc0d0'); b2g.addColorStop(0.5, '#88acd0'); b2g.addColorStop(1, '#78a0d0');
    R.dome(band2, b2g, 0.17, 0.04, 16, 1);
    // rippled contour lines in the pale border
    for (let i = 0; i < 9; i++) {
      const pp = P(ragRect(30 + i * 8, 48 + i * 6, 986 - i * 5, 990 - i * 5, 40 + i * 0.3, 16 + i * 0.8, 0.02), true, false);
      R.groove(pp, 5, i % 2 ? '#8a9c90' : '#e8e6d8', 0.2, 0.03, 1, 0.35);
    }
    // purple band top-left
    const purp = P([[110, 100], [300, 62], [520, 60], [660, 80], [650, 132], [480, 132], [300, 142], [215, 170], [200, 250], [205, 350], [200, 450], [150, 470], [118, 380], [104, 260]]);
    const pg = a.createLinearGradient(100, 400, 600, 60); pg.addColorStop(0, '#5a64b8'); pg.addColorStop(0.3, '#3a2288'); pg.addColorStop(0.7, '#4a3888'); pg.addColorStop(1, '#7a76b0');
    R.dome(purp, pg, 0.2, 0.05, 20, 1);
    // right lilac/blue band
    R.dome(P([[850, 290], [930, 260], [955, 400], [950, 560], [900, 600], [860, 520], [850, 400]]), '#7890cc', 0.2, 0.04, 20, 1);
    // bottom-left grey-green ripple zone
    R.dome(P([[40, 720], [120, 700], [180, 820], [260, 900], [330, 960], [200, 980], [60, 960], [35, 850]]), '#5e6a60', 0.16, 0.04, 20, 1);
    for (let i = 0; i < 10; i++) R.groove(P([[40 + i * 6, 700 + i * 12], [90 + i * 8, 820 + i * 6], [170 + i * 10, 900 + i * 4], [300 + i * 6, 975 - i * 2]], false), 5, '#9aaa98', 0.2, 0.03, 1, 0.6);
    R.dome(P([[100, 640], [160, 650], [240, 720], [260, 820], [230, 900], [160, 890], [110, 800], [90, 700]]), '#2a1810', 0.18, 0.03, 16, 2);

    // ── black cosmos ──
    const black = P([[200, 150], [300, 140], [420, 128], [560, 126], [650, 100], [660, 58], [800, 50], [900, 64], [950, 130], [945, 240], [880, 290], [860, 330], [850, 450], [870, 570], [930, 610], [960, 700], [950, 770], [890, 810], [800, 860],
      [700, 880], [560, 900], [420, 918], [300, 920], [200, 900], [130, 860], [100, 760], [100, 660], [150, 560], [200, 480], [205, 380], [200, 260]]);
    R.flat(black, '#050709', 0.2, 2);
    // black crack-drips into the border
    for (const d of [[[150, 560], [120, 620], [110, 700]], [[200, 460], [170, 520], [140, 555]], [[660, 60], [500, 60], [300, 70]], [[100, 400], [60, 420]]])
      R.pipe(P(d, false), 6, '#101214', 0.2, 0.02, 2);
    // speckles in the black
    { const r = rng(9); a.save(); a.clip(black); for (let i = 0; i < 500; i++) { const x = 100 + r() * 860, y = 50 + r() * 870, rr = 1 + r() * r() * 4; a.fillStyle = r() < 0.8 ? '#d8e4ec' : '#7ab0d0'; a.fill(circleP(x, y, rr)); } a.restore(); }

    // ── cobalt blue pools ──
    const blueR = P([[612, 196], [680, 200], [745, 240], [785, 310], [790, 450], [792, 590], [760, 640], [710, 650], [650, 610], [630, 480], [610, 330]]);
    const brg = a.createLinearGradient(620, 200, 780, 640); brg.addColorStop(0, '#0e5ce8'); brg.addColorStop(0.5, '#0a48e0'); brg.addColorStop(1, '#0632d0');
    R.dome(blueR, brg, 0.22, 0.05, 30, 3);
    const blueB = P([[235, 930], [260, 885], [300, 860], [340, 825], [420, 800], [560, 812], [640, 800], [700, 822], [720, 860], [770, 886], [860, 892], [915, 868], [930, 770], [962, 735], [972, 800], [970, 968], [760, 968], [520, 972], [250, 966]]);
    const bbg = a.createLinearGradient(0, 750, 0, 970); bbg.addColorStop(0, '#0c44e0'); bbg.addColorStop(0.4, '#0628dc'); bbg.addColorStop(1, '#0420d8');
    R.dome(blueB, bbg, 0.22, 0.05, 30, 3);
    // blue edge under the face
    R.dome(P([[300, 700], [360, 745], [460, 770], [600, 760], [700, 740], [780, 730], [760, 790], [620, 820], [460, 830], [330, 800], [270, 740]]), '#5a7c9c', 0.23, 0.05, 30, 3);
    R.dome(P([[850, 570], [920, 560], [955, 620], [950, 700], [900, 680], [860, 640]]), '#8a98a4', 0.22, 0.04, 20, 4);
    R.dome(P([[790, 700], [820, 680], [860, 690], [880, 720], [870, 770], [830, 790], [795, 760]]), '#0c4ce6', 0.22, 0.05, 20, 3);
    for (let i = 0; i < 7; i++) { const t = i / 6, x0 = 830 - 40 + t * 80; R.pipe(P([[820, 760], [x0 - 40 + t * 20, 840]], false), 7, '#4c5a66', 0.22, 0.03, 4); }
    // blue splash, left
    R.dome(P([[330, 300], [355, 320], [360, 360], [345, 420], [330, 440], [322, 380]]), '#2a5ab0', 0.22, 0.03, 10, 3);
    for (const d of [[[300, 330], [310, 420], [330, 500], [350, 540]], [[320, 330], [330, 400], [350, 470]], [[250, 560], [300, 600], [320, 680]], [[300, 620], [330, 700], [350, 740]]])
      R.pipe(P(d, false), 5, '#3a70b8', 0.22, 0.02, 3);
    // lilac arc over the blue
    R.pipe(P([[300, 178], [400, 158], [520, 150], [640, 166], [715, 200], [765, 250], [790, 300]], false), 40, '#dcd4f0', 0.24, 0.06, 1);
    R.pipe(P([[300, 205], [420, 175], [540, 170], [640, 186]], false), 14, '#8ab8e8', 0.25, 0.03, 1);

    // ── translucent face blob ──
    const face = P([[360, 350], [420, 320], [500, 318], [560, 340], [595, 380], [590, 450], [560, 500], [490, 520], [420, 520], [370, 490], [350, 420]]);
    R.dome(face, '#6c9292', 0.24, 0.1, 50, 4);
    a.save(); a.clip(face); a.fillStyle = '#3e5a5c'; a.filter = 'blur(3px)';
    a.fill(P([[370, 410], [400, 395], [440, 410], [470, 395], [490, 410], [500, 440], [470, 450], [440, 440], [420, 455], [390, 440]])); a.restore();
    R.pipe(P([[330, 520], [380, 560], [400, 600]], false), 10, '#4a6874', 0.24, 0.03, 4);
    // lower blob with cobalt belly
    const low = P([[400, 560], [460, 535], [560, 535], [620, 555], [630, 600], [560, 620], [460, 625], [405, 600]]);
    R.dome(low, '#a6c2bc', 0.24, 0.08, 30, 4);
    a.save(); a.clip(low); a.fillStyle = '#0a3ce0'; a.fill(P([[400, 590], [500, 585], [630, 590], [630, 640], [400, 640]])); a.restore();
    R.bead(462, 570, 22, '#dcf2c4', 0.3, 0.12, 4);
    R.dome(ellipseP(417, 636, 22, 16, 0.3), '#d6de28', 0.24, 0.08, 10, 5);
    R.flat(circleP(424, 638, 5), '#1a1a10', 0.3, 5);
    R.dome(circleP(426, 302, 20), '#1a1c20', 0.22, 0.05, 8, 2); R.bead(426, 302, 12, '#e8d820', 0.27, 0.08, 5);
    R.dome(circleP(488, 652, 9), '#e0d420', 0.24, 0.05, 6, 5);

    // ── pink blobs ──
    R.dome(P([[290, 190], [330, 180], [380, 190], [390, 225], [370, 255], [330, 258], [295, 240]]), '#f69ac6', 0.24, 0.08, 20, 5);
    const pinkS = P([[210, 330], [260, 320], [285, 360], [280, 440], [290, 520], [280, 600], [250, 640], [215, 620], [205, 540], [220, 460], [210, 390]]);
    const psg = a.createLinearGradient(0, 330, 0, 640); psg.addColorStop(0, '#f05a98'); psg.addColorStop(1, '#b8386c');
    R.dome(pinkS, psg, 0.22, 0.06, 20, 5);
    { const r = rng(21); for (let i = 0; i < 26; i++) { const y = 470 + r() * 160, x = 215 + r() * 60; R.flat(circleP(x, y, 3 + r() * 6), '#3a0c1c', 0.24, 5); } }
    R.dome(P([[200, 690], [250, 700], [290, 740], [280, 790], [250, 790], [220, 740]]), '#e45090', 0.22, 0.05, 16, 5);
    // yellow sun
    R.dome(circleP(282, 298, 70), '#f2e21c', 0.24, 0.06, 40, 5);
    // black drip-tendril out of the sun
    R.pipe(P([[268, 330], [272, 380], [276, 440], [284, 500], [300, 540], [330, 560], [350, 600]], false), 16, '#0a0c10', 0.28, 0.05, 2);
    R.pipe(P([[276, 440], [262, 520], [250, 600]], false), 8, '#0a0c10', 0.28, 0.03, 2);
    R.pipe(P([[268, 330], [272, 380], [276, 440], [284, 500], [300, 540], [330, 560]], false), 4, '#2a6ab8', 0.3, 0.02, 3);
    R.bead(268, 348, 9, '#e8d820', 0.3, 0.05, 5);

    // ── glossy orange bead chains ──
    const OR = '#ff7400';
    // union outline of a row of beads (scalloped sausage), horizontal or vertical
    const chain = (pts, r, vert = false) => {
      const up = [], dn = [], A = pts.map(p => vert ? [p[1], p[0]] : p);
      const x0 = A[0][0] - r, x1 = A[A.length - 1][0] + r, c = A[0][1];
      for (let x = x0; x <= x1 + 0.01; x += 2) {
        let e = 0; for (const [bx] of A) { const d = x - bx; if (Math.abs(d) < r) e = Math.max(e, Math.sqrt(r * r - d * d)); }
        up.push([x, c - e]); dn.push([x, c + e]);
      }
      const pts2 = [...up, ...dn.reverse()];
      return P(vert ? pts2.map(([x, y]) => [y, x]) : pts2, true, false);
    };
    const top = [], vert = [], bot = [];
    for (let i = 0; i < 5; i++) top.push([412 + i * 48, 216]);
    for (let i = 0; i < 8; i++) vert.push([700, 372 + i * 44]);
    for (let i = 0; i < 9; i++) bot.push([392 + i * 47, 716]);
    for (const [pth, r] of [[chain(top, 38), 38], [chain(vert, 46, true), 46], [chain(bot, 44), 44]]) {
      a.save(); a.fillStyle = 'rgba(0,0,0,0.9)'; a.translate(-4, 6); a.filter = 'blur(4px)'; a.fill(pth); a.restore();
      R.dome(pth, OR, 0.3, 0.12, r * 0.7, 6);
    }
    R.pipe(P([[704, 340], [704, 500], [700, 670]], false), 16, '#c4a2e0', 0.44, 0.02, 7);
    R.pipe(P([[372, 716], [560, 712], [760, 708]], false), 13, '#c4a2e0', 0.44, 0.02, 7);
    R.bead(612, 256, 11, '#ff8a3a', 0.3, 0.06, 6);

    // ── orange beads in dark sockets ──
    for (const [x, y, r] of [[798, 80, 18], [896, 197, 15], [912, 677, 22], [118, 693, 18], [212, 757, 16], [183, 855, 18], [850, 878, 10]]) {
      R.dome(circleP(x, y, r * 1.9), '#141416', 0.24, 0.06, r * 0.8, 2);
      R.bead(x, y, r, '#ff6400', 0.3, 0.14, 6);
    }
    R.dome(circleP(880, 620, 20), '#0a0a0c', 0.24, 0.04, 8, 2);
    // white resin dots
    { const r = rng(33); const zones = [[620, 200, 170, 420], [260, 800, 700, 160], [780, 880, 180, 80]];
      for (let i = 0; i < 44; i++) { const z = zones[i % 3], x = z[0] + r() * z[2], y = z[1] + r() * z[3]; R.bead(x, y, 4 + r() * 5, '#e8eef4', 0.3, 0.06, 4); } }

    // ── soft painted depth / glow ──
    soft(x => {
      fillE(x, 150, 420, 50, 160, 0, '#4a4aa8'); fillE(x, 130, 560, 40, 90, 0, '#58a0c8'); fillE(x, 860, 400, 50, 140, 0, '#3c3c80');
      fillE(x, 900, 900, 90, 60, 0, '#d8e0d8'); fillE(x, 60, 300, 40, 120, 0, '#f0f0e8');
    }, 30, 0.5);
    soft(x => { fillE(x, 470, 400, 70, 40, 0, '#a8c4c0'); }, 30, 0.35);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.9, emis: 0.2, spec: 0.35, shin: 30, wrap: 0.3, coat: 0.05, ao: 0.4 }),        // pale resin border
        E.mat({ dif: 0.8, emis: 0.2, spec: 0.6, shin: 60, coat: 0.12 }),                          // black gloss
        E.mat({ dif: 0.9, emis: 0.3, spec: 0.6, shin: 50, wrap: 0.2, coat: 0.08 }),               // cobalt
        E.mat({ dif: 0.9, emis: 0.25, spec: 0.5, shin: 40, wrap: 0.4, coat: 0.1, rim: 0.4 }),     // translucent face
        E.mat({ dif: 0.9, emis: 0.3, spec: 0.5, shin: 40, wrap: 0.3, coat: 0.05 }),               // pink / yellow
        E.mat({ dif: 0.95, emis: 0.3, spec: 0.8, shin: 40, wrap: 0.25, coat: 0.06 }),             // orange gloss
        E.mat({ dif: 0.9, emis: 0.3, spec: 0.3, shin: 30, wrap: 0.3 })                            // lilac line
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.78, 0.78, 0.78], amb: [0.24, 0.24, 0.26],
      envTop: [1, 1, 1], envHor: [0.45, 0.47, 0.5], envBot: [0.05, 0.05, 0.06], envK: [0.3, 1.0, 0.4, 0],
      shadow: [-6, 6, 0.5, 8], r1: 2, r2: 8, k: [0, 0.6, 0.4, 80]
    });
    E.grain(0.035, 3);
  }
});
