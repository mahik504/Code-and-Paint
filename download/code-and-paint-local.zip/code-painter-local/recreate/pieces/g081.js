'use strict';
// g081 — "Zebra-winged studio visitor": a green-striped helmeted figure with zebra wings walks past a tall
// blue window in a mint-green rotunda with gothic arch windows, a camera on a black plinth and a surfboard.
REC.register('g081', {
  w: 726, h: 1024,
  draw(E) {
    const S = E.S, o = E.out;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const fill = (path, c) => { o.fillStyle = c; o.fill(path); };
    const stroke = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const ink = (path, c, wd = 3) => { fill(path, c); stroke(path, '#050505', wd); };
    const clipped = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const line = (pts, c, wd) => stroke(P(pts, false, false), c, wd);
    const curve = (pts, c, wd) => stroke(P(pts, false, true), c, wd);

    const GREEN = '#62e89c', BLUE = '#4f8bfd', BLK = '#040404';

    // ── zebra fields: wing (diagonal wavy stripes) and curtain (horizontal ripples) ──
    const zWing = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p - vec2(140., 580.);
      float ph = dot(q, normalize(vec2(1., -0.28))) / 15. + 1.4 * sin(q.y * 0.018) + 0.6 * (fbm(p * 0.01) - .5);
      float v = sin(6.2832 * ph);
      return mix(vec3(.02), vec3(.97, .97, .95), smoothstep(-.15, .15, v)); }`));
    const zCurt = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float ph = p.y / 16. + 0.5 * sin(p.x * 0.075 + p.y * 0.03) + 0.25 * sin(p.x * 0.16 - p.y * 0.05) + 0.6 * (fbm(p * vec2(0.02, 0.01)) - .5);
      float v = sin(6.2832 * ph);
      return mix(vec3(.02), vec3(.97, .97, .95), smoothstep(-.2, .2, v)); }`));

    // ── base: black ──
    fill(rrect(0, 0, 726, 1024, 0), BLK);

    // ── ceiling: plum dome + lamp medallion ──
    fill(P([[55, 0], [705, 0], [690, 32], [620, 54], [500, 68], [390, 72], [270, 68], [160, 57], [90, 40]], true, true), '#2e1428');
    fill(P([[560, 0], [705, 0], [690, 32], [620, 54], [560, 60]], true, true), '#1a1220');
    fill(ellipseP(212, 25, 10, 5, 0), '#e8e8f0'); fill(ellipseP(598, 20, 9, 4, 0), '#e8e8f0');
    // medallion
    const med = P([[275, 0], [512, 0], [515, 30], [500, 40], [505, 85], [490, 95], [295, 95], [280, 85], [285, 40], [270, 30]], true, false);
    ink(med, '#86a6e0', 4);
    clipped(med, () => {
      for (const [x0, y0, x1, y1] of [[280, 10, 505, 85], [280, 85, 505, 10], [390, 0, 390, 95], [275, 48, 515, 48]]) line([[x0, y0], [x1, y1]], '#f4f6fc', 9);
      for (const [x0, y0, x1, y1] of [[280, 10, 505, 85], [280, 85, 505, 10], [390, 0, 390, 95], [275, 48, 515, 48]]) line([[x0, y0], [x1, y1]], BLK, 3);
      const fr = rng(81);
      for (let i = 0; i < 14; i++) { const x = 290 + fr() * 210, y = 8 + fr() * 80; fill(ellipseP(x, y, 6, 4, fr() * 3), BLK); fill(circleP(x + 2, y - 1, 2), '#f4f6fc'); }
    });
    fill(ellipseP(392, 45, 48, 30, 0), BLK);
    stroke(ellipseP(392, 45, 48, 30, 0), '#e6ecf8', 2.5);
    fill(ellipseP(392, 40, 30, 18, 0), '#0c0c14');
    fill(circleP(380, 38, 7), '#f4f6fc');

    // ── mint rotunda wall ──
    const wallTop = [[92, 74], [200, 100], [300, 113], [400, 118], [500, 112], [600, 100], [700, 76], [726, 70]];
    fill(P([...wallTop, [726, 960], [92, 960]], true, false), GREEN);
    curve(wallTop.map(([x, y]) => [x, y - 4]), BLK, 6);
    // frieze lines (bowed band)
    const bow = (y0, dip) => { const pts = []; for (let x = 92; x <= 726; x += 30) { const t = (x - 410) / 330; pts.push([x, y0 + dip * (1 - t * t)]); } return pts; };
    curve(bow(162, 10), BLK, 3);
    curve(bow(172, 10), BLK, 2);
    fill(P([...bow(246, 8), ...bow(262, 8).reverse()], true, false), '#8ad8c6');
    curve(bow(246, 8), BLK, 3);
    curve(bow(262, 8), BLK, 3);
    curve(bow(272, 8), BLK, 2);
    curve(bow(278, 8), '#2c8a5a', 2);
    // gothic arch windows
    const arch = (cx, top, bot, w) => { const p = new Path2D(), sp = top + w * 0.62; p.moveTo(cx - w / 2, bot); p.lineTo(cx - w / 2, sp);
      p.quadraticCurveTo(cx - w / 2, top + w * 0.12, cx, top); p.quadraticCurveTo(cx + w / 2, top + w * 0.12, cx + w / 2, sp); p.lineTo(cx + w / 2, bot); p.closePath(); return p; };
    const wins = [[118, 122, 40], [183, 134, 40], [256, 138, 40], [330, 140, 40], [407, 141, 40], [487, 140, 40], [568, 137, 40], [648, 132, 40]];
    for (const [cx, top, w] of wins) {
      const bot = 250 + 8 * (1 - ((cx - 410) / 330) ** 2);
      const a = arch(cx, top, bot, w);
      ink(a, '#2e5a48', 4);
      clipped(a, () => {
        const r = rng(cx);
        for (let i = 0; i < 9; i++) fill(ellipseP(cx - w / 2 + r() * w, top + 20 + r() * (bot - top - 20), 3 + r() * 5, 10 + r() * 12, r()), '#4e8a6e');
        line([[cx, top], [cx, bot]], BLK, 2);
        stroke(arch(cx, top + 10, bot + 10, w - 12), BLK, 1.5);
      });
      line([[cx, top - 2], [cx, top - 12]], BLK, 2.5); fill(circleP(cx, top - 13, 2.5), BLK);
    }
    // small pale panels between windows
    for (const cx of [150, 219, 293, 367, 447, 527, 608]) {
      const t = (cx - 410) / 330, y = 214 + 8 * (1 - t * t);
      ink(rrect(cx - 10, y, 20, 32, 3), '#9ae4d0', 2.5);
    }
    curve(bow(300, 6), '#3aa86e', 1.2);

    // ── lower wall moulding with cyan tiles ──
    line([[92, 868], [726, 868]], BLK, 3);
    line([[92, 908], [726, 908]], BLK, 3);
    for (let x = 100; x < 726; x += 50) ink(rrect(x, 880, 38, 18, 4), '#90dad4', 2.5);

    // ── tall window ──
    fill(rrect(228, 322, 352, 470, 0), BLK);
    fill(rrect(244, 338, 322, 446, 0), '#efe8d6');
    fill(rrect(258, 354, 296, 418, 0), BLUE);
    fill(rrect(390, 354, 22, 418, 0), '#f4f0e6');
    line([[390, 354], [390, 772]], BLK, 2.5); line([[412, 354], [412, 772]], BLK, 2.5);
    stroke(rrect(258, 354, 296, 418, 0), BLK, 3);
    // ripples on the glass
    for (const [x0, y0] of [[300, 506], [300, 514], [420, 506], [420, 514]]) {
      const pts = []; for (let x = 0; x <= 84; x += 6) pts.push([x0 + x, y0 + Math.sin(x * 0.25) * 2.5]);
      curve(pts, BLK, 2);
    }

    // ── two black hound busts on the window ──
    fill(P([[160, 482], [158, 432], [170, 405], [200, 397], [250, 403], [290, 411], [312, 417], [321, 408], [328, 412], [328, 426], [342, 432], [360, 434], [369, 438], [377, 443], [368, 449], [352, 451], [340, 457], [333, 467], [318, 471], [305, 479], [300, 491], [250, 493], [200, 490]], true, false), BLK);
    fill(P([[424, 443], [433, 437], [452, 433], [467, 428], [472, 413], [480, 409], [488, 416], [505, 410], [540, 400], [580, 392], [620, 384], [662, 378], [662, 460], [640, 478], [600, 495], [550, 495], [510, 491], [500, 479], [486, 471], [472, 467], [464, 457], [448, 451], [432, 449]], true, false), BLK);

    // ── right: zebra curtain + surfboard ──
    const curt = P([[726, 60], [705, 80], [688, 120], [676, 170], [664, 230], [655, 300], [652, 360], [660, 420], [672, 470], [690, 520], [726, 530]], true, true);
    fill(curt, zCurt); stroke(curt, BLK, 3);
    fill(rrect(690, 520, 40, 504, 0), BLK);
    const board = P([[708, 492], [690, 560], [672, 650], [663, 760], [665, 860], [680, 930], [710, 965], [740, 965], [740, 492]], true, true);
    ink(board, '#7a9ce0', 4);
    curve([[710, 500], [708, 650], [706, 800], [712, 960]], BLK, 2);
    line([[680, 935], [640, 995]], BLK, 5);

    // ── left: softbox, light stand, equipment, plant, speaker ──
    const box = P([[0, 0], [30, 0], [160, 240], [128, 334], [0, 168]], true, false);
    ink(box, '#fbfbfb', 6);
    line([[10, 0], [140, 230]], BLK, 1.5);
    fill(rrect(43, 232, 16, 760, 0), BLK);
    line([[47, 232], [47, 990]], '#6f88c4', 2);
    line([[55, 232], [55, 990]], '#3a4870', 1.5);
    for (const y of [250, 300, 580, 900]) ink(rrect(34, y, 34, 22, 3), '#6f88c4', 2.5);
    line([[51, 965], [5, 1024]], '#283048', 8); line([[51, 965], [100, 1024]], '#283048', 8); line([[51, 965], [51, 1024]], '#283048', 6);
    line([[51, 965], [5, 1024]], '#8aa4d8', 2); line([[51, 965], [100, 1024]], '#8aa4d8', 2);
    ink(rrect(-4, 625, 42, 135, 2), '#89aff4', 3);
    ink(rrect(-4, 762, 42, 118, 2), '#89aff4', 3);
    ink(rrect(-4, 876, 42, 8, 1), '#c43a3a', 2);
    fill(rrect(0, 676, 22, 26, 4), BLK); stroke(rrect(4, 680, 14, 18, 3), '#89aff4', 2);
    // plant
    const pr = rng(7);
    for (let i = 0; i < 9; i++) { const a = -Math.PI / 2 + (pr() - 0.5) * 2.4, L = 30 + pr() * 30; fill(ellipseP(82 + Math.cos(a) * L * 0.5, 840 + Math.sin(a) * L * 0.5, L * 0.5, 6, a), '#1a3a2a'); }
    for (const [x, y] of [[74, 776], [78, 795], [70, 812]]) fill(circleP(x, y, 6), '#d8d4d8');
    ink(rrect(66, 862, 28, 20, 2), '#8a2a2a', 2);
    // speaker
    ink(rrect(66, 878, 50, 112, 2), '#101014', 3);
    clipped(rrect(76, 888, 30, 92, 0), () => { for (let y = 888; y < 980; y += 5) for (let x = 76; x < 106; x += 5) fill(circleP(x + (y % 10 ? 2.5 : 0), y, 1.2), '#8a90a0'); });
    for (let i = 0; i < 6; i++) fill(P(blob(20 + i * 9, 420 + i * 40, 10, 8, 30 + i, 8, 0.4)), '#3a1830');

    // ── floor ──
    const floor = P([[92, 952], [300, 950], [500, 952], [726, 958], [726, 1024], [92, 1024]], true, false);
    fill(floor, '#a8aebd');
    clipped(floor, () => { const fr = rng(3); for (let i = 0; i < 400; i++) fill(rrect(92 + fr() * 640, 950 + fr() * 80, 6 + fr() * 20, 1.2, 0), fr() < 0.5 ? '#8a90a2' : '#c6ccd8'); });
    line([[92, 952], [726, 958]], BLK, 3);

    // ── plinth + camera ──
    fill(ellipseP(536, 1012, 120, 14, 0), BLK);
    fill(rrect(432, 766, 208, 248, 0), BLK);
    fill(ellipseP(536, 1012, 104, 12, 0), BLK);
    fill(ellipseP(536, 766, 104, 14, 0), '#18181c'); stroke(ellipseP(536, 766, 104, 14, 0), '#c8ccd8', 2);
    line([[540, 690], [496, 764]], BLK, 4); line([[540, 690], [600, 764]], BLK, 4); line([[540, 690], [542, 764]], BLK, 4);
    line([[540, 690], [496, 764]], '#c8ccd8', 1); line([[540, 690], [600, 764]], '#c8ccd8', 1);
    fill(rrect(532, 664, 18, 30, 3), BLK);
    fill(rrect(518, 654, 38, 14, 3), BLK); stroke(rrect(518, 654, 38, 14, 3), '#c8ccd8', 1.5);
    const cam = P([[496, 632], [560, 624], [606, 622], [616, 645], [606, 668], [560, 664], [496, 660]], true, false);
    ink(cam, '#141418', 3);
    for (const x of [540, 560, 580]) line([[x, 625], [x, 664]], '#6a6a80', 2);
    curve([[500, 640], [560, 632], [604, 630]], '#9a98b8', 3);
    fill(ellipseP(610, 645, 8, 22, 0), '#2a2838'); stroke(ellipseP(610, 645, 8, 22, 0), '#8a88a8', 2);
    ink(rrect(508, 612, 30, 16, 3), '#141418', 2);
    fill(circleP(523, 620, 4), '#9a98b8');

    // ── the figure ──
    // wings
    const wing = P([[132, 426], [154, 440], [178, 472], [196, 525], [202, 600], [192, 680], [166, 742], [112, 742], [84, 700], [70, 620], [72, 540], [86, 482], [108, 444]], true, true);
    fill(wing, zWing); stroke(wing, BLK, 4);
    // legs
    const legB = P([[178, 760], [234, 770], [226, 820], [198, 880], [168, 940], [156, 985], [118, 975], [128, 930], [150, 870], [170, 810]], true, true);
    const legF = P([[230, 760], [282, 760], [290, 830], [296, 900], [304, 975], [262, 980], [256, 900], [244, 830]], true, true);
    fill(legF, BLK);
    fill(P([[262, 960], [300, 960], [330, 980], [340, 998], [300, 1004], [256, 1000]], true, true), BLK);
    fill(legB, '#159d51'); stroke(legB, BLK, 3);
    clipped(legB, () => { for (let y = 770; y < 1000; y += 26) curve([[110, y + 26], [170, y + 6], [240, y - 10]], BLK, 10); });
    const bootB = P([[118, 970], [158, 972], [170, 1000], [150, 1018], [112, 1016], [104, 998]], true, true);
    ink(bootB, '#159d51', 3);
    // torso
    const torso = P([[150, 566], [190, 548], [240, 548], [272, 566], [288, 630], [292, 700], [284, 768], [176, 772], [146, 720], [140, 640]], true, true);
    fill(torso, '#159d51');
    clipped(torso, () => {
      for (let y = 572; y < 780; y += 24) curve([[130, y + 6], [200, y], [300, y - 6]], BLK, 10);
      fill(P([[248, 548], [296, 560], [300, 780], [250, 780], [262, 700], [262, 620]], true, true), BLK);
    });
    stroke(torso, BLK, 3);
    // back arm + glove
    const armB = P([[160, 590], [148, 650], [150, 712], [164, 760]], false, true);
    stroke(armB, BLK, 36); stroke(armB, '#159d51', 28);
    clipped(rrect(120, 580, 70, 190, 0), () => { for (let y = 600; y < 770; y += 22) line([[120, y], [190, y - 4]], BLK, 7); });
    const glove = P([[150, 752], [176, 750], [186, 772], [178, 786], [160, 790], [146, 778]], true, true);
    ink(glove, '#f4f2ee', 2.5);
    // front arm + hand + phone
    const armF = P([[250, 590], [282, 650], [320, 618]], false, true);
    stroke(armF, BLK, 34); stroke(armF, '#159d51', 26);
    clipped(rrect(250, 580, 90, 90, 0), () => { for (let x = 262; x < 330; x += 18) line([[x, 600], [x + 10, 670]], BLK, 6); });
    fill(P([[332, 580], [370, 576], [348, 620], [326, 618]], true, false), '#f4f0e0'); stroke(P([[332, 580], [370, 576], [348, 620], [326, 618]], true, false), BLK, 2);
    const hand = P([[310, 600], [326, 588], [348, 596], [354, 614], [340, 630], [318, 628]], true, true);
    ink(hand, '#f4f2ee', 2.5);
    line([[326, 590], [324, 560]], '#f4f2ee', 6); fill(circleP(324, 556, 7), '#f4f2ee'); stroke(circleP(324, 556, 7), BLK, 1.5);
    // collar + helmet
    fill(P([[192, 534], [222, 536], [214, 556], [196, 552]], true, true), '#e8eef8');
    const head = P([[176, 500], [180, 470], [200, 456], [232, 452], [262, 462], [290, 474], [284, 486], [272, 496], [272, 550], [258, 560], [222, 556], [200, 540], [182, 524]], true, true);
    ink(head, '#159d51', 3);
    fill(P([[220, 492], [272, 494], [272, 552], [258, 558], [226, 552], [214, 528]], true, true), BLK);
    fill(P([[232, 480], [274, 484], [272, 520], [246, 524], [232, 510]], true, true), '#20a858');
    stroke(P([[232, 480], [274, 484], [272, 520], [246, 524], [232, 510]], true, true), BLK, 2);
    fill(P([[244, 498], [252, 486], [256, 500]], true, false), '#f4f2ee');
    curve([[196, 466], [230, 456], [270, 466]], '#4ad080', 3);
    fill(circleP(207, 510, 13), BLK); fill(circleP(207, 510, 9), '#e6e2f0'); fill(circleP(209, 511, 5.5), '#8a5ab8');
    line([[192, 432], [194, 480]], BLK, 3);

    E.grain(0.05, 81);
  }
});
