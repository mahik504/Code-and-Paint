'use strict';
// u074 — "Coral reactor colossus": a silver robot colossus with a grey coral-labyrinth chest, a tiny crowned
// statue and a glowing red capsule in its red-laced ribs, on red with a blurred blue lamp and green graffiti.
REC.register('u074', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, hx = R.h, S = E.S, o = E.out;
    const img = (cv, ctx = a, alpha = 1, op = 'source-over') => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clip = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, st, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), open = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };
    const FLAT = 0, SILVER = 1, CORAL = 2, GUN = 3, GLOSS = 4, SOFTM = 5;

    // ── 1. backdrop: red wall, blurred blue lamp, sun flare, green graffiti field, maroon disc ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#f01420', 0, FLAT);
    soft(x => { fill(ellipseP(25, 290, 92, 125), '#d8307c', x); fill(rrect(26, 80, 48, 130, 20), '#d03c80', x); }, 12, 0.85);
    soft(x => { fill(ellipseP(25, 290, 72, 105), '#0a44d8', x); fill(rrect(38, 98, 24, 110, 10), '#3050d0', x); }, 7);
    soft(x => { fill(ellipseP(20, 280, 40, 60), '#0c5ef0', x); }, 20, 0.8);
    fill(rrect(-10, -10, 400, 160, 0), rad(262, -4, 150, [[0, '#ffffff'], [0.16, '#fffbe0'], [0.32, '#ffd640'], [0.55, 'rgba(255,120,30,0.75)'], [1, 'rgba(240,20,32,0)']]));
    const GREEN = sm([[620, 60], [670, 36], [740, 16], [740, 1040], [405, 1040], [420, 900], [470, 820], [560, 790], [590, 740], [606, 680], [622, 600], [586, 455], [574, 400], [580, 330], [560, 290], [560, 200]]);
    soft(x => fill(GREEN, '#529a12', x), 6);
    soft(x => { fill(ellipseP(470, 760, 50, 60), '#a8b0b0', x); }, 30, 0.5);
    // graffiti: looping maroon script (prolate-cycloid cursive) with hot orange edges
    clip(GREEN, () => {
      const r = rng(74), lines = [];
      const starts = [[690, 380, 1.75], [650, 470, 1.9], [700, 560, 1.6], [620, 600, 1.75], [690, 700, 1.7], [600, 760, 1.5], [670, 820, 1.9], [560, 880, 0.6],
        [470, 920, 0.2], [600, 940, 0.4], [480, 990, 0.1], [700, 900, 1.5], [640, 1000, 0.0], [520, 830, 1.0]];
      for (const [x0, y0, th] of starts) {
        const dx = Math.cos(th), dy = Math.sin(th), n = 40 + Math.floor(r() * 30), pts = [];
        let R0 = 10 + r() * 8, w = 0.55 + r() * 0.3, ph = r() * 6.28, b = 0;
        for (let t = 0; t < n; t++) {
          R0 = Math.max(6, Math.min(22, R0 + (r() - 0.5) * 4)); ph += w + (r() - 0.5) * 0.5; w = Math.max(0.2, Math.min(1, w + (r() - 0.5) * 0.2));
          b += 3 + r() * 2.5; const ox = Math.cos(ph) * R0, oy = Math.sin(ph) * R0 * 1.4;
          pts.push([x0 + dx * b + ox * dx - oy * dy, y0 + dy * b + ox * dy + oy * dx]);
        }
        lines.push(open(pts));
      }
      soft(x => { for (const l of lines) stroke(l, '#f07a30', 15, x); }, 3, 0.7);
      for (const l of lines) stroke(l, '#9c2c22', 10);
    });
    R.flat(sm([[-10, 646], [40, 630], [100, 622], [160, 620], [170, 1040], [-10, 1040]]), '#a13028', 0, FLAT);
    stroke(open([[-10, 852], [30, 872], [62, 905], [74, 940]]), '#101418', 30);
    stroke(open([[-10, 852], [30, 872], [62, 905], [74, 940]]), '#7accf0', 20);
    fill(sm([[-10, 930], [14, 935], [30, 1040], [-10, 1040]]), '#ccc0a7');

    // ── 2. the silver colossus ──
    // left wing / cape
    const WING = sm([[150, 240], [235, 300], [245, 400], [200, 460], [140, 500], [80, 550], [20, 600], [-10, 622], [-10, 560], [40, 500], [70, 440], [100, 380], [115, 320], [130, 270]]);
    R.dome(WING, lin(0, 600, 250, 300, [[0, '#5e6474'], [0.4, '#9aa2b8'], [1, '#ccd0dc']]), 0.04, 0.16, 40, SILVER);
    // main torso
    const TORSO = sm([[330, 40], [420, 28], [520, 44], [580, 80], [620, 130], [640, 200], [650, 280], [600, 300], [565, 300], [560, 380], [535, 560], [560, 620], [560, 780],
      [480, 800], [448, 900], [430, 1040], [40, 1040], [100, 880], [140, 760], [170, 640], [200, 540], [228, 430], [228, 330], [222, 220], [235, 140], [270, 108], [305, 98]]);
    const SHOULDER = sm([[590, 92], [640, 82], [690, 108], [740, 130], [740, 262], [690, 264], [660, 220], [630, 150]]);
    R.dome(SHOULDER, lin(600, 100, 726, 260, [[0, '#9ca2b2'], [0.5, '#c4cad8'], [1, '#a4aabc']]), 0.08, 0.16, 30, SILVER);
    R.dome(TORSO, lin(200, 100, 600, 700, [[0, '#e4e8ee'], [0.5, '#d6dae2'], [1, '#c4c8d2']]), 0.06, 0.2, 60, SILVER);
    // long left blade of the robe
    const BAND = sm([[230, 430], [250, 460], [210, 600], [160, 760], [118, 900], [96, 1040], [36, 1040], [70, 880], [120, 720], [170, 560]]);
    R.dome(BAND, lin(60, 1000, 240, 450, [[0, '#c8ccd8'], [0.6, '#e8eaf0'], [1, '#f0f2f4']]), 0.1, 0.16, 26, SILVER);
    // crescent blade
    const CRES_O = [[440, 60], [510, 60], [560, 70], [600, 90], [630, 124], [650, 165], [665, 210], [682, 250], [718, 266]];
    const CRES = P([...CRES_O, [690, 270], [668, 274], [652, 296], [648, 260], [640, 215], [625, 172], [604, 132], [575, 102], [540, 84], [500, 78], [446, 80]], true, true);
    R.dome(CRES, '#f6f7fa', 0.3, 0.05, 6, SILVER);
    stroke(open(CRES_O), '#30343e', 3);
    // top cap + seam + slots
    R.dome(sm([[330, -10], [500, -10], [490, 40], [420, 48], [340, 44]]), '#5a5c66', 0.2, 0.1, 16, GUN);
    R.groove(open([[404, 40], [398, 225]]), 10, '#2a2c34', 0.26, 0.08, SILVER);
    for (const [x, y, w, h] of [[300, 118, 82, 44], [292, 172, 82, 44], [410, 98, 84, 42]]) {
      R.dome(rrect(x - 6, y - 6, w + 12, h + 12, 26), '#b0b4c0', 0.26, 0.04, 6, SILVER);
      R.flat(rrect(x, y, w, h, 20), '#4e5060', 0.2, GUN);
      R.dome(rrect(x + 10, y + 10, w - 20, h - 20, 12), '#606474', 0.2, 0.03, 6, GUN);
    }

    // ── 3. coral labyrinth chest ──
    const CORALP = sm([[290, 252], [330, 234], [380, 238], [430, 228], [480, 236], [530, 252], [560, 290], [562, 350], [540, 420], [515, 500], [505, 570], [470, 600],
      [400, 590], [330, 590], [285, 570], [272, 480], [276, 380], [280, 300]]);
    const COR = `float cor(vec2 p){
        // narrow-band isotropic noise, thresholded -> Turing-like labyrinth
        p += 14. * vec2(vnoise(p * .012) - .5, vnoise(p * .012 + 7.) - .5);
        float s = 0.;
        for (int i = 0; i < 15; i++) { float a = float(i) * 2.39996 + .4; s += cos(dot(p, vec2(cos(a), sin(a))) * .19 + hash(vec2(float(i), 3.7)) * 6.283); }
        return s / 2.74;
      }`;
    R.dome(CORALP, null, 0.1, 0.14, 30, CORAL);
    clip(CORALP, () => {
      img(E.fx(COR + `vec3 fx(vec2 uv, vec2 p){ float v = smoothstep(.05, .35, cor(p)); return mix(vec3(.6, .63, .7), vec3(.19, .2, .24), v); }`));
    });
    clip(CORALP, () => {
      hx.save(); hx.globalAlpha = 0.9;
      img(E.fx(COR + `vec3 fx(vec2 uv, vec2 p){ float v = smoothstep(-.3, .7, cor(p)); return vec3(.27 - .12 * v, 64. / 255., 0.); }`), hx);
      hx.restore();
    }, hx);
    // little crowned statue
    R.dome(sm([[380, 240], [420, 222], [470, 225], [520, 236], [540, 210], [530, 190], [500, 200], [470, 205], [420, 210]]), '#9ca0ac', 0.28, 0.08, 10, CORAL);
    const spike = (x, y, ang, len, wd, col) => { const c = Math.cos(ang), sn = Math.sin(ang);
      R.dome(poly([[x - sn * wd, y + c * wd], [x + c * len, y + sn * len], [x + sn * wd, y - c * wd]]), col, 0.32, 0.06, wd * 0.8, SILVER); };
    for (const ang of [-2.75, -2.35, -1.95, -1.57, -1.2, -0.8, -0.42]) spike(434 + Math.cos(ang) * 20, 186 + Math.sin(ang) * 6, ang, 40, 7, '#a4a8b4');
    for (const [x, y, ang, len] of [[492, 214, -0.9, 48], [500, 220, -0.6, 56], [512, 226, -0.3, 44], [486, 210, -1.25, 40]]) spike(x, y, ang, len, 8, '#9ca0ac');
    R.dome(ellipseP(434, 186, 27, 9), '#b0b4c0', 0.34, 0.06, 6, SILVER);
    R.dome(ellipseP(434, 210, 21, 25), '#c8ccd6', 0.34, 0.12, 16, SILVER);
    R.flat(ellipseP(424, 206, 6, 2.5), '#2a2c34', 0.44, GUN); R.flat(ellipseP(445, 206, 6, 2.5), '#2a2c34', 0.44, GUN);
    R.groove(open([[430, 226], [438, 226]]), 3, '#3a3c44', 0.46, 0.04, SILVER);

    // ── 4. ribbed lower body with red lace ──
    const RIBS = sm([[205, 600], [240, 575], [290, 562], [360, 580], [470, 590], [540, 610], [560, 700], [540, 790], [470, 800], [450, 900], [432, 1040], [96, 1040], [118, 900], [160, 760], [180, 680]]);
    // horizontal folds: the labyrinth noise stretched sideways
    const RIB = `float rib(vec2 p){
        vec2 q = vec2(p.x * .4, p.y + 16. * sin(p.x * .012)) + 12. * vec2(vnoise(p * .01) - .5, vnoise(p * .01 + 5.) - .5);
        float s = 0.;
        for (int i = 0; i < 13; i++) { float a = float(i) * 2.39996 + 1.1; s += cos(dot(q, vec2(cos(a), sin(a))) * .145 + hash(vec2(float(i), 9.1)) * 6.283); }
        return s / 2.55; }
      float lace(vec2 p){ return fbm(p * .07 + 3.) + .6 * (fbm(p * .22) - .5) + .2 * clamp((420. - p.x) / 300., -.7, 1.) + .1 * smoothstep(700., 1000., p.y) - .1; }`;
    clip(RIBS, () => {
      img(E.fx(RIB + `vec3 fx(vec2 uv, vec2 p){ float g = smoothstep(.2, .5, rib(p));
        vec3 c = mix(vec3(.78, .79, .86), vec3(.3, .31, .36), g);
        float l = lace(p), m = smoothstep(.6, .612, l);
        c = mix(c, vec3(.9, .6, .62), smoothstep(.58, .595, l) * (1. - m) * .8);
        c = mix(c, vec3(.6, .2, .18), m);
        return c; }`));
    });
    clip(RIBS, () => {
      img(E.fx(RIB + `vec3 fx(vec2 uv, vec2 p){ float g = smoothstep(-.2, .8, rib(p)); return vec3(.26 - .13 * g, 32. / 255., 0.); }`), hx);
    }, hx);
    soft(x => { fill(ellipseP(200, 1040, 130, 80), '#e83030', x); }, 30, 0.6);

    // ── 5. right side: elbow pipe, ball, windows, finger ribs ──
    R.flat(rrect(583, 455, 45, 150, 3), '#6a2418', 0.12, GUN);
    for (const [x, y, hh] of [[590, 468, 38], [590, 520, 22], [590, 555, 36]]) R.flat(rrect(x, y, 20, hh, 2), lin(x, y, x, y + hh, [[0, '#fff0b0'], [1, '#ffb050']]), 0.14, FLAT);
    R.pipe(open([[540, 600], [540, 470], [548, 400], [580, 370], [660, 350]]), 62, '#80848f', 0.3, 0.16, SILVER);
    for (const [y, w] of [[455, 16], [478, 14], [498, 12], [540, 14]]) R.pipe(open([[496, y], [586, y + 2]]), w, '#c4c8d2', 0.42, 0.06, SILVER);
    R.dome(ellipseP(690, 332, 46, 44), '#d0d4dc', 0.36, 0.2, 40, SILVER);
    R.dome(ellipseP(700, 322, 26, 24), '#a8acb8', 0.46, 0.06, 18, SILVER);
    for (const [y, x1] of [[592, 590], [628, 600], [664, 600], [702, 590], [740, 575]]) R.pipe(open([[440, y + 8], [500, y], [x1, y + 4]]), 28, '#c8ccd6', 0.3, 0.12, SILVER);
    // soft grey ball low right

    // ── 6. glowing red capsule ──
    const CAP = (() => { const p = new Path2D(), cx = 388, cy = 678, L = 164, Hh = 53, t = -0.23, c = Math.cos(t), s = Math.sin(t);
      const pts = []; for (let i = 0; i <= 40; i++) { const u = i / 40 * Math.PI; pts.push([L - Hh + Math.sin(u) * Hh, -Math.cos(u) * Hh]); }
      for (let i = 0; i <= 40; i++) { const u = i / 40 * Math.PI; pts.push([-(L - Hh) - Math.sin(u) * Hh, Math.cos(u) * Hh]); }
      return poly(pts.map(([u, v]) => [cx + u * c - v * s, cy + u * s + v * c])); })();
    R.dome(CAP, '#e8262e', 0.3, 0.06, 20, GLOSS);
    clip(CAP, () => { const r = rng(9); for (let i = 0; i < 260; i++) { fill(circleP(220 + r() * 340, 600 + r() * 160, 0.6 + r() * 2.2), r() < 0.7 ? '#f8e040' : '#fff8c0'); } });

    // ── 7. head sphere, hook, gunmetal arm, red knob, white loop ──
    R.pipe(open([[-20, 40], [120, 70], [262, 86]]), 92, lin(0, 20, 0, 140, [[0, '#2a2a32'], [0.4, '#5a5c68'], [1, '#202028']]), 0.2, 0.2, GUN);
    R.pipe(open([[192, 30], [186, 120]]), 26, '#5a5c66', 0.36, 0.1, GUN);
    R.dome(ellipseP(292, 62, 32, 32), '#a8443a', 0.36, 0.14, 24, GLOSS);
    R.dome(rrect(268, 70, 20, 30, 6), '#e8e0c8', 0.36, 0.06, 6, SILVER);
    R.pipe(open([[196, 66], [166, 100], [140, 160], [130, 220], [146, 270], [176, 300]]), 13, '#aab0bc', 0.4, 0.08, SILVER);
    R.pipe(open([[208, 80], [186, 110], [170, 160]]), 9, '#8a90a0', 0.4, 0.06, SILVER);
    R.dome(circleP(206, 238, 62), rad(185, 215, 80, [[0, '#a0a4b0'], [1, '#5c6070']]), 0.36, 0.3, 58, SILVER);
    R.dome(poly([[248, 270], [300, 278], [312, 300], [270, 318], [240, 300]]), '#d2443a', 0.38, 0.08, 10, GLOSS);
    R.pipe(open([[248, 410], [196, 412], [150, 450], [124, 520], [130, 590], [152, 620]]), 18, '#eef0f4', 0.3, 0.1, SILVER);
    // top right spiky statuettes
    R.dome(sm([[480, 52], [500, 22], [540, 6], [600, 0], [640, 0], [652, 60], [640, 120], [600, 110], [560, 82], [500, 64]]), '#8a8e9a', 0.2, 0.12, 20, SILVER);
    for (const [x0, y0, x1, y1] of [[540, 30, 530, 0], [560, 26, 560, -6], [580, 26, 592, -4], [620, 40, 640, -6], [650, 60, 690, 40], [664, 80, 700, 70]])
      R.pipe(open([[x0, y0], [x1, y1]]), 12, '#a8acb8', 0.3, 0.06, SILVER);
    R.dome(sm([[660, 90], [700, 82], [726, 96], [726, 130], [690, 140], [660, 120]]), '#9a3a34', 0.24, 0.08, 10, GLOSS);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.55, shin: 30, metal: 0.25, wrap: 0.3, ao: 0.6, rim: 0.3 }),          // 1 silver
        E.mat({ dif: 1, spec: 0.4, shin: 22, wrap: 0.25, ao: 0.9, rim: 0.2 }),                     // 2 coral
        E.mat({ dif: 0.8, spec: 0.9, shin: 40, metal: 0.3, ao: 0.5 }),                           // 3 gunmetal
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.3, coat: 0.15, ao: 0.3, emis: 0.15 }),     // 4 gloss red
        E.mat({ dif: 1, spec: 0.15, shin: 10, wrap: 0.7 })                                       // 5 soft ball
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.7, 0.7, 0.72], amb: [0.42, 0.42, 0.46],
      envTop: [1.05, 1.04, 1.06], envHor: [0.62, 0.62, 0.66], envBot: [0.25, 0.25, 0.3], envK: [0.2, 0.7, 0.3, 0],
      rimC: [0.3, 0.3, 0.36], rimD: [0.3, 0.6, 0.3], r1: 2, r2: 9, k: [0, 0.6, 0.4, 90], shadow: [-6, 7, 0.5, 6]
    });

    // ── 8. glows: capsule halo + rays (outside the capsule only), eye, sun, specks ──
    const OUTSIDE = new Path2D(); OUTSIDE.addPath(rrect(-10, -10, 746, 1044, 0)); OUTSIDE.addPath(CAP);
    o.save(); o.clip(OUTSIDE, 'evenodd');
    soft(x => { stroke(CAP, 'rgba(255,70,70,0.9)', 70, x); }, 18, 0.55, 'source-over', o);
    soft(x => { stroke(CAP, '#ffffff', 26, x); }, 7, 0.9, 'screen', o);
    soft(x => { const r = rng(5); for (let i = 0; i < 110; i++) { const t = i / 110 * 6.283, L = 166, Hh = 56;
      const u = Math.cos(t) * L, v = Math.sin(t) * Hh, c = Math.cos(-0.23), s = Math.sin(-0.23), k = 1.12 + r() * 0.22;
      stroke(open([[388 + u * c - v * s, 678 + u * s + v * c], [388 + (u * c - v * s) * k, 678 + (u * s + v * c) * k]]), r() < 0.6 ? '#ffffff' : '#ff5050', 2 + r() * 3, x); } }, 2, 0.85, 'screen', o);
    o.restore();
    stroke(CAP, '#fff4f0', 5, o);
    soft(x => fill(circleP(512, 820, 68), rad(492, 798, 90, [[0, '#c4cad8'], [0.6, '#a2a8bc'], [1, '#868ca0']], x), x), 7, 1, 'source-over', o);
    soft(x => fill(circleP(252, 285, 22), '#ffe080', x), 10, 1, 'screen', o);
    fill(circleP(252, 285, 9), '#fffff0', o);
    soft(x => fill(circleP(262, 0, 46), '#ffffff', x), 20, 0.7, 'screen', o);
    { const r = rng(17); for (let i = 0; i < 260; i++) fill(circleP(r() * 726, r() * 1024, 0.5 + r() * 1.3), `rgba(255,255,255,${0.4 + r() * 0.5})`, o); }
    E.bloom(0.12, 10);
    E.grain(0.04, 74);
  }
});
