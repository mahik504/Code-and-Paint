'use strict';
// g076 — "Glowing spiral control panel": a tilted white enamel board crowded with zebra spirals, a yellow
// cog full of pale-blue pills, a mauve creature ringed in orange glow, a red glitter tongue and white pods.
REC.register('g076', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    keep();
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const himg = (path, cv) => { R.h.save(); R.h.clip(path); R.h.setTransform(1, 0, 0, 1, 0, 0); R.h.drawImage(cv, 0, 0); R.h.restore(); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st) => { const g = a.createRadialGradient(x, y, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const F = (path, c) => { a.fillStyle = c; a.fill(path); };
    const K = (path, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.stroke(path); };
    const HENC = m => `vec3 henc(float hv){ float v = clamp(hv, 0., 1.) * 255., i = floor(v); return vec3(i / 255., ${m}. * 32. / 255., fract(v)); }`;

    // ── stripe / spiral fields (white = raised enamel line) ──
    // returns white-line mask w (1 = white) for the zebra block with the big spiral
    const ZB = `
      float spir(vec2 p, vec2 c, float per, float wob, float k){
        vec2 d = p - c; float r = length(d), an = atan(d.y, d.x);
        float s = (r + wob * sin(an * 3. + r * 0.045) + 3. * (vnoise(p * 0.03) - .5)) / per - k * an / 6.2832;
        return fract(s);
      }
      float zb(vec2 p){
        vec2 c = vec2(596., 266.); vec2 d = (p - c) * vec2(1.0, 1.04); float r = length(d);
        if (r < 82.) { float f = spir(p, c, 12.5, 1.5, 1.); return smoothstep(0.5, 0.56, f) * smoothstep(0.98, 0.92, f) + smoothstep(0.06, 0.0, r / 82.); }
        if (r < 91.) return 0.;
        if (r < 97.) return 1.;
        float y = p.y + 5. * sin(p.x * 0.022 + 1.) + 9. * (fbm(p * 0.008) - .5) + 4. * sin(p.x * 0.07 + p.y * 0.02);
        float f = fract(y / 22.5);
        return smoothstep(0.52, 0.58, f) * smoothstep(1.0, 0.94, f);
      }`;
    const zbA = pat(E.fx(ZB + `vec3 fx(vec2 uv, vec2 p){ float w = zb(p); return mix(vec3(.035,.03,.04), vec3(.95,.95,.97), w); }`));
    const zbH = E.fx(ZB + HENC(5) + `vec3 fx(vec2 uv, vec2 p){ float w = zb(p); return henc(0.1 + 0.035 * w); }`);
    // left spirals
    const SP = `
      float spir(vec2 p, vec2 c, float per, float wob, float k){
        vec2 d = p - c; float r = length(d), an = atan(d.y, d.x);
        float s = (r + wob * sin(an * 3. + r * 0.05) + 4. * (vnoise(p * 0.035) - .5)) / per - k * an / 6.2832;
        return fract(s);
      }
      float sp(vec2 p){
        vec2 c1 = vec2(165., 668.), c2 = vec2(148., 868.);
        float r1 = length(p - c1), r2 = length((p - c2) * vec2(1.0, 0.98));
        if (r1 < 86.) { if (r1 > 78.) return 0.; float f = spir(p, c1, 12., 1.5, 1.); return smoothstep(0.58, 0.66, f) * smoothstep(0.98, 0.9, f); }
        float f = spir(p, c2, 14., 1.5, 1.); return smoothstep(0.52, 0.6, f) * smoothstep(1.0, 0.92, f);
      }`;
    const spA = pat(E.fx(SP + `vec3 fx(vec2 uv, vec2 p){ float w = sp(p); return mix(vec3(.03,.03,.035), vec3(.93,.93,.95), w); }`));
    const spH = E.fx(SP + HENC(5) + `vec3 fx(vec2 uv, vec2 p){ float w = sp(p); return henc(0.08 + 0.035 * w); }`);
    // pleated shell fan (radial black/white)
    const fanA = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 d = p - vec2(345., 470.); float an = atan(d.x, -d.y);
      float f = fract(an * 7.5 + 0.02 * length(d)); float w = smoothstep(0.35, 0.45, f) * smoothstep(0.95, 0.85, f);
      return mix(vec3(.08,.06,.08), vec3(.93,.9,.93), w); }`));
    // red glitter
    const glitter = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ vec3 c = vec3(.86,.07,.1) * (0.85 + 0.3 * vnoise(p * 0.08));
      float h = hash(floor(p / 3.)); c = mix(c, vec3(1.,.85,.8), step(0.88, h) * 0.8);
      float g = hash(floor(p / 9.) + 3.); vec2 f = fract(p / 9.) - .5; c = mix(c, vec3(1.,.9,.2), step(0.8, g) * smoothstep(0.32, 0.18, length(f)));
      return c; }`));
    // wavy wood band
    const wood = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float s = p.y + 0.28 * p.x + 4. * sin(p.x * 0.09) + 3. * vnoise(p * 0.05);
      float f = fract(s / 5.5); vec3 c = mix(vec3(.55,.36,.28), vec3(.40,.24,.18), smoothstep(0.4, 0.6, f) * smoothstep(1., 0.8, f));
      return c * (0.9 + 0.2 * vnoise(p * 0.1)); }`));
    // grey embossed slab
    const slabA = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = fbm(p * 0.03); return vec3(.54,.58,.65) * (0.92 + 0.14 * n) + vec3(.06) * smoothstep(560., 420., p.y); }`));

    // ── dark backdrop ──
    R.flat(rrect(-10, -10, 746, 1044, 0), lin(0, 0, 726, 300, [[0, '#3a3236'], [0.5, '#2a282e'], [1, '#202026']]), 0, 0);
    F(P([[0, 80], [40, 70], [60, 140], [0, 160]], true, false), '#b8aa9c');
    // brown blob, rope, pebbles, orange letters, blue block
    R.dome(P([[0, 0], [100, 0], [115, 30], [100, 75], [60, 98], [20, 96], [0, 88]]), '#6e3a2c', 0.02, 0.1, 25, 3);
    // out-of-focus twisted rope (soft albedo only)
    soft(x => { x.strokeStyle = '#a6aab4'; x.lineWidth = 66; x.stroke(P([[50, 150], [90, 105], [135, 62], [180, 28], [220, -10]], false));
      x.strokeStyle = '#c8ccd4'; x.lineWidth = 16;
      for (let i = 0; i < 9; i++) { const t = i / 8, cx = 60 + t * 160, cy = 138 - t * 150; x.stroke(P([[cx - 24, cy - 22], [cx + 4, cy + 4], [cx + 24, cy + 26]], false)); } }, 4, 1);
    R.dome(ellipseP(232, 8, 34, 16, 0), '#dfe3ef', 0.06, 0.12, 14, 1);
    R.dome(ellipseP(410, 10, 52, 26, 0), '#d8dce8', 0.06, 0.12, 20, 1);
    R.dome(ellipseP(462, 30, 26, 18, 0), '#55555c', 0.03, 0.06, 10, 3);
    R.pipe(P([[512, 2], [512, 44]], false), 14, '#f0601a', 0.04, 0.08, 2);
    R.pipe(P([[512, 8], [545, 8]], false), 12, '#f0601a', 0.04, 0.08, 2);
    R.pipe(P([[512, 26], [538, 26]], false), 11, '#f0601a', 0.04, 0.08, 2);
    R.pipe(ellipseP(582, 30, 18, 14, 0), 11, '#f0601a', 0.04, 0.08, 2);
    R.pipe(P([[560, 0], [600, 6], [628, 0]], false), 11, '#e8501c', 0.04, 0.06, 2);
    R.dome(P([[640, 0], [726, 0], [726, 130], [690, 128], [660, 90], [645, 40]]), '#2a4ad8', 0.04, 0.12, 18, 2);
    F(ellipseP(712, 22, 9, 12, 0), '#101030'); F(ellipseP(712, 105, 9, 14, 0), '#101030'); F(ellipseP(672, 60, 8, 10, 0), '#101030');
    // right edge oddments
    R.flat(rrect(696, 128, 40, 240, 0), '#1c1618', 0.02, 0);
    R.pipe(P([[718, 140], [716, 230]], false), 10, '#d85a1c', 0.04, 0.08, 2);
    R.dome(rrect(714, 236, 16, 34, 6), '#2a48d8', 0.06, 0.06, 6, 2);
    R.pipe(P([[716, 290], [714, 345]], false), 9, '#c8501c', 0.04, 0.06, 2);
    keep();

    // ── the white enamel board ──
    const BOARD = P([[-20, 150], [100, 124], [250, 96], [400, 68], [560, 42], [645, 34], [676, 42], [690, 70], [698, 160], [712, 340], [726, 360], [740, 360],
      [740, 940], [600, 920], [540, 930], [420, 952], [300, 962], [200, 975], [100, 990], [-20, 1000]], true, false);
    R.flat(BOARD, lin(0, 60, 200, 900, [[0, '#cfe0f2'], [0.25, '#dce6f2'], [0.5, '#eaecf3'], [1, '#e8e6ee']]), 0.05, 0);
    // board lip highlight
    K(P([[-20, 150], [100, 124], [250, 96], [400, 68], [560, 42], [645, 34], [676, 42], [690, 70]], false), '#f8f9fc', 3);
    soft(x => { x.fillStyle = 'rgba(60,60,80,0.55)'; x.fill(ellipseP(225, 118, 46, 12, -0.2)); }, 8, 1);
    R.dome(P([[168, 80], [185, 56], [215, 48], [250, 54], [264, 80], [255, 108], [215, 117], [178, 108]]), '#dfe6f4', 0.08, 0.16, 28, 1);
    keep();

    // ── black swoosh + pale ghost + black field behind the pods ──
    const BLK = P([[70, 250], [55, 300], [58, 350], [75, 395], [110, 425], [160, 440],
      [190, 460], [178, 545], [130, 562], [70, 575], [45, 640], [0, 650], [0, 200], [40, 190], [70, 210]]);
    R.flat(BLK, '#26252c', 0.05, 0);
    soft(x => { x.strokeStyle = '#2c2c34'; x.lineWidth = 44; x.stroke(P([[262, 124], [230, 142], [180, 165], [125, 195], [88, 232], [70, 290], [72, 350], [92, 400], [130, 432], [180, 448]], false)); }, 3, 1);
    const GHOST = P([[240, 195], [260, 220], [262, 300], [250, 380], [215, 425], [170, 440], [120, 428], [82, 400], [64, 350], [66, 290], [85, 248], [130, 215], [190, 200]]);
    F(GHOST, rad(170, 320, 170, [[0, '#e4e4f0'], [0.7, '#dcdcea'], [1, '#d0d0e0']]));
    soft(x => { x.fillStyle = 'rgba(232,233,242,1)'; x.fill(ellipseP(268, 230, 26, 60, 0)); }, 12, 0.9);

    // ── black vertical bar with white rod ──
    R.flat(P([[350, 74], [374, 70], [392, 236], [366, 240]], true, false), '#0c0a0e', 0.07, 0);
    R.pipe(P([[363, 78], [379, 226]], false), 7, '#e8e8ee', 0.08, 0.04, 1);
    for (let y = 84; y < 222; y += 5) F(circleP(363 + (y - 78) * 0.108, y, 1.1), '#707078');
    R.dome(rrect(372, 222, 16, 18, 3), '#d8ccb8', 0.08, 0.04, 4, 3);
    F(circleP(452, 178, 5), '#101014'); F(circleP(404, 168, 2.5), '#101014');

    // ── zebra block with the big spiral ──
    const ZBP = P([[400, 260], [440, 245], [470, 228], [520, 205], [580, 186], [650, 176], [700, 175], [712, 352], [650, 352], [600, 362], [604, 410], [480, 412], [410, 408], [400, 330]], true, false);
    R.flat(ZBP, zbA, 0.1, 5); himg(ZBP, zbH);
    // brown wood band across its top
    const WOOD = P([[392, 220], [460, 198], [520, 178], [580, 162], [640, 152], [700, 148], [704, 186], [640, 190], [570, 202], [500, 222], [440, 242], [398, 254]]);
    R.dome(WOOD, wood, 0.1, 0.05, 6, 3);
    // little blue-grey tiles
    R.dome(P([[440, 262], [475, 252], [482, 272], [470, 292], [446, 290]]), '#a8b4c4', 0.12, 0.04, 6, 3);
    R.dome(P([[452, 250], [490, 236], [496, 260], [482, 270], [460, 268]]), '#b8bcc8', 0.12, 0.03, 5, 3);
    // purple and grey slab
    R.flat(P([[600, 362], [650, 352], [726, 356], [726, 402], [548, 404], [536, 470], [520, 540], [470, 540], [462, 412], [604, 410]], true, false), '#6a56c8', 0.08, 0);
    const SLAB = P([[548, 400], [726, 400], [726, 560], [600, 552], [560, 548], [532, 540], [536, 470]], true, false);
    R.flat(SLAB, slabA, 0.1, 3);
    { const q = rng(76);
      for (let i = 0; i < 16; i++) {
        let x = 560 + q() * 160, y = 412 + q() * 128; const pts = [[x, y]];
        for (let k = 0; k < 4; k++) { x += (q() - 0.5) * 40; y += (q() - 0.5) * 22; pts.push([x, y]); }
        R.groove(P(pts, false), 4, '#8c8a92', 0.1, 0.03, 3, 0.6);
      }
    }
    R.bead(672, 524, 9, '#2a40d8', 0.12, 0.05, 2); R.bead(708, 510, 11, '#f06818', 0.12, 0.05, 2); R.bead(698, 548, 7, '#f06818', 0.12, 0.04, 2);
    keep();

    // ── cream squiggles on the right ──
    const CREAM = '#f0e2b6';
    const sq = (pts, wd) => R.pipe(P(pts, false), wd * 1.3, CREAM, 0.06, 0.08, 3);
    sq([[598, 600], [612, 575], [640, 572], [656, 556], [684, 562], [700, 590], [688, 615], [705, 640], [730, 632]], 20);
    sq([[600, 600], [596, 630], [612, 652], [640, 648], [660, 668], [652, 692], [682, 706], [710, 690], [730, 702]], 20);
    sq([[640, 572], [628, 600], [650, 615], [672, 600]], 16);
    sq([[612, 712], [640, 712], [652, 736], [640, 760], [656, 788], [680, 800]], 18);
    sq([[690, 720], [700, 750], [726, 770]], 16);
    sq([[516, 470], [534, 476], [546, 496], [536, 520]], 18);
    keep();

    // ── yellow cog with the black cell of pale-blue pills ──
    const cog = (() => { const pts = []; const n = 220; for (let i = 0; i < n; i++) { const an = i / n * Math.PI * 2; const k = 1 + 0.055 * Math.pow(Math.abs(Math.sin(an * 11)), 0.7);
      pts.push([305 + Math.cos(an) * 146 * k, 333 + Math.sin(an) * 104 * k]); } return P(pts, true, false); })();
    R.dome(cog, '#f6e06c', 0.1, 0.06, 12, 2);
    const CELL = P([[190, 300], [205, 268], [245, 250], [310, 244], [380, 246], [418, 262], [432, 300], [428, 350], [415, 392], [380, 418], [310, 425], [240, 422], [200, 400], [186, 350]]);
    R.flat(CELL, '#0a090c', 0.12, 4);
    for (const [x, y, rx, ry] of [[233, 310, 33, 20], [310, 298, 35, 21], [386, 289, 32, 19], [232, 366, 37, 22], [310, 349, 36, 22], [390, 340, 30, 19]])
      R.dome(ellipseP(x, y, rx, ry, -0.08), lin(x - rx, y - ry, x + rx, y + ry, [[0, '#bfe4f4'], [1, '#8ec6e0']]), 0.13, 0.07, 10, 2);
    R.dome(circleP(237, 407, 15), '#bce040', 0.13, 0.06, 8, 2);
    R.dome(circleP(258, 433, 14), '#a8d4a0', 0.13, 0.06, 8, 2);
    R.dome(ellipseP(406, 378, 18, 21, 0.3), '#a6ccb0', 0.13, 0.06, 8, 2);
    R.dome(circleP(414, 356, 9), '#b4e050', 0.13, 0.05, 6, 2);
    F(circleP(172, 410, 6), '#0a0a0c');
    keep();

    // ── orange glow (painted on the board) ──
    const CRE = P([[168, 445], [185, 430], [215, 425], [250, 432], [280, 445], [300, 436], [320, 418], [350, 404], [380, 396], [405, 402], [420, 420], [440, 418],
      [456, 432], [452, 448], [472, 466], [462, 486], [446, 496], [440, 520], [420, 534], [395, 546], [372, 560], [360, 586], [346, 594], [330, 576], [300, 566],
      [260, 554], [220, 540], [190, 522], [172, 496], [164, 470]]);
    const LOOP = P([[262, 668], [272, 632], [305, 605], [350, 585], [400, 566], [440, 553], [480, 546], [525, 545], [560, 558], [578, 595], [572, 635], [548, 662],
      [505, 676], [455, 680], [400, 686], [340, 692], [290, 694], [268, 684]]);
    const BAR = P([[262, 730], [276, 712], [320, 708], [380, 702], [440, 696], [500, 694], [540, 684], [566, 672], [582, 692], [574, 714], [540, 722], [480, 727],
      [420, 742], [370, 753], [310, 758], [270, 750]]);
    const BLOBK = P([[396, 792], [410, 766], [440, 758], [480, 762], [500, 782], [494, 830], [490, 872], [498, 920], [482, 946], [440, 952], [410, 946], [404, 900], [410, 850], [398, 812]]);
    soft(x => { x.fillStyle = 'rgba(160,110,230,0.75)'; x.fill(ellipseP(500, 470, 50, 70, 0.3)); x.fill(ellipseP(360, 650, 90, 40, 0)); x.fill(ellipseP(320, 580, 30, 20, 0)); }, 20, 1);
    soft(x => { x.fillStyle = '#ffb070'; x.fill(P([[360, 760], [540, 760], [540, 950], [360, 950]])); x.strokeStyle = 'rgba(255,190,150,0.8)'; x.lineWidth = 110; for (const p of [CRE, LOOP, BAR]) x.stroke(p); }, 24, 0.9);
    soft(x => { x.strokeStyle = '#ff8a10'; x.fillStyle = '#ff8a10'; x.lineWidth = 46; for (const p of [CRE, LOOP, BAR]) { x.stroke(p); x.fill(p); } x.lineWidth = 44; x.stroke(BLOBK); x.fill(BLOBK);
      x.fill(P([[300, 690], [560, 680], [520, 730], [300, 740]])); }, 7, 1);
    soft(x => { x.strokeStyle = '#ffa418'; x.lineWidth = 22; for (const p of [CRE, LOOP, BAR]) x.stroke(p); x.lineWidth = 22; x.stroke(BLOBK); }, 3, 1);
    soft(x => { x.strokeStyle = '#ffe448'; x.lineWidth = 11; for (const p of [CRE, LOOP, BAR]) x.stroke(p); x.stroke(BLOBK); }, 1.5, 1);
    soft(x => { x.fillStyle = 'rgba(255,236,150,0.9)'; x.fill(ellipseP(440, 480, 22, 40, 0.4)); x.fill(ellipseP(390, 760, 20, 30, 0)); }, 10, 0.8);

    // ── mauve creature with the zebra shell ──
    R.dome(CRE, lin(170, 420, 470, 590, [[0, '#948496'], [0.5, '#8e7f90'], [1, '#86788a']]), 0.12, 0.08, 14, 3);
    for (let i = 0; i < 12; i++) {
      const an = (165 - i * 8.5) * Math.PI / 180, cx = 285, cy = 452;
      R.groove(P([[cx + Math.cos(an) * 52, cy + Math.sin(an) * 52], [cx + Math.cos(an) * 96, cy + Math.sin(an) * 96]], false), 8, '#4a4054', 0.2, 0.06, 3);
    }
    R.groove(P([[178, 452], [210, 444], [250, 452]], false), 6, '#5c5268', 0.2, 0.04, 3);
    R.pipe(circleP(192, 455, 9), 4, '#8e84a0', 0.2, 0.02, 3);
    R.pipe(P([[205, 475], [222, 470], [228, 480]], false), 4, '#8e84a0', 0.2, 0.02, 3);
    const FAN = P([[288, 470], [292, 430], [310, 400], [340, 382], [370, 384], [392, 404], [398, 440], [392, 470]]);
    R.dome(FAN, fanA, 0.16, 0.1, 22, 4);
    for (const s of [[430, 470, 20, 9, 5, 0.3], [418, 438, 16, 8, 5, 0.9], [452, 450, 14, 7, 5, 0.1], [400, 520, 14, 6, 4, 0.5]])
      R.dome(P(star(s[0], s[1], s[2], s[3], s[4], s[5]), true, false), '#a298ae', 0.18, 0.05, 6, 3);
    { const q = rng(7); for (let i = 0; i < 36; i++) F(circleP(345 + q() * 80, 440 + q() * 70, 1 + q() * 2.2), '#2a2232'); }
    R.bead(405, 500, 11, '#38c8e8', 0.2, 0.05, 2); R.bead(229, 492, 5, '#b4e040', 0.2, 0.03, 2); R.bead(334, 532, 6, '#b4e040', 0.2, 0.03, 2);
    R.bead(352, 600, 8, '#9890a0', 0.18, 0.05, 3);
    R.bead(490, 527, 6, '#2a3ad0', 0.14, 0.04, 2);
    keep();

    // ── red tongue loop with the blue disc ──
    R.dome(LOOP, lin(270, 560, 570, 690, [[0, '#a69cae'], [1, '#9890a4']]), 0.12, 0.08, 14, 3);
    const TONGUE = P([[280, 662], [290, 634], [320, 614], [370, 598], [415, 584], [440, 578], [450, 610], [446, 648], [420, 660], [370, 672], [320, 684], [290, 684]]);
    R.flat(TONGUE, glitter, 0.16, 0);
    K(TONGUE, '#5a1a30', 3);
    R.dome(circleP(493, 607, 56), '#1a1c6a', 0.16, 0.06, 8, 4);
    R.dome(circleP(493, 607, 50), '#2a3ac8', 0.18, 0.05, 10, 4);
    R.pipe(circleP(493, 607, 40), 3, '#d8a070', 0.22, 0.02, 4);
    R.dome(circleP(493, 607, 36), '#1c2ab0', 0.2, 0.03, 6, 4);
    R.bead(490, 600, 21, '#f4b080', 0.22, 0.08, 2);
    // lower bar
    R.dome(BAR, lin(262, 680, 580, 760, [[0, '#a69cb0'], [1, '#9a90a6']]), 0.12, 0.07, 12, 3);
    R.bead(286, 728, 9, '#f07018', 0.18, 0.04, 2);
    R.dome(rrect(325, 727, 44, 22, 11), '#f07818', 0.18, 0.04, 8, 2);
    R.bead(455, 710, 15, '#f07018', 0.18, 0.05, 2);
    R.bead(557, 700, 12, '#b0a0c0', 0.18, 0.05, 3);
    R.flat(BLOBK, '#0c0a10', 0.06, 4);
    keep();

    // ── white buttons ──
    for (const [x, y, r] of [[320, 846, 62], [568, 802, 66]]) {
      soft(z => { z.fillStyle = 'rgba(110,100,140,0.5)'; z.fill(circleP(x + 4, y + 10, r + 2)); }, 6, 1);
      R.dome(circleP(x + 2, y + 6, r), '#a8acc4', 0.06, 0.06, 8, 1);
      R.dome(circleP(x, y, r - 3), rad(x - 15, y - 20, r * 1.3, [[0, '#e4eaf6'], [0.7, '#d0d8ea'], [1, '#c0c6dc']]), 0.12, 0.05, 14, 1);
    }

    // ── left spirals ──
    const SPP = P([[66, 668], [80, 610], [120, 585], [170, 582], [220, 600], [250, 640], [252, 700], [230, 740], [180, 756], [120, 748], [80, 715]]);
    const SPP2 = P(blob(148, 870, 102, 104, 9, 22, 0.05));
    R.flat(SPP2, spA, 0.07, 5); himg(SPP2, spH);
    soft(x => { x.fillStyle = 'rgba(210,210,225,0.5)'; x.fill(circleP(166, 668, 92)); }, 4, 1);
    R.flat(circleP(165, 668, 86), spA, 0.08, 5); himg(circleP(165, 668, 86), spH);
    void SPP;
    F(circleP(200, 778, 5), '#0a0a0c');
    keep();

    // ── white pods over the black field ──
    const pod = (bx, by, tx, ty, wd) => {
      const dx = tx - bx, dy = ty - by, L = Math.hypot(dx, dy), ux = dx / L, uy = dy / L, nx = -uy, ny = ux, pts = [];
      for (let i = 0; i <= 16; i++) { const t = i / 16, w = wd * 0.5 * Math.pow(Math.sin(Math.PI * Math.min(1, t * 0.55 + 0.45 * t * t + 0.02)), 0.8) * (t < 0.15 ? 0.6 + t * 2.6 : 1);
        pts.push([bx + dx * t + nx * w, by + dy * t + ny * w]); }
      for (let i = 16; i >= 0; i--) { const t = i / 16, w = wd * 0.5 * Math.pow(Math.sin(Math.PI * Math.min(1, t * 0.55 + 0.45 * t * t + 0.02)), 0.8) * (t < 0.15 ? 0.6 + t * 2.6 : 1);
        pts.push([bx + dx * t - nx * w, by + dy * t - ny * w]); }
      const path = P(pts);
      soft(x => { x.fillStyle = 'rgba(0,0,0,0.8)'; x.translate(6, 8); x.fill(path); }, 6, 1);
      R.dome(path, lin(bx, by, tx, ty, [[0, '#b4c4e2'], [0.6, '#d4def0'], [1, '#c8d4ec']]), 0.1, 0.18, wd * 0.45, 1);
      R.flat(ellipseP(tx - ux * 5, ty - uy * 5, 5, 4, Math.atan2(uy, ux)), '#2c3446', 0.18, 1);
    };
    pod(-40, 255, 84, 146, 66);
    pod(-40, 350, 66, 220, 76);
    pod(-20, 400, 36, 318, 56);
    pod(-30, 500, 40, 370, 64);
    pod(0, 560, 56, 418, 56);
    pod(20, 640, 78, 436, 80);
    pod(112, 455, 126, 580, 62);
    keep();

    // ── bottom-left oddments ──
    R.flat(P([[0, 640], [60, 640], [52, 760], [40, 840], [0, 850]], true, false), '#1a1820', 0.04, 0);
    for (const [x, y, r] of [[8, 664, 8], [10, 686, 7], [20, 676, 6], [6, 706, 7], [18, 700, 5], [8, 726, 6], [22, 722, 4]]) R.bead(x, y, r, '#d8d8e0', 0.06, 0.06, 1);
    R.dome(P([[0, 690], [34, 684], [30, 760], [24, 840], [0, 836]]), '#7a3e26', 0.06, 0.06, 6, 3);
    R.dome(P([[36, 762], [100, 744], [104, 758], [42, 776]]), '#9a5634', 0.08, 0.04, 5, 3);
    clipA(P([[36, 770], [60, 765], [56, 840], [36, 845]]), () => { for (let y = 760; y < 850; y += 12) F(P([[30, y], [64, y - 3], [64, y + 4], [30, y + 7]], true, false), '#f0f0f2'); });
    R.dome(P([[0, 830], [34, 838], [54, 872], [62, 900], [80, 940], [82, 1000], [70, 1030], [0, 1030]]), '#e8601a', 0.06, 0.08, 10, 2);
    R.dome(P([[0, 846], [26, 852], [42, 880], [50, 906], [66, 944], [68, 1000], [58, 1030], [0, 1030]]), '#2240d0', 0.08, 0.1, 18, 2);
    for (const [x, y, r] of [[20, 970, 6], [38, 960, 5], [30, 990, 7]]) R.bead(x, y, r, '#e8601a', 0.16, 0.03, 2);
    keep();

    // ── bottom: brown rim pipe, grey slab, blue blob with orange rim, yellow wedge ──
    R.flat(P([[90, 1030], [150, 962], [230, 942], [300, 946], [420, 952], [560, 930], [600, 925], [600, 1030]], true, false), lin(0, 940, 0, 1024, [[0, '#4a4a52'], [1, '#6a6a72']]), 0.06, 3);
    R.pipe(P([[96, 1030], [150, 965], [225, 944], [300, 948], [362, 962]], false), 14, '#8a4a2a', 0.08, 0.08, 3);
    K(P([[362, 966], [460, 950], [540, 936]], false), '#3a3a40', 3);
    R.pipe(P([[440, 1030], [470, 1006], [520, 1000]], false), 10, '#c8c8d0', 0.08, 0.04, 3);
    R.dome(P([[676, 812], [690, 790], [726, 780], [726, 834], [690, 840]]), '#f0c020', 0.08, 0.06, 10, 2);
    const BB = P([[540, 1030], [534, 960], [544, 890], [570, 846], [610, 826], [680, 812], [740, 806], [740, 1030]]);
    R.dome(BB, '#f0601a', 0.08, 0.1, 10, 2);
    const BB2 = P([[558, 1030], [553, 960], [562, 906], [586, 866], [622, 846], [680, 834], [740, 830], [740, 1030]]);
    R.dome(BB2, '#2240d0', 0.1, 0.1, 22, 2);
    for (const [x, y, r] of [[620, 905, 5], [650, 925, 5], [690, 940, 6], [720, 880, 5], [640, 980, 6], [600, 1010, 5]]) R.groove(circleP(x, y, r), 5, '#0c1040', 0.2, 0.06, 2);
    for (const [x, y, r] of [[655, 955, 4], [705, 960, 5], [612, 1000, 4]]) R.bead(x, y, r, '#f07020', 0.2, 0.03, 2);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.85, spec: 1.1, shin: 60, wrap: 0.5, ao: 0.4, coat: 0.25, emis: 0.18 }),                       // 1 white glossy enamel
        E.mat({ dif: 0.95, spec: 1.0, shin: 70, wrap: 0.5, ao: 0.4, coat: 0.15, emis: 0.12 }),                       // 2 coloured gloss
        E.mat({ dif: 0.95, spec: 0.5, shin: 30, wrap: 0.6, ao: 0.5, emis: 0.14 }),                                   // 3 satin clay
        E.mat({ dif: 0.9, spec: 1.2, shin: 80, wrap: 0.4, ao: 0.4, coat: 0.2, emis: 0.08 }),                         // 4 glossy black / shell
        E.mat({ dif: 0.95, spec: 0.7, shin: 50, wrap: 0.6, ao: 0.3, emis: 0.14 })                                    // 5 enamel stripes
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.86, 0.85, 0.86], amb: [0.34, 0.34, 0.37],
      envTop: [1.1, 1.08, 1.1], envHor: [0.6, 0.58, 0.64], envBot: [0.2, 0.18, 0.22], envK: [0.3, 1.2, 0.3, 0],
      rimC: [0.1, 0.1, 0.12], rimD: [0, 1, 0], r1: 1.3, r2: 6, k: [0, 0.6, 0.4, 70], shadow: [-4, 6, 0.45, 7]
    });
    E.bloom(0.08, 8);
    E.grain(0.025, 76);
  }
});
