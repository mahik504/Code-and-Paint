'use strict';
// g096 — "Hedgehog zebra helmet": a spiny black hedgehog-beast with white cone spikes and a zebra-striped
// helmet, a navy pipe arm, a grey dotted truck and a pale spotted dog over navy, lime and pink-lilac stripes.
REC.register('g096', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, r1, stops) => { const g = a.createRadialGradient(x, y, r0, x, y, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const flat = (path, c) => R.flat(path, c, 0, 0);
    const poly = pts => P(pts, true, false);
    const sm = pts => P(pts, true, true);
    const BLK = '#0a0812';

    // ── background masses ──
    flat(rrect(-10, -10, 746, 1044, 0), '#c0e5f8');
    // cream grid panel (top right)
    const cream = poly([[440, -10], [736, -10], [736, 200], [440, 200]]);
    flat(cream, '#fbfaef');
    clipA(cream, () => {
      a.strokeStyle = 'rgba(150,190,200,0.45)'; a.lineWidth = 1;
      for (let x = 470; x < 736; x += 62) { a.beginPath(); a.moveTo(x, 0); a.lineTo(x + 6, 200); a.stroke(); }
      for (let y = 40; y < 200; y += 58) { a.beginPath(); a.moveTo(440, y); a.lineTo(736, y - 6); a.stroke(); }
      a.fillStyle = lin(0, 150, 0, 200, [[0, 'rgba(192,229,248,0)'], [1, 'rgba(192,229,248,0.9)']]); a.fillRect(440, 150, 300, 50);
    });
    // horizontal stripe bands (y at x=640, slight tilt)
    const bands = [[262, '#f81480'], [289, '#fb60c6'], [306, '#b8a6f6'], [349, '#c0e5f8'], [389, '#a890e8'], [417, '#fb88d6'], [438, '#f5127e'], [474, '#fb80d0'], [481, '#c0e5f8'],
      [520, '#a992e8'], [544, '#f995dc'], [570, '#a891e8'], [589, '#c1e6f9'], [624, '#a894ea'], [658, '#fa93d8'], [673, '#f5137e'], [706, '#f4eef2'], [730, '#f4eef2']];
    for (let i = 0; i < bands.length - 1; i++) {
      const [y0, c] = bands[i], y1 = bands[i + 1][0], k = 0.045;
      flat(poly([[320, y0 + 320 * k], [736, y0 - 96 * k], [736, y1 - 96 * k], [320, y1 + 320 * k]]), c);
    }
    // navy field (left) and lime planes
    flat(poly([[-10, -10], [292, -10], [330, 200], [300, 300], [120, 455], [-10, 465]]), '#2b2d91');
    flat(poly([[292, -10], [452, -10], [470, 140], [332, 205]]), '#9ec715');
    flat(poly([[-10, 462], [125, 452], [140, 600], [60, 640], [-10, 660]]), '#9ec713');
    flat(poly([[597, 610], [612, 720], [530, 820], [492, 900], [470, 1000], [440, 1034], [330, 1034], [345, 880], [380, 800], [430, 760], [500, 722]]), '#97c112');

    // ── pale tubes ──
    R.pipe(P([[-10, 92], [26, 120], [44, 165], [36, 205], [-10, 232]], false, true), 22, '#eef0f6', 0.1, 0.1, 2);
    R.pipe(P([[-10, 292], [26, 330], [40, 400], [32, 490], [18, 590]], false, true), 20, '#eef0f6', 0.1, 0.1, 2);
    R.pipe(P([[462, 190], [458, 300], [462, 420], [468, 500]], false, true), 16, '#eceef6', 0.1, 0.08, 2);
    // grey hook
    R.pipe(P([[516, 252], [514, 300], [540, 330], [580, 330], [612, 292], [636, 258], [660, 262], [664, 320]], false, true), 20, '#857888', 0.14, 0.1, 2);
    R.bead(518, 258, 4, '#f4f4f4', 0.26, 0.03, 2);

    // ── navy pipe arm ──
    const arm = lock([[280, 330], [280, 262], [300, 210], [360, 172], [450, 158], [560, 140], [632, 112], [664, 64], [676, 10]], 114, 60, 0.7);
    R.dome(sm(arm), lin(0, 120, 0, 300, [[0, '#4244ac'], [0.5, '#34349a'], [1, '#282a80']]), 0.12, 0.2, 36, 3);
    // cuffs
    for (const [x, y] of [[392, 172], [414, 168]]) R.dome(ellipseP(x, y, 12, 46, 0.12), '#3c44b0', 0.3, 0.06, 7, 3);
    R.bead(408, 190, 3.5, '#e8e8f0', 0.38, 0.03, 2);
    R.dome(poly([[636, 30], [700, 44], [694, 66], [628, 52]]), '#c89a2c', 0.3, 0.06, 6, 4);
    R.flat(rrect(654, 38, 14, 12, 2), '#8ad4f0', 0.36, 2);
    R.dome(P([[626, -10], [712, -10], [714, 26], [690, 34], [644, 28]], true, true), '#1e2030', 0.3, 0.06, 10, 3);
    R.dome(circleP(712, 112, 18), '#d8d8e0', 0.2, 0.1, 10, 2);
    R.dome(circleP(712, 112, 9), '#1a1a22', 0.3, 0.02, 4, 2);

    // ── grey dotted truck ──
    const dots = (x0, y0, x1, y1, step, rr, c) => { a.fillStyle = c; for (let y = y0; y < y1; y += step) for (let x = x0 + ((y / step) % 2) * step / 2; x < x1; x += step) { a.beginPath(); a.arc(x, y, rr, 0, 7); a.fill(); } };
    const truck = poly([[-10, 318], [36, 262], [48, 140], [212, 44], [262, 62], [292, 100], [300, 142], [276, 172], [240, 204], [150, 250], [90, 282], [30, 330], [-10, 356]]);
    R.dome(truck, lin(0, 300, 260, 60, [[0, '#c4c4d2'], [0.5, '#dcdce6'], [1, '#d0d0dc']]), 0.12, 0.08, 14, 1);
    // dotted lower chassis and cab front
    clipA(truck, () => {
      clipA(poly([[-10, 300], [60, 262], [190, 196], [200, 150], [250, 120], [300, 150], [300, 210], [100, 300], [-10, 370]]), () => dots(-10, 110, 310, 370, 4, 1.3, '#22223a'));
      clipA(poly([[232, 80], [262, 62], [292, 100], [300, 142], [276, 150], [250, 110]]), () => dots(220, 50, 310, 160, 4, 1.1, '#22223a'));
    });
    // windows (navy seen through the frame) and frame lines
    for (const [x, y, w, h] of [[66, 150, 44, 30], [120, 120, 44, 30], [172, 92, 40, 28]]) {
      a.save(); a.translate(x, y); a.rotate(-0.52); R.flat(rrect(0, 0, w, h, 2), '#2c2f8a', 0.16, 0); a.restore();
    }
    a.strokeStyle = '#3a3a52'; a.lineWidth = 2.2;
    a.stroke(poly([[50, 134], [212, 40], [262, 60]]));
    a.stroke(P([[48, 196], [230, 96], [276, 120]], false, false));
    a.stroke(P([[40, 262], [240, 156], [290, 140]], false, false));
    for (let i = 0; i < 7; i++) { a.beginPath(); a.moveTo(52 + i * 28, 136 - i * 16); a.lineTo(52 + i * 28, 264 - i * 16 - 24); a.stroke(); }
    // fan + figurehead
    a.strokeStyle = '#ececf2'; a.lineWidth = 2.5;
    for (let i = 0; i < 10; i++) { a.beginPath(); a.moveTo(288, 116); a.lineTo(258 + i * 7, 168 + (i % 2) * 6); a.stroke(); }
    R.dome(P([[280, 92], [312, 80], [356, 72], [338, 86], [314, 112], [290, 124]], true, true), '#d8d8e2', 0.2, 0.06, 6, 1);
    R.bead(298, 108, 9, '#d0d0dc', 0.22, 0.05, 1);
    // gear wheels
    for (const [x, y, r] of [[225, 215, 29], [138, 265, 31]]) {
      R.dome(poly(star(x, y, r, r * 0.86, 16)), '#e8e8f0', 0.2, 0.08, 6, 1);
      R.dome(circleP(x, y, r * 0.62), '#a4a4b6', 0.24, 0.04, 4, 1);
      R.dome(circleP(x, y, r * 0.3), '#30304a', 0.26, 0.03, 3, 1);
    }
    R.bead(182, 228, 10, '#d0d0dc', 0.2, 0.05, 1);
    R.bead(218, 42, 8, '#e0e0ea', 0.24, 0.05, 1);

    // ── dark navy panel (right) ──
    // teardrop: tip -> round bulb centred at (bx,by) with radius r
    const spike = (tx, ty, bx, by, r, n = 40) => {
      const L = Math.hypot(tx - bx, ty - by), ax = (tx - bx) / L, ay = (ty - by) / L, sx = L / 1.45, sy = r / 0.77, pts = [];
      for (let i = 0; i < n; i++) {
        const t = i / n * 2 * Math.PI, x = Math.cos(t), y = Math.sin(t) * Math.abs(Math.sin(t / 2)) ** 1.1;
        const u = (x + 0.45) * sx, v = y * sy;
        pts.push([bx + ax * u - ay * v, by + ay * u + ax * v]);
      }
      return pts;
    };
    const drawSpike = (tx, ty, bx, by, r, sh = '#9a8ea6', m = 5) => {
      const nx = -(by - ty), ny = bx - tx, L = Math.hypot(nx, ny), ux = nx / L, uy = ny / L;
      const mx = (tx + bx) / 2, my = (ty + by) / 2;
      const g = lin(mx - ux * r, my - uy * r, mx + ux * r, my + uy * r, [[0, '#ffffff'], [0.45, '#f6f4f8'], [1, sh]]);
      R.dome(sm(spike(tx, ty, bx, by, r)), g, 0.14, 0.3, r * 0.9, m);
    };
    drawSpike(668, 304, 694, 372, 30);
    const panel = poly([[672, 322], [736, 318], [736, 546], [636, 540]]);
    R.flat(panel, '#141228', 0.2, 0);
    const st = rng(96);
    clipA(panel, () => { a.fillStyle = '#e8e8f8'; for (let i = 0; i < 40; i++) { a.beginPath(); a.arc(640 + st() * 96, 314 + st() * 236, st() * 1.2 + 0.3, 0, 7); a.fill(); } });
    R.bead(675, 340, 3, '#ffffff', 0.3, 0.02, 0); R.bead(688, 512, 3, '#ffffff', 0.3, 0.02, 0);
    // brown ring + grey tube (right edge)
    R.pipe(P([[726, 572], [700, 600], [684, 660], [690, 730], [712, 790], [736, 810]], false, true), 14, '#3a120a', 0.14, 0.08, 2);
    R.pipe(P([[668, 626], [692, 614], [736, 612]], false, true), 22, '#9c90a0', 0.16, 0.08, 2);

    // ── dark beast body ──
    const edge = [[736, 470], [680, 492], [640, 530], [590, 595], [540, 660], [500, 712], [455, 770], [400, 820], [372, 862], [350, 930], [332, 1034]];
    const bodyK = sm([[-10, 640], [60, 600], [120, 600], [180, 640], [260, 660], [330, 640], [390, 590], [430, 570], [480, 560], [525, 535], [565, 500], [605, 470], [645, 440], [690, 420], [736, 400], ...edge, [-10, 1034]]);
    R.flat(bodyK, '#0c0a16', 0.02, 0);
    clipA(bodyK, () => { a.fillStyle = '#d8d8f0'; for (let i = 0; i < 260; i++) { a.beginPath(); a.arc(st() * 700, 380 + st() * 660, st() * 1.1 + 0.2, 0, 7); a.fill(); } });
    // dark navy behind spikes near helmet
    R.flat(sm([[380, 470], [430, 440], [470, 470], [440, 540], [390, 560]]), '#22203e', 0.02, 0);
    // zebra flames along the body edge + pale rim line
    clipA(bodyK, () => {
      const fl = rng(12);
      for (let j = 1; j < 8; j++) {
        const [x0, y0] = edge[j], [x1, y1] = edge[j + 1], L = Math.hypot(x1 - x0, y1 - y0), ux = (x1 - x0) / L, uy = (y1 - y0) / L;
        for (let d = 8; d < L; d += 26) {
          const x = x0 + ux * d, y = y0 + uy * d, nx = uy, ny = -ux, len = 30 + fl() * 26, w = 7 + fl() * 5;
          const pts = [[x - ux * w, y - uy * w], [x - ux * w * 0.6 - nx * len * 0.5 + ux * 6, y - uy * w * 0.6 - ny * len * 0.5 + uy * 6], [x - nx * len, y - ny * len], [x + ux * w * 0.8 - nx * len * 0.45, y + uy * w * 0.8 - ny * len * 0.45], [x + ux * w, y + uy * w]];
          a.fillStyle = '#ebe6ee'; a.fill(P(pts, true, true));
        }
      }
    });
    a.strokeStyle = '#c4bcd6'; a.lineWidth = 6; a.stroke(P(edge.slice(1, 8), false, true));
    a.lineWidth = 5; a.stroke(P([[372, 862], [300, 884], [206, 916]], false, true));
    flat(poly([[-10, 778], [28, 788], [26, 880], [-10, 886]]), '#9ec713');

    // ── zebra helmet ──
    const brim = ellipseP(266, 384, 163, 102, -0.1);
    R.dome(brim, '#1a1826', 0.18, 0.14, 34, 6);
    a.strokeStyle = '#d8d6e4'; a.lineWidth = 2.5; a.stroke(P([[112, 360], [170, 310], [262, 284], [350, 296], [416, 340]], false, true));
    R.groove(P([[106, 452], [130, 380], [190, 334], [262, 318], [340, 326], [400, 352], [424, 386]], false, true), 5, '#8a86a0', 0.3, 0.03, 6, 0.9);
    const dome = sm([[108, 470], [130, 420], [175, 385], [240, 368], [320, 360], [380, 372], [418, 400], [420, 460], [405, 540], [370, 610], [320, 655], [262, 672], [200, 655], [150, 610], [118, 550]]);
    const zeb = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float u = clamp((p.x - 260.) / 150., -1.15, 1.1), v = clamp((p.y - 520.) / 150., -1.0, 1.1);
      float ph = 1.5041 - 0.8994 * v + 0.011 * v * v - 0.2728 * v * v * v + 1.5829 * u - 0.2067 * u * v + 0.6378 * u * v * v
               + 0.1759 * u * u + 0.4501 * u * u * v + 0.5062 * u * u * u;
      float f = fract(ph), dw = min(f, 1. - f), db = abs(f - 0.5);
      float w = smoothstep(0.185, 0.155, dw), b = smoothstep(0.19, 0.06, db);
      vec3 c = vec3(.016, .012, .012);
      c = mix(c, vec3(.72, .58, .60) * (0.75 + 0.25 * b), b);
      return mix(c, vec3(.99, .99, .96), w); }`));
    R.dome(dome, zeb, 0.12, 0.16, 70, 1);
    clipA(dome, () => { a.strokeStyle = '#060508'; a.lineWidth = 22; a.stroke(dome); });
    for (const [x0, y0, x1, y1] of [[214, 300, 226, 336], [102, 404, 118, 470]]) { a.strokeStyle = '#e8e8f0'; a.lineWidth = 3; a.beginPath(); a.moveTo(x0, y0); a.lineTo(x1, y1); a.stroke(); }

    // ── flower, gold nut, hashtag, pink dots ──
    R.dome(sm(star(165, 715, 72, 34, 14, 0.1)), '#8687f2', 0.1, 0.05, 10, 1);
    R.dome(poly([[28, 650], [54, 640], [72, 672], [70, 718], [46, 728], [30, 700]]), '#d8a83c', 0.12, 0.1, 10, 4);
    a.strokeStyle = '#f4f4f8'; a.lineWidth = 4;
    for (const [x0, y0, x1, y1] of [[80, 726, 90, 780], [100, 722, 110, 776], [68, 744, 128, 738], [72, 762, 132, 756]]) { a.beginPath(); a.moveTo(x0, y0); a.lineTo(x1, y1); a.stroke(); }
    for (const [x, y, r] of [[80, 575, 25], [340, 490, 12], [196, 258, 10], [268, 940, 18]]) R.dome(circleP(x, y, r), '#f8c8ec', 0.2, 0.04, r * 0.5, 1);
    R.pipe(P([[-10, 610], [12, 618], [20, 650], [8, 676], [-10, 680]], false, true), 14, '#c8c4cc', 0.14, 0.06, 2);

    // ── spikes ──
    const spikesA = [[618, 330, 650, 415, 26], [560, 355, 620, 440, 30], [510, 395, 578, 480, 32], [465, 440, 530, 525, 33], [408, 475, 490, 575, 37], [360, 530, 455, 628, 38],
      [292, 611, 390, 690, 36], [262, 658, 340, 760, 34], [225, 716, 288, 805, 33], [181, 731, 222, 825, 33], [125, 759, 160, 856, 31], [62, 762, 100, 866, 30], [8, 790, 36, 880, 30]];
    for (const [tx, ty, bx, by, r] of spikesA) drawSpike(tx, ty, bx, by, r * 1.15);
    const spikesB = [[25, 869, 10, 1040], [81, 900, 50, 1040], [122, 881, 80, 1040], [153, 869, 110, 1040], [187, 856, 140, 1040], [206, 912, 175, 1040], [225, 937, 205, 1040], [250, 950, 230, 1040], [275, 962, 255, 1040], [294, 975, 278, 1040]];
    for (const [tx, ty, bx, by] of spikesB) drawSpike(tx, ty, bx + (tx - bx) * 0.3, by + (ty - by) * 0.3, 27, '#8a7e98', 1);

    // ── spotted dog ──
    const dog = sm([[420, 712], [444, 700], [500, 708], [548, 726], [600, 714], [680, 740], [736, 760], [736, 1034], [470, 1034], [480, 960], [500, 900], [524, 852], [480, 824], [440, 800], [420, 770]]);
    // spiky fur halo
    const fr = rng(7);
    a.strokeStyle = '#f8f8fc'; a.lineCap = 'round';
    for (let i = 0; i < 70; i++) {
      const t = fr(), x = 550 + t * 190, y = 712 + t * 40 + (fr() - 0.5) * 20, L = 20 + fr() * 30, an = -1.9 + t * 1.6 + (fr() - 0.5) * 0.5;
      a.lineWidth = 1.5 + fr() * 2; a.beginPath(); a.moveTo(x, y + 20); a.lineTo(x + Math.cos(an) * L, y + 20 + Math.sin(an) * L); a.stroke();
    }
    for (let i = 0; i < 50; i++) {
      const t = fr(), x = 500 - t * 40 + (fr() - 0.5) * 20, y = 880 + t * 150, L = 20 + fr() * 30, an = Math.PI + (fr() - 0.5) * 0.9;
      a.lineWidth = 1.5 + fr() * 2; a.beginPath(); a.moveTo(x + 10, y); a.lineTo(x + Math.cos(an) * L, y + Math.sin(an) * L); a.stroke();
    }
    R.dome(dog, lin(420, 0, 736, 0, [[0, '#d4d2e2'], [0.6, '#c8c7d9'], [1, '#b8b4c8']]), 0.12, 0.16, 50, 1);
    R.dome(sm([[604, 800], [620, 796], [628, 830], [640, 880], [690, 896], [704, 920], [680, 936], [620, 930], [588, 905], [584, 860], [594, 820]]), '#a89eb6', 0.24, 0.05, 14, 1);
    for (const [x, y, rx, ry, rot] of [[528, 995, 36, 24, 0.2], [676, 980, 30, 34, 0], [608, 906, 13, 10, 0], [667, 868, 6, 8, 0], [590, 1013, 8, 7, 0]]) R.dome(ellipseP(x, y, rx, ry, rot), '#8c7c8c', 0.22, 0.03, 6, 1);
    R.dome(ellipseP(437, 716, 18, 14, 0.2), '#08080c', 0.24, 0.06, 8, 7);
    R.dome(ellipseP(565, 778, 15, 17, 0.2), '#f4f4f8', 0.22, 0.04, 6, 1);
    a.fillStyle = BLK; a.fill(circleP(570, 782, 7));
    a.strokeStyle = BLK; a.lineWidth = 3;
    a.beginPath(); a.moveTo(586, 758); a.lineTo(594, 770); a.stroke();
    a.beginPath(); a.moveTo(428, 770); a.quadraticCurveTo(470, 800, 500, 810); a.lineTo(522, 842); a.stroke();
    // white paw
    R.dome(sm([[350, 945], [380, 925], [420, 930], [460, 950], [470, 990], [440, 1000], [400, 980], [370, 990], [352, 970]]), '#e8e6f0', 0.14, 0.1, 18, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 30, wrap: 0.4, ao: 0.4, coat: 0.05 }),          // 1 matte clay
        E.mat({ dif: 1, spec: 0.6, shin: 40, wrap: 0.4, ao: 0.4, coat: 0.1 }),           // 2 tubes
        E.mat({ dif: 1, spec: 0.5, shin: 26, wrap: 0.5, ao: 0.5, coat: 0.08 }),           // 3 navy arm
        E.mat({ dif: 0.6, spec: 0.9, shin: 60, metal: 0.5, ao: 0.4, coat: 0.2 }),         // 4 gold
        E.mat({ dif: 1, spec: 0.55, shin: 30, wrap: 0.7, ao: 0.3, coat: 0.12, emis: 0.06 }),   // 5 spikes
        E.mat({ dif: 1, spec: 0.5, shin: 40, wrap: 0.3, ao: 0.5, coat: 0.1 }),            // 6 helmet brim
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.2, ao: 0.3, coat: 0.2 })             // 7 nose
      ],
      light: [-0.5, 0.6, 0.65], lc: [0.75, 0.75, 0.78], amb: [0.42, 0.42, 0.45],
      envTop: [1, 1, 1], envHor: [0.6, 0.6, 0.7], envBot: [0.2, 0.2, 0.3], envK: [0.15, 0.8, 0.3, 0],
      r1: 1.6, r2: 8, k: [0, 0.6, 0.4, 90], shadow: [-4, 5, 0.5, 7]
    });
    E.grain(0.035, 96);
  }
});
