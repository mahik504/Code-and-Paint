'use strict';
// g019 — "Crosshatch visor girl": an inked comic profile — a grey cross-hatched face with round green
// glasses, coral lips and a pink blush, an orange ear and neck, a starry visor, orange-gloved hands on a
// grey laptop, zebra-striped sleeves, a blue coiled cable, a lattice tower and a black fur cuff.
REC.register('g019', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const F = (path, c) => { o.fillStyle = c; o.fill(path); };
    const K = (path, c = INK, wd = 2.4) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const FK = (path, c, wd = 2.4) => { F(path, c); K(path, INK, wd); };
    const C = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const poly = pts => P(pts, true, false);
    const INK = '#141414', OR = '#f2922c', PAPER = '#f9f7ef';

    // ── textures ──
    const hatch = (base, ink, d) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float a = abs(fract(dot(p, vec2(0.80, 0.60)) / 4.2 + 0.3 * vnoise(p * 0.05)) - 0.5);
      float b = abs(fract(dot(p, vec2(-0.55, 0.83)) / 4.6 + 0.3 * vnoise(p * 0.05 + 5.)) - 0.5);
      float c = abs(fract(dot(p, vec2(0.98, -0.2)) / 6.0) - 0.5);
      float l = max(max(smoothstep(0.2, 0.08, a), smoothstep(0.2, 0.08, b)), smoothstep(0.14, 0.04, c) * uD);
      return mix(uB, uI, l * (0.75 + 0.25 * hash(floor(p * 0.5)))); }`, { uB: base, uI: ink, uD: d }));
    // bottom sleeve: stripes fanning out from a point above the arm
    const zFan = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float an = atan(p.x - 61., p.y - 381.) + 0.012 * sin(p.y * 0.05);
      float s = cos(6.2832 * (an - 0.183) / 0.0488) - 0.1;
      return mix(vec3(0.97, 0.96, 0.93), vec3(0.07), smoothstep(-0.12, 0.12, s)); }`));
    // middle sleeve: near-horizontal stripes, kinked near the left edge
    const zArm = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float ph = (p.y - 20. * clamp((p.x - 10.) / 30., 0., 1.) - 0.15 * max(p.x - 70., 0.) - 382.) / 26.2;
      float s = cos(6.2832 * ph) - 0.1;
      return mix(vec3(0.97, 0.96, 0.93), vec3(0.07), smoothstep(-0.12, 0.12, s)); }`));
    const fur = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float h = hash(floor(p * 0.9)); return vec3(0.05) + vec3(0.6) * step(0.93, h) * (0.5 + 0.5 * vnoise(p * 0.2)); }`));

    // ── paper ──
    F(rrect(0, 0, 726, 1024, 0), PAPER);
    // pale green field left of the face
    F(poly([[95, 200], [250, 160], [262, 300], [230, 440], [240, 480], [110, 480], [100, 330]]), '#d3e0a2');
    // zebra: top-left
    const zTop = poly([[-5, -5], [260, -5], [250, 40], [200, 80], [120, 95], [60, 100], [-5, 110]]);
    F(zTop, pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float u = (p.x - 120.) / 100., v = (p.y - 40.) / 100.;   // phase constants fitted offline to the stripe flow
      float ph = 0.4093 + 3.6569 * v - 1.3379 * v * v - 1.9024 * u - 0.43318 * u * v - 0.1829 * u * u;
      return mix(vec3(0.97, 0.96, 0.93), vec3(0.07), smoothstep(-0.12, 0.12, cos(6.2832 * ph) - 0.1)); }`)));
    // grey slab behind the top hand
    FK(poly([[232, -5], [292, -5], [160, 252], [104, 226]]), '#b7b9b6');
    // blue coiled cable
    for (let y = 210; y <= 392; y += 20) { const e = ellipseP(52, y, 58, 14, -0.05); FK(e, '#1d3ea4', 2.2); K(P([[10, y - 3], [40, y - 8], [80, y - 6]], false), 'rgba(140,170,240,0.6)', 2); }
    // brown sleeve + glove (top-left)
    const sleeve = poly([[-5, 108], [55, 96], [78, 170], [70, 205], [-5, 214]]);
    FK(sleeve, '#7a3e22');
    C(sleeve, () => { for (let x = 0; x < 80; x += 7) K(P([[x, 95], [x + 6, 215]], false), 'rgba(240,170,120,0.55)', 1.2); });
    const gloveT = P([[58, 100], [100, 80], [160, 70], [210, 76], [262, 92], [270, 104], [240, 106], [200, 102], [190, 122], [222, 140], [220, 160], [190, 162], [150, 150], [110, 160], [78, 172]]);
    FK(gloveT, OR);
    K(P([[110, 105], [170, 100], [205, 102]], false), INK, 1.5);

    // ── zebra arm (left middle) ──
    const zMid = P([[-5, 350], [60, 360], [130, 380], [190, 410], [240, 460], [250, 520], [180, 520], [100, 560], [40, 640], [-5, 690]]);
    F(zMid, zArm); K(zMid);

    // ── visor / helmet ──
    const helm = poly([[248, -5], [726, -5], [726, 70], [612, 98], [606, 138], [262, 154], [246, 112]]);
    FK(helm, '#3c3c3e');
    const panel = poly([[275, -5], [612, -5], [604, 86], [288, 92]]);
    F(panel, '#141416');
    { const r = rng(19); o.fillStyle = '#f0f0f0'; for (let i = 0; i < 70; i++) { o.globalAlpha = 0.5 + r() * 0.5; o.beginPath(); o.arc(285 + r() * 315, 5 + r() * 80, 0.6 + r() * 1.6, 0, 6.283); o.fill(); } o.globalAlpha = 1;
      for (const [x, y, rr] of [[392, 14, 9], [520, 44, 8], [310, 46, 6], [455, 30, 4]]) F(P(blob(x, y, rr * 1.4, rr, x, 7, 0.4)), '#f07a3a'); }
    K(circleP(552, 18, 22), 'rgba(230,230,230,0.8)', 2); K(circleP(552, 18, 6), 'rgba(230,230,230,0.8)', 1.5);
    for (let i = 0; i < 14; i++) F(rrect(286 + i * 22, 78 - i * 0.4, 8, 4, 2), '#3b8cf0');
    const band = poly([[250, 102], [612, 92], [608, 138], [262, 152]]);
    FK(band, '#f4f4f0');
    F(poly([[254, 114], [610, 104], [609, 114], [256, 126]]), '#20368c');
    FK(poly([[606, 62], [726, 26], [726, 96], [612, 132]]), '#1c2c78');
    F(poly([[616, 76], [726, 44], [726, 74], [618, 104]]), '#f0f0ec');
    o.font = 'bold 11px Arial, sans-serif'; o.fillStyle = '#f4f4f4'; o.textAlign = 'center'; o.fillText('MATTANIVIOK', 650, 62);

    // ── hair (back) ──
    const hair = P([[560, 96], [726, 84], [726, 520], [690, 500], [650, 482], [600, 470], [580, 440], [575, 400], [580, 360], [590, 320], [600, 290], [592, 250], [620, 190], [586, 120]]);
    FK(hair, '#1c1c1c');
    { const r = rng(5); for (let i = 0; i < 40; i++) { const x = 620 + r() * 100, y = 180 + r() * 300; K(P([[x, y], [x - 8 + r() * 16, y + 30 + r() * 30]], false), 'rgba(200,200,200,0.55)', 1); } }
    // ── neck + ear ──
    const neck = P([[440, 462], [462, 440], [500, 410], [535, 372], [550, 330], [552, 260], [575, 250], [598, 290], [588, 330], [578, 370], [575, 410], [582, 444], [600, 468], [636, 470], [646, 486], [560, 515], [470, 520], [440, 500]]);
    FK(neck, OR);
    const ear = P([[584, 130], [620, 112], [652, 124], [658, 170], [646, 230], [626, 270], [602, 286], [586, 250]]);
    FK(ear, OR);
    K(P([[610, 150], [630, 140], [640, 170], [628, 220], [612, 240]], false), INK, 1.8);
    K(ellipseP(592, 315, 10, 18, 0), '#9a9a9a', 3); K(ellipseP(592, 315, 10, 18, 0), INK, 1);

    // ── face ──
    const face = P([[262, 152], [380, 146], [520, 140], [574, 134], [568, 200], [556, 270], [550, 330], [535, 372], [500, 410], [462, 440], [425, 480], [360, 496], [314, 494], [302, 468], [300, 440], [292, 418], [290, 396], [276, 372], [272, 352], [282, 340], [264, 322], [252, 310], [236, 290], [240, 270], [252, 240], [256, 200]]);
    F(face, hatch([0.80, 0.77, 0.75], [0.25, 0.24, 0.24], 0.5));
    C(face, () => { o.save(); o.globalAlpha = 0.5; o.filter = `blur(${4 * S}px)`; F(poly([[430, 190], [530, 175], [540, 230], [500, 300], [440, 290], [425, 240]]), '#e0908a'); o.restore(); });
    C(face, () => F(poly([[436, 196], [526, 180], [532, 226], [498, 296], [442, 286], [430, 240]]), 'rgba(226,140,134,0.35)'));
    K(face, INK, 2.6);
    // bangs over the neck
    for (let i = 0; i < 9; i++) { const x = 380 + i * 9; F(poly([[x - 6, 470], [x + 8, 470], [x + 2 + (i % 3) * 3, 530 + (i % 2) * 14]]), '#1c1c1c'); }
    // lips + teeth
    const lips = P([[276, 350], [300, 344], [330, 350], [370, 356], [374, 364], [350, 384], [318, 400], [296, 410], [288, 398], [296, 382], [286, 372], [272, 360]]);
    FK(lips, '#f4808a');
    F(poly([[300, 366], [340, 366], [356, 372], [322, 380], [298, 378]]), '#f8e8c8'); K(P([[290, 366], [360, 368]], false), INK, 1.8);
    K(P([[264, 306], [282, 302], [292, 310]], false), INK, 2);
    // glasses
    for (const [cx, cy, rx, ry] of [[366, 178, 50, 52], [262, 208, 28, 46]]) { FK(ellipseP(cx, cy, rx, ry, 0), '#6c836a', 3); K(ellipseP(cx, cy, rx - 5, ry - 5, 0), 'rgba(30,40,30,0.4)', 2); }
    K(P([[290, 194], [316, 186]], false), INK, 3);
    for (const [x, y, r] of [[394, 160, 11], [372, 152, 5], [244, 206, 6], [250, 236, 4], [258, 250, 3]]) F(circleP(x, y, r), '#ffffff');

    // ── collar + sweater ──
    const coll = P([[440, 500], [520, 512], [600, 498], [648, 480], [656, 506], [610, 536], [540, 552], [470, 552], [444, 536]]);
    FK(coll, '#1f3b9b');
    const sweater = poly([[444, 540], [540, 560], [610, 540], [656, 506], [664, 520], [664, 652], [446, 652]]);
    F(sweater, hatch([0.86, 0.85, 0.83], [0.25, 0.25, 0.25], 0.2)); K(sweater);

    // ── black laptop + white window ──
    FK(poly([[234, 540], [600, 648], [586, 866], [238, 866]]), '#060606');
    F(poly([[296, 712], [465, 762], [465, 866], [296, 866]]), PAPER);
    // grey plank (laptop edge)
    const plank = poly([[18, 408], [606, 626], [600, 682], [18, 450]]);
    FK(plank, '#b4b6b2', 2.6);
    F(poly([[18, 408], [606, 626], [604, 640], [18, 422]]), '#cfd0cc');
    { o.save(); o.translate(420, 572); o.rotate(0.355); K(rrect(-18, -8, 36, 14, 2), INK, 2); o.restore(); }
    K(P([[270, 510], [330, 530], [340, 545]], false), INK, 2);

    // ── book ──
    const book = poly([[100, 650], [140, 618], [300, 662], [302, 760], [262, 836], [110, 790]]);
    FK(book, '#f6d6b6');
    FK(poly([[140, 618], [300, 662], [302, 760], [262, 836], [258, 700]]), '#f4a066');
    C(book, () => { for (let k = 0; k < 12; k++) K(P([[128 + k * 3, 680 + k * 10], [228 + k * 2, 702 + k * 10]], false), '#f08840', 2); });
    FK(rrect(156, 640, 76, 10, 4), '#f07840', 1.5);

    // ── orange arm (left) + hand on plank ──
    const arm = P([[45, 610], [80, 570], [130, 530], [150, 560], [120, 620], [96, 700], [100, 780], [140, 820], [120, 870], [70, 860], [40, 800], [30, 700]]);
    FK(arm, OR);
    for (const y of [610, 650, 690, 740, 790]) K(P([[38, y], [80, y - 10], [120, y + 4]], false), INK, 1.5);
    const hand = P([[120, 540], [160, 516], [230, 508], [280, 516], [302, 540], [300, 584], [288, 592], [276, 560], [252, 560], [240, 600], [200, 616], [150, 612], [118, 590]]);
    FK(hand, OR);
    for (const x of [190, 220, 248]) K(P([[x, 560], [x - 6, 606]], false), INK, 1.5);
    FK(P([[270, 724], [296, 712], [320, 734], [310, 776], [282, 790], [264, 760]]), OR);

    // ── lattice tower ──
    FK(rrect(662, 338, 64, 60, 6), '#c4c6c4');
    F(rrect(664, 340, 62, 14, 4), '#e4e4e2');
    C(rrect(668, 398, 58, 470, 0), () => {
      F(rrect(668, 398, 58, 470, 0), '#e8e6e0');
      F(rrect(686, 398, 22, 470, 0), '#f39a40');
      for (let y = 398; y < 870; y += 34) { K(P([[668, y], [726, y + 34]], false), '#6a6a6a', 3); K(P([[726, y], [668, y + 34]], false), '#6a6a6a', 3); K(P([[668, y], [726, y]], false), '#4a4a4a', 2); }
      const r = rng(23); for (let i = 0; i < 26; i++) F(ellipseP(672 + r() * 50, 400 + r() * 460, 5, 7, 0), '#2a2a2a');
    });
    K(P([[668, 398], [668, 868]], false), INK, 3); K(P([[722, 398], [722, 868]], false), INK, 3);

    // ── bottom zebra + lower hand ──
    const zBot = P([[60, 900], [120, 850], [200, 826], [300, 816], [380, 822], [450, 840], [500, 870], [500, 1030], [40, 1030]]);
    F(zBot, zFan); K(zBot);
    const hand2 = P([[290, 880], [340, 870], [400, 872], [460, 866], [500, 870], [500, 962], [440, 974], [380, 972], [340, 960], [330, 940], [380, 930], [300, 905]]);
    FK(hand2, OR);
    K(P([[330, 912], [400, 918]], false), INK, 1.5);

    // ── black fur cuff ──
    const furP = P(ragged([[486, 868], [560, 856], [726, 862], [726, 1030], [520, 1030], [500, 960]], 0, 6, 9, 7, 8));
    F(furP, fur);
    K(P([[490, 870], [480, 940], [505, 1024]], false), '#f0f0f0', 12);
    K(P([[490, 870], [480, 940], [505, 1024]], false), INK, 1.5);
    // grey cables
    for (const [cx, cy, rx, ry] of [[660, 984, 40, 34], [700, 1000, 34, 40], [640, 1020, 50, 30]]) { K(ellipseP(cx, cy, rx, ry, 0.3), INK, 10); K(ellipseP(cx, cy, rx, ry, 0.3), '#b8b8b8', 6); }

    // ── left rifle stock ──
    const stock = poly([[-5, 680], [40, 690], [60, 760], [80, 860], [110, 960], [130, 1030], [-5, 1030]]);
    FK(stock, '#c47a48');
    F(poly([[0, 760], [38, 770], [60, 860], [8, 860]]), '#a05a30');
    FK(P([[54, 900], [100, 890], [120, 1000], [90, 1030], [70, 1000]]), '#e88a50');
    F(rrect(100, 1000, 40, 24, 6), '#e04070');

    // ── snow dots ──
    { const r = rng(91); o.fillStyle = '#ffffff'; for (const [x, y, rr] of [[150, 348, 14], [30, 800, 13], [50, 730, 8], [80, 660, 7], [90, 740, 5], [28, 262, 6], [52, 288, 5], [20, 160, 5], [196, 405, 4], [216, 403, 4], [166, 322, 4], [24, 744, 6]]) { o.beginPath(); o.arc(x, y, rr, 0, 6.283); o.fill(); }
      for (let i = 0; i < 30; i++) { o.globalAlpha = 0.8; o.beginPath(); o.arc(r() * 160, 220 + r() * 640, 1 + r() * 2.5, 0, 6.283); o.fill(); } o.globalAlpha = 1; }
    E.grain(0.05, 19);
  }
});
