'use strict';
// g137 — "Zebra-bearded hat robot": a glowing cream robot face under a khaki hat with a grey brim and rows of
// teeth, a perforated silver disc, a raised zebra-striped beard with grey worm tendrils, a cream frill and a lavender skirt.
REC.register('g137', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, x1 = x, y1 = y) => { const g = a.createRadialGradient(x1, y1, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true);
    const op = pts => P(pts, false, true);
    // height canvas from GLSL (returns h in 0..1) written into the height buffer inside a clip
    const hfx = (path, glsl, m) => {
      const cv = E.fx(`vec3 hq(float h){ float v = clamp(h, 0., 1.) * 255.; float i = floor(v); return vec3(i / 255., ${m * 32}. / 255., (v - i)); }\n` + glsl);
      const hx = R.h; hx.save(); hx.clip(path); hx.setTransform(1, 0, 0, 1, 0, 0); hx.drawImage(cv, 0, 0); hx.restore();
    };
    // ribbed worm: tapered tube with ring grooves
    const worm = (cl, w0, w1, alb, h0) => {
      const path = P(lock(cl, w0, w1));
      R.dome(path, alb, h0, 0.12, Math.max(w0, w1) * 0.5, 2);
      const pts = []; const pp = P(cl, false, true);
      // sample the centreline for grooves
      let L = 0; const seg = [];
      for (let i = 1; i < cl.length; i++) { const d = Math.hypot(cl[i][0] - cl[i - 1][0], cl[i][1] - cl[i - 1][1]); seg.push(d); L += d; }
      for (let s = 6; s < L - 4; s += 7) {
        let acc = 0, i = 0; while (i < seg.length - 1 && acc + seg[i] < s) { acc += seg[i]; i++; }
        const t = (s - acc) / seg[i], p0 = cl[i], p1 = cl[i + 1];
        const x = p0[0] + (p1[0] - p0[0]) * t, y = p0[1] + (p1[1] - p0[1]) * t, dx = (p1[0] - p0[0]) / seg[i], dy = (p1[1] - p0[1]) / seg[i];
        const w = (w1 + (w0 - w1) * Math.pow(1 - s / L, 0.8)) * 0.42;
        pts.push([[x - dy * w, y + dx * w], [x + dy * w, y - dx * w]]);
      }
      clipA(path, () => { for (const [p, q] of pts) R.groove(P([p, q], false, false), 2.6, '#7c8090', h0 + 0.12, 0.05, 2, 0.7); });
    };

    // ── background: black night with blue bokeh, red wall on the left ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#09080f', 0, 0);
    soft(x => {
      x.fillStyle = '#e80820'; x.fill(P([[-10, 300], [70, 320], [160, 420], [200, 700], [160, 1034], [-10, 1034]], true, false));
      x.fillStyle = '#5a1020'; x.fill(P([[-10, 180], [60, 200], [80, 320], [-10, 330]], true, false));
    }, 12, 1);
    soft(x => { x.fillStyle = '#ff1a2a'; x.fill(P([[-10, 470], [40, 470], [60, 620], [30, 1034], [-10, 1034]], true, false)); }, 20, 0.9);
    soft(x => {
      const r = rng(37);
      for (let i = 0; i < 46; i++) {
        const X = r() * 726, Y = r() * 220, rr = 4 + r() * 8;
        if (X > 520 && Y > 70) continue;
        x.fillStyle = `rgba(${60 + r() * 50 | 0},${80 + r() * 50 | 0},${200 + r() * 55 | 0},${0.5 + r() * 0.5})`; x.fill(circleP(X, Y, rr));
      }
      x.fillStyle = 'rgba(70,90,230,0.9)'; for (const [X, Y, rr] of [[470, 38, 11], [296, 20, 8], [52, 148, 10], [80, 76, 9], [212, 76, 8], [688, 66, 7], [44, 8, 9]]) x.fill(circleP(X, Y, rr));
    }, 2.5, 1);
    // glowing bulb top right
    soft(x => { x.fillStyle = '#ffdc80'; x.fill(circleP(656, 8, 70)); }, 30, 0.5);
    R.dome(circleP(656, 2, 46), rad(656, 2, 46, [[0, '#fffbe8'], [0.7, '#ffe9a8'], [1, '#e8b860']]), 0.05, 0.1, 20, 0);
    soft(x => { x.strokeStyle = '#e8a040'; x.lineWidth = 3; x.stroke(P([[612, 30], [650, 46], [700, 40]], false)); }, 1, 0.8);

    // ── perforated silver disc (right) ──
    const disc = circleP(730, 290, 212);
    R.dome(disc, lin(600, 80, 640, 500, [[0, '#c0c8cc'], [0.45, '#a8b0b4'], [1, '#70747a']]), 0.1, 0.05, 12, 4);
    clipA(disc, () => {
      const r = rng(5); a.fillStyle = 'rgba(60,60,64,0.25)';
      for (let i = 0; i < 1800; i++) { a.beginPath(); a.arc(526 + r() * 200, 96 + r() * 400, 0.5 + r() * 0.9, 0, 6.283); a.fill(); }
      a.fillStyle = 'rgba(240,240,244,0.35)';
      for (let i = 0; i < 900; i++) { a.beginPath(); a.arc(526 + r() * 200, 96 + r() * 400, 0.5 + r() * 0.8, 0, 6.283); a.fill(); }
    });
    for (const [x, y, rr] of [[632, 188, 16], [610, 366, 14], [700, 188, 9], [570, 236, 9], [602, 270, 8], [648, 268, 7], [690, 312, 6], [600, 214, 5], [636, 140, 5], [668, 230, 5], [580, 312, 5], [636, 320, 5], [700, 240, 5], [710, 380, 5], [574, 172, 4], [650, 220, 3], [625, 250, 3], [680, 180, 3], [618, 300, 3], [668, 340, 4], [560, 290, 3], [720, 290, 6]])
      { R.flat(circleP(x, y, rr), '#060608', 0.06, 0); R.groove(circleP(x, y, rr + 1.5), 3, '#d8d8dc', 0.15, 0.03, 4, 0.5); }
    for (const rr of [184, 164, 144, 124]) { const p = new Path2D(); p.arc(730, 290, rr, -2.05 + (184 - rr) * 0.004, -1.52); R.groove(p, 11, '#08080a', 0.15, 0.08, 4, 1); }
    for (const cl of [[[680, 290], [726, 288]], [[668, 312], [726, 310]], [[676, 334], [726, 334]], [[670, 418], [700, 420]], [[690, 440], [726, 444]]])
      R.groove(P(cl, false), 10, '#08080a', 0.15, 0.08, 4, 1);
    clipA(disc, () => soft(x => { x.fillStyle = 'rgba(20,20,26,0.8)'; x.fill(P([[500, 200], [560, 230], [580, 330], [620, 440], [700, 520], [500, 520]], true, false)); }, 24, 0.7));
    R.pipe(op([[528, 250], [536, 320], [560, 400], [600, 456], [660, 494], [726, 512]]), 7, '#e01818', 0.16, 0.06, 2);
    R.pipe(P([[582, 104], [606, 122]], false), 6, '#a0a0a8', 0.15, 0.08, 3);
    R.dome(circleP(576, 97, 16), '#c8c8d0', 0.16, 0.1, 6, 3); R.flat(circleP(576, 97, 6), '#1a1a1e', 0.18, 0);
    R.pipe(op([[655, 410], [640, 440], [620, 470]]), 8, '#8c8c94', 0.16, 0.06, 3);
    R.dome(circleP(656, 402, 22), rad(656, 402, 22, [[0, '#e8e8f0'], [1, '#8a8a92']], 648, 394), 0.18, 0.14, 12, 3);
    R.dome(circleP(724, 52, 12), '#c8c8d0', 0.12, 0.08, 6, 3);

    // ── striped cylinder + grey ball (left) ──
    R.dome(sm([[44, 214], [84, 192], [132, 196], [138, 248], [128, 296], [80, 304], [46, 286], [32, 250]]), '#101014', 0.08, 0.14, 26, 2);
    R.dome(sm([[62, 204], [100, 194], [112, 250], [104, 300], [70, 300], [56, 250]]), '#f2f2f0', 0.1, 0.14, 20, 2);
    R.dome(sm([[100, 194], [118, 196], [124, 250], [116, 300], [100, 300], [106, 250]]), '#1a1a1e', 0.12, 0.1, 6, 2);
    R.bead(32, 312, 28, rad(32, 312, 28, [[0, '#9a9aa0'], [1, '#5a5a62']], 24, 300), 0.12, 0.2, 3);

    // ── hat crown ──
    const crown = sm([[118, 256], [136, 200], [180, 136], [240, 100], [320, 84], [410, 90], [470, 116], [508, 158], [520, 200], [300, 220], [110, 260]]);
    R.dome(crown, lin(110, 100, 520, 240, [[0, '#dccf70'], [0.5, '#d6c878'], [1, '#c8b86c']]), 0.08, 0.16, 50, 1);
    clipA(crown, () => {
      a.strokeStyle = 'rgba(140,124,60,0.55)'; a.lineWidth = 1.4;
      for (let i = 0; i < 70; i++) { const x0 = 110 + i * 6.2; a.beginPath(); a.moveTo(x0 + 20, 80); a.quadraticCurveTo(x0 + (x0 - 300) * 0.15, 160, x0 - (x0 - 300) * 0.1, 250); a.stroke(); }
    });
    const band = P([[262, 92], [330, 84], [392, 88], [414, 200], [254, 206]], true, false);
    R.dome(band, '#d2c68e', 0.2, 0.03, 8, 1);
    clipA(band, () => { a.strokeStyle = 'rgba(120,108,60,0.6)'; a.lineWidth = 1.6; for (let y = 96; y < 206; y += 6) { a.beginPath(); a.moveTo(250, y); a.lineTo(420, y - 3); a.stroke(); } });
    R.pipe(P([[284, 70], [290, 100]], false), 5, '#c8c0b0', 0.2, 0.06, 2);
    R.bead(278, 62, 12, '#f4f0e8', 0.22, 0.14, 2);
    R.dome(ellipseP(440, 128, 40, 26, 0.05), '#8c9094', 0.2, 0.1, 14, 3);
    R.dome(circleP(442, 130, 14), '#f2c010', 0.28, 0.06, 6, 2); R.dome(circleP(442, 130, 6), '#f4e8a0', 0.32, 0.03, 3, 2);
    R.bead(142, 227, 8, '#b0a050', 0.22, 0.05, 3);

    // ── grey brim with red piping ──
    const brim = sm([[6, 430], [12, 370], [44, 300], [100, 236], [200, 190], [300, 174], [400, 168], [500, 174], [566, 184], [570, 212], [500, 206], [440, 202], [380, 206], [300, 224], [240, 245], [180, 273], [140, 298], [112, 324], [100, 360], [100, 400], [104, 446], [112, 492], [70, 498], [30, 476]]);
    R.dome(brim, lin(300, 170, 60, 480, [[0, '#ece2cc'], [0.35, '#d8d8dc'], [0.7, '#b0c0d8'], [1, '#8ea4c4']]), 0.12, 0.12, 22, 2);
    R.flat(circleP(56, 432, 15), '#d8d8dc', 0.2, 2); R.flat(circleP(56, 432, 9), '#08080a', 0.18, 0);
    // dark teeth band
    const tband = sm([[112, 492], [100, 446], [98, 392], [104, 340], [140, 300], [200, 266], [260, 241], [340, 216], [420, 204], [500, 208], [540, 212], [548, 262], [544, 310], [510, 300], [450, 296], [380, 302], [300, 322], [250, 338], [200, 360], [165, 385], [150, 420], [160, 480], [178, 560], [204, 650], [180, 662], [150, 600]]);
    R.flat(tband, '#24262c', 0.1, 2);
    R.pipe(op([[104, 444], [100, 400], [100, 360], [106, 330], [120, 315], [140, 300], [160, 287], [200, 265], [240, 247], [280, 232], [300, 226], [340, 215], [380, 208], [420, 204], [460, 204], [500, 208], [530, 210]]), 7, '#e01818', 0.17, 0.06, 2);
    R.pipe(op([[114, 420], [114, 396], [120, 379], [140, 356], [160, 338], [180, 324], [200, 311], [240, 290], [280, 275], [300, 267], [340, 256], [380, 249], [420, 246], [460, 248], [500, 253], [520, 258]]), 6, '#e01818', 0.16, 0.05, 2);
    R.bead(531, 210, 6, '#e01818', 0.16, 0.06, 2);
    R.pipe(op([[500, 262], [530, 290], [546, 330], [562, 390], [580, 440], [606, 480]]), 5, '#e01818', 0.14, 0.05, 2);
    // teeth along the band
    const teeth = (pts, step, tw, th, alb) => {
      let L = 0; const seg = [];
      for (let i = 1; i < pts.length; i++) { const d = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); seg.push(d); L += d; }
      for (let s = step / 2; s < L; s += step) {
        let acc = 0, i = 0; while (i < seg.length - 1 && acc + seg[i] < s) { acc += seg[i]; i++; }
        const t = (s - acc) / seg[i], p0 = pts[i], p1 = pts[i + 1];
        const x = p0[0] + (p1[0] - p0[0]) * t, y = p0[1] + (p1[1] - p0[1]) * t, ang = Math.atan2(p1[1] - p0[1], p1[0] - p0[0]);
        const p = new Path2D(), m = new DOMMatrix().translate(x, y).rotate(ang * 180 / Math.PI);
        p.addPath(rrect(-tw / 2, -th / 2, tw, th, Math.min(tw, th) * 0.35), m);
        R.dome(p, alb, 0.14, 0.08, Math.min(tw, th) * 0.4, 2);
      }
    };
    teeth([[524, 233], [500, 230], [460, 226], [420, 225], [380, 228], [340, 236], [300, 246], [280, 254], [240, 268], [200, 288], [180, 300], [160, 312], [140, 328], [118, 346]], 24, 19, 30, '#dfe3ec');
    teeth([[516, 272], [500, 267], [460, 262], [420, 260], [380, 263], [340, 270], [300, 281], [280, 289], [240, 304], [200, 325], [180, 338], [160, 352], [140, 372]], 24, 18, 15, '#d4d8e0');
    teeth([[112, 380], [112, 430], [118, 480], [126, 530], [136, 580], [150, 630]], 22, 14, 18, '#d4d8e0');
    teeth([[140, 410], [142, 456], [150, 500], [160, 546], [172, 592], [186, 640]], 22, 13, 16, '#ccd0d8');
    teeth([[540, 300], [552, 350], [566, 400], [584, 450]], 18, 12, 14, '#ccd0d8');

    // ── the glowing face ──
    const face = sm([[150, 420], [165, 386], [200, 366], [250, 344], [300, 328], [380, 309], [450, 303], [510, 306], [545, 322], [565, 400], [580, 450], [600, 484], [540, 506], [470, 540], [420, 580], [330, 604], [260, 620], [206, 652], [184, 560], [160, 480]]);
    R.dome(face, rad(380, 440, 300, [[0, '#fff4d0'], [0.6, '#fdecc0'], [1, '#f6e0b0']], 340, 420), 0.12, 0.08, 14, 1);
    R.pipe(op([[156, 410], [170, 380], [200, 360], [250, 337], [300, 321], [380, 302], [450, 296], [512, 299]]), 5, '#f2d070', 0.16, 0.03, 1);
    soft(x => { x.fillStyle = 'rgba(252,214,110,0.9)'; x.fill(ellipseP(380, 540, 160, 50, -0.3)); x.fill(ellipseP(500, 470, 50, 60, 0)); }, 40, 0.5);
    // eye: black-rimmed lens with an amber glow
    const eye = sm([[166, 430], [178, 394], [214, 366], [270, 351], [330, 346], [344, 352], [322, 386], [286, 420], [240, 452], [196, 462], [170, 450]]);
    R.groove(eye, 14, '#0a0808', 0.16, 0.1, 2, 1);
    R.flat(eye, rad(250, 410, 90, [[0, '#fffbe8'], [0.4, '#fbe6b0'], [0.75, '#e8a048'], [1, '#6a2a08']], 250, 420), 0.1, 1);
    R.dome(circleP(255, 377, 9), '#0a0808', 0.1, 0.02, 4, 1);
    R.dome(ellipseP(372, 352, 9, 6, 0), '#9aa0aa', 0.14, 0.05, 4, 3);
    // slots
    const slot = (pts, wd) => { const p = op(pts); R.groove(p, wd, '#0a0808', 0.16, 0.14, 2, 1); a.lineWidth = wd * 0.82; a.strokeStyle = '#0a0808'; a.lineCap = 'round'; a.stroke(p); };
    slot([[196, 500], [328, 446], [346, 432], [498, 370]], 24);
    slot([[254, 526], [400, 466], [516, 406]], 24);
    slot([[424, 324], [490, 313]], 15);
    R.dome(circleP(462, 334, 6), '#0a0808', 0.1, 0.02, 3, 1);

    // blue slab (left)
    const slab = sm([[0, 745], [50, 690], [100, 630], [130, 608], [170, 610], [176, 690], [150, 742], [110, 790], [80, 860], [62, 950], [52, 1010], [24, 1010], [24, 850], [0, 800]]);
    R.dome(slab, '#c8ccd6', 0.08, 0.1, 8, 2);
    R.dome(sm([[22, 768], [62, 712], [110, 652], [136, 626], [166, 620], [172, 690], [150, 742], [110, 790], [80, 860], [62, 950], [52, 1004], [36, 1004], [36, 860]]), lin(20, 640, 160, 900, [[0, '#4a94ee'], [0.4, '#2c76d8'], [1, '#1450b0']]), 0.12, 0.08, 12, 2);
    soft(x => { x.fillStyle = '#c8384c'; x.fill(P([[-10, 1000], [70, 990], [90, 1034], [-10, 1034]], true, false)); }, 8, 0.9);
    // ── zebra beard: raised tubes from a fitted stripe flow ──
    const beard = sm([[160, 660], [200, 640], [260, 622], [330, 606], [420, 584], [470, 544], [540, 508], [604, 484], [650, 520], [700, 560], [736, 580], [736, 780], [700, 810], [660, 850], [630, 880], [600, 895], [560, 898], [520, 880], [470, 850], [420, 830], [375, 822], [337, 828], [300, 840], [269, 862], [237, 894], [200, 925], [160, 935], [120, 935], [100, 880], [100, 820], [130, 780], [150, 750]]);
    // two fitted stripe flows, switched along the long tendril's centreline (it hides the seam)
    const BPH = `float bph(vec2 p){ float u = (p.x - 363.) / 512., v = (p.y - 512.) / 512.;
      float wx = p.y < 640. ? mix(402., 412., clamp((p.y - 590.) / 50., 0., 1.)) : p.y < 690. ? mix(412., 428., (p.y - 640.) / 50.) : p.y < 740. ? mix(428., 440., (p.y - 690.) / 50.)
        : p.y < 790. ? mix(440., 436., (p.y - 740.) / 50.) : mix(436., 420., clamp((p.y - 790.) / 50., 0., 1.));
      return p.x < wx ? 2.11171 +9.10787*u +0.01255*v -8.89287*u*u -8.40957*u*v -31.67310*v*v +4.16741*u*u*u +26.56312*u*u*v +23.89731*u*v*v +25.18585*v*v*v
        : -0.88316 +9.78181*u -19.08512*v +2.20734*u*u +5.17241*u*v -3.50272*v*v -0.48626*u*u*u -8.02677*u*u*v -7.18685*u*v*v +6.94740*v*v*v; }`;
    a.save(); a.clip(beard); img(E.fx(BPH + `
      vec3 fx(vec2 uv, vec2 p){ float ph = bph(p); float c = cos(6.2832 * ph);
        float k = 0.9 / max(fwidth(ph) * 6.2832, 1e-3); float v = clamp(0.5 + (c + 0.1) * min(k, 5.) * 0.5, 0., 1.);
        vec3 lt = mix(vec3(.80, .83, .90), vec3(.93, .94, .97), smoothstep(0.3, 1., c));
        return mix(vec3(.03, .03, .05), lt, v); }`)); a.restore();
    hfx(beard, BPH + `
      vec3 fx(vec2 uv, vec2 p){ float c = cos(6.2832 * bph(p)); return hq(0.1 + 0.14 * sqrt(max(c + 0.1, 0.) / 1.1)); }`, 2);
    // vertical tubes inside the frill loop (lower left)
    const loop = sm([[104, 800], [180, 772], [240, 800], [292, 842], [269, 862], [237, 894], [200, 925], [160, 935], [120, 935], [100, 880]]);
    const VPH = `float vph(vec2 p){ float u = (p.x - 363.) / 512., v = (p.y - 512.) / 512.; return 17.22431 +2.67977*u -46.69803*v +6.43295*u*u +21.19683*u*v +32.32152*v*v; }`;
    a.save(); a.clip(loop); img(E.fx(VPH + `
      vec3 fx(vec2 uv, vec2 p){ float c = cos(6.2832 * vph(p)); float v = smoothstep(-0.2, 0.2, c + 0.1);
        return mix(vec3(.04, .04, .07), vec3(.84, .86, .92), v); }`)); a.restore();
    hfx(loop, VPH + `vec3 fx(vec2 uv, vec2 p){ float c = cos(6.2832 * vph(p)); return hq(0.1 + 0.12 * sqrt(max(c + 0.1, 0.) / 1.1)); }`, 2);
    // lavender fan at the far left
    const fan = sm([[45, 732], [100, 736], [150, 740], [176, 760], [166, 800], [150, 850], [126, 900], [100, 915], [90, 880], [80, 830], [60, 790]]);
    R.dome(fan, lin(40, 740, 150, 900, [[0, '#a8a8e0'], [1, '#8a8ad0']]), 0.1, 0.08, 14, 1);
    clipA(fan, () => { for (let i = 0; i < 12; i++) R.groove(P([[50 + i * 9, 740 + i * 2], [90 + i * 5, 800 + i * 5], [120 + i * 2, 920]], false), 3.5, '#6a6ab8', 0.17, 0.04, 1, 0.6); });

    // ── lavender skirt ──
    const skirt = sm([[64, 940], [112, 950], [162, 940], [200, 925], [237, 894], [269, 862], [300, 840], [337, 828], [375, 822], [420, 830], [470, 850], [520, 880], [560, 898], [600, 895], [630, 880], [660, 850], [700, 810], [736, 780], [736, 900], [680, 912], [620, 910], [570, 930], [510, 960], [470, 1000], [440, 1034], [100, 1034], [70, 1000]]);
    R.dome(skirt, lin(100, 840, 300, 1034, [[0, '#a0a6e0'], [0.4, '#7880c8'], [1, '#4a5090']]), 0.06, 0.1, 30, 1);
    clipA(skirt, () => {
      const r = rng(11);
      for (let i = 0; i < 24; i++) {
        const x0 = 100 + i * 26 + r() * 10, y0 = 850 + Math.max(0, 300 - x0) * 0.4;
        soft(x => { x.strokeStyle = 'rgba(40,44,110,0.85)'; x.lineWidth = 5 + r() * 8; x.beginPath(); x.moveTo(x0, y0); x.quadraticCurveTo(x0 - 10, y0 + 70, x0 - 30 + r() * 20, 1040); x.stroke(); }, 5, 0.8);
      }
    });
    soft(x => { x.fillStyle = '#05050a'; x.fill(P([[640, 930], [736, 890], [736, 1034], [600, 1034]], true, false)); }, 20, 0.85);

    // ── cream frill rope ──
    const frillCl = [[42, 730], [58, 760], [56, 787], [75, 819], [94, 862], [81, 912], [69, 937], [112, 950], [162, 940], [200, 925], [237, 894], [269, 862], [300, 840], [337, 828], [375, 822], [420, 830], [470, 850], [520, 880], [560, 898], [600, 895], [630, 880], [660, 850], [700, 810], [736, 780]];
    const frill = [];
    { let k = 0; for (let i = 0; i < frillCl.length - 1; i++) { const p = frillCl[i], q = frillCl[i + 1], L = Math.hypot(q[0] - p[0], q[1] - p[1]), n = Math.max(2, Math.round(L / 7)), nx = -(q[1] - p[1]) / L, ny = (q[0] - p[0]) / L;
      for (let j = 0; j < n; j++, k++) { const t = j / n, w = 7 * Math.sin(k * 0.95); frill.push([p[0] + (q[0] - p[0]) * t + nx * w, p[1] + (q[1] - p[1]) * t + ny * w]); } } }
    soft(x => { x.strokeStyle = '#000'; x.lineWidth = 30; x.translate(4, 8); x.stroke(P(frill, false, true)); }, 8, 0.45);
    R.pipe(P(frill, false, true), 26, '#f4e4bc', 0.2, 0.12, 2);

    // ── grey worm tendrils + flower ──
    for (const [cl, w0, w1] of [
      [[[222, 650], [218, 690], [230, 730], [224, 770], [214, 790], [218, 800]], 18, 9],
      [[[268, 640], [262, 680], [258, 720], [266, 750], [262, 770]], 18, 9],
      [[[330, 618], [326, 660], [320, 700], [318, 740], [306, 772], [296, 796]], 22, 11],
      [[[402, 590], [412, 640], [428, 690], [440, 740], [436, 790], [420, 840], [404, 890], [392, 940], [400, 980], [416, 1004]], 26, 14],
      [[[520, 596], [532, 640], [548, 690], [558, 730], [548, 752], [530, 748], [522, 732]], 18, 9],
      [[[296, 800], [286, 820], [272, 828]], 14, 8],
      [[[456, 870], [462, 920], [468, 970], [478, 1010], [484, 1034]], 18, 12],
      [[[566, 900], [572, 950], [586, 1000], [592, 1034]], 16, 12],
      [[[384, 856], [372, 900], [382, 950], [372, 990], [366, 1020]], 18, 12],
      [[[648, 970], [656, 1010], [654, 1034]], 14, 12],
      [[[512, 700], [530, 720], [536, 744]], 12, 8],
    ]) worm(cl, w0 * 1.2, w1 * 1.2, '#bcc0cc', 0.2);
    // daisy
    for (let i = 0; i < 9; i++) { const t = i / 9 * 6.283 - 1.2, cx = 465 + Math.cos(t) * 24, cy = 712 + Math.sin(t) * 22; R.dome(ellipseP(cx, cy, 16, 9, t), '#f6e6bc', 0.28, 0.08, 7, 1); }
    R.dome(circleP(465, 712, 12), '#f0cc84', 0.34, 0.08, 6, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.5, ao: 0.4, coat: 0.08 }),                    // 1 satin (crown, face, skirt)
        E.mat({ dif: 1, spec: 0.85, shin: 50, wrap: 0.45, ao: 0.45, coat: 0.15 }),                 // 2 glossy plastic
        E.mat({ dif: 0.5, metal: 0.55, spec: 1.0, shin: 50, rim: 0.2, ao: 0.4, grain: 0.15 }),     // 3 brushed metal
        E.mat({ dif: 1, spec: 0.7, shin: 40, wrap: 0.5, ao: 0.4, grain: 0.1 }),                     // 4 sandblasted silver
      ],
      light: [-0.4, 0.62, 0.68], lc: [0.75, 0.74, 0.72], amb: [0.42, 0.42, 0.45],
      envTop: [1.1, 1.1, 1.15], envHor: [0.6, 0.6, 0.66], envBot: [0.08, 0.08, 0.1], envK: [0.5, 1.2, 0, 0],
      r1: 1.3, r2: 6, k: [0, 0.6, 0.4, 140], shadow: [-4, 6, 0.6, 7]
    });
    E.grain(0.02, 137);
  }
});
