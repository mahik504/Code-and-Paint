'use strict';
// g017 — "Plumber's figure eight": inked comic plumbing on a green brick wall — a glossy white pipe
// looping in a figure eight with chrome bands, a smiling ball-head valve, a chrome/blue first-aid
// cylinder, a ribbed copper hose, spiral discs, a white egg tank, zebra rings and snow globes.
REC.register('g017', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    // flush the height buffer after every relief call (a canvas-recording glitch otherwise drops height strokes)
    for (const k of ['dome', 'flat', 'pipe', 'groove']) { const f0 = R[k]; R[k] = (...args) => { f0(...args); R.h.getImageData(0, 0, 1, 1); }; }
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const F = (path, c) => { a.fillStyle = c; a.fill(path); };
    const K = (path, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.lineCap = a.lineJoin = 'round'; a.stroke(path); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    // Catmull-Rom sampling of a centreline -> [x, y, tx, ty]
    const samp = (pts, step) => {
      const out = [], n = pts.length, g = i => pts[Math.max(0, Math.min(n - 1, i))];
      for (let i = 0; i < n - 1; i++) {
        const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2), L = Math.hypot(p2[0] - p1[0], p2[1] - p1[1]), k = Math.max(1, Math.round(L / step));
        for (let j = 0; j < k; j++) {
          const t = j / k, t2 = t * t, t3 = t2 * t;
          const f = (a0, a1, a2, a3) => 0.5 * (2 * a1 + (-a0 + a2) * t + (2 * a0 - 5 * a1 + 4 * a2 - a3) * t2 + (-a0 + 3 * a1 - 3 * a2 + a3) * t3);
          const d = (a0, a1, a2, a3) => 0.5 * ((-a0 + a2) + 2 * (2 * a0 - 5 * a1 + 4 * a2 - a3) * t + 3 * (-a0 + 3 * a1 - 3 * a2 + a3) * t2);
          const x = f(p0[0], p1[0], p2[0], p3[0]), y = f(p0[1], p1[1], p2[1], p3[1]); let tx = d(p0[0], p1[0], p2[0], p3[0]), ty = d(p0[1], p1[1], p2[1], p3[1]); const l = Math.hypot(tx, ty) || 1;
          out.push([x, y, tx / l, ty / l]);
        }
      }
      return out;
    };
    // chrome band around a pipe: short butt-capped cylinder along the pipe
    const band = (x, y, tx, ty, wd, len, alb = '#a8acb4') => {
      for (const c of [a, R.h]) c.lineCap = 'butt';
      R.pipe(P([[x - tx * len / 2, y - ty * len / 2], [x + tx * len / 2, y + ty * len / 2]], false), wd, alb, 0.42, 0.22, 3);
      for (const c of [a, R.h]) c.lineCap = 'round';
    };
    const INK = '#0e1214';
    const opipe = (path, wd, alb, h0, dh, m) => { a.lineWidth = wd + 6; a.strokeStyle = INK; a.stroke(path); R.pipe(path, wd, alb, h0, dh, m); };
    const WHITE = '#ece9e4';

    // ── paper ground ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#d4d4d6', 0, 0);
    { const r = rng(17); a.fillStyle = 'rgba(150,150,160,0.25)'; for (let i = 0; i < 2500; i++) { a.beginPath(); a.arc(r() * 726, r() * 1024, 0.4 + r(), 0, 6.283); a.fill(); } }
    // ── green brick wall panel ──
    const panel = P([[96, -10], [660, -10], [660, 1000], [96, 1000], [92, 520], [82, 470], [90, 300], [76, 240], [92, 120], [84, 50]], true, false);
    const brick = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 b = vec2(40., 21.); vec2 q = p; float row = floor(q.y / b.y); q.x += mod(row, 2.) * b.x * 0.5;
      vec2 f = fract(q / b), id = floor(q / b);
      float m = smoothstep(0.03, 0.08, f.x) * smoothstep(0.98, 0.93, f.x) * smoothstep(0.06, 0.16, f.y) * smoothstep(0.96, 0.86, f.y);
      vec3 br = vec3(0.25, 0.33, 0.28) * (0.75 + 0.45 * hash(id)) * (0.8 + 0.4 * fbm(p * 0.05));
      vec3 c = mix(vec3(0.12, 0.15, 0.13), br, m);
      float ink = smoothstep(0.6, 0.68, fbm(p * 0.025 + 3.)) + 0.5 * smoothstep(0.62, 0.66, fbm(p * 0.08 + 9.));
      return mix(c, vec3(0.05, 0.06, 0.06), ink * 0.8); }`);
    R.flat(panel, '#2e3e36', 0.0, 0);
    clipA(panel, () => img(brick));
    // teal paint patches behind the cylinder
    soft(x => { x.fillStyle = '#2a9ab8'; for (const [cx, cy, rx, ry] of [[240, 300, 30, 50], [300, 240, 40, 20], [420, 420, 40, 26], [470, 470, 30, 40], [230, 420, 22, 70], [260, 470, 30, 20], [520, 410, 20, 30]]) x.fill(P(blob(cx, cy, rx, ry, cx + cy, 12, 0.35))); }, 1.5, 0.95);
    // black ink edges on the left and top
    soft(x => { x.fillStyle = '#070808'; x.fill(P(ragged([[60, 60], [100, 40], [110, 300], [100, 470], [70, 470], [50, 380], [40, 240], [30, 120]], 0, 8, 14, 10, 3))); x.fill(P(ragged([[30, 0], [180, 0], [140, 30], [60, 40]], 0, 4, 12, 8, 4))); }, 1, 1);
    soft(x => { x.fillStyle = '#4a3428'; x.fill(P(ragged([[200, -10], [430, -10], [420, 40], [360, 60], [250, 58], [205, 40]], 0, 6, 10, 6, 5))); }, 1, 1);
    // brown cardboard bottom-left
    const card = P([[0, 480], [70, 482], [84, 520], [100, 600], [118, 720], [140, 820], [175, 920], [215, 1000], [0, 1000]], true, false);
    R.flat(card, lin(0, 480, 200, 1000, [[0, '#a07858'], [0.4, '#7e5440'], [1, '#8a5c40']]), 0.02, 1);
    soft(x => { x.fillStyle = '#c8a888'; x.fill(P([[10, 480], [70, 482], [80, 540], [60, 600], [30, 560]])); x.fillStyle = '#5a3828'; x.fill(P([[100, 820], [150, 830], [180, 920], [130, 960]])); }, 6, 0.7);
    R.flat(rrect(46, 782, 52, 42, 2), '#f0d848', 0.05, 1);
    // cyan splashes left
    soft(x => { x.fillStyle = '#58c4dc'; x.fill(P(ragged([[0, 290], [40, 300], [70, 350], [80, 420], [60, 480], [20, 490], [0, 470]], 0, 7, 10, 8, 6))); x.fill(P(ragged([[0, 790], [40, 795], [55, 840], [40, 900], [0, 905]], 0, 5, 10, 8, 7))); }, 1, 1);
    a.fillStyle = '#ffffff'; for (const [cx, cy, r] of [[38, 432, 8], [32, 855, 8], [52, 750, 6]]) { a.beginPath(); a.arc(cx, cy, r, 0, 6.283); a.fill(); }
    // bottom floor strip
    R.flat(P([[96, 975], [660, 975], [726, 990], [726, 1034], [0, 1034], [0, 1000]], true, false), '#cfd0d2', 0.01, 0);
    soft(x => { x.fillStyle = '#202224'; for (let i = 0; i < 30; i++) x.fill(ellipseP(120 + i * 18, 985 + (i % 3) * 5, 10, 3, 0)); }, 2, 0.6);

    // ── right side: zebra rings, teal strip, beige brick column, black panel ──
    const zeb = P([[548, 92], [580, 72], [630, 64], [662, 62], [662, 612], [620, 608], [575, 596], [555, 560], [550, 500], [560, 440], [548, 380], [556, 300], [546, 220], [556, 150]]);
    const zcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      // ring centre / squash / spacing fitted offline to the reference's ring flow
      vec2 d = p - vec2(699.07, 240.48);
      float r = sqrt(d.x * d.x + 0.59679 * d.y * d.y) + 3. * (vnoise(p * 0.03) - 0.5);
      float ph = r / 20.717 + 1.2035e-3 * r * r / 20.717 + 1.8515;
      float s = cos(6.2832 * ph) - 0.1;
      return mix(vec3(0.94), vec3(0.05), smoothstep(-0.15, 0.15, s)); }`);
    R.flat(zeb, '#ffffff', 0.04, 1); clipA(zeb, () => img(zcv));
    R.dome(rrect(660, 58, 42, 664, 3), '#4ea4ac', 0.06, 0.04, 4, 1);
    R.flat(rrect(702, 120, 30, 880, 0), '#c8b096', 0.03, 1);
    clipA(rrect(702, 120, 30, 880, 0), () => { for (let y = 130; y < 1000; y += 34) K(P([[702, y], [726, y]], false), '#6a5848', 2); });
    R.flat(rrect(650, 718, 50, 262, 2), '#121314', 0.05, 1);
    for (const y of [770, 935]) R.bead(678, y, 5, '#a0a4a8', 0.08, 0.04, 3);
    R.bead(681, 465, 13, '#f0c018', 0.1, 0.12, 2);
    R.bead(684, 658, 7, '#e0b020', 0.1, 0.06, 2);
    R.bead(640, 500, 25, '#f4f4f4', 0.1, 0.12, 2);
    R.flat(circleP(640, 500, 17), '#e02828', 0.16, 2);
    R.flat(P([[635, 488], [645, 488], [645, 495], [652, 495], [652, 505], [645, 505], [645, 512], [635, 512], [635, 505], [628, 505], [628, 495], [635, 495]], true, false), '#ffffff', 0.18, 2);
    // brass bits on the teal strip
    R.dome(rrect(672, 190, 26, 70, 3), '#d0b070', 0.1, 0.06, 4, 4);

    // ── grey stone blocks ──
    { const r = rng(5);
      for (let gy = 0; gy < 9; gy++) for (let gx = 0; gx < 4; gx++) {
        const x = 92 + gx * 48 + (gy % 2) * 20, y = 482 + gy * 46; if (x > 280 || (gy > 6 && x > 220)) continue;
        R.dome(rrect(x, y, 44, 42, 3), mixHex('#8c8a90', '#5a5a62', r() * 0.6), 0.06, 0.04, 4, 4);
      } }

    // ── hanging lamps ──
    const lamp = (x, y, w, h) => {
      R.pipe(P([[x, -10], [x, y]], false), 12, '#8a7a60', 0.2, 0.08, 4);
      R.dome(rrect(x - w / 2, y, w, h, 6), '#a89070', 0.2, 0.12, 8, 4);
      for (let k = 1; k < 4; k++) R.groove(P([[x - w / 2 + 2, y + k * h / 4], [x + w / 2 - 2, y + k * h / 4]], false), 3, '#3a3024', 0.32, 0.06, 4);
    };
    lamp(183, 34, 54, 50); lamp(515, 6, 66, 46);
    R.pipe(P([[548, 10], [610, 10]], false), 10, '#8a7a60', 0.2, 0.06, 4);
    R.pipe(P([[132, 48], [160, 48]], false), 10, '#8a7a60', 0.2, 0.06, 4);
    R.pipe(P([[367, -10], [367, 112]], false), 7, '#40a8d0', 0.22, 0.06, 2);

    // ── lower white loop ──
    const se = t => { const c = Math.cos(t), sn = Math.sin(t), e = sn < 0 ? 0.78 : 0.95; return [372 + Math.sign(c) * Math.pow(Math.abs(c), e) * 232, 770 + Math.sign(sn) * Math.pow(Math.abs(sn), e) * 175]; };
    const lower = []; for (let i = 0; i < 96; i++) lower.push(se(i / 96 * 6.283));
    opipe(P(lower, true), 64, WHITE, 0.3, 0.26, 1);
    for (const t of [0.35, 0.95, 1.6, 2.15, 2.75, 3.6, 5.6, 6.0]) { const [x, y] = se(t), [x2, y2] = se(t + 0.01), tx = x2 - x, ty = y2 - y, l = Math.hypot(tx, ty); band(x, y, tx / l, ty / l, 70, 7); band(x + tx / l * 11, y + ty / l * 11, tx / l, ty / l, 70, 5); }
    // ── vertical stem + upper loop ──
    opipe(P([[367, 380], [367, 652]], false), 78, WHITE, 0.32, 0.26, 1);
    const up = [[372, 505], [310, 500], [250, 468], [212, 410], [182, 335], [170, 262], [180, 182], [205, 125], [260, 82], [340, 66], [440, 80], [512, 130], [548, 200], [556, 290]];
    opipe(P(up, false), 64, WHITE, 0.32, 0.26, 1);
    { const sp = samp(up, 4); for (const k of [24, 60, 82, 104, 140, 166, 190, 214, 236]) { if (k >= sp.length) continue; const [x, y, tx, ty] = sp[k]; band(x, y, tx, ty, 70, 7); band(x + tx * 11, y + ty * 11, tx, ty, 70, 5); } }

    // ── ribbed copper hose ──
    const hose = [[505, 400], [540, 432], [548, 492], [516, 548], [440, 578], [340, 585], [260, 592], [212, 610], [190, 640]];
    opipe(P(hose, false), 76, '#a87250', 0.36, 0.2, 2);
    { const sp = samp(hose, 3); for (let k = 0; k < sp.length; k += 6) { const [x, y, tx, ty] = sp[k]; R.groove(P([[x - ty * 39, y + tx * 39], [x + ty * 39, y - tx * 39]], false), 5, '#2a140c', 0.56, 0.14, 2, 1); } }

    // ── robot head + collar ──
    R.pipe(P([[300, 200], [282, 180], [276, 160], [290, 150]], false), 4, '#b06030', 0.3, 0.04, 3);
    R.pipe(P([[440, 200], [460, 180], [462, 160], [450, 150]], false), 4, '#b06030', 0.3, 0.04, 3);
    R.pipe(P([[310, 230], [276, 240], [268, 262]], false), 4, '#b06030', 0.3, 0.04, 3);
    R.pipe(P([[430, 230], [466, 240], [470, 262]], false), 4, '#b06030', 0.3, 0.04, 3);
    R.bead(301, 198, 10, '#e8e8e8', 0.3, 0.08, 1); R.bead(447, 198, 10, '#e8e8e8', 0.3, 0.08, 1);
    R.bead(370, 185, 48, '#f2f0ec', 0.3, 0.22, 1);
    R.dome(ellipseP(370, 128, 58, 17, 0), '#a83030', 0.42, 0.06, 8, 2);
    R.dome(ellipseP(370, 120, 50, 10, 0), '#c04040', 0.46, 0.04, 6, 2);
    R.dome(rrect(304, 218, 132, 40, 10), '#9a9ea8', 0.4, 0.12, 10, 3);
    R.dome(rrect(330, 255, 80, 22, 4), '#80848e', 0.42, 0.08, 6, 3);
    // ── chrome / blue cylinder ──
    for (const c of [a, R.h]) c.lineCap = 'butt';
    R.pipe(P([[262, 331], [490, 331]], false), 120, '#9ea2ac', 0.42, 0.26, 3);
    R.pipe(P([[488, 331], [590, 331]], false), 116, '#2a90b0', 0.42, 0.26, 2);
    for (const [x, wd] of [[270, 16], [292, 10], [418, 14], [440, 14], [464, 14], [486, 10]]) R.pipe(P([[x - wd / 2, 331], [x + wd / 2, 331]], false), 128, '#b0b4bc', 0.44, 0.26, 3);
    for (const c of [a, R.h]) c.lineCap = 'round';
    R.dome(ellipseP(592, 331, 20, 57, 0), '#2a90b0', 0.5, 0.12, 14, 2);
    R.flat(P([[513, 282], [538, 282], [538, 318], [575, 318], [575, 344], [538, 344], [538, 388], [513, 388], [513, 344], [496, 344], [496, 318], [513, 318]], true, false), '#f4f6f6', 0.66, 2);
    R.groove(circleP(367, 357, 7), 6, '#141414', 0.66, 0.1, 3, 1);
    R.dome(rrect(322, 386, 90, 22, 6), '#d8d6d0', 0.36, 0.08, 8, 1);

    // ── egg tank ──
    R.dome(rrect(312, 640, 112, 22, 8), '#d4d4d0', 0.36, 0.1, 8, 1);
    R.dome(ellipseP(367, 778, 104, 126, 0), WHITE, 0.3, 0.3, 60, 1);
    R.groove(circleP(396, 857, 8), 14, '#101010', 0.5, 0.2, 1, 1);

    // ── spiral discs ──
    const spiral = (cx, cy, r) => {
      R.dome(circleP(cx, cy, r), '#e4e4e8', 0.4, 0.1, r * 0.4, 3);
      const pts = []; for (let i = 0; i <= 200; i++) { const t = i / 200, an = t * 6.283 * 5.5, rr = 3 + t * (r - 6); pts.push([cx + Math.cos(an) * rr, cy + Math.sin(an) * rr]); }
      R.groove(P(pts, false), 3.2, '#1a1a1e', 0.5, 0.06, 3, 1);
    };
    spiral(152, 555, 34); spiral(226, 715, 44); spiral(302, 812, 41);

    // ── snow globes + red cross button ──
    const globe = (cx, cy, rx, ry, fig) => {
      R.dome(ellipseP(cx, cy, rx + 6, ry + 6, 0), '#7a7e86', 0.2, 0.08, 6, 3);
      R.dome(ellipseP(cx, cy, rx, ry, 0), '#b4dcec', 0.24, 0.12, rx * 0.5, 5);
      fig();
    };
    R.dome(rrect(508, 912, 150, 98, 14), '#c4c8d0', 0.2, 0.12, 14, 3);
    R.groove(P([[512, 975], [654, 975]], false), 6, '#202226', 0.32, 0.08, 3, 1);
    R.dome(ellipseP(583, 922, 70, 22, 0), '#aeb2ba', 0.34, 0.06, 8, 3);
    globe(580, 848, 58, 66, () => {
      R.paint(ellipseP(582, 872, 28, 30, 0), '#e02020'); R.paint(circleP(582, 830, 14), '#f0c8a0'); R.paint(ellipseP(582, 822, 15, 9, 0), '#202020');
      R.paint(ellipseP(580, 905, 40, 8, 0), '#c06040');
    });
    R.dome(ellipseP(583, 932, 52, 16, 0), '#e03030', 0.4, 0.04, 6, 2);
    R.flat(P([[575, 922], [591, 922], [591, 928], [612, 928], [612, 936], [591, 936], [591, 942], [575, 942], [575, 936], [554, 936], [554, 928], [575, 928]], true, false), '#ffffff', 0.45, 2);
    globe(85, 948, 40, 48, () => { R.paint(ellipseP(80, 965, 22, 22, 0), '#202428'); R.paint(circleP(80, 940, 12), '#e0b090'); R.paint(ellipseP(80, 932, 13, 9, 0), '#303030'); R.paint(circleP(96, 965, 9), '#d02020'); });

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.35, coat: 0.18, ao: 0.5, rim: 0.2 }),                  // 1 white gloss / paint
        E.mat({ dif: 1, spec: 0.9, shin: 50, wrap: 0.3, coat: 0.12, ao: 0.4 }),                             // 2 coloured gloss
        E.mat({ dif: 0.7, metal: 0.45, spec: 1.1, shin: 60, rim: 0.3, ao: 0.4, emis: 0.08 }),                           // 3 chrome
        E.mat({ dif: 0.8, metal: 0.3, spec: 0.6, shin: 30, ao: 0.4, grain: 0.1 }),                          // 4 brass / stone
        E.mat({ dif: 0.9, spec: 1.2, shin: 90, coat: 0.25, ao: 0.1, emis: 0.2 })                             // 5 glass globe
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.82, 0.82, 0.8], amb: [0.36, 0.37, 0.38],
      envTop: [1.1, 1.1, 1.1], envHor: [0.62, 0.64, 0.64], envBot: [0.12, 0.14, 0.14], envK: [0.4, 1.0, 0.0, 0],
      rimC: [0.2, 0.22, 0.24], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 6, k: [0, 0.6, 0.4, 120], shadow: [-5, 6, 0.6, 6]
    });

    // ── ink outlines ──
    const o = E.out;
    const ink = (path, wd = 2.5) => { o.lineWidth = wd; o.strokeStyle = INK; o.lineJoin = o.lineCap = 'round'; o.stroke(path); };
    const outline = (pts, closed, wd) => { o.lineWidth = wd + 5; o.strokeStyle = INK; o.lineCap = o.lineJoin = 'round'; o.stroke(P(pts, closed)); };
    o.save(); o.globalCompositeOperation = 'destination-over'; o.restore();
        ink(ellipseP(367, 778, 104, 126)); ink(circleP(370, 185, 48)); ink(rrect(660, 58, 42, 664, 3));
        // face
    o.fillStyle = INK; for (const x of [354, 388]) { o.beginPath(); o.arc(x, 183, 5, 0, 6.283); o.fill(); }
    o.lineWidth = 2.5; o.strokeStyle = INK; o.beginPath(); o.arc(371, 196, 11, 0.4, 2.7); o.stroke();
    o.font = 'bold 13px Arial, sans-serif'; o.fillStyle = '#20242c'; o.textAlign = 'center'; o.fillText('SYNIFICAIND', 360, 326); o.fillStyle = '#f0f4f8'; o.fillText('PRHNNI', 588, 326);
    // egg hair scribbles
    { const r = rng(9); o.strokeStyle = 'rgba(30,30,30,0.7)'; o.lineWidth = 1.2; for (let i = 0; i < 24; i++) { const x = 330 + r() * 80, y = 740 + r() * 30; o.beginPath(); o.moveTo(x, y + 18); o.lineTo(x + (r() - 0.5) * 6, y - 4 - r() * 10); o.stroke(); } }
    E.bloom(0.08, 8);
    E.grain(0.04, 17);
  }
});
