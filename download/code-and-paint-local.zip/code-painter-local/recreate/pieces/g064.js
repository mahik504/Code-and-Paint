'use strict';
// g064 — "Grey camera spiral board": a monochrome relief — a grey shield plate with white spirals and black
// holes, ringed by a puffy white chain, a black/white spiral and a target on a starry black ground, a grey
// camera lens poking in from a sprayed red and blue edge, with a cyan eye at the bottom left.
REC.register('g064', {
  w: 726, h: 1024,
  draw(E) {
    // stripe fields first (WebGL) — spiral, target, plate spirals
    const SPF = `float spir(vec2 p){
        vec2 q = p - vec2(553., 108.); float r = length(q / vec2(1.15, 1.0)), th = atan(q.y, q.x);
        float n = (-12. + sqrt(144. + 10.4 * max(r - 22., 0.))) / 5.2;
        float big = fract(n + 0.17);
        if (r < 22.) big = fract(r / 6. - th / 6.2832);
        float s1 = smoothstep(0.0, 0.05, big) * (1. - smoothstep(0.32, 0.37, big));
        vec2 t = p - vec2(690., 565.); float rt = length(t / vec2(1.05, 1.0));
        float tg = fract((rt - 33.) / 43.);
        float s2 = (rt > 28. && rt < 190.) ? smoothstep(0.0, 0.04, tg) * (1. - smoothstep(0.4, 0.46, tg)) : 0.;
        const vec4 PS[3] = vec4[3](vec4(228., 522., 48., 7.5), vec4(346., 570., 55., 8.), vec4(266., 702., 46., 7.5));
        float s3 = 0.;
        for (int i = 0; i < 3; i++) { vec2 d = p - PS[i].xy; float rr = length(d);
          if (rr < PS[i].z) { float f = fract(rr / PS[i].w - atan(d.y, d.x) / 6.2832); s3 = smoothstep(0.45, 0.55, f) * (1. - smoothstep(0.9, 1.0, f)) * smoothstep(2., 6., rr); } }
        if (p.y < 340. && p.x > 300.) return s1;
        if (p.x > 480. && p.y > 340. && p.y < 800.) return s2;
        return s3; }`;
    const scv = E.fx(SPF + `vec3 fx(vec2 uv, vec2 p){ return vec3(mix(0.03, 0.95, spir(p))); }`);
    const shv = E.fx(SPF + `vec3 fx(vec2 uv, vec2 p){ return vec3(spir(p) * 0.06, 0., 0.); }`);

    const R = E.relief(), a = R.a, hx = R.h, S = E.S, o = E.out;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    // masked copy of a full-canvas layer, drawn without clipping the relief buffers (avoids a buffer wipe)
    const masked = (cv, ...paths) => { const c = E.newCanvas(), x = c.getContext('2d'); x.drawImage(cv, 0, 0); x.setTransform(S, 0, 0, S, 0, 0);
      for (const p of paths) { x.globalCompositeOperation = 'destination-in'; x.fillStyle = '#000'; x.fill(p); } return c; };
    const hAdd = (cv, ...paths) => { const m = masked(cv, ...paths); hx.save(); hx.setTransform(1, 0, 0, 1, 0, 0); hx.globalCompositeOperation = 'lighter'; hx.drawImage(m, 0, 0); hx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x, x0, y0, x1, y1, st) => { const g = x.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const WH = '#f0f0ee', GR = '#8a8a8c', DG = '#5a5a5e';

    // ── black ground ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#070707', 0, 0);

    // ── sprayed red / blue edge with white haze ──
    const BE = [[96, -10], [84, 20], [62, 50], [70, 90], [98, 130], [106, 200], [96, 250], [60, 296]];
    const blue = P([[-10, -10], ...BE, [-10, 306]], true, true);
    const red = P([[-10, 280], [80, 276], [130, 290], [200, 330], [180, 362], [262, 400], [230, 450], [160, 500], [150, 620], [150, 760], [146, 850], [128, 920], [126, 1040], [-10, 1040]], true, true);
    const off = (pts, d) => pts.map(([x, y]) => [x + d, y]);
    const redBand = P([...off(BE, -2), ...off(BE, 18).reverse()], true, true);
    const whiteBand = P([[300, -10], [300, 12], [200, 18], [150, 30], [126, 60], [130, 110], [150, 140], [140, 190], [146, 240], [136, 280], ...off(BE, 14).reverse().slice(1)], true, true);
    R.paint(red, '#fd0a04');
    soft(x => { x.fillStyle = '#fd0a04'; x.fill(red); }, 4, 1);
    soft(x => { x.fillStyle = '#f2eeee'; x.fill(whiteBand); x.fill(ellipseP(160, 84, 34, 40, 0)); x.lineWidth = 14; x.strokeStyle = '#f2eeee'; x.stroke(P([[150, 520], [156, 620], [156, 760], [152, 850], [134, 920], [132, 1040]], false)); }, 2.5, 1);
    soft(x => { x.fillStyle = '#f61a24'; x.fill(redBand); }, 2.5, 1);
    soft(x => { x.fillStyle = '#0466f6'; x.fill(blue); }, 2, 1);
    soft(x => { x.fillStyle = '#c02a6a'; x.fill(ellipseP(40, 300, 70, 24, 0)); }, 14, 0.8);
    { const r = rng(5); a.fillStyle = '#e8e4e4';
      for (let i = 0; i < 2600; i++) { const t = r(), side = r() < 0.4;
        const x = side ? 150 + (r() - 0.3) * 30 + Math.sin(t * 9) * 8 : 156 + (r() - 0.2) * 34, y = side ? t * 300 : 500 + t * 540;
        a.globalAlpha = 0.25 + r() * 0.6; a.fillRect(x, y, 1.2, 1.2); }
      a.globalAlpha = 1; }
    soft(x => { x.fillStyle = '#070707'; x.fill(P([[176, 50], [196, 76], [190, 108], [166, 116], [148, 104], [150, 86], [166, 92], [176, 80], [170, 62]], true, true)); }, 1.5, 1);
    // cyan eye in the red corner
    R.dome(ellipseP(10, 990, 110, 160, -0.35), '#080808', 0.02, 0.04, 6, 1);
    R.dome(ellipseP(4, 1000, 92, 140, -0.35), WH, 0.04, 0.06, 10, 1);
    R.dome(ellipseP(30, 975, 26, 56, -0.35), '#2ee0f0', 0.08, 0.04, 8, 1);
    keep();

    // ── stars ──
    { const r = rng(9), zones = [[150, 20, 300, 230], [430, 860, 296, 164], [160, 880, 260, 144], [600, 820, 126, 120]];
      for (const [x0, y0, w, h] of zones) for (let i = 0; i < 22; i++) R.bead(x0 + r() * w, y0 + r() * h, 2 + Math.pow(r(), 2.5) * 10, WH, 0.04, 0.1, 1);
      for (const [x, y, rr] of [[208, 160, 11], [287, 157, 9], [245, 67, 8], [297, 78, 6], [341, 109, 9], [238, 215, 8], [212, 905, 7], [235, 945, 10], [270, 975, 9], [690, 890, 12], [650, 930, 9], [616, 980, 10], [560, 1000, 8], [700, 960, 9], [672, 1000, 6]])
        R.bead(x, y, rr, WH, 0.04, 0.12, 1); }
    R.pipe(circleP(262, 377, 11), 5, WH, 0.06, 0.06, 1);
    keep();

    // ── top spiral and right target (white raised bands) ──
    const spiralD = ellipseP(560, 108, 240, 226, 0);
    const spClip = new Path2D(); spClip.addPath(P([[300, -10], [740, -10], [740, 330], [640, 336], [300, 336]], true, false));
    img(masked(scv, spClip, spiralD));
    hAdd(shv, spClip, spiralD);
    const target = ellipseP(690, 565, 196, 190, 0);
    img(masked(scv, target));
    hAdd(shv, target);
    keep();

    // ── right side props: lamp, blimp, seed pod ──
    R.pipe(P([[700, -10], [704, 60], [714, 130], [726, 200]], false), 26, GR, 0.12, 0.12, 3);
    R.dome(P([[668, 70], [700, 50], [726, 56], [726, 120], [700, 118], [676, 100]], true, true), '#9a9a9c', 0.2, 0.1, 10, 3);
    const blimp = ellipseP(690, 318, 34, 112, -0.12);
    R.dome(blimp, '#b4b4b6', 0.14, 0.18, 30, 2);
    clipA(blimp, () => { const r = rng(15); a.fillStyle = '#2a2a2c'; for (let i = 0; i < 160; i++) { a.globalAlpha = 0.5 + r() * 0.5; a.fillRect(660 + r() * 60, 210 + r() * 220, 1.5 + r() * 2, 1.5 + r() * 2); } a.globalAlpha = 1;
      a.strokeStyle = '#6a6a6c'; a.lineWidth = 2; for (const dx of [-14, 0, 14]) { a.beginPath(); a.moveTo(690 + dx + 12, 210); a.lineTo(690 + dx - 14, 430); a.stroke(); } });
    R.dome(ellipseP(626, 376, 44, 13, -0.05), '#a8a8aa', 0.14, 0.06, 6, 2);
    R.pipe(P([[592, 376], [626, 370], [660, 376]], false), 4, '#202022', 0.2, 0.02, 2);
    R.bead(626, 374, 6, WH, 0.2, 0.04, 1);
    R.pipe(P([[612, 168], [630, 196], [646, 214]], false), 8, '#8a6a4a', 0.12, 0.06, 2);
    keep();

    // ── grey figurine cluster above the plate ──
    { const r = rng(17);
      for (const [x, y, rx, ry] of [[430, 400, 26, 18], [470, 410, 30, 16], [520, 420, 34, 18], [450, 380, 14, 18], [486, 386, 16, 10], [540, 378, 12, 20], [408, 430, 30, 10], [500, 440, 60, 14], [436, 360, 8, 14], [552, 352, 14, 8]])
        R.dome(P(blob(x, y, rx, ry, Math.floor(r() * 99), 10, 0.25)), '#9a9a9c', 0.12, 0.1, Math.min(rx, ry) * 0.8, 2);
      for (const [x0, y0, x1, y1] of [[426, 344, 430, 380], [470, 360, 478, 330], [412, 376, 398, 360], [500, 370, 520, 346]]) R.pipe(P([[x0, y0], [x1, y1]], false), 3, WH, 0.2, 0.04, 2);
      for (const [x, y] of [[530, 422], [548, 430], [560, 410], [520, 440]]) R.bead(x, y, 3, '#222', 0.25, 0.02, 2); }
    keep();

    // ── grey shield plate ──
    const plate = P([[160, 470], [210, 456], [300, 462], [400, 470], [470, 462], [548, 452], [570, 520], [560, 600], [532, 690], [494, 760], [448, 812], [398, 852], [350, 878], [296, 856], [240, 818], [198, 766], [168, 700], [154, 610], [150, 530]], true, true);
    R.dome(plate, lin(a, 150, 460, 560, 880, [[0, '#7e7e80'], [0.5, '#6e6e70'], [1, '#606062']]), 0.08, 0.1, 18, 2);
    R.pipe(plate, 12, '#9a9a9c', 0.16, 0.06, 2);
    R.groove(P([[178, 500], [180, 620], [196, 730], [250, 806], [340, 856]], false), 4, '#4a4a4c', 0.18, 0.04, 2, 0.8);
    // grey drips along the top edge
    { const r = rng(23); for (let i = 0; i < 14; i++) { const x = 230 + i * 24 + r() * 10, y = 440 + r() * 24; R.dome(P(blob(x, y, 14 + r() * 12, 10 + r() * 8, 50 + i, 10, 0.3)), '#909092', 0.14, 0.08, 8, 2); } }
    // black holes
    for (const [x, y, rr] of [[432, 612, 28], [480, 626, 26], [456, 660, 30], [500, 676, 18], [424, 656, 16]]) R.flat(circleP(x, y, rr), '#050505', 0.02, 0);
    // spirals on the plate
    for (const [x, y, rr] of [[228, 522, 48], [346, 570, 55], [266, 702, 46]]) {
      const c = circleP(x, y, rr);
      R.dome(c, null, 0.12, 0.04, 6, 1);
      img(masked(scv, c));
      hAdd(shv, c);
      R.pipe(circleP(x, y, rr + 3), 6, '#6a6a6c', 0.16, 0.04, 2);
    }
    // grey squiggles
    for (const [pts, wd] of [
      [[[318, 640], [340, 622], [372, 628], [388, 610], [378, 594]], 16], [[[268, 612], [292, 618], [306, 610]], 12],
      [[[250, 646], [300, 660], [330, 650]], 10],
      [[[280, 740], [300, 722], [330, 726], [338, 756], [318, 786], [326, 812], [356, 808]], 20],
      [[[392, 728], [420, 712], [448, 726], [440, 760], [410, 776], [418, 806], [446, 812]], 18],
      [[[300, 520], [330, 506], [360, 510]], 8], [[[420, 520], [460, 540], [500, 530], [530, 560]], 12]])
      R.pipe(P(pts, false), wd, '#9c9c9e', 0.18, 0.08, 2);
    keep();

    // ── camera lens ──
    const lensB = P([[-10, 352], [96, 342], [128, 350], [134, 548], [100, 560], [-10, 566]], true, true);
    R.dome(lensB, lin(a, 0, 340, 0, 566, [[0, '#9a9a9c'], [0.3, '#7a7a7c'], [0.6, '#5a5a5c'], [1, '#3a3a3c']]), 0.12, 0.2, 40, 3);
    for (const x of [8, 22, 36, 50]) R.groove(P([[x, 352], [x + 2, 566]], false), 6, '#2a2a2c', 0.32, 0.12, 3, 0.9);
    R.dome(rrect(86, 350, 64, 72, 6), '#7c7c7e', 0.2, 0.12, 8, 3);
    R.pipe(P([[100, 350], [92, 312], [98, 276], [126, 252], [160, 240]], false), 6, '#a0a0a2', 0.24, 0.04, 3);
    keep();

    // ── puffy white chain ──
    const chain = [[184, 276, 40], [240, 282, 36], [298, 278, 38], [354, 280, 34], [410, 272, 36], [462, 262, 38], [516, 252, 38], [572, 248, 36], [624, 246, 30],
      [204, 320, 44], [176, 370, 34], [150, 410, 30], [124, 450, 30], [114, 490, 30], [108, 530, 32],
      [110, 572, 34], [120, 620, 38], [144, 672, 34], [152, 724, 34], [166, 770, 36], [196, 806, 36], [236, 840, 40], [280, 868, 40], [322, 898, 40],
      [366, 926, 40], [404, 940, 38], [452, 914, 38], [496, 894, 42], [540, 882, 40], [578, 880, 30]];
    R.pipe(P([[184, 276], [300, 280], [410, 272], [520, 252], [628, 246]], false), 66, WH, 0.1, 0.16, 1);
    R.pipe(P([[204, 300], [176, 370], [124, 450], [108, 530], [120, 620], [150, 700], [166, 770], [236, 840], [322, 898], [404, 940], [496, 894], [578, 880]], false), 56, WH, 0.1, 0.16, 1);
    for (const [x, y, rr] of chain) R.bead(x, y, rr + 4, WH, 0.12, 0.22, 1);
    for (const [x, y, rr] of [[600, 830, 30], [690, 760, 30], [660, 770, 22]]) R.bead(x, y, rr, WH, 0.12, 0.2, 1);
    keep();

    // ── lower-right grey cylinders ──
    R.pipe(P([[494, 790], [560, 768], [646, 752]], false), 46, '#8c8c8e', 0.16, 0.2, 3);
    for (const x of [540, 556, 572]) R.groove(P([[x, 750], [x + 8, 794]], false), 4, '#3a3a3c', 0.34, 0.08, 3, 0.9);
    R.pipe(P([[500, 760], [530, 720], [560, 696], [590, 690]], false), 34, '#9a9a9c', 0.2, 0.18, 3);
    R.dome(rrect(486, 770, 50, 70, 8), '#c8c8c8', 0.2, 0.08, 8, 2);
    clipA(rrect(486, 770, 50, 70, 8), () => { const r = rng(31); a.fillStyle = '#1a1a1a'; for (let i = 0; i < 60; i++) a.fillRect(488 + r() * 46, 772 + r() * 66, 1 + r() * 3, 1 + r() * 3); });
    R.dome(rrect(646, 722, 100, 76, 36), WH, 0.14, 0.2, 30, 1);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.35, ao: 0.5, coat: 0.15, rim: 0.2 }),               // 1 glossy white
        E.mat({ dif: 1, spec: 0.45, shin: 28, wrap: 0.45, ao: 0.6, rim: 0.15 }),                         // 2 grey satin
        E.mat({ dif: 0.7, metal: 0.45, spec: 1.0, shin: 40, ao: 0.5, rim: 0.2 })                         // 3 grey metal
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.9, 0.9, 0.9], amb: [0.32, 0.32, 0.33],
      envTop: [1.05, 1.05, 1.05], envHor: [0.5, 0.5, 0.52], envBot: [0.06, 0.06, 0.06], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.2, 0.2, 0.2], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 90], shadow: [-5, 7, 0.75, 7]
    });
    E.bloom(0.06, 8);
    E.grain(0.035, 64);
  }
});
