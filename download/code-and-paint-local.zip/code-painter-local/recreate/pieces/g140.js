'use strict';
// g140 — "Moonstruck zebra singer": a flat grey figure with zebra-striped hair throws its head back and sings
// under a crescent moon — sky-blue starfield, a royal-blue moon blob with a navy hole, a red flame, zebra waves.
REC.register('g140', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, x1 = x, y1 = y) => { const g = a.createRadialGradient(x1, y1, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true);
    const op = pts => P(pts, false, true);
    const CR = '#fbf9ee';
    const line = (pts, wd, col = CR, h = 0.1) => R.pipe(op(pts), wd, col, h, 0.03, 1);
    const zfx = (expr, dark = [.02, .02, .025], light = [.985, .98, .93]) => E.fx(`vec3 fx(vec2 uv, vec2 p){ float u = (p.x - 363.) / 512., v = (p.y - 512.) / 512.;
      float ph = ${expr};
      float c = cos(6.2832 * ph); float k = 0.9 / max(fwidth(ph) * 6.2832, 1e-3); float t = clamp(0.5 + c * min(k, 6.) * 0.5, 0., 1.);
      return mix(vec3(${dark}), vec3(${light}), t); }`);

    // ── backgrounds: black night (top left), sky blue, grey glow (top right) ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#0c0c0b', 0, 0);
    R.flat(P([[-10, 252], [140, 260], [240, 272], [330, 280], [366, 330], [380, 480], [200, 520], [120, 700], [90, 800], [-10, 800]], true, false), '#0789ec', 0.02, 0);
    soft(x => { x.fillStyle = '#e4e2de'; x.fill(circleP(660, 60, 50)); }, 30, 0.5);
    // crescent moon
    const moon = P([[30, 54], [12, 74], [0, 104], [-6, 140], [4, 176], [30, 206], [66, 230], [104, 244], [140, 242], [138, 194], [118, 182], [86, 172], [56, 160], [40, 144], [32, 126], [30, 96], [34, 66]], true, true);
    R.dome(moon, CR, 0.06, 0.04, 6, 1);
    // stars
    for (const [x, y, r] of [[62, 312, 20], [138, 358, 13], [124, 432, 16], [118, 300, 5], [82, 478, 4], [305, 357, 7], [70, 56, 4]]) R.dome(circleP(x, y, r), CR, 0.06, 0.03, 4, 1);
    { const s4 = []; for (let i = 0; i < 8; i++) { const t = i / 8 * 6.283 - 1.2, r = i % 2 ? 21 : 44; s4.push([205 + Math.cos(t) * r, 392 + Math.sin(t) * r * 0.95]); } R.dome(P(s4, true, true), CR, 0.06, 0.04, 6, 1); }

    // ── royal blue moon blob with its eye and navy hole ──
    const blob = sm([[408, -20], [600, -30], [760, -30], [760, 232], [736, 300], [690, 310], [666, 330], [640, 400], [646, 460], [650, 520], [640, 580],
      [618, 640], [590, 690], [540, 732], [500, 766], [470, 800], [452, 832], [442, 856], [420, 840], [400, 760], [396, 680], [410, 600], [450, 520], [520, 440], [600, 340], [560, 300], [500, 250], [440, 180], [410, 100]]);
    R.flat(blob, null, 0.04, 0);
    soft(x => { x.fillStyle = '#3048d4'; x.fill(blob); }, 10, 1);
    soft(x => { x.fillStyle = '#bebcbc'; x.fill(ellipseP(706, 60, 96, 150, -0.1)); }, 30, 1);
    clipA(blob, () => soft(x => { x.fillStyle = '#3a4ccc'; x.fill(P([[400, -10], [560, -10], [560, 300], [400, 300]], true, false)); x.fillStyle = '#2442dc'; x.fill(P([[380, 400], [700, 400], [700, 900], [380, 900]], true, false)); }, 60, 0.8));
    R.dome(ellipseP(532, 628, 64, 98, 0.22), '#0a0a7c', 0.05, 0.02, 10, 1);
    R.dome(ellipseP(514, 140, 21, 24, 0.2), CR, 0.06, 0.04, 6, 1); R.flat(circleP(513, 138, 10), '#08080a', 0.1, 0);
    R.flat(circleP(630, 127, 7), '#08080a', 0.04, 0);
    // zebra waves (right + bottom)
    const zr = sm([[668, 296], [736, 262], [736, 1044], [416, 1044], [418, 940], [430, 880], [452, 832], [480, 796], [540, 750], [596, 700], [632, 620], [652, 500], [640, 420], [646, 350]]);
    R.flat(zr, null, 0.04, 0);
    clipA(zr, () => img(zfx('-1.77530 +3.96561*u +9.88134*v -15.43335*u*u +2.26698*u*v +7.43978*v*v +25.31892*u*u*u -16.20972*u*u*v -2.88388*u*v*v -4.08352*v*v*v -8.38469*u*u*u*u +17.72386*u*u*u*v -9.54783*u*u*v*v +5.56963*u*v*v*v -1.24886*v*v*v*v')));
    R.flat(P([[700, 770], [736, 770], [736, 1044], [692, 1044]], true, false), '#fefdf1', 0.04, 0);

    // ── red flame ──
    const flame = sm([[612, 316], [604, 340], [594, 368], [576, 400], [534, 432], [480, 464], [450, 496], [426, 528], [412, 560], [400, 592], [390, 624], [384, 656], [384, 700], [388, 750], [394, 790], [404, 820], [414, 848],
      [398, 836], [372, 790], [362, 750], [350, 700], [344, 650], [342, 600], [348, 550], [360, 506], [380, 466], [416, 430], [460, 400], [530, 368], [566, 350], [596, 330]]);
    R.pipe(flame, 10, CR, 0.06, 0.03, 1);
    R.flat(flame, '#fa0a0c', 0.08, 0);

    // ── grey figure ──
    const body = sm([[156, 496], [200, 484], [252, 476], [304, 468], [336, 452], [346, 420], [352, 380], [360, 340], [330, 320], [312, 280], [300, 230], [306, 196], [336, 178], [372, 150], [400, 140],
      [430, 170], [456, 206], [486, 240], [520, 270], [560, 296], [606, 304], [612, 320], [600, 334], [566, 352], [530, 370], [462, 400], [420, 432], [384, 464], [364, 500], [352, 540], [344, 600],
      [344, 660], [350, 720], [362, 760], [374, 790], [398, 830], [420, 856], [424, 900], [418, 960], [416, 1044], [190, 1044], [162, 960], [132, 896], [108, 832], [90, 768], [76, 720], [66, 660], [70, 600], [88, 560], [116, 524]]);
    R.pipe(body, 12, CR, 0.06, 0.03, 1);
    R.dome(body, lin(100, 500, 400, 1000, [[0, '#bcb8b5'], [0.5, '#b8b4b1'], [1, '#b4b0ad']]), 0.08, 0.03, 10, 1);
    // hair
    const hair = sm([[124, -30], [410, -30], [406, 60], [400, 118], [372, 146], [338, 176], [306, 198], [300, 230], [300, 262], [260, 270], [220, 272], [180, 270], [148, 262], [126, 244], [138, 214], [118, 186], [100, 150], [98, 100], [108, 40]]);
    R.pipe(hair, 14, CR, 0.06, 0.03, 1);
    R.flat(hair, null, 0.08, 0);
    // hair stripes fan out from the crown (fitted: an angle term about (215, 290) plus a cubic warp)
    clipA(hair, () => img(zfx('78.95438 -37.74874 * ((mod(atan(p.y - 290., p.x - 215.) - 1.57, 6.28318) + 1.57) / 6.28318) +145.41399*u +64.08226*v -85.89893*u*u +217.10584*u*v +25.44215*v*v -42.20447*u*u*u -76.05082*u*u*v +96.58756*u*v*v -0.12724*v*v*v')));
    // little zebra curl (beard) under the chin
    const curl = sm([[262, 444], [270, 420], [300, 410], [334, 404], [352, 380], [360, 404], [348, 436], [320, 452], [290, 462], [266, 460]]);
    R.pipe(curl, 8, CR, 0.08, 0.03, 1);
    R.flat(curl, null, 0.09, 0);
    clipA(curl, () => img(zfx('(p.x * 0.8 + p.y * 0.6) / 16.')));

    // ── face details ──
    const eye = sm([[310, 232], [326, 212], [350, 206], [372, 214], [368, 236], [350, 252], [326, 254]]);
    R.pipe(eye, 6, CR, 0.1, 0.03, 1); R.flat(eye, '#c8c4c0', 0.09, 0);
    clipA(eye, () => { for (let i = 0; i < 8; i++) line([[316 + i * 6, 252], [312 + i * 6, 226]], 2, '#e8e6e0'); });
    R.flat(circleP(343, 234, 8), '#08080a', 0.1, 0);
    line([[318, 208], [338, 196], [360, 196], [380, 206]], 5);
    line([[402, 150], [420, 160], [432, 176], [424, 190], [438, 204], [432, 222], [448, 236], [448, 252], [436, 262], [418, 258], [400, 248]], 5);
    line([[406, 166], [420, 172], [416, 184]], 4);
    line([[318, 300], [334, 316], [352, 326], [366, 336]], 6);
    // open mouth
    const mouth = new Path2D(); mouth.addPath(ellipseP(0, 0, 38, 24, 0), new DOMMatrix().translate(466, 291).rotate(-28));
    R.pipe(mouth, 12, CR, 0.1, 0.03, 1); R.flat(mouth, '#060608', 0.08, 0);
    line([[452, 252], [470, 246], [492, 250]], 5);
    line([[500, 290], [526, 300], [560, 316], [596, 332]], 6);

    // ── body contour lines ──
    line([[350, 334], [372, 360], [388, 380], [400, 400]], 6);
    line([[300, 474], [276, 482], [244, 490]], 5);
    line([[244, 552], [232, 580], [224, 620], [222, 660], [230, 700], [246, 740]], 6);
    line([[272, 592], [262, 610], [266, 632], [282, 640]], 5);
    R.dome(circleP(268, 624, 14), CR, 0.1, 0.03, 4, 1); R.flat(circleP(268, 624, 8), '#08080a', 0.12, 0);
    line([[184, 734], [204, 760], [216, 800], [222, 850], [226, 900], [232, 960], [240, 1030]], 7);
    line([[248, 790], [290, 806], [330, 808], [360, 800]], 6);
    line([[290, 916], [330, 940], [370, 950], [410, 954]], 6);
    line([[130, 610], [140, 660], [150, 700]], 5);

    // ── black corner with a chrome rim (bottom left) ──
    const corner = P([[-10, 586], [0, 586], [20, 650], [44, 720], [80, 800], [120, 900], [170, 1044], [-10, 1044]], true, false);
    R.flat(corner, '#040404', 0.06, 0);
    R.pipe(op([[0, 600], [22, 660], [46, 726], [82, 806], [122, 906], [166, 1040]]), 9, '#a8a8b0', 0.1, 0.06, 2);
    R.pipe(op([[0, 640], [30, 720], [70, 830]]), 3, '#c84040', 0.1, 0.02, 2);
    { const r = rng(140); for (let i = 0; i < 30; i++) R.bead(r() * 110, 640 + r() * 380, 0.8 + r() * 1.2, '#d8d8e0', 0.08, 0.01, 0); }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.12, shin: 14, wrap: 0.7, ao: 0.2 }),                               // 1 flat matte paint
        E.mat({ dif: 0.4, metal: 0.6, spec: 1.2, shin: 70, rim: 0.2, ao: 0.3 }),                   // 2 chrome rim
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.35, 0.35, 0.35], amb: [0.78, 0.78, 0.78],
      envTop: [1.1, 1.1, 1.15], envHor: [0.6, 0.6, 0.66], envBot: [0.08, 0.08, 0.1], envK: [0.5, 1.2, 0, 0],
      r1: 1.2, r2: 5, k: [0, 0.6, 0.4, 90], shadow: [-3, 4, 0.25, 6]
    });
    E.grain(0.015, 140);
  }
});
