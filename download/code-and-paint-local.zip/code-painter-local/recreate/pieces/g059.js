'use strict';
// g059 — "Warbler zebra collage": a flat cut-out collage — salmon pink field with olive discs and steel
// pyramids, a paint can, a speckled pear, a yellow warbler over a zebra fan, an orange tablet and a dotted ball.
REC.register('g059', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S, r = rng(59);
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const F = (path, c) => { o.fillStyle = c; o.fill(path); };
    const K = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const FK = (path, c, wd = 2.5) => { F(path, c); K(path, '#101010', wd); };
    const C = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const B = (px, fn) => { o.save(); o.filter = `blur(${px * S}px)`; fn(); o.restore(); };
    const poly = pts => P(pts, true, false);
    const lin = (x0, y0, x1, y1, st) => { const g = o.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const speck = (path, n, seed, col, rmax, box) => C(path, () => { const q = rng(seed); for (let i = 0; i < n; i++) F(circleP(box[0] + q() * box[2], box[1] + q() * box[3], 0.5 + q() * rmax), col); });
    const shadow = (path, dx = 6, dy = 8) => { o.save(); o.translate(dx, dy); B(4, () => F(path, 'rgba(60,40,40,0.35)')); o.restore(); };

    // ── white graph paper ──
    F(rrect(0, 0, 726, 1024, 0), '#fbfbfa');
    for (let x = 0; x < 726; x += 22) K(P([[x, 0], [x, 1024]], false), 'rgba(150,170,210,0.25)', 1);
    for (let y = 0; y < 1024; y += 22) K(P([[0, y], [726, y]], false), 'rgba(150,170,210,0.25)', 1);

    // ── salmon field ──
    const pink = P([[-5, 236], [60, 180], [120, 110], [165, 52], [250, 12], [330, 4], [440, 20], [470, 60], [480, 130], [470, 220], [470, 300], [460, 380], [420, 430], [330, 462], [220, 470], [120, 478], [40, 470], [-5, 470]], true, false);
    F(pink, '#f4a596');
    K(P([[-5, 236], [60, 180], [120, 110], [165, 52], [250, 12]], false), '#101010', 2.5);
    // white paper strip, blue balls
    FK(poly([[72, -5], [120, -5], [168, 92], [150, 104]]), '#ffffff', 2);
    FK(circleP(105, 85, 15), '#2a5ad8', 2); F(circleP(100, 80, 5), '#ffffff');
    for (const [x, y, rr] of [[46, 94, 4], [62, 40, 3], [8, 76, 3]]) F(circleP(x, y, rr), '#2a5ad8');

    // olive discs + steel pyramids on the pink
    const disc = (x, y, rr) => { FK(circleP(x, y, rr), '#a8a75a', 2); F(circleP(x, y, rr * 0.62), '#c6c47a'); K(circleP(x, y, rr * 0.62), 'rgba(40,40,20,0.6)', 1.5); };
    for (const [x, y, rr] of [[205, 50, 18], [242, 86, 16], [440, 66, 18], [96, 158, 11], [358, 220, 25], [356, 306, 25], [96, 354, 25], [122, 440, 28], [382, 360, 12], [390, 265, 8], [140, 382, 7], [600, 60, 10], [72, 196, 12]]) disc(x, y, rr);
    for (const [x, y, rr, c] of [[52, 280, 15, '#ffffff'], [320, 262, 12, '#d8dadc'], [80, 300, 6, '#5a6a78'], [312, 110, 6, '#5a6a78'], [400, 180, 6, '#5a6a78'], [400, 392, 6, '#5a6a78'], [422, 106, 7, '#5a6a78']]) FK(circleP(x, y, rr), c, 2);
    const pyr = (pts, apex) => { FK(poly(pts), '#5d7d92', 2.5); for (const p of pts) K(P([p, apex], false), 'rgba(20,30,40,0.7)', 1.5); F(poly([pts[0], pts[1], apex]), 'rgba(180,210,230,0.45)'); };
    pyr([[70, 258], [96, 206], [120, 258]], [98, 240]);
    pyr([[0, 322], [40, 360], [-5, 362]], [16, 350]);
    pyr([[164, 402], [238, 408], [204, 470]], [204, 422]);
    pyr([[268, 418], [312, 336], [380, 420]], [318, 398]);
    pyr([[330, 122], [386, 124], [358, 170]], [358, 136]);
    pyr([[408, 286], [470, 300], [432, 350]], [436, 310]);

    // black starry card
    const card = poly([[262, 52], [290, -5], [430, -5], [400, 96]]);
    FK(card, '#0a0a0a', 2.5);
    speck(card, 40, 3, '#ffffff', 2.4, [260, 0, 170, 100]);

    // paint can
    const can = P([[142, 136], [320, 168], [302, 342], [262, 362], [196, 352], [112, 304]], true, false);
    shadow(can, 8, 12);
    FK(can, lin(110, 0, 320, 0, [[0, '#7b8285'], [0.3, '#62696c'], [0.75, '#5c6366'], [1, '#4e5558']]), 3);
    speck(can, 16, 7, '#f4f4f4', 2.2, [120, 150, 190, 180]);
    FK(poly([[132, 150], [162, 156], [146, 318], [112, 304], [122, 220]]), '#ffffff', 2);
    FK(poly([[146, 262], [296, 286], [292, 318], [140, 296]]), '#ec6218', 2);
    o.save(); o.translate(160, 290); o.rotate(0.14); o.fillStyle = '#ffffff'; o.font = 'bold 16px sans-serif'; o.fillText('LOY KAUNOW', 0, 0); o.font = 'bold 12px sans-serif'; o.fillStyle = '#f4f0e0'; o.fillText('KEETVK', 2, -26); o.restore();
    const lid = ellipseP(230, 146, 92, 44, 0.18);
    FK(lid, '#e8eaea', 3); F(ellipseP(230, 150, 78, 34, 0.18), '#fbfbfb'); K(ellipseP(230, 150, 78, 34, 0.18), '#9aa0a2', 2);

    // hand reaching in from the top
    const hand = P([[384, 58], [430, 34], [480, 6], [500, -5], [640, -5], [640, 42], [570, 50], [520, 70], [480, 100], [446, 128], [432, 116], [458, 86], [424, 72], [386, 70]], true, true);
    FK(hand, '#fdf3e2', 2.5);

    // grey speckled grid board (right)
    const grid = poly([[444, 118], [580, 112], [731, 120], [731, 410], [620, 400], [540, 380], [480, 336], [452, 300]]);
    F(grid, pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 g = abs(fract(p / 13.) - 0.5); float ln = smoothstep(0.42, 0.5, max(g.x, g.y));
      float sp = step(0.86, hash(floor(p / 2.6))) * step(0.45, fbm(p * 0.05));
      float bl = smoothstep(0.55, 0.75, fbm(p * 0.03 + 4.));
      vec3 c = vec3(0.6, 0.59, 0.62) - 0.1 * ln - 0.28 * sp - 0.12 * bl;
      return c; }`)));
    K(grid, '#101010', 2);
    // camera
    FK(poly([[628, 40], [660, 0], [731, -5], [731, 160], [690, 162], [670, 130], [640, 110]]), '#3c3c40', 2.5);
    FK(rrect(642, 52, 90, 66, 10), '#5a5c62', 2);
    F(rrect(650, 60, 36, 50, 6), '#e4e6ea');
    for (const [x, c] of [[690, '#2a5ad8'], [704, '#f0c020'], [716, '#202024']]) F(rrect(x, 56, 10, 58, 3), c);
    FK(rrect(668, 130, 40, 30, 4), '#2a2a2e', 2);

    // pear
    const pear = P([[545, 40], [560, 82], [575, 130], [592, 180], [598, 228], [586, 270], [552, 300], [500, 304], [450, 290], [422, 254], [420, 210], [440, 166], [480, 128], [508, 96], [528, 48]]);
    FK(pear, '#cfde98', 3);
    speck(pear, 260, 11, '#20241a', 1.5, [415, 30, 190, 280]);
    FK(P([[536, 46], [540, 18], [552, 10]], false), 'rgba(0,0,0,0)', 0); K(P([[538, 48], [540, 20], [552, 8]], false), '#101010', 9); K(P([[538, 48], [540, 20], [552, 8]], false), '#cfde98', 5);
    FK(poly([[488, 296], [506, 296], [500, 334], [486, 334]]), '#ffffff', 2);

    // leafy green + top-right spotted blob
    FK(P([[618, 380], [630, 350], [652, 342], [668, 318], [690, 330], [712, 300], [731, 300], [731, 392], [660, 396]]), '#c4d890', 2);
    const spotBlob = (pts, seed, dots) => {
      const pth = P(pts); shadow(pth, 5, 7); FK(pth, '#faf3e2', 2.5);
      C(pth, () => {
        for (const [x, y, rr, t] of dots) {
          if (t) { F(circleP(x, y, rr), '#a8a050'); speck(circleP(x, y, rr), 30, seed + x, '#4a4620', 1.2, [x - rr, y - rr, rr * 2, rr * 2]); }
          else { F(circleP(x, y, rr), '#5c6a7c'); F(circleP(x, y, rr * 0.55), '#2a3040'); F(circleP(x - rr * 0.2, y - rr * 0.2, rr * 0.2), '#dfe4ea'); }
        }
        speck(pth, 120, seed, '#3a3a3a', 0.8, [300, 360, 430, 480]);
      });
    };
    spotBlob([[570, 424], [600, 396], [650, 386], [700, 384], [731, 394], [731, 492], [640, 490], [590, 472], [570, 450]], 21,
      [[628, 404, 16, 1], [672, 408, 14, 1], [640, 436, 12, 1], [605, 460, 10, 0], [690, 460, 14, 0], [650, 470, 8, 0], [716, 424, 7, 0]]);

    // ── zebra fan ──
    const zeb = P([[120, 480], [220, 470], [320, 462], [400, 432], [452, 396], [482, 420], [502, 480], [502, 620], [440, 640], [360, 720], [320, 800], [250, 780], [200, 745], [130, 740], [110, 700], [60, 640], [40, 580], [60, 520]], true, false);
    F(zeb, pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p - vec2(330., 1100.); float a = atan(q.x, -q.y); float rr = length(q);
      float ph = a * 120. / 6.2832 + 0.9 * sin(rr * 0.02 + a * 2.) + 0.7 * (fbm(p * 0.01) - 0.5);
      float s = cos(6.2832 * ph); float w = max(fwidth(s), 0.02);
      return mix(vec3(0.03), vec3(0.99), smoothstep(-0.05 - w, -0.05 + w, s)); }`)));
    K(zeb, '#101010', 2);

    // black starry patch + white robot tool + rope
    const sky = poly([[-5, 622], [50, 626], [120, 650], [150, 700], [132, 762], [60, 772], [-5, 770]]);
    FK(sky, '#0a0a0a', 2); speck(sky, 40, 5, '#ffffff', 2.2, [0, 590, 150, 180]);
    o.save(); o.translate(18, 760); o.rotate(-Math.PI / 2); o.fillStyle = '#f4f4f4'; o.font = 'bold 22px sans-serif'; o.fillText('uomo  AS', 0, 0); o.restore();
    FK(poly([[-5, 440], [40, 452], [64, 500], [60, 600], [-5, 600]]), '#3a3c42', 2);
    FK(poly([[-5, 470], [24, 476], [28, 560], [-5, 566]]), '#2a50c0', 2);
    for (let i = 0; i < 4; i++) F(poly([[-5, 480 + i * 22], [18, 490 + i * 22], [-5, 500 + i * 22]]), '#ec6218');
    const tool = P([[18, 392], [44, 378], [74, 432], [110, 500], [150, 540], [168, 580], [140, 594], [104, 560], [70, 520], [44, 470]], true, false);
    FK(tool, '#f6f6f6', 2.5);
    FK(rrect(-5, 520, 70, 44, 6), '#e8e8ea', 2);
    for (const [x, y, rr] of [[136, 556, 25], [80, 522, 18]]) { FK(circleP(x, y, rr), '#ffffff', 2); FK(circleP(x, y, rr * 0.6), '#202428', 2); F(circleP(x - 3, y - 3, rr * 0.18), '#dfe8f0'); }
    K(P([[30, 404], [36, 420]], false), '#101010', 2); K(P([[38, 430], [44, 444]], false), '#101010', 2);
    const rope = P([[106, 482], [150, 500], [190, 540], [210, 590], [196, 640], [170, 660], [180, 610], [214, 618], [222, 650], [180, 690], [120, 712], [70, 750]], false);
    K(rope, '#401808', 13); K(rope, '#c86a2a', 9); o.save(); o.setLineDash([4, 5]); K(rope, '#ffd0a0', 2); K(rope, '#7a3410', 1); o.restore();

    // ── orange tablet ──
    shadow(rrect(500, 490, 260, 346, 14), 8, 10);
    FK(rrect(500, 490, 260, 346, 14), '#f8f8f8', 2.5);
    FK(rrect(522, 510, 230, 292, 4), '#fd6806', 2);
    F(circleP(657, 600, 5), '#ffffff'); FK(circleP(700, 750, 16), '#ffffff', 1.5);
    o.fillStyle = '#ffffff'; o.font = 'bold 15px sans-serif'; o.fillText('EIO', 566, 540);
    K(P([[630, 576], [638, 590]], false), '#ffffff', 1.5);

    // ── warbler ──
    const wing = P([[292, 692], [360, 610], [430, 530], [486, 456], [512, 444], [500, 480], [450, 540], [380, 620]], true, false);
    FK(wing, '#c9cbc7', 2.5);
    K(P([[320, 660], [400, 580], [470, 500]], false), '#8a8c88', 1.5);
    const body = P([[440, 476], [480, 436], [520, 404], [548, 392], [556, 420], [544, 466], [510, 510], [470, 540], [446, 528]], true, false);
    FK(body, '#f6f6f2', 2.5);
    C(body, () => { for (let i = 0; i < 6; i++) K(P([[440 + i * 10, 520 - i * 16], [470 + i * 10, 500 - i * 16]], false), '#151515', 5); });
    F(P([[486, 470], [520, 418], [540, 420], [528, 470], [494, 512]]), '#f4e000');
    const headB = P([[462, 404], [480, 362], [510, 338], [546, 326], [586, 318], [562, 346], [548, 378], [526, 400], [498, 422]], true, false);
    FK(headB, '#0c0c0c', 2.5);
    F(P([[516, 360], [540, 336], [558, 336], [548, 360], [528, 376]]), '#f8e010');
    F(P([[528, 384], [552, 368], [552, 392], [534, 408]]), '#f8e010');
    F(circleP(536, 352, 3), '#ffffff');
    FK(poly([[560, 330], [586, 318], [566, 340]]), '#3a3a3a', 1.5);

    // ── spotted blobs over the zebra ──
    spotBlob([[320, 762], [334, 704], [372, 662], [424, 622], [462, 612], [500, 640], [502, 702], [470, 760], [428, 800], [380, 820], [332, 812]], 31,
      [[440, 630, 16, 0], [376, 672, 8, 0], [430, 668, 9, 0], [356, 716, 14, 1], [396, 696, 12, 0], [404, 742, 16, 1], [360, 790, 16, 1], [450, 712, 14, 0], [470, 670, 7, 0], [342, 760, 10, 0], [420, 776, 8, 0], [480, 740, 8, 0], [462, 776, 6, 0]]);
    spotBlob([[492, 652], [512, 626], [560, 618], [610, 620], [626, 642], [612, 690], [572, 724], [522, 728], [496, 702]], 41,
      [[546, 640, 15, 1], [592, 632, 7, 0], [612, 640, 6, 0], [528, 672, 9, 0], [568, 672, 12, 0], [604, 680, 9, 1], [540, 712, 9, 0], [512, 704, 6, 0]]);

    // grey leaf + dark boards
    const leaf = P([[328, 846], [420, 792], [520, 752], [600, 722], [690, 700], [664, 726], [568, 782], [470, 830], [380, 862]], true, true);
    FK(leaf, '#c8cac6', 2.5); K(P([[360, 840], [480, 790], [600, 740], [680, 706]], false), '#8a8c88', 1.5);
    FK(poly([[300, 846], [470, 812], [560, 790], [548, 966], [300, 966]]), '#4a4a4e', 2.5);
    FK(poly([[302, 880], [470, 820], [548, 806], [546, 856], [440, 886], [312, 934]]), '#5c5d60', 2);
    FK(poly([[484, 786], [536, 778], [548, 800], [534, 962], [484, 962]]), '#3e3f42', 2.5);
    FK(poly([[300, 880], [312, 934], [330, 960], [300, 960]]), '#2a2a2c', 2);
    // white paper + side strip, blue cloth, orange block
    FK(rrect(546, 852, 156, 180, 2), '#ffffff', 2.5);
    FK(rrect(420, 880, 30, 60, 2), '#f4f4f4', 1.5);
    F(rrect(690, 826, 40, 200, 0), pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 g = abs(fract(p / 13.) - 0.5); float ln = smoothstep(0.42, 0.5, max(g.x, g.y)); return vec3(0.6, 0.59, 0.62) - 0.1 * ln - 0.25 * step(0.85, hash(floor(p / 2.6))); }`)));
    FK(circleP(706, 830, 34), '#c8cacc', 2.5); F(circleP(706, 830, 16), '#e8eaec');
    const cloth = poly([[220, 962], [470, 946], [470, 1030], [220, 1030]]);
    FK(cloth, '#1037bd', 2.5); C(cloth, () => { for (let x = 222; x < 470; x += 7) K(P([[x, 950], [x + 4, 1030]], false), 'rgba(10,20,80,0.6)', 1.5); });
    FK(poly([[468, 950], [560, 946], [562, 1030], [468, 1030]]), '#f26a12', 2.5);
    for (const x of [458, 516]) { FK(rrect(x - 10, 938, 22, 22, 4), '#46484c', 2); F(circleP(x + 1, 949, 4), '#d8d8d8'); }

    // ── dotted ball ──
    const ball = circleP(156, 886, 146);
    FK(ball, '#8c7c70', 3);
    C(ball, () => {
      F(P([[0, 930], [50, 950], [80, 990], [110, 1030], [0, 1030]]), '#ec6a14');
      F(P([[0, 975], [40, 985], [60, 1030], [0, 1030]]), '#3e4a36');
      const br = rng(77);
      for (let gy = 0; gy < 10; gy++) for (let gx = 0; gx < 10; gx++) {
        const x0 = 8 + gx * 35 + (gy % 2) * 17, y0 = 744 + gy * 31, dx = x0 - 156, dy = y0 - 886, d = Math.hypot(dx, dy);
        if (d > 140) continue;
        const k = 1 - 0.35 * (d / 140) ** 2, x = 156 + dx * (0.85 + 0.15 * k), y = 886 + dy * (0.85 + 0.15 * k), rr = (10 + br() * 6) * k + 3;
        if (x < 70 && y > 950) continue;
        F(circleP(x, y, rr), '#e2eab4'); K(circleP(x, y, rr), '#4a4038', 1.5); o.save(); o.setLineDash([3, 3]); K(circleP(x, y, rr * 0.8), 'rgba(90,90,60,0.6)', 1); o.restore();
      }
    });
    FK(poly([[196, 722], [222, 716], [228, 750], [200, 752]]), '#c06a30', 2);
    // bottom-left bits
    FK(poly([[-5, 788], [30, 792], [30, 830], [-5, 832]]), '#c8d84a', 2);
    F(P([[-5, 950], [12, 940], [20, 1030], [-5, 1030]]), '#5a8a6a');

    E.grain(0.025, 59);
  }
});
