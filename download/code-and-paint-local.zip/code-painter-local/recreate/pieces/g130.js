'use strict';
// g130 — "Chrome gnome in the stars": a cream relief frame with a dripping chrome rim around a starry black
// window — a chain of white clay pearls, a chrome-horned helmet gnome with blue bead eyes, a gold beak and a
// striped chrome beard, a zebra fan tail ending in holed pearls, a chrome spoon and pod, striped dunes below.
REC.register('g130', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const F = (path, c) => { o.fillStyle = c; o.fill(path); };
    const K = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const C = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const B = (px, fn) => { o.save(); o.filter = `blur(${px * S}px)`; fn(); o.restore(); };
    const lin = (x0, y0, x1, y1, st) => { const g = o.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st, fx = x, fy = y) => { const g = o.createRadialGradient(fx, fy, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const BK = '#030305';
    const CHROME = [[0, '#1a1c22'], [0.18, '#7c8494'], [0.36, '#f4f8ff'], [0.5, '#b8c8de'], [0.62, '#5a6272'], [0.8, '#dfe6f0'], [1, '#2a2c34']];

    // chrome tube along a centreline: radius r0 -> r1, cut into ribbed bands with black seams
    const tube = (pts, r0, r1, bands, seam = 2.2, fill = null) => {
      const n = 80, cl = [];
      const path = P(pts, false, true);
      // resample the smooth centreline by sampling a Catmull-Rom spline manually
      const g = i => pts[Math.max(0, Math.min(pts.length - 1, i))];
      for (let k = 0; k <= n; k++) {
        const t = k / n * (pts.length - 1), i = Math.min(pts.length - 2, Math.floor(t)), u = t - i;
        const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2);
        const cr = (a, b, c, d) => 0.5 * (2 * b + (-a + c) * u + (2 * a - 5 * b + 4 * c - d) * u * u + (-a + 3 * b - 3 * c + d) * u * u * u);
        cl.push([cr(p0[0], p1[0], p2[0], p3[0]), cr(p0[1], p1[1], p2[1], p3[1])]);
      }
      const L = [], R = [];
      for (let k = 0; k <= n; k++) {
        const a = cl[Math.max(0, k - 1)], b = cl[Math.min(n, k + 1)];
        let dx = b[0] - a[0], dy = b[1] - a[1]; const m = Math.hypot(dx, dy) || 1; dx /= m; dy /= m;
        const r = r0 + (r1 - r0) * k / n;
        L.push([cl[k][0] - dy * r, cl[k][1] + dx * r]); R.push([cl[k][0] + dy * r, cl[k][1] - dx * r]);
      }
      const per = n / bands;
      for (let b = 0; b < bands; b++) {
        const k0 = Math.round(b * per), k1 = Math.min(n, Math.round((b + 1) * per));
        const quad = [...L.slice(k0, k1 + 1), ...R.slice(k0, k1 + 1).reverse()];
        const km = Math.round((k0 + k1) / 2);
        F(P(quad, true, false), fill ? fill(b) : lin(L[km][0], L[km][1], R[km][0], R[km][1], CHROME));
        if (seam > 0) K(P([L[k1], R[k1]], false, false), BK, seam);
      }
      K(P([...L, ...R.slice().reverse()], true, false), BK, 1.6);
      return path;
    };
    const pearl = (x, y, rx, ry = rx, rot = 0, refl = true) => {
      if (refl) B(2, () => F(ellipseP(x, y + ry * 1.25, rx * 0.85, ry * 0.32, rot), 'rgba(220,214,200,0.35)'));
      F(ellipseP(x + 3, y + 5, rx, ry, rot), 'rgba(0,0,0,0.6)');
      F(ellipseP(x, y, rx, ry, rot), rad(x, y, Math.max(rx, ry) * 1.05, [[0, '#fffdf6'], [0.55, '#f2eee2'], [0.85, '#d8d2c2'], [1, '#a8a294']], x - rx * 0.35, y - ry * 0.4));
    };

    // ── cream frame ──
    F(rrect(0, 0, 726, 1024, 0), lin(0, 0, 726, 0, [[0, '#ece8e2'], [0.04, '#d8d2ca'], [0.1, '#eeeae4'], [0.9, '#f4f2ee'], [1, '#f6f5f1']]));
    B(10, () => { F(rrect(0, 0, 40, 1024, 0), 'rgba(190,180,170,0.4)'); F(rrect(0, 0, 726, 30, 0), 'rgba(210,200,190,0.35)'); });

    // ── black window with a dripping chrome rim ──
    const win = P([[94, 60], [161, 46], [179, 55], [198, 75], [225, 78], [255, 59], [261, 41], [287, 40], [304, 42], [343, 33], [365, 39], [387, 57], [433, 41], [475, 50],
      [515, 42], [537, 51], [611, 40], [650, 46], [676, 70], [686, 120], [684, 200], [692, 270], [682, 390], [677, 435], [688, 504], [693, 533], [690, 600], [686, 700],
      [690, 780], [692, 860], [600, 880], [400, 890], [200, 890], [60, 880], [40, 780], [38, 700], [41, 524], [47, 444], [62, 400], [62, 329], [64, 235], [55, 154], [68, 84]], true, true);
    K(win, '#3a3634', 16); K(win, '#9a9490', 9); K(win, '#f8f6f2', 3);
    F(win, BK);

    // stars
    { const st = [153,58,3,310,75,6,424,81,4,472,84,4,400,84,4,276,89,2,350,91,4,434,90,2,88,100,3,237,110,2,227,115,6,374,113,3,459,113,2,131,129,7,474,142,4,598,142,4,
        107,144,3,119,145,4,299,145,4,155,152,9,322,147,4,425,158,2,260,161,4,289,166,6,342,163,2,513,167,2,552,169,2,397,172,6,224,175,4,110,178,2,616,177,2,650,180,4,
        176,187,4,581,189,4,339,193,2,88,219,5,602,250,3,81,267,4,81,294,2,601,307,3,456,318,4,105,321,6,272,319,2,112,335,3,523,340,4,106,342,5,497,342,2,578,343,4,
        460,348,2,529,355,3,260,364,7,96,375,2,513,377,5,675,382,8,245,381,4,453,383,3,79,387,7,476,384,2,537,385,2,623,393,8,224,390,2,590,398,3,664,400,2,468,402,3,
        77,417,4,444,416,2,545,418,2,425,425,4,460,426,2,657,439,6,581,439,2,476,451,2,551,459,3,534,466,4,555,470,2,525,483,2,489,492,2,666,496,7,445,501,4,486,506,2,
        60,517,3,475,529,2,528,532,2,421,534,2,503,537,5,81,558,4,496,558,2,59,577,6,427,580,4,647,588,10,517,582,2,675,593,6,536,599,4,568,602,5,461,601,2,53,613,12,
        681,609,7,454,612,2,412,613,2,79,618,6,662,622,6,489,622,2,63,627,4,530,626,2,679,634,9,647,632,4,52,646,6,653,649,4,71,655,6,685,656,4,676,661,6,43,669,6,
        683,672,6,54,677,4,67,681,3,38,686,6,677,685,6,664,695,5,44,706,9,653,702,3,663,735,12,39,732,7,39,756,3,659,761,4,648,781,7,634,797,4,651,810,10,637,832,4,
        686,450,5,684,470,4,48,562,10,226,570,0];
      for (let i = 0; i < st.length; i += 3) if (st[i + 2] > 0) {
        const [x, y, r] = [st[i], st[i + 1], st[i + 2] * 0.9];
        F(circleP(x, y, r), r > 4 ? rad(x, y, r, [[0, '#ffffff'], [0.6, '#eeeae4'], [1, '#a8a49c']], x - r * 0.3, y - r * 0.3) : '#f4f2ee');
      }
      // sand sprinkles under the pod and along the right edge
      const r = rng(130); o.fillStyle = '#d8d4cc';
      for (let i = 0; i < 260; i++) { const t = r(); const x = i < 70 ? 606 + r() * 14 : 676 + r() * 18, y = i < 70 ? 585 + r() * 50 : 440 + t * 400; o.beginPath(); o.arc(x, y, 0.8 + r() * 1.4, 0, 6.283); o.fill(); }
      for (let i = 0; i < 70; i++) { o.beginPath(); o.arc(612 + r() * 36, 672 + r() * 34, 0.8 + r() * 1.2, 0, 6.283); o.fill(); }
    }

    // ── spoon (top right) and chrome leaf ──
    tube([[540, 96], [590, 62], [640, 50], [668, 64], [684, 100], [684, 150], [674, 200], [662, 222]], 13, 9, 6, 1.2);
    const leaf = ellipseP(552, 96, 56, 21, -0.38);
    F(leaf, lin(500, 80, 600, 115, CHROME)); C(leaf, () => { for (let i = -5; i <= 5; i++) K(ellipseP(552, 96, 56 * (1 - Math.abs(i) / 7), 21, -0.38), 'rgba(10,10,14,0.65)', 1.2); }); K(leaf, BK, 2);
    F(ellipseP(552, 96, 30, 6, -0.38), '#1a1a20');
    const bowl = ellipseP(652, 282, 29, 80, 0.22);
    F(bowl, lin(620, 280, 690, 280, CHROME)); C(bowl, () => { for (let i = -6; i <= 6; i++) K(ellipseP(652 + i * 4.2, 282, 3, 80, 0.22), 'rgba(10,10,14,0.7)', 1.2); }); K(bowl, BK, 2);
    // striped pod
    const pod = ellipseP(611, 516, 24, 70, 0);
    F(pod, lin(587, 0, 635, 0, [[0, '#9a9690'], [0.4, '#f6f4ee'], [0.7, '#e0dcd4'], [1, '#6a6660']]));
    C(pod, () => { for (let i = -5; i <= 5; i++) K(P([[611 + i * 4.5, 446], [611 + i * 3.8, 590]], false), '#141418', 1.6); }); K(pod, '#2a2a2a', 1.5);

    // ── left zebra mound ──
    const mound = P([[-10, 900], [-10, 860], [20, 820], [50, 760], [90, 690], [130, 640], [170, 620], [205, 650], [232, 720], [262, 800], [290, 860], [300, 905], [262, 905]], true, true);
    F(mound, pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(185., 590.);
      float a = atan(d.x, d.y);
      float s = sin(a * 120. + 0.015 * length(d) + 2. * sin(p.y * 0.02));
      float k = smoothstep(0.55, 0.75, s);
      vec3 base = mix(vec3(0.95, 0.94, 0.92), vec3(0.8, 0.79, 0.77), smoothstep(-0.6, 0.4, d.x / 200.));
      return mix(base, vec3(0.06), k * 0.9); }`)));
    const sheet = P([[150, 930], [170, 860], [196, 790], [214, 740], [236, 790], [256, 870], [262, 930]], true, true);
    F(sheet, lin(160, 800, 260, 860, [[0, '#9a9894'], [0.4, '#e8e6e2'], [0.7, '#c8c6c2'], [1, '#f2f0ec']]));
    // ── zebra fan tail ──
    // fan: a bent accordion of black and white bands from under the beard round to the cuff
    tube([[196, 676], [204, 726], [228, 770], [266, 804], [314, 818], [356, 810], [384, 792]], 30, 52, 42, 0, b => b % 3 === 2 ? '#08080a' : '#f6f4ee');
    // ribbed chrome cuff + holed pearls
    tube([[374, 734], [386, 766], [396, 800], [404, 842]], 26, 24, 10, 2.4);
    pearl(577, 690, 42, 47, -0.3); pearl(507, 722, 45, 57, -0.25); pearl(446, 760, 48, 62, -0.35);
    F(ellipseP(507, 720, 11, 13, 0), BK); F(ellipseP(437, 752, 12, 14, 0), BK);

    // ── pearl chains ──
    for (const [x, y, r] of [[548, 252, 31], [490, 250, 32], [432, 250, 33], [373, 249, 32], [314, 249, 32], [256, 250, 32], [200, 250, 30]]) pearl(x, y, r, r * 1.05);
    tube([[208, 252], [172, 246], [146, 242], [126, 236], [116, 224], [122, 212], [134, 208], [142, 214]], 22, 3, 8, 1.6);
    for (const [x, y, r] of [[182, 318, 29], [168, 373, 31], [163, 428, 31], [158, 482, 30], [153, 535, 30], [150, 590, 31]]) pearl(x, y, r, r, 0, false);

    // ── gnome: little horn, big horn, helmet, face, eyes, beak, beard ──
    tube([[178, 522], [146, 524], [116, 518], [96, 506], [86, 492], [92, 482], [104, 486]], 20, 3, 7, 1.6);
    tube([[296, 462], [330, 430], [362, 398], [382, 366], [388, 340], [378, 322], [360, 318], [350, 332], [358, 342]], 52, 4, 15, 2.2);
    const face = circleP(265, 566, 76);
    F(face, rad(265, 566, 80, [[0, '#f2eebe'], [0.6, '#dcd69e'], [1, '#9a9468']], 240, 540));
    const helm = P([[182, 528], [184, 478], [200, 440], [236, 418], [288, 414], [326, 428], [344, 462], [344, 506], [342, 532], [300, 540], [240, 540]], true, true);
    F(helm, lin(0, 410, 0, 540, [[0, '#8a92a2'], [0.15, '#f4f8ff'], [0.3, '#b8c4d4'], [0.45, '#f8fbff'], [0.6, '#c8d4e4'], [0.75, '#6a7282'], [0.9, '#eef2f8'], [1, '#4a4e58']]));
    C(helm, () => { for (let i = 0; i < 9; i++) { const y = 424 + i * 13; K(P([[176, y + 6], [262, y - 2], [350, y + 8]], false, true), BK, 2.2); } });
    K(helm, BK, 2);
    for (const [x, y] of [[236, 553], [304, 546]]) {
      F(circleP(x, y, 25), BK);
      F(circleP(x, y, 21), rad(x, y, 22, [[0, '#7ad0ff'], [0.4, '#1e5ad8'], [0.8, '#0a1a5a'], [1, '#05081a']], x - 4, y - 6));
      F(circleP(x - 6, y - 8, 5), '#ffffff');
    }
    F(P([[300, 590], [330, 572], [372, 618], [366, 624], [318, 610]], true, true), lin(300, 580, 370, 620, [[0, '#8a7a30'], [0.5, '#f2e6a0'], [1, '#c8b860']]));
    K(P([[300, 590], [330, 572], [372, 618], [366, 624], [318, 610]], true, true), '#3a3010', 1.5);
    tube([[162, 606], [170, 646], [200, 684], [258, 704], [320, 696], [362, 666], [380, 628]], 26, 25, 18, 2);
    pearl(268, 598, 22, 22, 0, false);
    // gold/blue bead necklace under the beard
    for (let i = 0; i < 6; i++) { const a = 2.5 - i * 0.28; F(circleP(265 + Math.cos(a) * 52, 600 + Math.sin(a) * 26, 4), i % 2 ? '#d8c060' : '#203a8a'); }

    // ── dark striated slope under the pearls, striped dunes below ──
    const slope = P([[240, 880], [300, 850], [420, 830], [520, 800], [600, 784], [640, 800], [600, 830], [540, 870], [500, 900], [300, 905]], true, false);
    F(slope, pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float s = sin((p.y + 0.36 * p.x) * 0.42 + 3. * sin(p.x * 0.02));
      float k = smoothstep(0.88, 0.98, s) * smoothstep(0.45, 0.75, vnoise(vec2(p.x * 0.015, (p.y + 0.36 * p.x) * 0.2)));
      return mix(vec3(0.03), vec3(0.8, 0.79, 0.77), k); }`)));
    const dune = P([[-10, 1034], [-10, 878], [80, 892], [160, 912], [240, 884], [300, 898], [440, 898], [480, 912], [520, 900], [560, 880], [600, 860], [640, 844], [736, 830], [736, 1034]], true, true);
    F(dune, pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float w = 14. * sin(p.x * 0.012 + p.y * 0.004) + 8. * sin(p.x * 0.031 + 1.7);
      float ph = (p.y - 0.2 * (726. - p.x) * smoothstep(1000., 860., p.y) + w) / 7.5;
      float s = sin(6.2832 * ph);
      vec3 lo = mix(vec3(0.74, 0.72, 0.69), vec3(0.66, 0.64, 0.61), uv.y), hi = mix(vec3(0.98, 0.97, 0.95), vec3(0.93, 0.92, 0.89), uv.y);
      return mix(lo, hi, smoothstep(-0.7, 0.5, s)); }`)));

    E.grain(0.03, 130);
  }
});
