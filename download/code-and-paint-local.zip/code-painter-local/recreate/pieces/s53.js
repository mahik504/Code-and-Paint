'use strict';
// s53 — "Milk face": translucent milky-porcelain blobs (big disc, round eye, two dark
// nostril pits, bubbles) with bright fresnel rims, blue-grey depths and salmon blushes.
REC.register('s53', {
  w: 1024, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    // soft paint: draw into a temp canvas, blur it, composite into the albedo
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fillE = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };

    // ── ground: pale grey, slate towards the right edge ──
    const g = a.createLinearGradient(0, 0, 1024, 200);
    g.addColorStop(0, '#e2e6ea'); g.addColorStop(0.55, '#d4d8de'); g.addColorStop(0.85, '#7d8d99'); g.addColorStop(1, '#3a5260');
    R.flat(rrect(-10, -10, 1044, 1044, 0), g, 0, 0);

    // ── outer torus body ──
    R.dome(ellipseP(560, 540, 468, 505, 0), '#bec0c6', 0.02, 0.3, 120, 1);
    // lower-left white lobe + left arc
    R.dome(ellipseP(150, 858, 200, 172, -0.35), '#d8dade', 0.2, 0.24, 90, 1);
    R.dome(P([[40, 170], [150, 150], [230, 180], [200, 240], [150, 300], [110, 380], [100, 470], [120, 560], [60, 600], [20, 520], [10, 400], [15, 280]]), '#d2d4d9', 0.2, 0.16, 50, 1);
    // top-left salmon blob
    R.dome(ellipseP(60, 230, 110, 80, -0.2), '#e4c4c4', 0.2, 0.2, 60, 1);

    // ── big disc ──
    R.dome(circleP(578, 560, 272), '#b6bec9', 0.18, 0.3, 90, 1);
    { const arc = new Path2D(); arc.arc(578, 560, 282, -0.9, 1.2); R.pipe(arc, 18, '#eef0f4', 0.4, 0.08, 1); }
    // salmon oval (upper right) + its ring
    const so = a.createLinearGradient(640, 120, 640, 290); so.addColorStop(0, '#c9423a'); so.addColorStop(0.35, '#c88c90'); so.addColorStop(1, '#b3b3c4');
    R.dome(ellipseP(655, 205, 152, 78, -0.12), so, 0.3, 0.14, 40, 1);
    R.groove(ellipseP(655, 205, 158, 84, -0.12), 10, '#e8e8ee', 0.44, 0.03, 1, 0.6);
    // top blob under the salmon streak
    R.dome(ellipseP(385, 205, 120, 62, -0.1), '#bec1ca', 0.25, 0.14, 40, 1);
    // round eye
    R.dome(ellipseP(354, 381, 125, 127, -0.3), '#b2bbc8', 0.3, 0.26, 50, 1);
    { const arc = new Path2D(); arc.ellipse(354, 381, 128, 130, -0.3, 1.3, 3.9); R.pipe(arc, 16, '#f2f3f6', 0.34, 0.08, 1); }

    // ── nostril pits ──
    R.dome(circleP(368, 566, 60), '#e4e7ec', 0.3, 0.3, 54, 1);
    R.dome(circleP(556, 572, 62), '#e6e8ee', 0.34, 0.2, 26, 1);
    R.dome(ellipseP(558, 575, 36, 42, 0), '#9aa6b6', 0.4, -0.08, 20, 1);
    // bright lower rim of the disc
    { const arc = new Path2D(); arc.arc(578, 560, 262, 0.25, 2.75); R.pipe(arc, 20, '#eceef2', 0.44, 0.08, 1); }

    // ── right-side lobes ──
    R.dome(ellipseP(960, 470, 110, 95, 0.2), '#848d9b', 0.12, 0.26, 60, 1);
    R.dome(ellipseP(985, 727, 48, 40, 0), '#a2a9b5', 0.2, 0.2, 30, 1);
    R.pipe(P([[830, 780], [900, 795], [960, 815], [1040, 852]], false), 44, '#e8eaee', 0.25, 0.14, 1);
    R.dome(ellipseP(985, 225, 62, 100, 0), '#b4bac6', 0.12, 0.2, 40, 1);
    R.dome(ellipseP(990, 300, 70, 30, -0.1), '#c8ccd6', 0.2, 0.14, 22, 1);

    // white sweeping ridge along the bottom
    R.pipe(P([[250, 975], [330, 935], [420, 908], [520, 905], [620, 918], [720, 945], [800, 980]], false), 52, '#f0f1f4', 0.3, 0.16, 1);
    // ── bubbles ──
    const bub = [[613, 34, 20], [577, 282, 26], [800, 300, 46], [555, 695, 22], [498, 663, 18], [777, 791, 34], [895, 602, 34], [880, 548, 18], [505, 863, 22],
      [39, 588, 18], [129, 591, 18], [264, 659, 25], [300, 734, 20], [318, 809, 22], [371, 755, 24], [640, 862, 14], [830, 685, 12], [955, 870, 12], [470, 225, 22]];
    for (const [x, y, r] of bub) {
      R.dome(circleP(x, y, r), '#aeb4be', 0.4, 0.14, r * 0.8, 1);
      R.groove(circleP(x, y, r), 4, '#eef0f4', 0.42, 0.02, 1, 0.7);
    }

    // ── soft depth shading + salmon blush painted into the albedo ──
    soft(x => {
      fillE(x, 470, 520, 70, 50, 0, '#3f5c78'); fillE(x, 610, 440, 90, 45, -0.2, '#4b6784'); fillE(x, 540, 470, 40, 30, 0, '#3a5570');
      fillE(x, 110, 450, 20, 40, 0, '#6b5444'); fillE(x, 150, 290, 16, 26, 0, '#6d5a4c'); fillE(x, 300, 700, 90, 20, -0.2, '#8a8078');
      fillE(x, 260, 960, 120, 40, -0.3, '#6a7f9b'); fillE(x, 700, 1000, 150, 50, 0, '#6f86a0'); fillE(x, 760, 560, 40, 70, 0, '#8ea4bc');
      fillE(x, 870, 760, 60, 50, 0, '#7e8ea2'); fillE(x, 330, 450, 90, 60, 0, '#95a2b6');
      fillE(x, 160, 500, 50, 40, 0, '#6d7282'); fillE(x, 200, 690, 60, 25, 0.2, '#9a8472'); fillE(x, 130, 110, 50, 50, 0, '#6e6d6a'); fillE(x, 700, 890, 120, 25, 0, '#7d8ca2');
      x.strokeStyle = '#4a5a6c'; x.lineWidth = 26; x.beginPath(); x.arc(578, 560, 290, 0.35, 2.6); x.stroke();
    }, 22, 0.8);
    soft(x => { fillE(x, 600, 735, 190, 70, 0, '#dde2ea'); fillE(x, 700, 640, 90, 90, 0, '#d0d6e0'); }, 30, 0.6);
    soft(x => { fillE(x, 422, 614, 40, 34, 0, '#0e1c28'); fillE(x, 405, 672, 62, 9, 0.08, '#3a2c24'); fillE(x, 558, 576, 18, 30, 0, '#08121c'); }, 9, 1);
    soft(x => { x.strokeStyle = '#3c5470'; x.lineWidth = 16; x.beginPath(); x.arc(368, 566, 66, -0.6, 1.9); x.stroke(); x.beginPath(); x.arc(556, 572, 68, -0.4, 1.8); x.stroke(); }, 10, 0.7);
    soft(x => {
      fillE(x, 250, 90, 120, 40, -0.25, '#e8876f'); fillE(x, 700, 150, 110, 38, 0.1, '#d6452e'); fillE(x, 60, 230, 90, 60, 0, '#e5a39b');
      fillE(x, 30, 980, 60, 60, 0, '#d9a7a6'); fillE(x, 150, 600, 60, 20, 0.2, '#f0aaa0');
    }, 26, 0.9);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.3, shin: 22, wrap: 0.4, ao: 1.0, coat: 0.08, rim: 1.2 }),     // 1 milky porcelain
        E.mat({ dif: 1, spec: 0.1, shin: 10, wrap: 0.3, ao: 0.6 })                              // 2 dark pit
      ],
      light: [-0.45, 0.55, 0.7], lc: [0.5, 0.5, 0.5], amb: [0.47, 0.5, 0.56],
      envTop: [1, 1, 1.02], envHor: [0.7, 0.72, 0.78], envBot: [0.3, 0.34, 0.4], envK: [0.2, 0.6, 0.3, 0],
      rimC: [0.72, 0.73, 0.75], rimD: [-0.3, 0.4, 0.15], r1: 3, r2: 12, k: [0, 0.6, 0.4, 90], shadow: [-14, 14, 0.6, 4]
    });
    E.out.save(); E.out.filter = 'none'; E.out.restore();
    E.draw(E.blur(E.snapshot(), 1.2), 1);
    E.grain(0.03, 53);
  }
});
