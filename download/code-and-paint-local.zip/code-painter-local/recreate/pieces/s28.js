'use strict';
// s28 — "Op-art wreck": a glitch collage of silver paper-plane planes, green topo
// marble panels, black/white op-art stripe fans, a bundle of yellow/orange/blue beams,
// lavender boxes, a wireframe knot, teal cloud panels and hot-pink strips.
REC.register('s28', {
  w: 1024, h: 1024,
  draw(E) {
    const o = E.out, W = 1024, H = 1024;
    const poly = (pts) => P(pts, true, false);
    const fillP = (pts, fs) => { o.fillStyle = fs; o.fill(poly(pts)); };
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const clipDraw = (pts, cv) => { o.save(); o.clip(poly(pts)); o.drawImage(cv, 0, 0, W, H); o.restore(); };

    // ── procedural textures ──
    const marble = E.fx(`vec3 fx(vec2 uv, vec2 px){
      vec2 p = px * 0.011;
      float v = fbm(p + 1.7 * vec2(fbm(p * 0.8 + 3.1), fbm(p * 0.8 + 8.4)));
      float s = sin(v * 46.0);
      float k = smoothstep(0.05, 0.4, s);
      return mix(vec3(0.005, 0.06, 0.05), vec3(0.03, 0.29, 0.24), k * 0.95);
    }`);
    const fan = E.fx(`vec3 fx(vec2 uv, vec2 px){
      float d1 = length(px - vec2(905.0, 640.0)) - 190.0;
      vec2 n = normalize(vec2(360.0, 30.0));
      float d2 = dot(px - vec2(940.0, 60.0), -n);
      float d = min(d1, d2 + 8.0);
      float per = 18.0;
      float s = sin(6.2832 * d / per);
      float w = smoothstep(-0.34, 0.02, s);
      return mix(vec3(0.0), vec3(0.93), w);
    }`);
    const bigStripes = E.fx(`vec3 fx(vec2 uv, vec2 px){
      float d = length(px - vec2(1130.0, 1150.0));
      float s = sin(6.2832 * d / 64.0 + 1.3);
      float w = smoothstep(-0.12, 0.12, s);
      float n = 0.9 + 0.1 * vnoise(px * 0.5);
      return mix(vec3(0.0), vec3(0.94) * n, w);
    }`);
    const cloud = E.fx(`vec3 fx(vec2 uv, vec2 px){
      vec2 p = px * 0.006;
      float c = fbm(p + fbm(p * 1.3 + 4.0));
      vec3 col = mix(vec3(0.07, 0.30, 0.26), vec3(0.36, 0.45, 0.43), smoothstep(0.35, 0.75, c));
      return col;
    }`);
    const topo = E.fx(`vec3 fx(vec2 uv, vec2 px){
      vec2 p = px * vec2(0.012, 0.05);
      float v = fbm(p + vec2(fbm(p * 1.1 + 2.0), 0.0) * 1.4);
      float s = sin(v * 40.0 + px.y * 0.25);
      return mix(vec3(0.005, 0.06, 0.05), vec3(0.05, 0.30, 0.25), smoothstep(-0.2, 0.2, s) * 0.8);
    }`);

    // ── base: green topo marble everywhere ──
    o.drawImage(marble, 0, 0, W, H);

    // pink top band
    fillP([[0, 0], [1024, 0], [1024, 42], [268, 97], [0, 97]], lin(0, 0, 1024, 60, [[0, '#ffb8bb'], [0.3, '#fe9aab'], [0.55, '#fe6a86'], [0.7, '#f24a66'], [0.85, '#c03a52'], [1, '#742836']]));

    // right cloud panel with dark topo horizon
    const RP_ = [[862, 348], [1024, 262], [1024, 700], [862, 700]];
    clipDraw(RP_, cloud);
    const horizonR = [[862, 700], [862, 625], [900, 618], [935, 590], [945, 612], [990, 612], [1024, 600], [1024, 700]];
    clipDraw(horizonR, topo);

    // bottom-right big op-art stripes
    clipDraw([[520, 700], [1024, 700], [1024, 1024], [520, 1024]], bigStripes);
    // pink triangle right
    fillP([[930, 690], [1024, 650], [1024, 712]], '#fe6a86');

    // ── op-art fan ──
    const FAN = [[935, 66], [905, 400], [872, 560], [835, 660], [560, 770], [470, 700], [405, 412], [560, 330], [700, 228]];
    clipDraw(FAN, fan);
    clipDraw([[380, 890], [560, 880], [540, 1024], [385, 1024]], fan);

    // left grey panel
    fillP([[0, 92], [190, 222], [190, 600], [0, 600]], lin(0, 150, 150, 520, [[0, '#9c9c9c'], [0.35, '#b4b4b4'], [1, '#c6c6c6']]));
    fillP([[0, 92], [190, 222], [190, 330], [0, 235]], 'rgba(90,90,90,0.18)');
    // dark green diagonal band top-left
    fillP([[0, 0], [82, 0], [236, 222], [190, 224], [0, 94]], lin(0, 0, 200, 200, [[0, '#0b5a4c'], [1, '#0a4a3f']]));
    // pink box behind the wing
    fillP([[190, 222], [236, 222], [300, 300], [190, 306]], '#fe7f96');
    // ── silver paper-plane wing ──
    fillP([[85, 28], [520, 190], [652, 236], [640, 262], [505, 345], [470, 362], [395, 405], [300, 290], [236, 222]],
      lin(150, 60, 420, 380, [[0, '#dcdcdc'], [0.5, '#b8b8b8'], [1, '#8e8e8e']]));
    fillP([[85, 28], [520, 190], [520, 240], [440, 240]], lin(100, 40, 520, 230, [[0, '#f4f4f4'], [0.6, '#ffffff'], [1, '#e8e8e8']]));
    fillP([[85, 28], [440, 240], [470, 362], [395, 405], [300, 290]], lin(150, 100, 430, 380, [[0, 'rgba(120,120,120,0.25)'], [1, 'rgba(90,90,90,0.35)']]));
    fillP([[440, 240], [652, 236], [640, 262], [505, 345], [470, 362]], lin(450, 240, 640, 300, [[0, '#b0b0b0'], [1, '#d0d0d0']]));
    fillP([[440, 236], [652, 232], [660, 245], [470, 252]], '#404444');
    // thin rod
    o.save(); o.lineCap = 'round'; o.strokeStyle = '#9a9a9a'; o.lineWidth = 8; o.beginPath(); o.moveTo(226, 222); o.lineTo(318, 468); o.stroke(); o.restore();
    // grey wedge left of beams
    fillP([[0, 588], [190, 568], [190, 598], [0, 600]], '#1d4a42');
    fillP([[0, 600], [150, 610], [160, 636], [0, 650]], '#f2f2f2');

    // ── beam bundle converging to the upper right ──
    const beams = [
      [[0, 690], [0, 1024], [400, 1024], [570, 560], [430, 540]], '#fed801',
      [[0, 760], [0, 1000], [480, 600], [520, 560]], '#f98a07',
      [[0, 1000], [0, 1024], [60, 1024], [300, 760]], '#fdb402',
      [[0, 640], [0, 700], [420, 560], [410, 548]], '#dede20',
      [[0, 695], [0, 745], [430, 580], [420, 566]], '#4466c8',
      [[0, 740], [0, 762], [430, 590], [425, 584]], '#28c070',
      [[0, 758], [0, 800], [440, 600], [430, 590]], '#b8dc30',
      [[330, 520], [340, 545], [620, 470], [610, 455]], '#e0f040',
      [[330, 560], [330, 600], [640, 490], [630, 470]], '#4466c8',
      [[360, 640], [380, 680], [650, 520], [640, 500]], '#4a68cc',
      [[430, 520], [470, 520], [560, 470], [540, 470]], '#28b060',
      [[420, 610], [640, 480], [660, 520], [570, 650], [470, 670]], '#4a64c4',
      [[380, 1024], [432, 1024], [620, 560], [600, 560]], '#2a2a2a',
      [[432, 1024], [485, 1024], [690, 520], [665, 515]], '#9a9ae8',
      [[485, 1024], [520, 1024], [690, 560], [680, 555]], '#1c1c1c'
    ];
    for (let i = 0; i < beams.length; i += 2) fillP(beams[i], beams[i + 1]);
    fillP([[0, 760], [0, 1000], [480, 600], [520, 560]], lin(0, 1000, 300, 700, [[0, 'rgba(255,180,0,0.3)'], [0.5, 'rgba(255,110,0,0.0)'], [1, 'rgba(255,200,0,0.25)']]));
    o.save(); o.lineWidth = 3; o.strokeStyle = 'rgba(210,240,60,0.8)';
    for (const [x0, y0, x1, y1] of [[0, 930, 520, 580], [0, 985, 420, 650]]) { o.beginPath(); o.moveTo(x0, y0); o.lineTo(x1, y1); o.stroke(); }
    o.restore();
    fillP([[500, 560], [545, 540], [520, 610]], '#c8e030');

    // lavender panels
    fillP([[560, 770], [470, 780], [520, 640], [700, 505], [720, 500]], lin(500, 760, 700, 520, [[0, '#a8a8f0'], [1, '#8686d0']]));
    fillP([[490, 378], [602, 385], [662, 425], [655, 560], [585, 540], [500, 500], [470, 440]], lin(490, 380, 650, 550, [[0, '#9a9ae0'], [1, '#8282cc']]));
    // bright green rods
    o.save(); o.lineCap = 'butt';
    const rod = (x0, y0, x1, y1, w, c0, c1) => { o.strokeStyle = lin(x0, y0, x1, y1, [[0, c0], [1, c1]]); o.lineWidth = w; o.beginPath(); o.moveTo(x0, y0); o.lineTo(x1, y1); o.stroke(); };
    rod(330, 520, 540, 432, 22, '#a0e040', '#40e050');
    rod(560, 408, 680, 380, 28, '#30c060', '#28d078');
    o.restore();
    // cyan prism
    fillP([[600, 452], [660, 418], [722, 420], [700, 470], [640, 500], [606, 492]], lin(600, 450, 720, 450, [[0, '#20e0a0'], [0.6, '#20b0c0'], [1, '#2080e0']]));

    // left marble panel
    const LP = [[190, 306], [305, 300], [330, 480], [392, 690], [190, 725]];
    clipDraw(LP, marble);
    fillP([[190, 552], [292, 626], [190, 662]], lin(190, 560, 290, 640, [[0, '#9a9a9a'], [1, '#6a7472']]));
    fillP([[190, 668], [300, 650], [390, 688], [190, 726]], lin(190, 660, 380, 700, [[0, '#f0f0f0'], [1, '#c8c8c8']]));

    // wireframe knot
    fillP([[655, 400], [720, 372], [800, 372], [890, 410], [885, 470], [830, 650], [770, 570], [690, 510], [650, 470]], 'rgba(4,4,4,0.88)');
    const wr = rng(28); o.save(); o.lineWidth = 0.8;
    for (let i = 0; i < 70; i++) {
      const x0 = 660 + wr() * 230, y0 = 380 + wr() * 200, x1 = 660 + wr() * 230, y1 = 380 + wr() * 250;
      o.strokeStyle = `rgba(210,210,210,${0.25 + wr() * 0.4})`; o.beginPath(); o.moveTo(x0, y0); o.lineTo(x1, y1); o.stroke();
    }
    o.restore();

    // ── bottom teal cloud panel with topo horizon + pink strip ──
    const BP = [[190, 848], [865, 700], [865, 892], [190, 892]];
    clipDraw(BP, cloud);
    clipDraw([[190, 892], [190, 870], [300, 866], [420, 850], [520, 848], [600, 836], [640, 826], [700, 836], [760, 814], [780, 820], [865, 830], [865, 892]], topo);
    fillP([[190, 885], [865, 885], [865, 916], [190, 902]], lin(190, 900, 865, 900, [[0, '#f04a68'], [1, '#a02e44']]));
    // shading of the cloud panel edge
    fillP([[190, 848], [865, 700], [865, 712], [190, 858]], 'rgba(0,30,25,0.25)');

    E.grain(0.04, 9);
  }
});
