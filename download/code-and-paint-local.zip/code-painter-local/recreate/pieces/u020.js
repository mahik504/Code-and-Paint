'use strict';
// u020 — "Chrome kid at the garage": a glossy black robot head with rainbow eyes and blue-chrome shoulders
// on pink, a grey ghost and a zebra tube behind a cow-spotted cream cut-out, a cream car with bone decals,
// a brick wall with a tunnel, a yellow sign and a zebra-roofed vintage car.
REC.register('u020', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const soft = (fn, blur, alpha = 1, clip) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clip) a.clip(clip); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const line = (pts, wd, col, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = col; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(P(pts, false, false)); };
    const poly = (pts, sm = false) => P(pts, true, sm);
    const flat = (path, col) => R.flat(path, col, 0, 0);

    // ── pink wall, brick wall, asphalt ──
    flat(rrect(-5, -5, 440, 540, 0), '#f1cecb');
    const wall = rrect(422, -5, 310, 640, 0);
    flat(wall, '#99948f');
    clipA(wall, () => {
      const r = rng(4);
      for (let row = 0; row < 24; row++) {
        const y = 12 + row * 27; line([[422, y], [726, y]], 2.4, '#1e1c1c');
        for (let x = 430 + (row % 2) * 30 + r() * 10; x < 726; x += 58 + r() * 8) line([[x, y], [x, y + 27]], 2.4, '#1e1c1c');
      }
      a.fillStyle = '#99948f'; for (let i = 0; i < 40; i++) a.fillRect(422 + r() * 300, r() * 620, 10 + r() * 30, 4);
      a.fillStyle = '#141212'; for (let i = 0; i < 160; i++) { a.beginPath(); a.arc(422 + r() * 304, r() * 620, 0.6 + r() * 1.6, 0, 6.3); a.fill(); }
    });
    // asphalt
    const ground = poly([[560, 560], [726, 540], [726, 1030], [560, 1030]]);
    flat(ground, '#8c8886');
    clipA(ground, () => { const r = rng(9); for (let i = 0; i < 260; i++) { a.fillStyle = r() < 0.7 ? '#1a1818' : '#c8c4c0'; a.beginPath(); a.arc(560 + r() * 170, 540 + r() * 490, 0.6 + r() * 2.4, 0, 6.3); a.fill(); } });
    // tunnel with brick arch
    const tun = poly([[726, 367], [704, 369], [684, 377], [665, 389], [648, 406], [636, 424], [627, 458], [628, 520], [635, 594], [660, 590], [680, 546], [700, 530], [726, 540]], true);
    R.flat(ellipseP(700, 480, 112, 132, 0), '#a29d98', 0.02, 0);
    clipA(ellipseP(700, 480, 112, 132, 0), () => { for (let k = 0; k < 14; k++) { const t = 3.3 + k * 0.17; line([[700 + Math.cos(t) * 82, 480 + Math.sin(t) * 104], [700 + Math.cos(t) * 112, 480 + Math.sin(t) * 132]], 2.2, '#1e1c1c'); } });
    R.flat(tun, '#060506', 0.02, 0);
    clipA(tun, () => { const r = rng(12); a.fillStyle = '#d8d8e0'; for (let i = 0; i < 40; i++) { a.beginPath(); a.arc(626 + r() * 100, 370 + r() * 220, 0.5 + r(), 0, 6.3); a.fill(); } });
    // pole, rope bar, chain
    R.pipe(P([[501, -5], [501, 238]], false), 9, '#2a2626', 0.05, 0.08, 4);
    R.pipe(P([[422, 124], [566, 124]], false), 8, '#3a3634', 0.05, 0.06, 4);
    R.pipe(P([[560, 236], [640, 196], [726, 150]], false), 6, '#2a2626', 0.05, 0.05, 4);
    for (const [x, y] of [[452, 38], [449, 96], [445, 238], [430, 330]]) R.bead(x, y, 6, '#2c2a2c', 0.05, 0.1, 4);
    // sign: black ring with a white S, yellow bar
    R.flat(circleP(700, 60, 140), '#0e0c0e', 0.02, 0);
    R.flat(circleP(700, 60, 114), '#99948f', 0.02, 0);
    R.flat(circleP(702, 58, 109), '#0e0c0e', 0.02, 0);
    clipA(circleP(702, 58, 109), () => { a.font = 'bold italic 96px Georgia, serif'; a.fillStyle = '#c8c4c0'; a.fillText('S', 652, 80); });
    R.flat(rrect(560, 90, 170, 60, 0), '#8e8a86', 0.03, 0);
    R.flat(rrect(574, 100, 160, 42, 0), '#f6dc4c', 0.04, 0);
    line([[574, 100], [574, 142], [730, 142]], 3, '#2a2420');

    // ── grey ghost shapes ──
    const ghost = poly([[432, 250], [470, 228], [520, 215], [560, 222], [585, 250], [596, 300], [600, 360], [606, 430], [618, 500], [628, 560], [630, 620], [624, 680], [606, 712],
      [580, 716], [560, 690], [575, 620], [578, 560], [560, 515], [530, 490], [505, 500], [490, 470], [470, 440], [450, 420], [430, 400], [412, 380], [408, 340], [420, 300]], true);
    R.dome(ghost, '#9d9995', 0.05, 0.12, 40, 1);
    const torso = poly([[150, 380], [300, 375], [380, 400], [420, 440], [440, 480], [470, 520], [480, 600], [470, 680], [400, 690], [300, 680], [220, 640], [180, 560], [150, 470]], true);
    R.dome(torso, '#96928f', 0.05, 0.08, 30, 1);

    // ── blue-chrome body ──
    const chromeL = poly([[0, 486], [26, 452], [60, 425], [100, 403], [140, 386], [182, 374], [176, 400], [152, 430], [132, 470], [110, 500], [70, 520], [50, 600], [40, 700], [20, 780], [0, 800]], true);
    R.dome(chromeL, '#8a90a6', 0.08, 0.3, 40, 3);
    soft(x => { fe(x, 30, 470, 26, 40, 0.5, '#e0f0f0'); fe(x, 95, 440, 30, 18, -0.5, '#c0d8e8'); fe(x, 20, 560, 14, 40, 0, '#a8d0e8'); }, 8, 0.9, chromeL);
    const chromeR = poly([[486, 700], [530, 676], [576, 684], [604, 720], [606, 790], [584, 840], [572, 900], [584, 970], [640, 1000], [646, 1030], [540, 1030], [528, 900], [500, 840], [484, 780]], true);
    R.dome(chromeR, '#7c8298', 0.08, 0.3, 36, 3);
    R.dome(circleP(540, 775, 38), '#8890aa', 0.3, 0.2, 30, 3);
    R.dome(circleP(527, 775, 22), '#d8d8dc', 0.45, 0.1, 14, 5);
    // collar chain
    R.dome(ellipseP(268, 368, 92, 16, 0), '#8890a8', 0.3, 0.08, 8, 3);
    { const r = rng(3); for (let i = 0; i < 30; i++) R.bead(182 + i * 6, 368 + Math.sin(i * 1.3) * 4, 3.4, '#c8ccd8', 0.4, 0.05, 3); }

    // ── head: glossy black dome, ear cups, skull face ──
    const head = P([[265, 84], [300, 94], [338, 120], [366, 158], [384, 200], [390, 250], [380, 298], [356, 334], [318, 352], [268, 358], [220, 352], [184, 334], [160, 300], [150, 250],
      [156, 200], [174, 155], [204, 116], [236, 94]]);
    for (const [cx, rx] of [[132, 30], [404, 30]]) R.dome(ellipseP(cx, 255, rx, 72, 0), '#1a2440', 0.2, 0.4, 28, 2);
    R.dome(head, '#0c0c10', 0.25, 0.4, 70, 2);
    R.dome(ellipseP(265, 90, 15, 10, 0), '#1c1c24', 0.6, 0.1, 6, 2);
    // face paint (brown-pink skull mask) and teal forehead bands
    clipA(head, () => {
      a.fillStyle = '#5a3c38';
      a.fill(P([[176, 222], [205, 200], [240, 196], [262, 214], [278, 214], [300, 196], [336, 200], [366, 222], [372, 262], [356, 300], [330, 322], [300, 346], [236, 346], [208, 322],
        [180, 298], [168, 262]]));
      a.fillStyle = '#16161c';
      a.fill(P([[214, 292], [240, 286], [256, 300], [252, 326], [262, 344], [276, 344], [288, 326], [284, 300], [300, 286], [326, 292], [312, 316], [292, 340], [244, 340], [226, 316]]));
      a.fill(P([[256, 250], [282, 250], [292, 300], [284, 330], [256, 330], [248, 300]]));
      a.fillStyle = '#5c8a92';
      for (const [y, w2] of [[122, 30], [140, 46], [158, 60], [176, 72]]) a.fill(ellipseP(268, y, w2, 6, 0));
      a.fillStyle = '#c87870'; a.fill(P(star(270, 206, 14, 4, 4, 0.3), true, false));
    });

    // ── zebra tube, spring and lens ──
    const zeb = P([[300, 408], [336, 404], [360, 440], [384, 476], [410, 500], [440, 520], [462, 545], [470, 590], [446, 618], [408, 606], [330, 600], [262, 604], [232, 600], [222, 560],
      [228, 520], [250, 480], [282, 440]]);
    R.dome(zeb, '#f4f0e2', 0.15, 0.12, 30, 1);
    // stripe centrelines measured from the reference (width, x/y pairs)
    const ZT = [[8.8, [296, 578, 284, 580]], [7.2, [328, 458, 315, 448, 286, 444]], [6.8, [324, 428, 312, 417, 301, 412, 303, 405, 309, 402]], [8.4, [460, 268, 460, 272, 466, 278]], [10, [404, 542, 336, 542, 273, 532, 237, 523, 229, 525]], [8, [252, 610, 258, 609, 263, 601]], [8.4, [353, 508, 320, 500, 261, 493]], [11.6, [284, 580, 228, 566, 222, 560]], [9.4, [284, 580, 281, 591, 276, 596, 263, 601]], [8, [328, 471, 313, 463, 284, 460]], [12, [392, 594, 373, 593, 359, 587]], [12, [228, 587, 233, 591, 257, 597, 263, 601]], [8.4, [272, 478, 284, 477, 315, 481, 329, 485, 338, 491]], [6.4, [288, 431, 302, 429, 314, 433, 327, 443, 331, 450]], [8.8, [403, 522, 390, 525, 357, 524, 282, 514, 251, 507, 245, 508]], [12, [226, 542, 311, 561, 357, 567, 391, 568]], [8.6, [451, 296, 448, 289]], [5.8, [410, 365, 410, 373, 407, 376]], [9.8, [425, 332, 431, 341]], [10.4, [443, 321, 437, 312]]];
    const zpaths = ZT.map(([w, f]) => { const pts = []; for (let i = 0; i < f.length; i += 2) pts.push([f[i], f[i + 1]]); return [w, P(pts, false, true)]; });
    clipA(zeb, () => { for (const [w, p] of zpaths) { a.lineWidth = w * 1.25 + 1; a.strokeStyle = '#121014'; a.lineCap = 'round'; a.stroke(p); } });
    // diagonal zebra wedge at the top
    const wedge = poly([[476, 238], [462, 262], [446, 290], [430, 320], [414, 352], [404, 380], [420, 372], [440, 340], [458, 306], [470, 276]]);
    R.flat(wedge, '#f0ece0', 0.06, 1);
    clipA(wedge, () => { for (const [w, p] of zpaths) { a.lineWidth = w * 1.6 + 2; a.strokeStyle = '#121014'; a.stroke(p); } });
    for (let i = 0; i < 10; i++) R.pipe(P([[326 + i * 4.4, 392 + i * 11], [362 + i * 4.4, 402 + i * 11]], false), 9, '#a8a8aa', 0.3, 0.1, 4);
    R.dome(ellipseP(440, 570, 36, 50, 0.2), '#8a8a90', 0.25, 0.15, 14, 4);
    for (const k of [0.8, 0.6, 0.4]) R.pipe(ellipseP(442, 570, 36 * k, 50 * k, 0.2), 4, '#c8c8cc', 0.4, 0.05, 4);
    R.dome(ellipseP(446, 570, 8, 11, 0.2), '#1a1a20', 0.45, 0.05, 4, 3);
    // dark tendril behind the head
    R.flat(P([[384, 300], [396, 330], [400, 370], [394, 400], [410, 392], [418, 360], [410, 320]]), '#1a181c', 0.03, 0);

    // ── the cow-spotted cream cut-out (measured outline) ──
    const cream = P([[40, 477], [59, 496], [37, 538], [49, 626], [12, 721], [41, 769], [295, 782], [488, 811], [494, 738], [557, 666], [575, 615], [575, 550], [544, 504], [504, 495],
      [512, 530], [497, 510], [488, 521], [532, 622], [489, 622], [439, 694], [433, 666], [314, 664], [234, 615], [248, 604], [225, 602], [192, 547], [200, 518], [178, 497],
      [234, 493], [253, 460], [183, 460], [158, 444], [104, 533], [76, 528], [81, 496], [63, 475]], true, false);
    R.dome(cream, '#f6f0dc', 0.12, 0.14, 16, 1);
    const holeA = P([[173, 662], [164, 651], [150, 643], [123, 641], [96, 652], [62, 676], [50, 692], [50, 705], [61, 716], [85, 710], [101, 710], [117, 716], [145, 718], [169, 708],
      [176, 695], [177, 675]]);
    R.flat(holeA, '#0a090c', 0.05, 0);
    const holeB = P([[312, 738], [340, 732], [372, 744], [402, 740], [410, 760], [400, 784], [370, 778], [330, 782], [306, 768]]);
    R.flat(holeB, '#8a96aa', 0.05, 0);
    clipA(holeB, () => { a.fillStyle = '#26262e'; a.fill(ellipseP(372, 768, 24, 18, 0)); a.fillStyle = '#c8ccd4'; a.fill(ellipseP(330, 750, 16, 10, 0)); });
    for (const [x, y, w, h] of [[70, 556, 30, 34], [126, 566, 32, 32]]) R.flat(rrect(x, y, w, h, 2), '#8c8a90', 0.06, 0);
    R.flat(rrect(150, 440, 116, 56, 3), '#e6e8e0', 0.1, 1);
    // ball on a stick
    R.pipe(P([[504, 470], [508, 528]], false), 5, '#d8d4cc', 0.3, 0.05, 5);
    R.bead(500, 440, 32, '#ece8de', 0.3, 0.3, 5);
    R.bead(52, 488, 14, '#ece8de', 0.3, 0.2, 5);

    // ── vintage car on the right ──
    R.flat(poly([[578, 836], [726, 842], [726, 900], [580, 884]]), '#1c1a1e', 0.05, 0);
    const vc = P([[582, 842], [586, 812], [600, 792], [624, 776], [640, 766], [652, 748], [668, 700], [690, 650], [710, 612], [726, 598], [726, 852], [700, 858]], true, false);
    R.dome(vc, '#ece8dc', 0.1, 0.1, 14, 1);
    const hood = poly([[656, 762], [672, 706], [692, 656], [712, 618], [726, 608], [726, 770], [700, 774]]);
    R.flat(hood, '#ece8dc', 0.16, 1);
    clipA(hood, () => { a.strokeStyle = '#141216'; a.lineWidth = 3.4; for (let y = 612; y < 780; y += 10.5) { a.beginPath(); a.moveTo(640, y + 6); a.lineTo(730, y); a.stroke(); } });
    R.flat(rrect(640, 772, 60, 76, 4), '#b8bcc0', 0.18, 3);
    for (let k = 0; k < 10; k++) R.groove(P([[646 + k * 5.4, 778], [646 + k * 5.4, 842]], false), 2.6, '#2a2a30', 0.2, 0.03, 3);
    R.bead(622, 790, 12, '#e8e8ec', 0.2, 0.12, 5); R.bead(712, 800, 12, '#e8e8ec', 0.2, 0.12, 5);
    R.flat(ellipseP(596, 832, 12, 14, 0), '#1a1a1c', 0.12, 0);
    R.pipe(P([[582, 846], [640, 854], [726, 860]], false), 9, '#d0d4d8', 0.15, 0.08, 3);
    for (const pth of [[[700, 600], [688, 572], [700, 548], [720, 552], [716, 580], [700, 600]], [[706, 612], [726, 580]]]) R.pipe(P(pth, false), 5, '#d8d4cc', 0.12, 0.05, 1);

    // ── the cream car: windshield with bone decals ──
    const carB = poly([[0, 812], [30, 792], [70, 782], [120, 776], [300, 776], [480, 784], [516, 800], [528, 840], [526, 900], [512, 1030], [-5, 1030]], true);
    R.dome(carB, '#f2ecdc', 0.1, 0.1, 20, 1);
    const ws = poly([[0, 869], [0, 912], [245, 932], [266, 926], [300, 940], [402, 952], [480, 963], [499, 944], [500, 852], [398, 830], [76, 802], [50, 811]], false);
    const wsP = P([[0, 850], [40, 805], [70, 797], [300, 797], [470, 800], [500, 808], [512, 830], [516, 900], [510, 950], [495, 965], [300, 955], [120, 935], [40, 928], [0, 925]], true, false);
    R.pipe(wsP, 10, '#b8bcc8', 0.16, 0.08, 3);
    R.flat(wsP, '#9b7e68', 0.12, 0);
    clipA(wsP, () => { const r = rng(2); a.fillStyle = '#c8b4a0'; for (let i = 0; i < 120; i++) a.fillRect(r() * 510, 800 + r() * 160, 1, 1); });
    const bone = (x0, y0, x1, y1) => {
      const dx = x1 - x0, dy = y1 - y0, L = Math.hypot(dx, dy), nx = -dy / L * 13, ny = dx / L * 13, p = new Path2D();
      p.addPath(P([[x0 + nx * 0.6, y0 + ny * 0.6], [x1 + nx * 0.6, y1 + ny * 0.6], [x1 - nx * 0.6, y1 - ny * 0.6], [x0 - nx * 0.6, y0 - ny * 0.6]], true, false));
      for (const [cx, cy] of [[x0 + nx, y0 + ny], [x0 - nx, y0 - ny], [x1 + nx, y1 + ny], [x1 - nx, y1 - ny]]) p.addPath(circleP(cx, cy, 13));
      return p;
    };
    // bone decals (measured outlines)
    for (const b of [[[72, 881], [86, 887], [100, 876], [109, 869], [148, 873], [167, 879], [169, 898], [180, 906], [188, 906], [199, 894], [196, 876], [214, 862], [216, 852], [209, 846], [197, 846], [180, 860], [160, 859], [121, 852], [117, 839], [102, 835], [88, 846], [89, 859], [74, 872]],
      [[271, 876], [270, 885], [280, 901], [272, 915], [269, 928], [298, 936], [305, 919], [330, 919], [367, 928], [372, 938], [388, 948], [399, 949], [393, 930], [400, 918], [398, 903], [384, 894], [372, 899], [366, 908], [356, 908], [314, 900], [301, 892], [299, 877], [288, 869], [280, 869]]])
      R.flat(P(b, true, true), '#f6f0e2', 0.14, 1);
    line([[210, 916], [300, 944], [340, 948]], 3, '#1c1c20'); line([[0, 920], [40, 930]], 3, '#1c1c20');
    R.pipe(P([[0, 925], [120, 935], [300, 955], [495, 965]], false), 6, '#c8ccd4', 0.18, 0.05, 3);
    R.flat(rrect(250, 784, 26, 18, 3), '#1a1a1e', 0.18, 0);
    { const r = rng(6); for (let i = 0; i < 30; i++) R.flat(rrect(100 + i * 4.4, 936 + i * 0.5, 2, 8, 1), '#3a3a40', 0.12, 0); }
    R.pipe(P([[140, 1024], [190, 950]], false), 4, '#6a6e7a', 0.12, 0.04, 3);
    R.bead(604, 966, 24, '#ece8de', 0.3, 0.25, 5);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.25, shin: 18, wrap: 0.5, ao: 0.5 }),                                          // 1 matte paint
        E.mat({ dif: 0.9, spec: 1.0, shin: 60, metal: 0.05, rim: 0.8, iri: 0.15, ao: 0.4, coat: 0.05 }),          // 2 glossy black head
        E.mat({ dif: 0.45, metal: 0.7, spec: 1.0, shin: 50, rim: 0.35, ao: 0.4, tint: [0.9, 0.92, 1.0] }),   // 3 blue chrome
        E.mat({ dif: 0.8, spec: 0.4, shin: 30, wrap: 0.3, ao: 0.6 }),                                          // 4 iron
        E.mat({ dif: 1, spec: 0.8, shin: 60, wrap: 0.4, coat: 0.2, ao: 0.4 })                                  // 5 glossy balls
      ],
      light: [-0.4, 0.55, 0.72], lc: [0.7, 0.7, 0.72], amb: [0.45, 0.45, 0.48],
      envTop: [0.95, 0.9, 0.95], envHor: [0.45, 0.48, 0.62], envBot: [0.06, 0.06, 0.12], envK: [0.35, 1.0, 0.3, 0],
      rimC: [0.2, 0.4, 0.75], rimD: [0.2, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 90], shadow: [6, 8, 0.45, 6]
    });

    // ── rainbow eyes ──
    for (const [cx, cy] of [[206, 248], [334, 248]]) {
      const g = o.createRadialGradient(cx + 4, cy, 0, cx, cy, 40);
      for (const [t, c] of [[0, '#fff8f0'], [0.18, '#ffe0f0'], [0.32, '#f080c0'], [0.46, '#f8d040'], [0.6, '#60d070'], [0.74, '#40a0e0'], [0.86, '#d050c0'], [1, '#402040']]) g.addColorStop(t, c);
      o.fillStyle = g; o.fill(circleP(cx, cy, 40));
      o.fillStyle = '#ffffff'; o.fill(ellipseP(cx + 8, cy - 4, 10, 7, 0));
      o.fillStyle = 'rgba(30,20,40,0.85)'; o.fill(P([[cx - 2, cy], [cx + 22, cy - 14], [cx + 22, cy + 14]]));
    }
    // print speckle
    { const r = rng(21); o.fillStyle = '#ffffff'; for (let i = 0; i < 500; i++) { o.globalAlpha = 0.3 + r() * 0.6; o.fillRect(r() * 726, r() * 1024, 1.2, 1.2); } o.globalAlpha = 1; }
    E.grain(0.05, 20);
  }
});
