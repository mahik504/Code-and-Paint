'use strict';
// s33 — "Blue-pipe maw": a striped periwinkle tube loops over a maroon, spike-studded flesh
// bed that spills into a chrome toilet-like torus; a white-rimmed blue bean with pink and
// orange dots floats over the dark hole, on cracked beige gravel and grey asphalt.
REC.register('s33', {
  w: 1024, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const r = rng(33);
    const probe = document.createElement('canvas').getContext('2d');

    // ── procedural textures ──
    const ground = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      // cracked dry gravel: warped cell noise
      vec2 w = p + 9. * vec2(fbm(p * 0.03), fbm(p * 0.03 + 5.2));
      vec2 g = w / 13.; vec2 i = floor(g), f = fract(g); float d1 = 9., d2 = 9.;
      for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) { vec2 o = vec2(x, y); vec2 q = o + vec2(hash(i + o), hash(i + o + 7.3)) - f; float d = dot(q, q); if (d < d1) { d2 = d1; d1 = d; } else if (d < d2) d2 = d; }
      float edge = smoothstep(0.03, 0.12, sqrt(d2) - sqrt(d1));
      float n = fbm(p * 0.05), cell = hash(i + floor(vec2(d1 * 3.)));
      float hole = step(0.8, vnoise(p * 0.08)) * step(0.5, hash(i));
      vec3 beige = mix(vec3(.58,.53,.45), vec3(.82,.77,.67), n * 0.7 + 0.3 * hash(i)) * mix(0.18, 1.0, edge);
      beige = mix(beige, vec3(.2,.18,.15), hole * 0.8);
      vec3 asph = vec3(.36);
      return mix(beige, asph, uA); }`, { uA: 0 }));
    const asphalt = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.06), sp = hash(floor(p * 0.45)), sp2 = vnoise(p * 0.3);
      return vec3(.38,.38,.39) * (0.65 + 0.55 * n) * mix(0.45, 1.05, smoothstep(0.25, 0.6, sp2)) + step(0.94, sp) * 0.10; }`));
    const flesh = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.018), m = fbm(p * 0.07 + 3.1), s = hash(floor(p * 0.7));
      vec3 c = mix(vec3(.60,.16,.24), vec3(.40,.07,.13), smoothstep(0.52, 0.62, n + 0.25 * m));
      c *= 0.9 + 0.2 * m; c += step(0.985, s) * 0.25;
      return c; }`));
    const brick = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.02);
      vec2 q = vec2(p.x * 0.9 + p.y * 0.5, p.y * 1.1 - p.x * 0.3) / 70.; vec2 f = abs(fract(q) - 0.5);
      float line = smoothstep(0.47, 0.5, max(f.x, f.y));
      vec3 c = mix(vec3(.55,.20,.10), vec3(.34,.08,.05), n); c *= 1. - 0.35 * line;
      return c; }`));

    // ── ground ──
    R.flat(rrect(-10, -10, 1044, 1044, 0), ground, 0, 0);
    R.flat(ellipseP(700, 630, 470, 540, 0), asphalt, 0.02, 0);

    // ── chrome pipes at the top ──
    R.pipe(P([[420, -20], [470, 40], [540, 118]], false), 58, '#b8bcc2', 0.1, 0.3, 3);
    for (const t of [0.35, 0.6]) R.groove(P([[440 + t * 100 - 22, -20 + t * 138 + 22], [440 + t * 100 + 22, -20 + t * 138 - 22]], false), 6, '#6a6e74', 0.4, 0.1, 3, 0.6);
    R.pipe(P([[700, -30], [700, 30], [690, 86]], false), 118, '#c8ccd2', 0.1, 0.3, 3);
    for (let k = 0; k < 5; k++) R.groove(P([[645, 5 + k * 16], [755, 0 + k * 16]], false), 7, '#7a7e84', 0.42, 0.14, 3, 0.7);
    R.pipe(P([[305, -20], [318, 30]], false), 36, '#b0b4ba', 0.1, 0.2, 3);

    // ── chrome torus ──
    const torus = ellipseP(700, 600, 405, 460, 0);
    R.dome(torus, '#909094', 0.06, 0.34, 150, 3);
    clipA(torus, () => {
      soft(x => {
        x.fillStyle = '#4e4e52'; x.fill(ellipseP(560, 230, 210, 90, -0.2));
        x.fillStyle = '#8e8e92'; x.fill(ellipseP(820, 190, 170, 50, 0.08));
        x.fillStyle = '#f4f4f6'; x.fill(ellipseP(990, 360, 40, 120, 0.1));
        x.fillStyle = '#c6c6ca'; x.fill(ellipseP(930, 620, 60, 120, 0));
        x.fillStyle = '#56585c'; x.fill(ellipseP(900, 800, 90, 60, -0.6));
        x.fillStyle = '#5a5c5e'; x.fill(ellipseP(600, 930, 260, 22, -0.1));
        x.fillStyle = '#f2f2f4'; x.fill(ellipseP(600, 995, 200, 34, -0.05));
      }, 22, 1);
    });
    // the dark hole
    const hole = ellipseP(630, 462, 285, 190, 0);
    const hg = a.createRadialGradient(650, 500, 20, 640, 480, 290);
    hg.addColorStop(0, '#030303'); hg.addColorStop(0.55, '#0c0c0c'); hg.addColorStop(0.8, '#3a3a3c'); hg.addColorStop(1, '#6e6e72');
    R.dome(hole, hg, 0.38, -0.34, 70, 3);
    clipA(hole, () => soft(x => { x.fillStyle = '#6c6c70'; x.fill(ellipseP(630, 330, 270, 80, 0)); x.fillStyle = '#000'; x.fill(ellipseP(650, 485, 160, 70, 0)); }, 30, 0.9));

    // ── brown tiled floor inside the hole + crust ──
    const floorP = P([[362, 650], [410, 575], [520, 545], [640, 585], [770, 640], [812, 720], [780, 780], [690, 820], [560, 870], [420, 900], [350, 880]]);
    R.flat(floorP, brick, 0.16, 1);
    soft(x => { x.fillStyle = '#1a0402'; x.fill(ellipseP(640, 640, 150, 50, 0.3)); }, 30, 0.7);
    const crust = P([[330, 900], [420, 880], [540, 850], [650, 815], [740, 772], [800, 745], [822, 770], [790, 820], [700, 870], [600, 910], [470, 940], [330, 950]]);
    R.dome(crust, flesh, 0.18, 0.1, 18, 1);

    // ── maroon flesh bed (left) ──
    const bed = P([[0, 40], [120, 30], [300, 60], [440, 150], [470, 250], [360, 320], [262, 360], [300, 460], [360, 560], [410, 640], [400, 740], [362, 840], [345, 910], [250, 945], [150, 930], [60, 900], [0, 880]]);
    R.flat(bed, flesh, 0.14, 1);
    // white-edged blue rim along the bed's right side
    const rimPts = [[228, 322], [242, 392], [290, 452], [318, 500], [338, 548], [380, 596], [405, 650], [404, 715], [378, 790], [355, 862], [348, 915]];
    R.pipe(P(rimPts, false), 30, '#6f92c8', 0.16, 0.14, 2);
    R.pipe(P(rimPts.map(p => [p[0] - 13, p[1]]), false), 8, '#eef2f8', 0.2, 0.08, 2);
    // blue wedge left of the bean
    R.dome(P([[360, 548], [420, 518], [500, 496], [520, 510], [470, 540], [400, 572]]), '#6d8fc6', 0.18, 0.1, 14, 2);

    // ── pink waffle ──
    const waf = [[258, 345], [395, 340], [418, 462], [320, 490], [270, 420]];
    R.dome(P(waf, true, false), '#b35a6a', 0.2, 0.08, 8, 1);
    for (let i = 0; i < 5; i++) for (let j = 0; j < 5; j++) {
      const x = 290 + i * 24 + j * 4, y = 360 + j * 24 - i * 1.5;
      R.dome(rrect(x, y, 13, 13, 2), '#6e2632', 0.28, -0.1, 5, 1);
    }

    // ── spikes ──
    const spike = (x, y, len, wd, ang, col, h0) => {
      const c = Math.cos(ang), s = Math.sin(ang), pts = [];
      for (let k = 0; k <= 16; k++) {
        const t = k / 16 * Math.PI * 2, u = Math.cos(t), v = Math.sin(t);
        const along = u > 0 ? u * len : u * len * 0.35, across = v * wd * (u > 0 ? Math.pow(1 - u, 0.7) : 1);
        pts.push([x + c * along - s * across, y + s * along + c * across]);
      }
      R.dome(P(pts), col, h0, 0.22, wd * 0.9, 4);
    };
    const bedTest = (x, y) => probe.isPointInPath(bed, x, y) && probe.isPointInPath(bed, x + 45, y) && probe.isPointInPath(bed, x, y - 30) && !probe.isPointInPath(P(waf, true, false), x, y);
    let n = 0;
    while (n < 58) {
      const x = 15 + r() * 390, y = 90 + r() * 820;
      if (!bedTest(x, y)) continue;
      // keep off the tube
      if ((y < 330 && y > 170 && x > 60) || (x < 95 && y > 260)) continue;
      spike(x, y, 26 + r() * 10, 10 + r() * 3, -1.3 + (r() - 0.5) * 0.4, '#b8babf', 0.22); n++;
    }
    for (let k = 0; k < 22; k++) {
      const x = 380 + r() * 400, y = 640 + r() * 220;
      if (!probe.isPointInPath(floorP, x, y)) continue;
      spike(x, y, 26 + r() * 8, 9, Math.PI + 0.35 + (r() - 0.5) * 0.4, '#a4a6ac', 0.2);
    }
    for (let k = 0; k < 30; k++) { const t = r(), x = 360 + t * 440, y = 900 - t * 150 + (r() - 0.5) * 30; R.dome(ellipseP(x, y, 7 + r() * 5, 4, -0.3), '#d8c8cc', 0.26, 0.06, 4, 4); }

    // ── big striped periwinkle tube ──
    const tubeA = [[-40, 18], [60, 12], [160, 24], [260, 56], [360, 88], [440, 124], [472, 180], [462, 242], [412, 288], [330, 294], [252, 264], [182, 230], [115, 234], [62, 272], [38, 340], [26, 430], [16, 520], [6, 620], [-4, 720], [-20, 830]];
    const tube = P(tubeA, false);
    R.pipe(tube, 104, '#3f679c', 0.3, 0.3, 2);
    for (const [wd, c] of [[92, '#7093c6'], [66, '#b6c8e2'], [42, '#7496c8']]) { a.lineWidth = wd; a.strokeStyle = c; a.stroke(tube); }
    // lower blue lip of the torus
    const lip = P([[150, 905], [260, 950], [400, 962], [540, 935], [660, 880], [750, 818], [812, 760], [835, 730]], false);
    R.pipe(lip, 52, '#6e90c6', 0.2, 0.2, 2);
    a.lineWidth = 16; a.strokeStyle = '#a8bde0'; a.stroke(lip);
    // blue horn bottom-left
    const horn = P([[-10, 1040], [-10, 960], [60, 858], [150, 772], [247, 690], [232, 762], [214, 880], [200, 1040]]);
    R.dome(horn, '#86a6d6', 0.3, 0.4, 80, 2);
    soft(x => { x.fillStyle = '#f4f7fc'; x.fill(P([[60, 1030], [80, 930], [150, 820], [228, 718], [190, 850], [140, 1030]])); x.fillStyle = '#3d5f94'; x.fill(P([[-10, 1040], [-10, 980], [40, 1040]])); }, 12, 0.85);
    R.dome(rrect(186, 820, 30, 60, 10), '#7b9bcf', 0.55, 0.1, 10, 2);

    // ── the bean ──
    const beanPts = [[462, 596], [474, 532], [528, 490], [625, 474], [725, 478], [805, 506], [862, 566], [882, 640], [862, 712], [806, 748], [766, 742], [742, 704], [700, 668], [640, 652], [565, 652], [505, 664], [470, 642]];
    R.pipe(P([[644, 640], [644, 735]], false), 22, '#a8acb2', 0.22, 0.12, 3);
    const bean = P(beanPts);
    R.dome(bean, '#f6f7fa', 0.34, 0.16, 16, 5);
    const cx = 670, cy = 590;
    const inner = P(beanPts.map(([x, y]) => { const dx = x - cx, dy = y - cy, d = Math.hypot(dx, dy); return [x - dx / d * 20, y - dy / d * 20]; }));
    const bg = a.createLinearGradient(480, 480, 860, 740); bg.addColorStop(0, '#3b8ac8'); bg.addColorStop(1, '#2275b0');
    R.dome(inner, bg, 0.46, -0.1, 14, 6);
    clipA(inner, () => {
      a.strokeStyle = 'rgba(160,200,235,0.55)'; a.lineWidth = 8; a.stroke(inner);
      for (let k = 0; k < 260; k++) { a.fillStyle = r() < 0.5 ? 'rgba(20,70,130,0.35)' : 'rgba(110,170,220,0.3)'; a.fillRect(470 + r() * 410, 470 + r() * 280, 6, 2); }
      for (let k = 0; k < 40; k++) { a.fillStyle = '#f6a8d0'; a.beginPath(); a.arc(480 + r() * 390, 490 + r() * 250, 1 + r() * 1.8, 0, 6.283); a.fill(); }
    });
    for (const [x, y, rr, c] of [[578, 552, 22, '#f5a3cf'], [770, 646, 24, '#f5a3cf'], [522, 608, 8, '#f5a3cf'], [640, 508, 8, '#f5a3cf'], [826, 646, 9, '#f5a3cf'], [812, 700, 4, '#f5a3cf'], [720, 545, 23, '#f7a943'], [652, 600, 10, '#f7a943']])
      R.dome(circleP(x, y, rr), c, 0.36, 0.02, 3, 6);

    // ── shading tints ──
    soft(x => { x.fillStyle = '#1a0006'; x.fill(ellipseP(250, 150, 160, 60, 0.2)); x.fill(ellipseP(160, 620, 70, 200, 0)); }, 40, 0.35);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.12, shin: 12, wrap: 0.4, ao: 0.8, grain: 0.3 }),                          // 1 flesh / brick
        E.mat({ dif: 0.95, spec: 0.9, shin: 45, wrap: 0.35, coat: 0.12, rim: 0.4, ao: 0.6 }),                // 2 glossy blue plastic
        E.mat({ dif: 0.75, spec: 0.9, shin: 55, metal: 0.35, wrap: 0.3, rim: 0.5, ao: 0.6 }),                // 3 chrome
        E.mat({ dif: 0.9, spec: 0.9, shin: 40, wrap: 0.4, ao: 0.4, emis: 0.08 }),                             // 4 spikes
        E.mat({ dif: 0.9, spec: 0.5, shin: 30, wrap: 0.6, emis: 0.1 }),                                      // 5 white rim
        E.mat({ dif: 0.8, spec: 0.3, shin: 20, wrap: 0.5, emis: 0.15 })                                      // 6 blue bean
      ],
      light: [0.35, 0.6, 0.72], lc: [0.85, 0.85, 0.85], amb: [0.36, 0.36, 0.38],
      envTop: [1, 1, 1], envHor: [0.55, 0.56, 0.6], envBot: [0.12, 0.12, 0.13], envK: [0.4, 1.0, 0.4, 0],
      rimC: [0.5, 0.52, 0.56], rimD: [0.4, 0.5, 0.3], r1: 2, r2: 10, k: [0, 0.6, 0.4, 70], shadow: [-8, 10, 0.55, 6]
    });
    E.grain(0.035, 33);
  }
});
