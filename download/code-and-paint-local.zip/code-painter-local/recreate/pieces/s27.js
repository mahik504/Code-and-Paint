'use strict';
// s27 — "Foil bouquet": a crumpled liquid-chrome figure under a black cowl, bursting into
// low-poly petals — lime, coral-to-magenta, steel blue slabs — on a peach-to-violet studio gradient.
REC.register('s27', {
  w: 1024, h: 1024,
  draw(E) {
    const W = 1024, H = 1024, S = E.S, o = E.out;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const fill = (path, c) => { o.fillStyle = c; o.fill(path); };
    const stroke = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const clipped = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const blurred = (px, fn) => { o.save(); o.filter = `blur(${px * S}px)`; fn(); o.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const poly = pts => P(pts, true, false);

    // ── studio gradient: peach (top left) -> mauve (right) -> violet (bottom right) ──
    const bg = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 peach = vec3(.80, .63, .50), mauve = vec3(.65, .53, .67), rose = vec3(.70, .53, .58), violet = vec3(.55, .45, .84);
      vec3 c = mix(peach, mauve, smoothstep(330., 760., p.x + .12 * p.y));
      c = mix(c, rose, .55 * smoothstep(180., 60., abs(p.x + .1 * p.y - 520.)) * smoothstep(420., 120., p.y));
      c = mix(c, rose, .6 * smoothstep(420., 620., p.y) * (1. - smoothstep(700., 900., p.y)));
      c = mix(c, violet, smoothstep(620., 940., p.y + .15 * (p.x - 800.)));
      return c; }`);
    E.draw(bg);

    // chrome textures
    // chrome: a folded height field lit by a studio environment (white top, dark horizon band, grey floor)
    const CHROME = `
      float hf(vec2 p){ vec2 q = p + 90. * vec2(vnoise(p * .004), vnoise(p * .004 + 7.)); vec2 f = mat2(.92, .39, -.39, .92) * q * vec2(SX, SY); return vnoise(f) + .5 * vnoise(f * 2.1 + 3.) + .18 * vnoise(q * .035 + 5.); }
      vec3 fx(vec2 uv, vec2 p){
        float e = 3., h0 = hf(p);
        vec3 n = normalize(vec3(-(hf(p + vec2(e, 0.)) - h0) * NRMK, -(hf(p + vec2(0., e)) - h0) * NRMK, 1.));
        float y = -n.y, x = n.x;
        float c = mix(HOR, TOP, smoothstep(.0, .5, y));
        c = mix(c, BOT, smoothstep(.0, -.45, y));
        c -= DARK * exp(-pow((y - .08) * 7., 2.));
        c += .35 * smoothstep(.55, .9, y + .3 * x);
        vec3 col = vec3(c) + .05 * iri(y * 2. + x) * smoothstep(.3, .8, c);
        return clamp(col, 0., 1.); }`;
    const chrome = (sx, sy, k, top, hor, bot, dark) => pat(E.fx(CHROME.split('SX').join(sx).split('SY').join(sy).split('NRMK').join(k)
      .split('TOP').join(top).split('HOR').join(hor).split('BOT').join(bot).split('DARK').join(dark)));
    const foil = chrome('.006', '.013', '30.', '1.0', '.9', '.58', '.3');
    const darkChrome = chrome('.02', '.006', '30.', '.85', '.4', '.12', '.3');

    // ── petals behind ──
    fill(poly([[42, 330], [48, 288], [90, 256], [140, 250], [140, 430], [100, 425], [62, 390]]), lin(40, 250, 140, 430, [[0, '#b8ea68'], [0.5, '#c6e27a'], [1, '#e2d8a8']]));
    const coral = poly([[434, 200], [456, 150], [505, 128], [548, 142], [584, 186], [570, 222], [540, 250], [480, 262], [446, 244]]);
    fill(coral, lin(440, 140, 580, 260, [[0, '#ff8a98'], [0.5, '#ff9c86'], [1, '#ffa47a']]));
    fill(poly([[584, 186], [570, 222], [540, 262], [520, 260], [560, 214]]), lin(540, 200, 584, 260, [[0, '#d8f070'], [1, '#a8e060']]));
    const pink = poly([[512, 320], [560, 262], [660, 226], [750, 206], [800, 214], [826, 260], [836, 350], [835, 415], [760, 410], [660, 414], [600, 405], [520, 370]]);
    fill(pink, lin(640, 206, 700, 420, [[0, '#ff9a80'], [0.35, '#ff8a9a'], [0.7, '#fc68c6'], [1, '#f65ad4']]));
    fill(poly([[620, 415], [835, 412], [770, 452], [712, 470]]), lin(620, 415, 780, 470, [[0, '#b0e880'], [0.6, '#c8f070'], [1, '#98d890']]));

    // ── steel-blue slabs ──
    fill(poly([[380, 262], [440, 250], [520, 262], [530, 300], [470, 330], [410, 300]]), lin(380, 250, 530, 330, [[0, '#9ab0c4'], [1, '#6a8298']]));
    fill(poly([[470, 330], [560, 300], [600, 380], [560, 440], [500, 460], [460, 400]]), lin(470, 300, 600, 460, [[0, '#a8b0b4'], [0.5, '#8a9aa8'], [1, '#6a7a8c']]));
    fill(poly([[330, 250], [400, 262], [380, 300], [350, 330]]), '#a8b8c8'); fill(poly([[350, 330], [380, 300], [420, 360], [372, 380]]), '#7a8a9a');
    fill(poly([[440, 250], [500, 200], [540, 250], [480, 262]]), '#9aacbc');
    fill(poly([[372, 380], [420, 360], [430, 440], [390, 452]]), '#e8e098');
    fill(poly([[420, 360], [470, 340], [480, 430], [430, 440]]), '#c8ccc0');
    const slab = poly([[464, 400], [560, 378], [822, 556], [764, 620], [620, 590], [470, 482]]);
    fill(slab, lin(470, 390, 800, 620, [[0, '#8ca2b8'], [0.5, '#7890a8'], [1, '#6a8298']]));
    fill(poly([[560, 378], [822, 556], [812, 566], [556, 392]]), '#4a4868');
    fill(poly([[470, 482], [620, 590], [764, 620], [700, 640], [560, 600]]), '#3a3c50');
    stroke(P([[380, 300], [470, 330], [560, 300]], false), 'rgba(40,40,60,0.6)', 2);

    // ── black cowl ──
    const cowl = P([[134, 290], [148, 212], [190, 175], [240, 158], [292, 170], [332, 212], [362, 272], [392, 342], [414, 402], [432, 472], [444, 560], [380, 600], [300, 560], [200, 440], [140, 400]]);
    fill(cowl, lin(150, 160, 440, 560, [[0, '#262626'], [0.4, '#1c1c1c'], [1, '#2c2c30']]));
    clipped(cowl, () => blurred(12, () => { stroke(P([[200, 190], [280, 200], [340, 280]], false), 'rgba(90,90,96,0.5)', 14); stroke(P([[360, 330], [400, 420], [420, 500]], false), 'rgba(120,120,130,0.5)', 10); }));

    fill(poly([[360, 300], [470, 480], [620, 590], [610, 700], [530, 690], [400, 600], [330, 500]]), '#1e1e22');
    // ── black diagonal blade ──
    const blade = poly([[330, 530], [480, 548], [582, 610], [606, 704], [530, 690], [420, 600]]);
    fill(blade, lin(330, 530, 600, 700, [[0, '#1a1a1c'], [0.5, '#2a2a2c'], [1, '#141416']]));
    stroke(P([[340, 532], [590, 610]], false), 'rgba(160,160,170,0.5)', 2);

    // ── the chrome figure (face column) ──
    const face = P([[100, 440], [104, 380], [120, 330], [150, 300], [200, 296], [260, 310], [300, 360], [330, 440], [360, 520], [380, 600], [350, 660], [260, 700], [150, 690], [96, 640], [98, 560]]);
    fill(face, darkChrome);
    clipped(face, () => {
      fill(poly([[100, 440], [150, 310], [200, 300], [160, 420], [120, 560], [100, 600]]), 'rgba(10,10,12,0.55)');
      blurred(8, () => { stroke(P([[230, 330], [262, 420], [280, 520]], false), 'rgba(255,255,255,0.55)', 16); fill(ellipseP(290, 420, 14, 40, -0.3), 'rgba(160,220,190,0.35)'); });
    });
    stroke(face, 'rgba(20,20,24,0.8)', 3);

    // ── crumpled chrome foil (bottom) ──
    const foilP = P([[0, 640], [60, 612], [100, 600], [160, 640], [230, 610], [300, 640], [360, 610], [420, 640], [470, 620], [520, 690], [600, 700], [640, 640], [690, 620], [740, 600], [760, 640], [720, 680], [705, 760], [700, 840], [670, 920], [660, 1030], [0, 1030]], true, false);
    fill(foilP, foil);
    clipped(foilP, () => {
      blurred(10, () => { fill(ellipseP(180, 760, 80, 40, 0.3), 'rgba(40,40,44,0.5)'); fill(ellipseP(430, 700, 60, 30, 0), 'rgba(30,30,34,0.5)'); fill(ellipseP(560, 880, 60, 40, -0.4), 'rgba(90,90,96,0.35)'); });
      // zebra stripes of a sleeve at the bottom left
      const sl = poly([[0, 880], [150, 850], [200, 1030], [0, 1030]]);
      clipped(sl, () => { fill(sl, '#e8e8e8'); for (let i = -4; i < 10; i++) fill(poly([[i * 44, 1030], [i * 44 + 24, 1030], [i * 44 + 96, 860], [i * 44 + 72, 860]]), '#6c6c6c'); });
    });
    // small crumpled black knot
    fill(poly([[340, 610], [380, 590], [420, 610], [410, 650], [370, 660]]), '#1a1a1c');
    fill(poly([[380, 600], [410, 612], [396, 634]]), '#8a8a90');

    E.draw(E.blur(E.snapshot(), 0.6), 0.5);
    E.grain(0.03, 27);
  }
});
