'use strict';
// g020 — "Zebra-masked moustache man": a glossy 3D bust against blue sky — cream noodle curls and a
// yellow quiff, green eyes, a face wrapped in black/white zebra stripes, a curly white moustache over
// buttery teeth, a pale neck, a cobalt turtleneck, a gold drape and a striped flag on the right.
REC.register('g020', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    for (const k of ['dome', 'flat', 'pipe', 'groove']) { const f0 = R[k]; R[k] = (...args) => { f0(...args); R.h.getImageData(0, 0, 1, 1); }; }
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const K = (path, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.lineCap = a.lineJoin = 'round'; a.stroke(path); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, r1, st) => { const g = a.createRadialGradient(x, y, r0, x, y, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const INK = '#141214', SKIN = '#dcc6a0';

    // ── sky ──
    R.flat(rrect(-10, -10, 746, 1044, 0), lin(0, 0, 0, 1024, [[0, '#2f7ec8'], [0.6, '#4498d6'], [1, '#4aa2da']]), 0, 0);

    // ── striped flag (right) ──
    const flag = P([[598, 250], [640, 205], [700, 168], [736, 150], [736, 1000], [690, 985], [630, 960], [598, 940], [594, 860], [604, 760], [600, 660], [612, 560], [636, 470], [662, 400], [670, 320], [640, 280]]);
    const fcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float ph;
      float u = p.x - 690.;
      if (p.y > 600.) ph = (p.y - 765.6 + 0.41 * (p.x - 680.)) / (28.3 + 0.0136 * (p.y - 750.));
      else if (p.y > 400.) ph = (p.y - 470. + 0.2824 * u - 2.3137e-3 * u * u) / (27.68 + 0.0126 * (p.y - 450.));
      else ph = (p.y - 489.4 + 0.011 * u - 0.0964e-3 * u * u) / (35.18 + 0.0399 * (p.y - 450.));
      float s = cos(6.2832 * ph) - 0.1;
      return mix(vec3(0.96, 0.95, 0.92), vec3(0.06), smoothstep(-0.12, 0.12, s)); }`);
    R.dome(flag, '#ffffff', 0.04, 0.1, 30, 2); clipA(flag, () => img(fcv));
    // ── gold drape ──
    const gold = P([[470, 600], [556, 586], [600, 612], [612, 700], [598, 800], [610, 880], [592, 946], [510, 934], [486, 860], [494, 760], [480, 680]]);
    R.dome(gold, lin(480, 600, 610, 940, [[0, '#e8b030'], [0.5, '#d09820'], [1, '#f0bc38']]), 0.06, 0.18, 30, 4);
    for (const y of [640, 700, 760, 820, 880]) R.pipe(P([[505, y], [550, y + 8], [598, y]], false), 18, null, 0.2, 0.06, 4);

    // ── shoulders + turtleneck ──
    R.dome(P([[-10, 884], [70, 868], [130, 880], [112, 1034], [-10, 1034]]), lin(0, 870, 120, 1024, [[0, '#4a4a52'], [1, '#2a2a30']]), 0.06, 0.08, 20, 3);
    R.pipe(P([[60, 900], [100, 1000], [110, 1034]], false), 22, '#d8a838', 0.12, 0.06, 4);
    R.dome(P([[500, 920], [590, 932], [650, 975], [690, 1010], [700, 1034], [520, 1034]]), '#141418', 0.06, 0.08, 20, 3);
    R.pipe(P([[520, 935], [560, 990], [575, 1034]], false), 18, '#d8a838', 0.12, 0.06, 4);
    const coll = P([[104, 1034], [112, 908], [150, 834], [182, 800], [260, 846], [380, 860], [478, 842], [500, 800], [540, 880], [568, 1034]]);
    R.dome(coll, lin(100, 800, 560, 1024, [[0, '#1c38b4'], [0.5, '#1430a8'], [1, '#0e2490']]), 0.1, 0.24, 50, 2);
    R.pipe(P([[156, 812], [182, 800], [260, 836], [380, 850], [478, 832], [500, 800]], false), 10, '#e8ecf0', 0.32, 0.06, 2);

    // ── neck ──
    const neck = P([[178, 600], [250, 700], [330, 750], [430, 760], [494, 720], [500, 800], [480, 838], [380, 852], [260, 840], [184, 800], [174, 700]]);
    R.dome(neck, lin(180, 700, 500, 800, [[0, '#b4ae8a'], [0.35, '#a8a684'], [0.6, '#5a6c6c'], [1, '#42545a']]), 0.1, 0.18, 50, 1);
    soft(x => { x.fillStyle = '#c8a050'; x.fill(ellipseP(260, 760, 30, 50, 0)); }, 16, 0.35);

    // ── hair: cream noodle curls + yellow quiff ──
    const hair = P([[62, 380], [70, 300], [90, 210], [130, 130], [190, 66], [260, 22], [340, 4], [420, 0], [500, 24], [570, 64], [624, 112], [662, 190], [672, 280], [666, 380], [648, 450], [610, 470], [600, 300], [560, 160], [420, 110], [260, 130], [200, 220], [176, 330], [170, 480], [160, 560], [120, 540], [80, 470]]);
    const hcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 8. * vec2(vnoise(p * 0.04), vnoise(p * 0.04 + 7.));
      float v = vnoise(q * 0.07) + 0.5 * vnoise(q * 0.14 + 3.);
      float b = abs(fract(v * 3.) - 0.5);
      float t = smoothstep(0.36, 0.2, b);
      return mix(vec3(0.52, 0.47, 0.40), vec3(0.90, 0.86, 0.79), t); }`);
    R.dome(hair, '#d8ccb8', 0.08, 0.16, 26, 1);
    clipA(hair, () => img(hcv));
    { const r = rng(21); for (let i = 0; i < 520; i++) { const x = 60 + r() * 620, y = 0 + r() * 570; if (!a.isPointInPath(hair, x * S, y * S)) continue; const an = r() * 6.283, rr = 5 + r() * 6;
      const pts = []; for (let k = 0; k <= 6; k++) { const t = an + k * 0.9; pts.push([x + Math.cos(t) * rr * (0.5 + k * 0.1), y + Math.sin(t) * rr * (0.5 + k * 0.1)]); }
      R.pipe(P(pts, false), 5.5, r() < 0.5 ? '#ece6da' : '#d2c8b6', 0.16 + r() * 0.04, 0.06, 1); } }
    { const r = rng(20); for (let i = 0; i < 140; i++) { const an = r() * 6.283; let x = 80 + r() * 580, y = 10 + r() * 470; const inside = (x - 390) * (x - 390) / (300 * 300) + (y - 250) * (y - 250) / (250 * 250) < 1; if (!inside) continue; R.pipe(P([[x, y], [x + Math.cos(an) * 10, y + Math.sin(an) * 10], [x + Math.cos(an + 1.5) * 16, y + Math.sin(an + 1.5) * 14]], false), 7, null, 0.18, 0.04, 1); } }
    // ── ears ──
    R.dome(P([[150, 368], [120, 360], [96, 380], [88, 420], [100, 470], [126, 510], [160, 530], [172, 480], [170, 400]]), '#c08a58', 0.14, 0.14, 20, 1);
    R.groove(P([[140, 390], [116, 400], [112, 440], [130, 480]], false), 6, '#8a5a38', 0.28, 0.06, 1, 0.8);
    R.dome(P([[590, 456], [616, 450], [630, 480], [626, 540], [604, 588], [584, 580]]), '#d4a676', 0.14, 0.12, 14, 1);
    // ── white coil by the ear ──
    for (let y = 572; y <= 728; y += 16) R.dome(ellipseP(152, y, 28, 9, 0), '#e8ecf0', 0.16, 0.06, 6, 3);

    // ── face: skin, then zebra mask ──
    const face = P([[214, 190], [260, 130], [400, 104], [540, 130], [600, 200], [616, 300], [612, 420], [598, 520], [566, 640], [516, 720], [430, 762], [330, 752], [252, 700], [202, 620], [180, 500], [176, 390], [186, 290]]);
    R.dome(face, lin(200, 100, 600, 500, [[0, '#e4d0a8'], [0.5, SKIN], [1, '#c8a880']]), 0.16, 0.22, 60, 1);
    // forehead wrinkles
    for (let k = 0; k < 4; k++) R.groove(P([[350, 182 + k * 13], [420, 176 + k * 13], [540, 186 + k * 13]], false), 4, '#a08060', 0.36, 0.04, 1, 0.6);
    const zcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float dx = p.x - 418.14;
      float f = (dx < 0. ? 3.4327 : 10.5231) * 1e-6 * abs(dx * dx * dx);
      float ph = (p.y - 437.46 - f) / (23.56 + 2.1735e-4 * dx * dx + 0.0077 * (p.y - 450.));
      float s = cos(6.2832 * ph) - 0.1;
      return mix(vec3(0.96, 0.95, 0.92), vec3(0.06), smoothstep(-0.15, 0.15, s)); }`);
    const mask = P([[178, 320], [230, 316], [380, 330], [470, 336], [612, 330], [612, 420], [598, 520], [566, 640], [516, 720], [430, 762], [330, 752], [252, 700], [202, 620], [180, 500]]);
    clipA(mask, () => img(zcv));
    // yellow quiff strands
    const quiff = [[[400, 60], [330, 80], [270, 120], [230, 170]], [[410, 58], [360, 90], [300, 150]], [[420, 60], [430, 110], [420, 150]], [[425, 58], [480, 90], [520, 120]], [[430, 60], [520, 80], [580, 130], [610, 200], [620, 270]], [[400, 70], [300, 110], [250, 150], [200, 240], [180, 330], [172, 420]], [[430, 70], [560, 110], [600, 180]], [[380, 66], [290, 90], [220, 140]]];
    for (const q of quiff) R.pipe(P(q, false), 22, '#f0d040', 0.26, 0.1, 5);
    R.dome(P([[236, 150], [270, 100], [330, 62], [400, 46], [470, 52], [540, 76], [590, 116], [620, 170], [630, 240], [610, 210], [580, 160], [540, 118], [500, 104], [470, 140], [440, 156], [425, 132], [395, 124], [340, 118], [290, 132], [250, 180], [214, 230], [196, 290], [186, 360], [176, 420], [164, 370], [170, 290], [190, 214]]), '#f2d444', 0.24, 0.1, 14, 5);
    for (const q of [[[540, 90], [590, 140], [612, 200], [622, 280], [610, 340]], [[600, 300], [606, 380], [596, 470]]]) R.pipe(P(q, false), 14, '#f0d040', 0.26, 0.08, 5);
    for (const [x, y, s] of [[90, 170, 1], [78, 270, 1], [62, 360, 1], [160, 70, 1]]) R.pipe(P([[x + 20, y - 10], [x, y - 14], [x - 10, y], [x, y + 12]], false), 12, '#f0d040', 0.2, 0.06, 5);

    // top-left zebra patch on the forehead
    const patch = P([[176, 270], [190, 210], [230, 150], [290, 120], [310, 140], [270, 190], [240, 250], [214, 300]]);
    clipA(patch, () => { a.fillStyle = '#f2f0ea'; a.fill(patch); a.lineWidth = 16; a.strokeStyle = '#0e0e10'; for (const off of [0, 36, 72]) a.stroke(P([[150 + off, 300], [190 + off, 220], [250 + off, 140], [290 + off, 110]], false)); });
    // skin eye sockets and nose
    const sockL = P([[204, 300], [262, 284], [340, 292], [384, 318], [374, 368], [342, 392], [290, 394], [238, 374], [206, 344]]);
    const sockR = P([[470, 334], [530, 320], [594, 330], [614, 360], [604, 414], [570, 434], [520, 432], [480, 406]]);
    R.dome(sockL, '#d8b890', 0.3, 0.06, 12, 1); R.dome(sockR, '#d8b890', 0.3, 0.06, 12, 1);
    const nose = P([[396, 296], [446, 296], [456, 380], [476, 440], [498, 478], [494, 516], [462, 532], [420, 536], [374, 526], [362, 500], [372, 458], [392, 400]]);
    R.dome(nose, lin(360, 300, 500, 540, [[0, '#e8d4ac'], [0.6, '#d8b888'], [1, '#c09468']]), 0.3, 0.16, 26, 1);
    R.groove(ellipseP(400, 512, 12, 7, 0.2), 8, '#5a3020', 0.42, 0.08, 1, 1); R.groove(ellipseP(462, 512, 12, 7, -0.2), 8, '#5a3020', 0.42, 0.08, 1, 1);
    // eyes
    for (const [cx, cy, rx, ry, ix] of [[310, 346, 48, 22, 312], [528, 380, 44, 22, 526]]) {
      R.dome(ellipseP(cx, cy, rx, ry, 0), '#f4f2ee', 0.34, 0.06, 10, 5);
      R.paint(circleP(ix, cy, 21), rad(ix, cy, 2, 21, [[0, '#0a2a20'], [0.3, '#18a070'], [0.85, '#108858'], [1, '#0c3a2a']]));
      R.paint(circleP(ix, cy, 8), '#080808'); R.paint(circleP(ix - 6, cy - 7, 4), '#ffffff');
      K(ellipseP(cx, cy, rx, ry, 0), '#6a4028', 3);
    }
    // eyebrows
    R.dome(P([[224, 278], [270, 252], [340, 246], [404, 262], [410, 286], [360, 274], [290, 274], [240, 292]]), '#121212', 0.38, 0.06, 6, 2);
    R.dome(P([[476, 292], [520, 276], [580, 282], [622, 318], [612, 326], [570, 300], [520, 298], [482, 306]]), '#121212', 0.38, 0.06, 6, 2);

    // ── buttery teeth, lips, moustache ──
    for (const [x, y, rx, ry] of [[330, 594, 34, 30], [388, 566, 36, 34], [452, 576, 36, 34], [500, 606, 28, 28], [316, 610, 20, 18]]) R.dome(ellipseP(x, y, rx, ry, 0), '#f6e09a', 0.4, 0.16, 18, 5);
    R.dome(P([[336, 622], [400, 612], [480, 616], [506, 634], [470, 656], [400, 662], [350, 648]]), lin(330, 600, 500, 670, [[0, '#f2c8a8'], [1, '#e4ac8c']]), 0.4, 0.08, 12, 5);
    R.groove(P([[300, 652], [400, 640], [520, 656]], false), 4, '#704030', 0.44, 0.06, 5, 0.8);
    const stache = [[[420, 548], [370, 548], [310, 552], [262, 566], [238, 592], [252, 610], [272, 600]], [[430, 548], [480, 552], [528, 572], [548, 610], [552, 650], [568, 672], [576, 656]]];
    for (const s of stache) R.pipe(P(s, false), 30, '#e6eaee', 0.46, 0.14, 3);
    R.pipe(P([[340, 470], [350, 460], [366, 462]], false), 14, '#e6eaee', 0.44, 0.08, 3);
    R.pipe(P([[480, 480], [496, 490]], false), 12, '#e6eaee', 0.44, 0.08, 3);
    // drips / spatters
    { const r = rng(7); for (let i = 0; i < 18; i++) R.bead(200 + r() * 420, 120 + r() * 450, 2 + r() * 4, '#f2f2f2', 0.44, 0.04, 3); }
    R.pipe(P([[230, 160], [270, 180], [320, 200], [330, 240], [338, 300]], false), 3, '#f0f0f0', 0.42, 0.03, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.7, shin: 40, wrap: 0.4, coat: 0.12, ao: 0.5, rim: 0.2 }),                // 1 glossy skin / plastic
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.3, coat: 0.2, ao: 0.4, rim: 0.2 }),                 // 2 lacquer
        E.mat({ dif: 1, spec: 0.9, shin: 50, wrap: 0.5, coat: 0.2, ao: 0.4 }),                           // 3 white gloss
        E.mat({ dif: 0.8, metal: 0.45, spec: 1.0, shin: 40, ao: 0.4, tint: [1.1, 0.95, 0.6], emis: 0.08 }),   // 4 gold
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.4, coat: 0.15, ao: 0.3 })                           // 5 yellow gloss / eyes
      ],
      light: [-0.35, 0.6, 0.72], lc: [0.75, 0.74, 0.72], amb: [0.42, 0.43, 0.46],
      envTop: [1.05, 1.08, 1.12], envHor: [0.45, 0.55, 0.7], envBot: [0.15, 0.18, 0.25], envK: [0.25, 0.8, 0.1, 0],
      rimC: [0.3, 0.4, 0.55], rimD: [0.4, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 80], shadow: [-6, 7, 0.6, 6]
    });
    // dark outline around the bust silhouette
    const o = E.out; o.lineWidth = 3; o.strokeStyle = INK; o.lineJoin = 'round'; o.stroke(face); o.stroke(neck);
    E.bloom(0.08, 8);
    E.grain(0.035, 20);
  }
});
