'use strict';
// g136 — "Crackled eye dish": a glossy cream dish with a grey crackle glaze and two holes like eyes, set on a
// zebra-striped hill under a night sky; orange and blue paint drips, a purple blob, rainbow streaks below.
REC.register('g136', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, x1 = x, y1 = y) => { const g = a.createRadialGradient(x1, y1, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true);
    const poly = pts => P(pts, true, false);
    // smooth radial dome written straight into the height buffer (no medial-axis creases)
    const rdome = (path, alb, cx, cy, rx, ry, h0, dh, m, op = 'source-over') => {
      if (alb) { a.fillStyle = alb; a.fill(path); }
      const hx = R.h; hx.save(); hx.clip(path); hx.globalCompositeOperation = op; hx.translate(cx, cy); hx.scale(1, ry / rx);
      const g = hx.createRadialGradient(0, 0, 0, 0, 0, rx);
      for (let i = 0; i <= 10; i++) { const t = i / 10; g.addColorStop(t, hc(h0 + dh * Math.sqrt(Math.max(0, 1 - t * t)), m)); }
      hx.fillStyle = g; hx.fillRect(-rx * 2, -rx * 2, rx * 4, rx * 4); hx.restore();
    };

    // ── rainbow streak floor (whole canvas) ──
    const floor = E.fx(`
      vec3 h(float x){ return vec3(float((int(x) >> 16) & 255), float((int(x) >> 8) & 255), float(int(x) & 255)) / 255.; }
      vec3 fx(vec2 uv, vec2 p){
        vec2 d = p - vec2(380., 640.);
        float an = atan(d.y, d.x) + 0.04 * (vnoise(vec2(length(d) * 0.01, 3.)) - .5);
        if (an < -1.0) an += 6.2832;
        const int N = 16;
        float A[N] = float[N](0.30, 0.80, 1.07, 1.22, 1.38, 1.56, 1.73, 1.90, 2.07, 2.20, 2.30, 2.42, 2.56, 2.68, 2.82, 2.98);
        vec3 C[N] = vec3[N](h(16017962.), h(15499397.), h(14122384.), h(14844283.), h(16156728.), h(14266977.), h(11780505.), h(11258028.), h(12963964.), h(11126705.), h(9748185.), h(9612241.), h(10258361.), h(11768489.), h(14664014.), h(11247044.));
        vec3 c = C[0];
        for (int i = 1; i < N; i++) c = mix(c, C[i], smoothstep(A[i - 1], A[i], an));
        float st = vnoise(vec2(an * 50., 1.)) * .6 + vnoise(vec2(an * 160., 7.)) * .4;
        c *= 0.93 + 0.14 * st;
        c = mix(c, vec3(.95, .93, .97), 0.3 * smoothstep(300., 180., length(d * vec2(0.8, 1.2))));
        return c; }`);
    img(floor);
    R.flat(rrect(-10, -10, 746, 1044, 0), null, 0, 0);
    // right-hand orange and lavender bands
    soft(x => { x.fillStyle = '#f46a2a'; x.fill(poly([[690, 560], [736, 540], [736, 1034], [660, 1034], [670, 800]])); }, 14, 0.9);
    soft(x => { x.fillStyle = '#9a62b0'; x.fill(poly([[640, 250], [736, 240], [736, 470], [700, 450], [680, 360]])); }, 4, 1);

    // ── night sky, grey ground, white grass, cloud ──
    R.flat(poly([[330, -10], [736, -10], [736, 250], [330, 250]]), lin(400, 60, 726, 220, [[0, '#c4c7cc'], [1, '#b4bcc2']]), 0.02, 1);
    R.flat(poly([[280, -10], [736, -10], [736, 98], [660, 102], [580, 96], [500, 84], [440, 66], [390, 46], [330, 18], [282, 0]]), lin(0, 0, 0, 100, [[0, '#06060f'], [1, '#0e0f20']]), 0.02, 0);
    R.paint(poly([[282, 0], [330, 18], [390, 46], [440, 66], [500, 84], [580, 96], [500, 98], [440, 82], [390, 62], [330, 32], [280, 12]]), '#cdd0d4');
    R.paint(sm([[370, 62], [420, 74], [470, 90], [500, 96], [496, 116], [470, 110], [420, 92]]), '#b294d0');
    soft(x => {
      const r = rng(5);
      for (let i = 0; i < 150; i++) {
        const t = r(), X = 400 + t * 336, base = 40 + 60 * Math.min(1, (X - 400) / 180) - (X > 640 ? (X - 640) * 0.05 : 0);
        const L = 15 + r() * 45, lean = (r() - 0.5) * 8;
        x.strokeStyle = `rgba(${170 + r() * 70 | 0},${175 + r() * 65 | 0},${190 + r() * 55 | 0},${0.25 + r() * 0.45})`;
        x.lineWidth = 0.6 + r() * 1.4; x.beginPath(); x.moveTo(X, base + 4); x.lineTo(X + lean, base - L); x.stroke();
      }
    }, 0.6, 1);
    soft(x => { x.fillStyle = '#f2f2f4'; for (const [cx, cy, r] of [[372, 18, 16], [360, 44, 15], [380, 56, 15], [374, 4, 12], [392, 30, 12], [350, 30, 10], [372, 68, 10]]) x.fill(circleP(cx, cy, r)); }, 3, 1);
    soft(x => { x.fillStyle = '#8a8c94'; for (const [cx, cy, r] of [[380, 60, 9], [366, 54, 7], [392, 44, 6]]) x.fill(circleP(cx, cy, r)); }, 4, 0.7);
    // pink patch top right
    R.dome(sm([[600, 190], [680, 172], [736, 168], [736, 262], [690, 252], [640, 232]]), '#f1b0b4', 0.04, 0.04, 8, 1);

    // ── cream platter under everything in the middle ──
    const platter = sm([[10, 590], [60, 560], [150, 560], [230, 530], [262, 470], [300, 440], [420, 430], [570, 420], [665, 430], [718, 480], [726, 560], [712, 650],
      [668, 728], [580, 786], [460, 806], [340, 800], [300, 790], [280, 700], [200, 660], [100, 652], [20, 650]]);
    R.dome(platter, lin(300, 400, 600, 800, [[0, '#f2ece0'], [1, '#e8dfd2']]), 0.06, 0.05, 14, 1);

    // ── zebra hill ──
    const zebraP = sm([[-20, -20], [270, -20], [280, 12], [330, 34], [390, 64], [440, 84], [480, 104], [452, 170], [400, 210], [362, 240], [356, 300], [372, 360], [360, 420], [320, 520], [290, 640],
      [120, 630], [70, 610], [-20, 606]]);
    // stripe phase: two smooth polynomial fields (hilltop / lower slope) fitted offline to the stripe flow
    const zcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float u = (p.x - 363.) / 512., v = (p.y - 512.) / 512.;
      float pT = 3. + 5.72403 -13.61994*u +63.86319*v -72.03041*u*u -12.94990*u*v +120.65071*v*v -64.08993*u*u*u -32.21998*u*u*v +8.14778*u*v*v +105.07552*v*v*v +7.94386*u*u*u*u +24.37957*u*u*u*v +47.11858*u*u*v*v -88.37483*u*v*v*v +67.38425*v*v*v*v +17.15965*u*u*u*u*u +39.15017*u*u*u*u*v +57.43609*u*u*u*v*v -25.21729*u*u*v*v*v -56.55076*u*v*v*v*v +33.72209*v*v*v*v*v;
      float pB = 3.65708 +41.92374*u +5.44256*v +107.21102*u*u +29.61125*u*v -24.10268*v*v +136.12708*u*u*u +89.26613*u*u*v -45.03281*u*v*v +9.31625*v*v*v +62.42804*u*u*u*u +80.25938*u*u*u*v -50.36387*u*u*v*v -2.31313*u*v*v*v +35.15684*v*v*v*v;
      float ph = mix(pT, pB, smoothstep(285., 315., p.y));
      float s = cos(6.2832 * ph);
      float k = 0.9 / max(fwidth(ph) * 6.2832, 1e-3);
      float c = clamp(0.5 + s * min(k, 6.) * 0.5, 0., 1.);
      return mix(vec3(.025, .025, .03), vec3(.96, .94, .89), c); }`);
    R.flat(zebraP, null, 0.08, 2);
    clipA(zebraP, () => img(zcv));
    // white grains on the dark stripes (top left)
    for (const [x, y, rx, ry, rt] of [[118, 98, 11, 4, -0.2], [70, 165, 12, 5, 0.1], [88, 200, 14, 6, 0.2], [18, 132, 9, 4, 0], [95, 246, 6, 3, 0], [182, 128, 7, 3, 0.2], [270, 152, 5, 2, 0]])
      R.dome(ellipseP(x, y, rx, ry, rt), '#f2eee6', 0.08, 0.04, 3, 3);

    // ── pink lumps on the left edge ──
    R.dome(sm([[-20, 482], [30, 486], [58, 516], [62, 560], [44, 600], [10, 612], [-20, 606]]), rad(10, 530, 80, [[0, '#f8bcb8'], [1, '#f2a8a6']], 0, 510), 0.1, 0.14, 26, 1);
    R.dome(sm([[-20, 180], [8, 196], [16, 240], [10, 290], [-20, 300]]), '#f4b2b0', 0.1, 0.08, 10, 1);

    // ── grey disc on its cream rim with a red pool ──
    const rim = sm([[124, 318], [138, 284], [176, 266], [232, 254], [282, 240], [306, 228], [332, 240], [346, 270], [334, 302], [314, 330], [300, 372], [280, 398], [236, 410], [180, 406], [140, 388], [124, 356]]);
    R.dome(rim, '#f1ebe0', 0.1, 0.07, 10, 1);
    R.dome(sm([[198, 262], [276, 254], [318, 246], [336, 266], [326, 300], [308, 330], [276, 310], [236, 284]]), '#f04424', 0.12, 0.02, 6, 1);
    R.dome(ellipseP(216, 344, 84, 60, -0.12), rad(216, 344, 90, [[0, '#c4c6cc'], [1, '#aeb2ba']], 190, 320), 0.16, 0.03, 8, 3);
    R.groove(P([[192, 340], [200, 330], [212, 336], [222, 324], [240, 332], [252, 344], [262, 340], [270, 352]], false), 2.5, '#9a9ea8', 0.19, 0.02, 3);
    R.groove(P([[198, 324], [206, 312], [214, 322], [210, 348], [196, 356]], false), 2, '#9a9ea8', 0.19, 0.02, 3);

    // ── light blue band behind the orange blob ──
    R.dome(sm([[566, 404], [604, 330], [652, 316], [690, 410], [726, 436], [700, 486], [650, 470], [600, 446]]), '#7cc0f0', 0.08, 0.06, 10, 1);

    // ── orange blob with its drips and a comb of pale strands ──
    R.dome(sm([[410, 176], [470, 150], [560, 148], [612, 160], [650, 200], [656, 260], [646, 320], [620, 360], [600, 400], [570, 418], [530, 390], [490, 346], [440, 330], [400, 300], [380, 250]]),
      lin(400, 150, 600, 400, [[0, '#ff7a14'], [1, '#f86a10']]), 0.12, 0.06, 12, 1);
    // dark comb + pale strands
    R.flat(sm([[356, 300], [500, 300], [508, 340], [480, 380], [420, 392], [372, 380], [356, 340]]), '#2a1612', 0.1, 0);
    for (let i = 0; i < 12; i++) {
      const x0 = 366 + i * 11.5, x1 = x0 + 4 + (i - 6) * 1.5;
      R.pipe(P([[x0, 302], [x0 + 2, 340], [x1, 386]], false), 5, '#e8c8c8', 0.12, 0.05, 2);
    }
    // drippy lighter-orange fringe
    const fr = [[330, 206], [342, 196], [352, 222], [362, 238], [374, 222], [388, 200], [402, 184], [414, 200], [430, 190], [446, 174], [462, 182], [480, 200], [494, 236], [500, 270],
      [496, 300], [490, 326], [478, 316], [470, 332], [458, 320], [444, 330], [432, 318], [418, 330], [404, 318], [392, 330], [380, 318], [368, 326], [360, 296], [352, 262], [340, 240]];
    R.dome(sm(fr), lin(330, 180, 500, 330, [[0, '#ffa424'], [0.6, '#ff9a1c'], [1, '#f68a14']]), 0.14, 0.1, 12, 2);
    // blue drips on the fringe
    for (const cl of [[[378, 204], [386, 228], [384, 252]], [[404, 196], [410, 222], [420, 246], [428, 262]], [[432, 210], [446, 236], [458, 260], [466, 270]], [[452, 196], [468, 214], [480, 236]], [[392, 220], [396, 244]]])
      R.dome(P(lock(cl, 18, 5)), '#1860e0', 0.24, 0.04, 6, 2);
    // green / navy / sky blue lumps at the top
    R.dome(ellipseP(474, 122, 28, 42, -0.55), lin(450, 90, 500, 160, [[0, '#46c43a'], [1, '#1e9a2c']]), 0.14, 0.12, 20, 2);
    R.dome(ellipseP(532, 128, 36, 22, 0.35), '#1238d0', 0.14, 0.08, 14, 2);
    R.dome(ellipseP(448, 154, 22, 14, 0.1), '#58b4f2', 0.16, 0.05, 8, 2);
    R.dome(sm([[480, 150], [520, 140], [560, 150], [552, 168], [500, 170]]), '#ff9a1c', 0.16, 0.04, 6, 2);
    // pink spots and the grey button on the orange
    R.dome(P(blob(470, 190, 24, 18, 4, 10, 0.18)), '#f6a8b2', 0.16, 0.02, 5, 1);
    R.dome(P(blob(612, 298, 28, 20, 6, 10, 0.18)), '#f6a8b2', 0.16, 0.02, 5, 1);
    R.dome(ellipseP(540, 293, 36, 26, 0), '#a8acb4', 0.16, 0.03, 6, 3);
    R.groove(P([[548, 286], [540, 282], [530, 288], [532, 300], [544, 302]], false), 3, '#8a8e98', 0.19, 0.03, 3);

    // blue splat with a grey-speckled heart
    const sp = [];
    { const r = rng(17); for (let i = 0; i < 26; i++) { const t = i / 26 * 6.283, k = 1 + (r() - 0.5) * 0.45 + (i % 3 === 0 ? 0.22 : 0); sp.push([602 + Math.cos(t) * 90 * k, 218 + Math.sin(t) * 66 * k]); } }
    sp.splice(6, 0, [660, 290], [692, 322], [694, 342], [664, 336], [632, 300]);
    R.dome(sm(sp), '#1450d8', 0.16, 0.06, 10, 2);
    R.dome(P(blob(598, 220, 60, 42, 23, 14, 0.3)), '#b4bccc', 0.2, 0.02, 4, 3);
    { const r = rng(29); for (let i = 0; i < 28; i++) R.dome(ellipseP(548 + r() * 100, 190 + r() * 60, 3 + r() * 6, 1.5 + r() * 3, r() * 3), '#1a58da', 0.22, 0.02, 2, 2); }
    R.dome(ellipseP(640, 182, 26, 10, -0.1), '#58b4f2', 0.18, 0.04, 6, 2);

    // ── the dish ──
    const dish = sm([[255, 560], [272, 490], [310, 436], [370, 398], [450, 372], [560, 378], [650, 405], [705, 460], [714, 540], [692, 610], [640, 660], [560, 690], [460, 700], [360, 696], [290, 684], [256, 640]]);
    R.dome(dish, lin(300, 380, 680, 700, [[0, '#f2ebde'], [1, '#ddd4c6']]), 0.12, 0.1, 18, 2);
    const inner = sm([[292, 570], [306, 494], [348, 432], [420, 402], [520, 396], [612, 410], [660, 440], [670, 466], [636, 490], [590, 530], [548, 585], [490, 628], [440, 646], [350, 656], [300, 640]]);
    R.flat(inner, '#a2aab6', 0.14, 4);
    const crk = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p * 0.034 + 0.35 * vec2(fbm(p * 0.03), fbm(p * 0.03 + 5.));
      vec2 i = floor(q), f = fract(q); float d1 = 9., d2 = 9.;
      for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) { vec2 g = vec2(x, y), o = vec2(hash(i + g), hash(i + g + 19.7)); float d = length(g + o - f); if (d < d1) { d2 = d1; d1 = d; } else if (d < d2) d2 = d; }
      float e = smoothstep(0.07, 0.0, d2 - d1 - 0.02 * vnoise(p * 0.2));
      float sh = 0.92 + 0.12 * fbm(p * 0.02);
      vec3 base = vec3(.54, .58, .65) * sh;
      return mix(base, vec3(.9, .91, .93), e * 0.85); }`);
    clipA(inner, () => img(crk));
    soft(x => { x.fillStyle = '#e8eef4'; x.fill(ellipseP(330, 600, 50, 40, 0.4)); x.fill(ellipseP(600, 440, 50, 18, 0.3)); }, 18, 0.5);
    // spiral groove ring
    const spiral = P([[566, 578], [500, 594], [420, 590], [370, 560], [362, 510], [400, 455], [480, 424], [580, 428], [650, 470], [664, 530], [630, 590], [560, 626], [460, 636], [370, 626], [318, 600]], false);
    R.pipe(spiral, 18, '#ece6da', 0.15, 0.06, 2);
    R.bead(567, 578, 9, '#ece4d8', 0.18, 0.06, 2);
    R.bead(497, 456, 6, '#b8bcc4', 0.16, 0.04, 3);
    // eye holes and the little ring
    const hole = (x, y, r0, r1) => { R.dome(circleP(x, y, r0), '#e4e0dc', 0.16, 0.08, r0 - r1, 3); R.flat(circleP(x, y, r1), '#06060a', 0.1, 0); };
    hole(478, 494, 22, 12); hole(542, 524, 34, 17);
    R.dome(circleP(348, 577, 18), '#dcdad8', 0.16, 0.05, 7, 3); R.flat(circleP(348, 577, 10), '#9aa2ae', 0.15, 4);

    // ── light blue ribbon wrapping the dish, blue tube right ──
    R.pipe(P([[736, 440], [690, 474], [646, 506], [604, 548], [560, 604], [500, 650], [420, 678], [340, 690], [304, 712], [292, 760]], false), 28, '#80c4f2', 0.14, 0.1, 2);
    R.dome(sm([[640, 470], [700, 430], [736, 410], [736, 470], [700, 500], [660, 520]]), '#80c4f2', 0.14, 0.1, 10, 2);
    R.dome(sm([[300, 700], [340, 690], [334, 740], [310, 770], [290, 760], [288, 720]]), '#80c4f2', 0.12, 0.06, 10, 2);
    R.pipe(P([[628, 776], [680, 752], [736, 742]], false), 44, '#86c6f0', 0.14, 0.14, 2);
    R.bead(626, 774, 22, '#86c6f0', 0.14, 0.16, 2);
    // orange chip under the dish
    R.dome(sm([[312, 722], [350, 706], [398, 712], [406, 770], [340, 778], [304, 762]]), '#ff6a12', 0.1, 0.04, 6, 1);

    // ── purple blob ──
    const pb = sm([[46, 724], [60, 684], [92, 652], [140, 630], [200, 618], [244, 622], [262, 656], [292, 704], [302, 752], [282, 808], [246, 836], [228, 870], [200, 900], [168, 906], [150, 884], [154, 852], [120, 830], [72, 802], [48, 770]]);
    soft(x => { x.fillStyle = '#1a1020'; x.translate(16, 22); x.fill(pb); }, 16, 0.75);
    rdome(pb, rad(160, 720, 200, [[0, '#8a3a80'], [0.6, '#702c6a'], [1, '#4a1c44']], 150, 700), 168, 740, 150, 140, 0.12, 0.34, 5);
    rdome(sm([[146, 800], [190, 790], [244, 820], [240, 870], [208, 904], [170, 910], [146, 884]]), '#6a2a64', 196, 864, 56, 52, 0.12, 0.26, 5, 'lighten');
    R.dome(P(lock([[80, 690], [78, 668], [74, 650]], 18, 5)), '#8a3a80', 0.3, 0.06, 6, 5);

    // ── grey pearls ──
    for (const [x, y, r] of [[70, 382, 11], [178, 442, 13], [122, 553, 22], [274, 500, 20], [303, 305, 15], [583, 340, 17], [621, 348, 12], [143, 244, 6], [303, 263, 7], [302, 450, 4]])
      R.bead(x, y, r, '#b8bcc6', 0.14, 0.1, 3);
    R.bead(629, 374, 7, '#f4d020', 0.18, 0.05, 2);
    R.dome(ellipseP(668, 391, 7, 5, 0), '#1660e0', 0.18, 0.03, 4, 2);
    R.bead(456, 746, 3, '#c8c0bc', 0.12, 0.02, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.7, shin: 40, wrap: 0.5, ao: 0.4, coat: 0.12 }),                    // 1 glossy cream / paint
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.5, ao: 0.4, coat: 0.18 }),                    // 2 wet gloss
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.45, ao: 0.4, coat: 0.15 }),                   // 3 grey clay gloss
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.5, ao: 0.2, coat: 0.08 }),                    // 4 crackle glaze
        E.mat({ dif: 1, spec: 1.0, shin: 40, wrap: 0.3, ao: 0.4, grain: 0.1, coat: 0.35 }),       // 5 dimpled purple
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.72, 0.72, 0.7], amb: [0.45, 0.45, 0.47],
      envTop: [1.1, 1.1, 1.15], envHor: [0.75, 0.75, 0.8], envBot: [0.1, 0.1, 0.14], envK: [0.5, 1.2, 0, 0],
      r1: 1.4, r2: 7, k: [0, 0.6, 0.4, 150], shadow: [-5, 7, 0.65, 8]
    });
    E.grain(0.025, 136);
  }
});
