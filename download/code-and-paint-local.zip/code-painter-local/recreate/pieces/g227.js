'use strict';
// g227 — "Brain-coral patchwork": a quilt of glossy relief panels — chrome brain-maze slabs, rust-red and
// speckled sand meanders — framing a lava cave with goggle-eyed creatures, a grey gel puddle with a sandy core,
// a toothy cream mouth with a tan worm, an eclipse eye, a spotted helmet under a blue sky, and starry black corners.
REC.register('g227', {
  w: 706, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over', clipP = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clipP) a.clip(clipP); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = (cv, alpha = 1, op = 'source-over') => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.drawImage(cv, 0, 0); a.restore(); };
    const hImg = (cv, path) => { R.h.save(); R.h.clip(path); R.h.setTransform(1, 0, 0, 1, 0, 0); R.h.drawImage(cv, 0, 0); R.h.restore(); };
    const lg = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rg = (x0, y0, r0, x1, y1, r1, stops) => { const g = a.createRadialGradient(x0, y0, r0, x1, y1, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const MAR = 1, SIL = 2, SAND = 3, GEL = 4, PLA = 5, CLAY = 6, GLOS = 7;
    // height-field shaders: return the relief painter's height encoding (R = int, G = material, B = fraction)
    const enc = m => `vec3 E8(float h){ float v = clamp(h, 0., 1.) * 255., i = floor(v); return vec3(i / 255., ${m * 32}. / 255., v - i); }`;
    // labyrinth: zero set of a sum of random-direction waves of one wavelength (a Turing / brain-coral pattern)
    const MAZE = `float maze(vec2 p, float lam, float sd){
        vec2 q = p + lam * 0.7 * vec2(vnoise(p / (lam * 1.6) + sd), vnoise(p / (lam * 1.6) + sd + 5.3));
        float s = 0.; vec2 g = vec2(0.);
        for (int i = 0; i < 14; i++) { float fi = float(i), an = 6.2832 * hash(vec2(fi * 1.31, sd)), ph = 6.2832 * hash(vec2(sd + 2.7, fi * 0.73));
          vec2 k = vec2(cos(an), sin(an)) * 6.2832 / lam; float t = dot(q, k) + ph; s += cos(t); g -= sin(t) * k; }
        float d = abs(s) / max(length(g), 1e-4), u = clamp(d / (lam * 0.24), 0., 1.);
        return sqrt(1. - (1. - u) * (1. - u)); }`;
    const fxH = (body, m) => E.fx(enc(m) + MAZE + `vec3 fx(vec2 uv, vec2 p){ ${body} }`);

    // ── 1. rust-red meander everywhere (left strip, top strip, bottom-left block) ──
    R.flat(rrect(-10, -10, 726, 1044, 0), lg(0, 0, 300, 1024, [[0, '#c8665e'], [0.5, '#c4645c'], [1, '#bc5e56']]), 0.1, MAR);
    hImg(fxH(`return E8(0.08 + 0.2 * maze(p, 86., 3.));`, MAR), rrect(-10, -10, 726, 1044, 0));
    soft(x => { const r = rng(2271); x.fillStyle = '#f0d8d0'; for (let i = 0; i < 220; i++) { const px = 10 + r() * 140, py = 800 + r() * 220; x.globalAlpha = r(); x.fill(circleP(px, py, 0.5 + r())); } }, 0.3, 0.9);

    // ── 2. skies: top-left blue, top-right + bottom-right starry black, right blue sky ──
    const stars = (x0, y0, w, h, n, seed) => { const r = rng(seed); for (let i = 0; i < n; i++) { a.globalAlpha = 0.4 + r() * 0.6; a.fillStyle = '#fff8f0'; a.fill(circleP(x0 + r() * w, y0 + r() * h, 0.5 + r() * 1.1)); } a.globalAlpha = 1; };
    R.flat(P([[30, -10], [215, -10], [215, 60], [30, 70]], true, false), '#0b32b4', 0.01, 0);
    const spT = P([[499, 111], [505, 40], [555, -10], [716, -10], [716, 200], [600, 200], [560, 180]], true, false);
    R.flat(spT, '#050407', 0.01, 0); clipA(spT, () => stars(499, 0, 210, 120, 70, 2272));
    const sky = P([[600, 192], [640, 186], [716, 180], [716, 600], [550, 600], [548, 330], [575, 240]], true, false);
    R.flat(sky, lg(0, 60, 0, 600, [[0, '#2a5af0'], [0.45, '#3a7af8'], [0.75, '#5c98f8'], [1, '#78b0f4']]), 0.01, 0);
    clipA(sky, () => { const r = rng(2273); a.fillStyle = '#e8f0ff'; for (let i = 0; i < 25; i++) { a.globalAlpha = 0.6; a.fill(circleP(560 + r() * 150, 200 + r() * 300, 1 + r() * 1.5)); } a.globalAlpha = 1; });
    soft(x => fe(x, 682, 383, 62, 58, 0, '#ffffff'), 14, 0.6);
    R.flat(ellipseP(682, 385, 50, 46, 0), '#ffffff', 0.02, 0);
    R.flat(P([[548, 525], [600, 520], [716, 515], [716, 600], [548, 600]], true, false), '#62c4d6', 0.02, 0);
    R.flat(P([[555, 556], [620, 562], [650, 574], [640, 585], [560, 578]], true, true), '#f4f8f8', 0.03, 0);
    const peach = P([[580, 455], [600, 420], [640, 405], [690, 400], [716, 405], [716, 500], [690, 505], [660, 520], [610, 545], [578, 540], [568, 505]]);
    R.dome(peach, '#f4ae80', 0.03, 0.04, 14, CLAY);
    R.bead(690, 260, 12, '#e82838', 0.04, 0.05, PLA);
    const spB = P([[557, 834], [544, 860], [551, 938], [545, 1034], [716, 1034], [716, 826], [639, 834], [587, 824]], true, false);
    R.flat(spB, '#050407', 0.01, 0);
    clipA(spB, () => {
      stars(545, 830, 170, 200, 90, 2274);
      for (const [x, y, r, c] of [[668, 888, 10, '#d040e0'], [568, 990, 9, '#c040e0'], [596, 875, 6, '#7090f0'], [690, 985, 17, '#4070e0'], [660, 1010, 5, '#e0a040']]) soft(q => fe(q, x, y, r, r, 0, c), r * 0.5, 0.9);
      R.paint(circleP(690, 985, 12), '#3a68d8'); R.paint(circleP(690, 985, 6), '#a8c0ff');
    });

    // ── 3. lava cave ──
    const cave = P([[25, 290], [330, 290], [330, 590], [25, 590]], true, false);
    const LAVA = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.03), m = fbm(p * 0.012 + 4.);
      vec3 c = mix(vec3(0.85, 0.22, 0.04), vec3(0.98, 0.5, 0.08), smoothstep(0.35, 0.75, n));
      c = mix(c, vec3(0.2, 0.55, 0.12), smoothstep(0.62, 0.7, fbm(p * 0.05 + 9.)) * step(p.y, 400.));
      c = mix(c, vec3(0.12, 0.02, 0.02), smoothstep(0.66, 0.74, fbm(p * 0.045 + 3.)) * 0.8);
      c *= 0.85 + 0.3 * hash(floor(p / 2.));
      // river and flows (lower area)
      float d = p.y - (560. - (p.x - 30.) * 0.95) + 40. * (m - 0.5);
      vec3 red = vec3(0.97, 0.13, 0.05), yel = vec3(0.98, 0.84, 0.18);
      float band = sin((p.x * 0.9 + p.y * 0.6) * 0.045 + 3. * m);
      vec3 flow = mix(red, yel, smoothstep(0.55, 0.75, band) * step(170., p.x));
      c = mix(c, flow, smoothstep(-10., 10., d - 40.));
      float riv = abs(p.y - (430. - (p.x - 150.) * 0.3) - 30. * (m - 0.5)) - 42. - 0.35 * max(0., 130. - p.x);
      vec3 dk = mix(vec3(0.1, 0.02, 0.02), vec3(0.3, 0.06, 0.05), smoothstep(0.4, 0.8, fbm(p * 0.05)));
      c = mix(c, dk, smoothstep(6., -6., riv));
      return c; }`);
    R.flat(cave, null, 0.02, 0); clipA(cave, () => img(LAVA));
    // glossy river highlights
    soft(x => { x.strokeStyle = '#f0c8c0'; x.lineWidth = 2; for (const L of [[[260, 340], [210, 370], [160, 405]], [[120, 500], [80, 515], [50, 530]], [[230, 390], [190, 420]]]) x.stroke(P(L, false)); }, 1, 0.6);
    // goggle-eyed creatures
    const SK = '#d27a58', OUT = '#2a120c';
    // small one: dark cap, two blue eyes
    R.dome(ellipseP(90, 380, 40, 42, -0.35), OUT, 0.04, 0.08, 10, CLAY);
    R.dome(ellipseP(96, 392, 30, 26, -0.35), SK, 0.07, 0.06, 8, CLAY);
    for (const [x, y] of [[79, 400], [100, 376]]) { R.dome(circleP(x, y, 12), '#1c0c08', 0.11, 0.04, 4, PLA); R.paint(circleP(x, y, 8), '#5aa8e0'); R.paint(circleP(x, y, 3.5), '#101820'); }
    // big goggle head, body, hands
    R.dome(P([[100, 440], [120, 405], [150, 390], [180, 400], [195, 430], [185, 465], [150, 480], [120, 476]]), OUT, 0.04, 0.08, 10, CLAY);
    R.dome(P([[106, 440], [124, 410], [150, 398], [175, 406], [188, 432], [180, 460], [150, 472], [124, 468]]), SK, 0.06, 0.08, 14, CLAY);
    R.dome(circleP(152, 424, 31), OUT, 0.12, 0.06, 8, CLAY);
    R.dome(circleP(152, 424, 24), '#c86448', 0.16, 0.04, 6, CLAY);
    R.dome(circleP(152, 425, 14), '#0c0c0c', 0.19, 0.04, 5, PLA); R.paint(circleP(152, 425, 8), '#a8ece4'); R.paint(circleP(152, 425, 3.5), '#203030');
    for (const [x, y, rx, ry, rot] of [[176, 458, 18, 14, 0.3], [78, 496, 24, 18, 0.2], [110, 488, 20, 16, -0.2]]) { R.dome(ellipseP(x, y, rx + 2, ry + 2, rot), OUT, 0.06, 0.04, 4, CLAY); R.dome(ellipseP(x, y, rx, ry, rot), SK, 0.08, 0.06, 7, CLAY); }
    R.dome(ellipseP(112, 462, 15, 19, 0.2), '#ffe040', 0.12, 0.08, 8, GLOS);
    soft(x => fe(x, 112, 462, 24, 24, 0, '#fff080'), 9, 0.6);

    // ── 4. psychedelic panel, bottom centre ──
    const psy = P([[270, 540], [565, 540], [565, 830], [270, 830]], true, false);
    const PSY = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 30. * vec2(fbm(p * 0.012), fbm(p * 0.012 + 5.));
      float n = fbm(q * 0.018);
      vec3 c = mix(vec3(0.07, 0.14, 0.28), vec3(0.15, 0.52, 0.62), smoothstep(0.35, 0.65, n));
      c = mix(c, vec3(0.03, 0.05, 0.12), smoothstep(0.62, 0.72, fbm(q * 0.03 + 2.)) * 0.8);
      float pk = smoothstep(0.58, 0.64, fbm(q * 0.015 + 11.));
      c = mix(c, vec3(0.95, 0.42, 0.38), pk);
      // rainbow swirl, top left
      float sw = length((p - vec2(400., 640.)) / vec2(1.6, 1.)) + 8. * fbm(p * 0.03);
      vec3 rb = 0.5 + 0.5 * cos(6.2832 * (sw / 34. + vec3(0., .33, .67)));
      c = mix(c, mix(rb, vec3(1.), 0.25), smoothstep(80., 70., sw) * smoothstep(40., 50., sw) * step(p.y, 615.) * step(p.x, 420.));
      return c; }`);
    R.flat(psy, null, 0.02, 0); clipA(psy, () => img(PSY));
    // salmon flows, rainbow swirl, glitch stripe, finger lobes
    R.pipe(P([[300, 596], [306, 660], [300, 720], [312, 790]], false), 30, '#f07a6c', 0.04, 0.06, GLOS);
    R.pipe(P([[336, 606], [372, 590], [430, 592], [482, 604], [520, 632], [532, 676]], false), 30, '#f07466', 0.04, 0.07, GLOS);
    { const cols = ['#2050e0', '#f8f8ff', '#e83040', '#30c050', '#f8e030', '#8030c0', '#2a60f0', '#f8f8ff', '#20b0e0', '#e83040'];
      const loop = ellipseP(345, 608, 60, 34, 0.12);
      R.dome(loop, '#101018', 0.05, 0.06, 10, GLOS);
      cols.forEach((c, i) => R.paint(ellipseP(345 + i * 1.5, 608 + i * 0.6, 55 - i * 5, 30 - i * 2.8, 0.12), c)); }
    a.save(); a.lineWidth = 4; for (const [c, o] of [['#f0e040', 0], ['#40a0f0', 5], ['#e040c0', 10]]) { a.strokeStyle = c; a.stroke(P([[322 + o, 640], [326 + o, 700], [320 + o, 760]], false)); } a.restore();
    for (const [x, y, rx, ry] of [[322, 800, 22, 32], [385, 806, 22, 24], [452, 806, 32, 20]]) R.dome(ellipseP(x, y, rx, ry, 0), '#f48c80', 0.06, 0.1, 12, GLOS);
    // sandy disc, badge, grey sphere, red beads
    const disc2 = P(blob(438, 684, 72, 70, 2275, 16, 0.04));
    R.dome(disc2, '#d0a888', 0.06, 0.06, 10, SAND);
    clipA(disc2, () => { const r = rng(2276); a.fillStyle = '#1a1210'; for (let i = 0; i < 120; i++) a.fill(circleP(366 + r() * 144, 614 + r() * 140, 0.6 + r() * 1.8)); });
    R.dome(circleP(425, 677, 19), '#5a2a1c', 0.1, 0.04, 6, PLA);
    R.paint(circleP(425, 677, 14), '#3a7ee0');
    soft(x => { x.strokeStyle = '#e8f4ff'; x.lineWidth = 3; x.stroke(P([[416, 686], [420, 670], [432, 668], [430, 680], [438, 684]], false)); }, 0.5, 1);
    R.bead(470, 722, 38, rg(458, 708, 2, 470, 722, 38, [[0, '#a8a4a8'], [0.6, '#6e6a70'], [1, '#4a464c']]), 0.12, 0.3, GEL);
    for (const [x, y, r] of [[535, 620, 9], [523, 677, 18], [518, 762, 12], [450, 787, 6], [398, 697, 7], [512, 640, 6], [384, 696, 5]]) R.bead(x, y, r, '#e83a2a', 0.1, Math.min(0.3, r * 0.015), GLOS);

    // ── 5. chrome brain-maze slabs ──
    const silT = P([[31, 59], [152, 58], [191, 41], [240, 54], [305, 55], [339, 43], [389, 42], [424, 27], [448, 28], [499, 47], [506, 110], [516, 140], [540, 165], [450, 170], [350, 170],
      [300, 180], [260, 205], [236, 236], [223, 270], [216, 312], [172, 304], [147, 313], [114, 313], [86, 302], [53, 302], [32, 236], [42, 160], [31, 130]]);
    const silM = P([[49, 545], [89, 530], [196, 539], [197, 550], [271, 554], [285, 590], [300, 600], [298, 700], [300, 780], [314, 800], [314, 814], [272, 814], [237, 795], [188, 797],
      [145, 788], [81, 792], [29, 766], [19, 727], [32, 648], [24, 594]]);
    const SILH = fxH(`return E8(0.3 + 0.2 * maze(p, 72., 11.));`, SIL);
    for (const pth of [silT, silM]) {
      soft(x => { x.strokeStyle = '#141414'; x.lineWidth = 5; x.stroke(pth); }, 2, 0.8);
      R.flat(pth, '#d4d4d8', 0.3, SIL); hImg(SILH, pth);
    }
    R.dome(circleP(338, 124, 15), '#0a0a0c', 0.3, 0.02, 3, PLA);
    R.paint(circleP(338, 124, 11), '#000000');

    // ── 6. speckled sand meanders ──
    const sandR = P([[566, 590], [557, 619], [546, 620], [547, 660], [559, 701], [540, 764], [540, 839], [587, 823], [639, 833], [716, 825], [716, 585]], true, true);
    const sandB = P([[300, 795], [331, 795], [364, 797], [367, 811], [395, 820], [476, 806], [531, 825], [541, 795], [559, 795], [559, 833], [542, 862], [550, 938], [545, 1034], [317, 1034],
      [305, 995], [318, 834], [300, 815]], true, true);
    const SANDH = fxH(`return E8(0.3 + 0.18 * maze(p, 64., 21.));`, SAND);
    const SANDA = E.fx(`vec3 fx(vec2 uv, vec2 p){ float g = hash(floor(p)) - 0.5; vec3 c = p.y > 795. && p.x < 560. ? vec3(0.6, 0.56, 0.54) : vec3(0.62, 0.56, 0.53);
      return c + vec3(g * 0.4, g * 0.38, g * 0.36) + vec3(0.06, 0.0, 0.08) * (hash(floor(p) + 3.) - 0.5); }`);
    for (const pth of [sandR, sandB]) {
      soft(x => { x.strokeStyle = '#141414'; x.lineWidth = 5; x.stroke(pth); }, 2, 0.8);
      R.flat(pth, null, 0.3, SAND); clipA(pth, () => img(SANDA)); hImg(SANDH, pth);
    }

    // ── 7. cream mouth with comb teeth and the tan worm ──
    const mouth = P([[214, 314], [221, 270], [235, 235], [260, 203], [300, 178], [350, 168], [450, 168], [541, 165], [548, 205], [480, 240], [400, 280], [330, 302], [290, 314]]);
    R.flat(mouth, lg(250, 180, 450, 300, [[0, '#f2ead6'], [1, '#e8dcc8']]), 0.12, CLAY);
    const teeth = [[218, 306], [222, 270], [235, 235], [260, 203], [300, 178], [350, 168], [450, 168], [541, 165]];
    { const tr = rng(2277);
      for (let i = 0; i < teeth.length - 1; i++) {
        const [x0, y0] = teeth[i], [x1, y1] = teeth[i + 1], L = Math.hypot(x1 - x0, y1 - y0), nx = (y1 - y0) / L, ny = -(x1 - x0) / L;
        for (let t = 0; t < L; t += 5.5) {
          const x = x0 + (x1 - x0) * t / L, y = y0 + (y1 - y0) * t / L, len = 14 + tr() * 14;
          R.pipe(P([[x, y], [x - nx * len * 0.6 + (tr() - 0.5) * 4, y - ny * len * 0.6], [x - nx * len, y - ny * len + 2]], false), 3.2, tr() < 0.5 ? '#5a6474' : '#7a7068', 0.34, 0.04, PLA);
        }
      } }
    const worm = [[295, 308], [320, 284], [345, 263], [370, 247], [392, 231], [416, 216], [455, 210], [500, 205], [526, 200]];
    R.pipe(P(worm, false), 34, '#d89a58', 0.14, 0.18, CLAY);
    for (let i = 0; i < worm.length - 1; i++) for (let t = 0.25; t < 1; t += 0.5) {
      const x = worm[i][0] + (worm[i + 1][0] - worm[i][0]) * t, y = worm[i][1] + (worm[i + 1][1] - worm[i][1]) * t;
      const dx = worm[i + 1][0] - worm[i][0], dy = worm[i + 1][1] - worm[i][1], L = Math.hypot(dx, dy);
      R.groove(P([[x - dy / L * 15, y + dx / L * 15], [x + dy / L * 15, y - dx / L * 15]], false), 4, '#9a5a28', 0.3, 0.06, CLAY);
    }
    R.pipe(P([[310, 192], [340, 196], [372, 194]], false), 16, '#e0a440', 0.2, 0.12, CLAY);
    for (const [x, y, r] of [[318, 238, 9], [283, 292, 7]]) R.bead(x, y, r, '#e0b070', 0.14, 0.1, GLOS);

    // ── 8. navy blob with the eclipse eye ──
    const navy = P([[383, 300], [410, 275], [448, 222], [498, 200], [563, 195], [613, 210], [625, 250], [628, 290], [613, 330], [590, 360], [540, 345], [480, 312], [420, 312]]);
    R.dome(navy, '#1c2048', 0.12, 0.14, 26, GLOS);
    clipA(navy, () => stars(383, 195, 250, 170, 30, 2278));
    soft(x => { x.strokeStyle = '#f8f0c0'; x.lineWidth = 9; x.stroke(ellipseP(533, 268, 40, 37, 0)); }, 2.5, 1);
    R.paint(ellipseP(533, 268, 38, 35, 0), '#0a1830');
    R.paint(P(blob(540, 262, 30, 31, 2279, 12, 0.06)), '#127a3a');

    // ── 9. grey gel puddle with the sandy core ──
    const gel = P([[255, 371], [259, 390], [292, 391], [288, 409], [254, 450], [257, 482], [279, 491], [308, 456], [324, 454], [349, 494], [378, 512], [407, 545], [450, 548],
      [500, 550], [560, 552], [590, 545], [570, 530], [551, 507], [566, 501], [577, 443], [590, 418], [601, 371], [612, 360], [624, 328], [624, 294], [610, 297], [586, 321],
      [587, 353], [553, 333], [537, 315], [537, 299], [496, 285], [441, 293], [411, 312], [392, 310], [349, 328], [325, 341]]);
    R.dome(gel, lg(250, 300, 600, 580, [[0, '#a09ea2'], [0.5, '#98969a'], [1, '#929096']]), 0.1, 0.24, 30, GEL);
    const core = P(blob(432, 428, 84, 82, 2280, 18, 0.06));
    R.dome(core, '#cca286', 0.2, 0.05, 8, SAND);
    clipA(core, () => { const r = rng(2281); a.fillStyle = '#1a1210'; for (let i = 0; i < 160; i++) a.fill(circleP(346 + r() * 172, 346 + r() * 166, 0.6 + r() * 2));
      for (const [x, y, rr] of [[436, 376, 5], [392, 446, 4], [416, 470, 4], [470, 470, 3]]) R.paint(circleP(x, y, rr), '#ffe040'); });
    R.dome(circleP(450, 437, 22), '#c88a40', 0.26, 0.04, 6, PLA);
    R.paint(circleP(450, 437, 17), '#5a2418'); R.paint(circleP(450, 437, 13), '#3070e0');
    soft(x => { x.strokeStyle = '#d8f0ff'; x.lineWidth = 3; x.stroke(P([[442, 446], [444, 430], [456, 428], [454, 442], [462, 446]], false)); }, 0.5, 1);
    // sand ridge under the gel
    const ridge = P([[272, 560], [290, 545], [320, 538], [350, 542], [380, 548], [420, 552], [470, 556], [520, 560], [565, 562], [575, 575], [560, 590], [500, 588], [440, 584], [380, 580], [330, 578], [290, 582], [272, 575]]);
    R.dome(ridge, '#c8ae98', 0.1, 0.1, 10, SAND);

    // ── 10. spotted helmet, iridescent goggles ──
    R.dome(P([[500, 140], [530, 115], [580, 108], [620, 118], [640, 150], [620, 175], [575, 170], [530, 165]]), '#3a2c3c', 0.12, 0.1, 14, GLOS);
    const irid = P(blob(578, 178, 34, 40, 2282, 12, 0.15));
    R.dome(irid, lg(545, 140, 610, 215, [[0, '#e83070'], [0.2, '#f0c020'], [0.4, '#30d080'], [0.6, '#3060f0'], [0.8, '#c040e0'], [1, '#f05050']]), 0.14, 0.08, 10, GLOS);
    R.dome(circleP(626, 175, 24), '#c09070', 0.16, 0.1, 10, PLA);
    clipA(circleP(626, 175, 24), () => { a.strokeStyle = '#5a3020'; a.lineWidth = 1.2; for (let k = -30; k < 30; k += 5) { a.beginPath(); a.moveTo(600 + k, 150); a.lineTo(640 + k, 200); a.stroke(); a.beginPath(); a.moveTo(650 + k, 150); a.lineTo(610 + k, 200); a.stroke(); } });
    R.pipe(P([[652, 192], [672, 196], [690, 190]], false), 10, '#c84a30', 0.16, 0.06, PLA);
    const helm = ellipseP(655, 120, 66, 56, -0.1);
    R.dome(helm, rg(640, 95, 5, 655, 120, 70, [[0, '#5a546a'], [1, '#2c2836']]), 0.14, 0.24, 40, GLOS);
    for (const [x, y, rx] of [[628, 108, 8], [652, 104, 8], [676, 104, 8], [700, 110, 7], [618, 132, 7], [640, 130, 8], [664, 128, 8], [688, 130, 8], [632, 154, 6], [656, 152, 7], [680, 152, 7], [702, 150, 6]])
      R.paint(ellipseP(x, y, rx, rx * 0.75, 0), '#f4f4f4');
    a.save(); a.fillStyle = '#e8e8f0'; a.font = 'bold 13px Arial'; a.translate(640, 80); a.rotate(-0.12); a.fillText('13400', 0, 0); a.restore();
    soft(x => { x.strokeStyle = '#f040b0'; x.lineWidth = 4; x.stroke(circleP(595, 60, 13)); }, 1, 1);

    // ── 11. top-left cartoon scraps ──
    R.flat(P([[-10, -10], [30, -10], [40, 60], [30, 120], [-10, 125]], true, false), '#0c0a10', 0.02, 0);
    R.dome(ellipseP(45, 12, 22, 20, 0), '#f0e040', 0.05, 0.05, 8, PLA); R.paint(circleP(45, 10, 9), '#101010');
    R.flat(P([[50, 30], [75, 22], [72, 50], [55, 58]]), '#e02830', 0.05, 0);
    R.dome(ellipseP(32, 90, 22, 26, 0.3), '#40c8c0', 0.05, 0.06, 8, PLA);
    R.dome(circleP(36, 100, 12), '#a0e040', 0.08, 0.04, 5, PLA); R.paint(circleP(36, 100, 5), '#101010');
    R.dome(ellipseP(28, 1012, 32, 20, 0), '#f0f0e0', 0.12, 0.04, 6, PLA);
    R.paint(ellipseP(120, 1002, 14, 10, 0), '#9030c0');

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.95, spec: 0.55, shin: 30, wrap: 0.3, coat: 0.12, ao: 0.5 }),                                   // 1 rust meander
        E.mat({ dif: 0.7, spec: 1.2, shin: 50, metal: 0.3, wrap: 0.45, coat: 0.4, ao: 0.4, emis: 0.12, tint: [1.05, 1.05, 1.08] }), // 2 chrome maze
        E.mat({ dif: 1.0, spec: 0.35, shin: 20, wrap: 0.3, ao: 0.6, coat: 0.05 }),                                   // 3 sand
        E.mat({ dif: 0.75, spec: 1.5, shin: 70, coat: 0.5, ao: 0.3, wrap: 0.4 }),                                               // 4 grey gel
        E.mat({ dif: 0.9, spec: 0.9, shin: 50, wrap: 0.3, coat: 0.15, ao: 0.3, emis: 0.1 }),                         // 5 plastic
        E.mat({ dif: 0.9, spec: 0.25, shin: 18, wrap: 0.5, emis: 0.15, ao: 0.4 }),                                   // 6 clay
        E.mat({ dif: 0.85, spec: 1.3, shin: 70, wrap: 0.3, coat: 0.3, ao: 0.3, emis: 0.15 })                          // 7 gloss
      ],
      light: [-0.5, 0.62, 0.6], lc: [0.8, 0.8, 0.8], amb: [0.36, 0.36, 0.38],
      envTop: [1.15, 1.15, 1.18], envHor: [0.62, 0.62, 0.66], envBot: [0.22, 0.2, 0.22], envK: [0.4, 0.9, 0.2, 0],
      rimC: [0.15, 0.15, 0.18], rimD: [0, 1, 0], r1: 2, r2: 8, k: [0, 0.55, 0.45, 110], shadow: [-4, 5, 0.5, 6]
    });
    E.bloom(0.1, 10);
    E.grain(0.04, 2283);
  }
});
