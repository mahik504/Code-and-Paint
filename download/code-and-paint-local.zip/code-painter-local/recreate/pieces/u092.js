'use strict';
// u092 — "Olive glass melt": molten olive-grey glass pools with golden rim light flow over cobalt blue and
// black — an oval sage disc with a cracked white star, cream blobs on the right edge, a pale green tongue,
// wavy cream-on-black zebra flows below and blue-black stripes above, with white crackle veins.
REC.register('u092', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a, r0 = 0) => { const g = ctx.createRadialGradient(x, y, r0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), line = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };
    // white crackle veins: random branching walks
    const crackle = (x0, y0, n, len, seed, col = 'rgba(225,235,240,0.8)', wd = 1.3) => {
      const r = rng(seed);
      for (let i = 0; i < n; i++) {
        let x = x0 + (r() - 0.5) * len, y = y0 + (r() - 0.5) * len, ang = r() * 6.283; const pts = [[x, y]];
        for (let k = 0; k < 7; k++) { ang += (r() - 0.5) * 1.6; x += Math.cos(ang) * len * 0.12; y += Math.sin(ang) * len * 0.12; pts.push([x, y]); }
        stroke(P(pts, false, false), col, wd * (0.6 + r()));
      }
    };

    // ── ground: black, with a cobalt field over the left and top ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#040405', 0, 0);
    const blue = sm([[-20, -20], [186, -20], [200, 26], [282, 26], [300, -20], [470, -20], [520, 50], [566, 86], [640, 56], [700, 16], [736, 16], [736, 300], [690, 300], [630, 262], [568, 290], [540, 450], [500, 520], [320, 560], [270, 770], [-20, 820]]);
    R.flat(blue, lin(0, 0, 500, 800, [[0, '#2e4c8c'], [0.5, '#3a5898'], [1, '#34508e']]), 0.01, 0);
    soft(x => {
      fill(ellipseP(390, 30, 110, 50, 0.2), '#4aa8e8', x); fill(ellipseP(30, 100, 80, 26, -0.5), '#4aa0e0', x);
      fill(ellipseP(160, 190, 90, 20, -0.15), '#3e90e0', x); fill(ellipseP(620, 140, 50, 70, 0), '#2a58c0', x);
    }, 16, 0.8);
    clipA(blue, () => { crackle(40, 300, 26, 170, 1); crackle(70, 660, 34, 200, 2); crackle(560, 120, 8, 80, 3, 'rgba(240,230,210,0.7)', 1); });
    { const r = rng(4); for (let i = 0; i < 60; i++) fill(circleP(560 + r() * 110, 80 + r() * 140, 0.6 + r() * 1.4), 'rgba(250,240,220,0.8)'); }

    // ── fitted zebra stripe phases (cubic B-spline grids) ──
    const ZA = `const float ZAC[160] = float[160](-17.343,-17.440,-16.684,-14.859,-11.894,-7.635,-4.095,-2.456,-2.252,-1.265,-0.093,-1.109,-2.673,-4.480,-5.789,-6.685,-12.620,-13.971,-14.186,-10.947,-6.248,-5.504,-1.669,-1.595,-2.397,-1.947,-1.230,-1.571,-3.541,-4.181,-4.146,-4.150,-8.011,-9.385,-11.297,-7.151,1.399,-4.332,-0.945,-2.503,0.146,-1.614,-6.704,-0.825,-5.018,-3.231,-2.283,-2.015,-4.285,-3.391,-3.206,-0.429,-2.318,-1.801,-0.144,-0.706,0.865,-1.483,-0.363,-0.593,-4.185,-0.961,-0.786,-0.700,-1.432,-1.927,-1.214,-1.176,-1.002,-0.292,1.647,0.717,1.577,-0.309,0.338,-0.244,-2.127,-2.463,-0.774,-0.070,0.505,-1.162,-0.150,0.790,0.551,2.408,1.480,1.568,6.817,1.010,1.127,0.485,-2.985,0.222,-0.490,-0.048,3.072,-0.156,1.673,0.799,2.748,2.212,5.699,-0.387,3.251,4.576,2.740,-0.620,2.185,-1.896,-0.191,0.266,4.708,0.253,1.636,3.112,3.323,2.783,4.724,0.588,1.518,2.465,1.182,4.455,-0.002,0.846,-0.645,0.478,7.666,5.062,5.766,3.558,4.848,3.356,7.180,3.768,2.482,2.605,2.411,1.781,1.365,1.698,1.836,1.104,4.633,-1.295,-0.934,5.667,6.968,3.534,4.396,4.727,4.252,4.664,6.702,9.020,8.228,3.145,1.436,0.951);
float za(vec2 p){ vec2 u = clamp((p - vec2(0.0, 740.0)) / vec2(40.7692, 40.5714), vec2(0.), vec2(12.999, 6.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  float f = 0.;
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += ZAC[(i.y + b) * 16 + i.x + a] * bx[a] * by[b];
  return f; }
`;
    const ZC = `const float ZCC[64] = float[64](-7.326,-5.445,-3.460,-2.801,-1.647,0.450,-0.185,-3.052,-5.340,-5.004,-4.560,-4.981,-4.194,0.941,-2.227,-4.815,-3.444,-2.657,-2.655,-3.364,-4.161,-2.762,-6.030,-4.393,-1.846,0.244,-1.289,-0.999,-1.347,-0.485,-4.818,-0.205,-0.374,-1.456,1.831,1.153,-0.094,0.623,-0.236,4.418,4.310,6.009,8.560,-1.297,2.434,0.993,3.144,2.434,11.151,10.884,8.926,3.511,1.383,4.276,3.863,1.503,18.231,14.426,10.354,7.095,4.701,4.490,3.440,1.444);
float zc(vec2 p){ vec2 u = clamp((p - vec2(40.0, 440.0)) / vec2(46.0000, 54.0000), vec2(0.), vec2(4.999, 4.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  float f = 0.;
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += ZCC[(i.y + b) * 8 + i.x + a] * bx[a] * by[b];
  return f; }
`;
    const ZEB = E.fx(`${ZA}
${ZC}
      vec3 fx(vec2 uv, vec2 p){
        float v = p.y > 735. ? smoothstep(.3, .55, cos(6.2832 * za(p))) : smoothstep(.15, .45, cos(6.2832 * zc(p)));
        vec3 cream = mix(vec3(.62, .62, .55), vec3(.82, .80, .70), fbm(p * .01));
        return mix(vec3(.03, .03, .035), cream, v); }`);
    // blue-black stripes, top left (diagonal)
    const TOPZ = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float d = p.y * .92 + p.x * .40 + 8. * sin(p.x * .02);
      float v = smoothstep(-.2, .2, sin(6.2832 * d / 34.));
      return mix(vec3(.04, .05, .08), vec3(.36, .42, .56), v); }`);
    const zTop = sm([[-10, 76], [70, 50], [150, 34], [230, 32], [268, 56], [246, 96], [180, 116], [120, 146], [60, 178], [-10, 206]]);
    R.dome(zTop, null, 0.04, 0.08, 20, 1);
    clipA(zTop, () => img(TOPZ));
    const zEye = sm([[96, 236], [140, 220], [176, 240], [170, 290], [140, 310], [104, 300]]);
    clipA(zEye, () => img(TOPZ));

    // ── olive glass pools ──
    const OLV = lin(100, 160, 500, 500, [[0, '#62645e'], [0.5, '#5c5c54'], [1, '#56544a']]);
    const head = sm([[96, 210], [140, 172], [200, 160], [262, 190], [302, 228], [362, 240], [420, 250], [462, 240], [502, 228], [534, 208], [562, 200], [580, 262], [560, 330], [520, 400], [482, 450], [420, 472], [360, 472], [300, 484], [250, 492], [200, 472], [140, 442], [100, 400], [80, 330], [84, 262]]);
    R.dome(head, OLV, 0.06, 0.12, 40, 1);
    clipA(zEye, () => img(TOPZ));
    const column = sm([[562, 200], [600, 172], [640, 182], [662, 232], [682, 300], [700, 400], [702, 480], [692, 560], [662, 612], [622, 622], [592, 582], [580, 500], [572, 420], [576, 350], [570, 280]]);
    R.dome(column, lin(560, 200, 700, 600, [[0, '#7a6c50'], [0.5, '#6a604e'], [1, '#5a5446']]), 0.06, 0.12, 30, 1);
    for (let i = 0; i < 9; i++) R.groove(line([[590, 400 + i * 12], [630, 396 + i * 12], [680, 404 + i * 12]]), 3, '#8a8070', 0.16, 0.02, 1, 0.6);
    const mid = sm([[250, 500], [300, 482], [360, 474], [420, 482], [470, 502], [500, 556], [482, 582], [432, 584], [402, 604], [382, 642], [364, 700], [344, 742], [302, 752], [262, 732], [242, 682], [250, 622], [270, 562]]);
    R.dome(mid, lin(250, 480, 480, 750, [[0, '#6a6c64'], [1, '#56584e']]), 0.06, 0.12, 30, 1);
    R.dome(sm([[560, 500], [600, 490], [612, 540], [604, 600], [584, 610], [566, 560]]), '#5c5c54', 0.06, 0.08, 10, 1);
    // drip rods
    R.pipe(line([[462, 280], [462, 360], [460, 440], [466, 500]]), 14, '#7a7a70', 0.2, 0.08, 1);
    R.bead(466, 500, 12, '#6a6a62', 0.22, 0.1, 1);
    R.pipe(line([[350, 620], [346, 680], [338, 740]]), 12, '#6a6a62', 0.2, 0.06, 1);
    // blue windows in the olive
    R.flat(sm([[504, 300], [540, 292], [560, 320], [556, 360], [530, 372], [506, 350]]), '#3858a8', 0.12, 0);
    R.flat(sm([[490, 398], [540, 392], [578, 410], [580, 452], [540, 470], [500, 464], [486, 430]]), '#3454a4', 0.12, 0);
    // lavender slivers
    for (const pts of [[[578, 236], [592, 232], [598, 300], [592, 372], [580, 380], [576, 300]], [[214, 600], [236, 606], [252, 690], [244, 760], [226, 740], [216, 680]], [[470, 790], [490, 780], [520, 840], [540, 920], [560, 1000], [540, 1004], [516, 920], [490, 840]]])
      R.flat(sm(pts), '#c0a0d8', 0.1, 0);

    R.dome(sm([[150, 640], [196, 630], [214, 700], [206, 770], [170, 780], [150, 720]]), '#5a5a54', 0.06, 0.08, 10, 1);
    // ── the sage oval disc on top ──
    const disc = ellipseP(420, 116, 156, 116, 0.08);
    R.dome(disc, lin(300, 0, 520, 230, [[0, '#4a7cb0'], [0.3, '#5e6c6c'], [1, '#646c62']]), 0.12, 0.08, 30, 1);
    clipA(disc, () => { crackle(436, 120, 10, 150, 5, 'rgba(220,235,255,0.85)', 1.6); stroke(line([[432, 40], [436, 100], [428, 160], [424, 200]]), 'rgba(230,240,255,0.9)', 3); stroke(line([[400, 110], [440, 116], [490, 130]]), 'rgba(230,240,255,0.8)', 2); });
    R.groove(circleP(384, 120, 13), 8, '#1a1c1a', 0.24, 0.1, 1);
    R.bead(130, 18, 46, '#7888a8', 0.04, 0.16, 1);
    clipA(circleP(130, 18, 46), () => { const r = rng(9); for (let i = 0; i < 300; i++) fill(circleP(84 + r() * 92, r() * 64, 0.7), 'rgba(230,240,255,0.6)'); });
    // eye holes in the head
    for (const [x, y, r] of [[196, 256, 13], [252, 252, 15]]) { R.groove(circleP(x, y, r), 6, '#1a1a1a', 0.2, 0.1, 1); fill(circleP(x, y, r - 4), '#0a0a0c'); }
    { const r = rng(11); for (let i = 0; i < 22; i++) fill(circleP(200 + r() * 260, 200 + r() * 260, 1.5 + r() * 2.5), '#eef0ea'); }

    // ── cream blobs (right edge) and the pale green tongue ──
    const CREAM = '#d4ccaa';
    R.dome(sm([[664, 40], [700, 28], [736, 28], [736, 364], [702, 352], [690, 300], [682, 240], [692, 180], [682, 130], [662, 92]]), CREAM, 0.1, 0.1, 20, 2);
    R.dome(sm([[652, 520], [690, 490], [736, 490], [736, 672], [692, 662], [652, 632], [642, 580]]), CREAM, 0.1, 0.1, 20, 2);
    const pale = sm([[370, 704], [402, 652], [462, 640], [530, 622], [580, 640], [640, 652], [700, 662], [736, 684], [736, 800], [682, 792], [640, 802], [600, 782], [560, 762], [500, 744], [440, 752], [402, 772], [370, 762]]);
    R.dome(pale, lin(370, 640, 736, 800, [[0, '#8a9478'], [0.6, '#9ca484'], [1, '#b8b896']]), 0.1, 0.1, 30, 2);
    R.dome(sm([[620, 832], [662, 802], [736, 812], [736, 900], [682, 916], [640, 906], [614, 872]]), '#b4ba98', 0.1, 0.1, 20, 2);
    // olive drip arm going down
    R.dome(sm([[420, 770], [470, 758], [510, 790], [536, 860], [560, 930], [580, 1000], [540, 1010], [500, 970], [470, 910], [444, 850]]), lin(430, 760, 550, 1000, [[0, '#7a7a5c'], [1, '#5a5844']]), 0.1, 0.08, 14, 1);

    // ── zebra flows ──
    const zA = sm([[-10, 800], [60, 790], [160, 770], [262, 752], [290, 770], [300, 830], [262, 860], [226, 890], [206, 940], [206, 1040], [-10, 1040]]);
    const zB = sm([[262, 752], [330, 748], [380, 770], [430, 820], [470, 880], [500, 940], [520, 1040], [420, 1040], [400, 980], [370, 920], [340, 880], [300, 830], [290, 770]]);
    const zC = sm([[40, 450], [120, 446], [200, 466], [250, 520], [262, 600], [252, 680], [222, 702], [200, 652], [150, 622], [80, 562], [40, 522]]);
    for (const z of [zA, zB, zC]) { R.dome(z, null, 0.08, 0.1, 24, 1); clipA(z, () => img(ZEB)); }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 1.1, shin: 60, wrap: 0.3, ao: 0.4, coat: 0.25, rim: 0.8 }),        // 1 olive glass
        E.mat({ dif: 1, spec: 0.35, shin: 30, wrap: 0.6, ao: 0.3, coat: 0.05, rim: 0.2 })          // 2 cream
      ],
      light: [-0.3, 0.55, 0.78], lc: [0.66, 0.62, 0.56], amb: [0.3, 0.3, 0.32],
      envTop: [0.8, 0.76, 0.68], envHor: [0.32, 0.34, 0.4], envBot: [0.05, 0.05, 0.08], envK: [0.3, 0.8, 0.4, 0],
      rimC: [0.9, 0.7, 0.35], rimD: [0.5, 0.3, 0.5], l2: [0.6, -0.3, 0.4, 3], l2c: [0.2, 0.35, 0.7],
      r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 60], shadow: [-4, 5, 0.5, 6]
    });
    // golden rim light along the pool edges
    const glow = (path, c, wd, px, al = 1) => { o.save(); o.globalAlpha = al; o.globalCompositeOperation = 'screen'; o.filter = `blur(${px * S}px)`; stroke(path, c, wd, o); o.restore(); };
    for (const p of [head, column, mid, pale]) { glow(p, '#f8d080', 4, 1.5, 0.9); glow(p, '#e0a050', 14, 8, 0.4); }
    glow(line([[640, 190], [646, 300], [650, 420], [640, 520]]), '#f0c070', 8, 6, 0.6);
    glow(disc, '#f0e8d0', 2.5, 1, 0.8);
    for (const p of [zA, zB]) glow(p, '#a0c0f0', 2, 1, 0.6);
    E.grain(0.035, 92);
  }
});
