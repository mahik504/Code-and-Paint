'use strict';
// u039 — "Golden eggs on the racetrack": three pale gold spheres cradled by white milk and a cream-gold swoosh, a
// zebra block, grid slab and pearls, ringed by red / blue / black racetrack bands under a blue sky; gingham below.
REC.register('u039', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a, x1 = x, y1 = y) => { const g = ctx.createRadialGradient(x1, y1, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };
    const specks = (path, n, seed, col, rmax = 1.1, ctx = a) => clipA(path, () => {
      const r = rng(seed); ctx.fillStyle = col;
      for (let i = 0; i < n; i++) { ctx.globalAlpha = 0.4 + r() * 0.6; ctx.beginPath(); ctx.arc(r() * 726, r() * 1024, 0.4 + r() * rmax, 0, 6.283); ctx.fill(); }
      ctx.globalAlpha = 1;
    }, ctx);
    const ALL = poly([[-10, -10], [736, -10], [736, 1034], [-10, 1034]]);

    // ── shader textures ──
    const BLDZ = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float ph = (p.x * .85 + p.y * .52 + 10. * sin(p.y * .035 + p.x * .01)) / 14.;
        float s = smoothstep(.56, .62, fract(ph)) - smoothstep(.9, .96, fract(ph));
        vec3 c = mix(vec3(.80, .80, .83) * (.85 + .2 * vnoise(p * .04)), vec3(.08, .08, .09), s);
        return c; }`);
    const SKY = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        vec3 c = mix(vec3(.32, .43, .68), vec3(.72, .75, .80), smoothstep(250., 760., p.x * .8 + p.y * 1.4));
        c = mix(c, vec3(.45, .42, .66), .55 * smoothstep(170., 0., length((p - vec2(440., -10.)) * vec2(1., 1.6))));
        vec2 g = floor(p / 7.), f = fract(p / 7.) - .5; float h = hash(g);
        c += step(.93, h) * smoothstep(.2, .05, length(f)) * .6;
        return c; }`);
    // concentric track stripes + gingham, bottom-left
    const RINGS = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        vec2 d = (p - vec2(200.4, 732.2)) * vec2(1.0565, 1.);
        float r = length(d) + 2.67 * sin(3. * atan(d.y, d.x) + .41);
        float s1 = smoothstep(-.2, .2, -cos(6.2832 * (r / 27.6 + 1.739)));
        // cross stripes (gingham) in the lower band
        vec2 q = p - vec2(330., 1250.);
        float an = atan(q.x, -q.y);
        float s2 = smoothstep(-.15, .15, sin(an * 70. + length(q) * .01));
        float gm = smoothstep(860., 920., p.y + .25 * (p.x - 200.)) * smoothstep(20., 140., p.x);
        float v = mix(s1, .5 * (s1 + s2), gm);
        vec3 c = mix(vec3(.08, .07, .09), vec3(.90, .89, .90), v);
        return c; }`);
    // vertical / mitred zebra block
    const ZEB = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        // nested square rings around (190, 560) (Chebyshev distance), only vertical bars further right
        float ph = max(max(p.x - 190., 0.) / 33.5 + .061, (560. - p.y) / 34.5 + .095);
        float f = fract(ph);
        float s = smoothstep(0., .03, f) * (1. - smoothstep(.43, .46, f));
        return mix(vec3(.08, .07, .08), vec3(.90, .89, .90), 1. - s); }`);
    // grid panel
    const GRID = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        vec2 q = vec2(p.x * .97 + p.y * .12, p.y - p.x * .05);
        vec2 f = abs(fract(q / vec2(18., 19.)) - .5);
        float l = smoothstep(.44, .49, max(f.x, f.y));
        vec3 c = mix(vec3(.88, .88, .90), vec3(.48, .48, .52), l * .8);
        c *= .94 + .1 * vnoise(p * .3);
        return c; }`);
    // speckled stone
    const STONE = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float n = vnoise(p * .45) * .5 + vnoise(p * 1.3) * .3 + hash(floor(p)) * .2;
        return mix(vec3(.42, .42, .45), vec3(.78, .78, .80), smoothstep(.25, .75, n)); }`);
    // vinyl rings bottom-right
    const VINYL = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        vec2 d = (p - vec2(760., 1060.)) * vec2(1., 1.25);
        float r = length(d);
        float s = .5 + .5 * sin(r * .55) * sin(r * .07 + 1.);
        vec3 c = mix(vec3(.10, .10, .12), vec3(.42, .42, .46), s * smoothstep(60., 120., r));
        vec2 g = floor(p / 6.), f = fract(p / 6.) - .5;
        c += step(.96, hash(g)) * smoothstep(.2, .05, length(f)) * .7;
        return c; }`);

    // ── backdrop ──
    R.flat(ALL, '#1a191e', 0, 0);
    img(SKY);
    const SKYP = poly([[140, -10], [736, -10], [736, 156], [700, 158], [650, 163], [600, 172], [560, 186], [500, 192], [450, 198], [400, 198], [300, 205], [250, 215], [200, 220], [140, 220]]);
    // dark track zone everything below the sky
    fill(poly([[-10, 160], [736, 140], [736, 1034], [-10, 1034]]), '#141317');
    specks(poly([[-10, 160], [736, 140], [736, 1034], [-10, 1034]]), 1400, 3, '#e8e8f0', 0.9);

    // ── racetrack bands (back) ──
    // blue outer band
    fill(poly([[230, 200], [300, 200], [400, 194], [460, 194], [450, 206], [400, 212], [350, 224], [300, 240], [230, 246]]), '#3a5cb6');
    // hatched black band + rail
    const RAIL = [[-20, 395], [40, 385], [90, 370], [140, 340], [180, 312], [250, 296], [300, 288], [350, 270], [400, 250], [450, 235], [500, 217], [550, 208], [600, 195], [650, 185], [700, 180], [740, 177]];
    const HATCH = [[-20, 368], [40, 358], [90, 343], [140, 314], [180, 288], [250, 272], [300, 254], [350, 237], [400, 220], [450, 207], [500, 195], [560, 185]];
    stroke(line(HATCH), '#0e0d10', 30);
    clipA(P(lock(HATCH, 30, 30), true, true), () => {
      a.strokeStyle = '#e4e4e6'; a.lineWidth = 4;
      for (let x = -40; x < 760; x += 13) { a.beginPath(); a.moveTo(x, 420); a.lineTo(x + 34, 140); a.stroke(); }
    });
    stroke(line(RAIL), '#c9c9ce', 38);
    stroke(line(RAIL.map(([x, y]) => [x, y + 14])), '#a9a9b0', 8);
    for (let i = 0; i < RAIL.length - 1; i++) {
      const [x0, y0] = RAIL[i], [x1, y1] = RAIL[i + 1], L = Math.hypot(x1 - x0, y1 - y0), nx = -(y1 - y0) / L, ny = (x1 - x0) / L;
      for (let t = 0.2; t < L; t += 38) { const x = x0 + (x1 - x0) * t / L, y = y0 + (y1 - y0) * t / L; stroke(line([[x - nx * 4, y - ny * 4], [x + nx * 14, y + ny * 14]]), '#111014', 2.5); }
      stroke(line([[x0 - nx * 3, y0 - ny * 3], [x1 - nx * 3, y1 - ny * 3]]), '#2a292e', 1.5);
    }
    // inner bands: blue, black, red, white
    stroke(line([[430, 276], [500, 278], [560, 290], [610, 308], [650, 336]]), '#3555b8', 26);
    const RED = [[650, 372], [600, 340], [550, 322], [500, 314], [450, 314], [400, 322], [350, 338], [300, 362], [262, 392], [200, 420], [130, 440], [60, 470], [20, 520], [-10, 570]];
    stroke(line(RED.map(([x, y]) => [x, y + 26])), '#e8e6e6', 42);
    stroke(line(RED), '#de3a2c', 12);
    stroke(line([[300, 420], [340, 404], [380, 388], [440, 370]]), '#de3a2c', 11);
    stroke(line([[300, 438], [340, 420], [390, 404], [450, 392]]), '#3555b8', 18);
    // salmon / blue / navy bands down the left edge
    fill(sm([[100, 426], [132, 424], [150, 440], [130, 470], [110, 500], [95, 530], [80, 560], [60, 600], [45, 640], [20, 680], [-10, 690], [-10, 470], [20, 455], [60, 438]]), '#d68a7c');
    stroke(line([[150, 430], [110, 446], [76, 476], [50, 520], [30, 570], [14, 620]]), '#c85a4c', 12);
    // big ring field bottom-left
    const RF = poly([[-10, 600], [30, 600], [60, 680], [80, 740], [120, 800], [180, 840], [260, 872], [360, 870], [450, 840], [540, 800], [585, 776], [347, 1034], [-10, 1034]]);
    clipA(RF, () => img(RINGS));
    stroke(line([[120, 560], [85, 580], [55, 612], [30, 652], [14, 700], [4, 760], [-4, 800]]), '#3a5cb0', 26);
    // yellow / orange chunks in the left stripes
    clipA(RF, () => soft(x => {
      fill(sm([[0, 790], [40, 770], [70, 800], [60, 870], [20, 900], [0, 880]]), '#e8a040', x);
      fill(sm([[60, 790], [100, 800], [120, 860], [90, 900], [60, 880]]), '#e8c050', x);
    }, 3, 0.55, 'multiply'));
    R.flat(RF, null, 0, 0);
    // bottom-right: plane edge, dark band, ticked bar, vinyl
    // (bands are measured along s = x + 0.92 y)
    const DK = poly([[736, 650], [736, 1034], [383, 1034]]);
    fill(DK, lin(560, 860, 600, 900, [[0, '#4a4a52'], [1, '#2e2e36']]));
    clipA(poly([[736, 777], [736, 1034], [500, 1034]]), () => img(VINYL));
    fill(poly([[736, 738], [736, 777], [500, 1034], [464, 1034]]), '#e2e0de');
    fill(poly([[600, 816], [640, 836], [628, 848], [590, 828]]), '#0e0d10');
    fill(poly([[503, 976], [536, 992], [524, 1004], [492, 988]]), '#0e0d10');
    // white plane + its bevelled edge
    const PLANE = poly([[430, 640], [736, 560], [736, 611], [580, 780], [540, 792], [450, 822], [380, 846]]);
    fill(PLANE, lin(500, 600, 700, 760, [[0, '#e8e6e4'], [1, '#dcdad8']]));
    fill(poly([[736, 608], [736, 655], [385, 1036], [345, 1036]]), lin(516, 850, 538, 870, [[0, '#e6e4e2'], [0.45, '#d8d6d6'], [0.8, '#8a8a92'], [1, '#4a4a52']]));
    specks(DK, 260, 9, '#f0f0f4', 0.9);
    const RE = poly([[640, 236], [736, 220], [736, 588], [660, 612], [640, 600]]);
    clipA(RE, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float r = length((p - vec2(520., 470.)) * vec2(1., .8));
      float s = smoothstep(.55, .75, sin(r * .45 + 2. * sin(r * .05)));
      return mix(vec3(.15, .14, .16), vec3(.62, .62, .66), s * .8); }`)));

    // ── sky + milk splash top-left ──
    fill(SKYP, '#000'); clipA(SKYP, () => img(SKY));
    // zebra building top-left
    const BLD = poly([[-10, -10], [150, -10], [150, 80], [200, 90], [280, 140], [280, 200], [-10, 210]]);
    fill(BLD, '#000'); clipA(BLD, () => img(BLDZ));
    const MILK = sm([[148, -10], [218, -10], [216, 30], [206, 58], [186, 84], [166, 104], [156, 126], [160, 140], [200, 146], [262, 140], [310, 142], [360, 130], [420, 126], [470, 132], [503, 150], [508, 174], [490, 186], [440, 184], [400, 188], [362, 196], [322, 208], [302, 228], [296, 252], [272, 266], [230, 272], [190, 272], [172, 282], [166, 300], [170, 322], [150, 336], [120, 340], [70, 342], [20, 346], [-10, 348], [-10, 172], [30, 168], [60, 150], [100, 128], [110, 118], [100, 110], [74, 100], [60, 86], [58, 62], [64, 52], [78, 70], [100, 76], [122, 66], [140, 40], [146, 10]]);
    R.dome(MILK, '#e6e4e4', 0.1, 0.16, 26, 1);
    fill(ellipseP(106, 46, 22, 20, 0), 'rgba(10,10,12,.85)');
    // grey ovals sitting in the milk
    R.flat(ellipseP(217, 206, 83, 56, -0.08), '#b2b1c0', 0.22, 4);
    R.dome(ellipseP(208, 366, 64, 52, 0), '#e8e6e6', 0.2, 0.08, 10, 1);
    R.flat(ellipseP(207, 366, 56, 44, 0), '#b4b3c2', 0.24, 4);
    R.flat(ellipseP(337, 370, 38, 19, -0.12), '#b6b5c4', 0.08, 4);
    R.dome(ellipseP(432, 155, 72, 24, 0.12), '#cfcfd6', 0.28, 0.06, 8, 1);
    R.flat(ellipseP(28, 278, 70, 42, 0.1), '#c4c4cc', 0.2, 4);
    // traffic light
    R.dome(rrect(46, 128, 64, 108, 32), '#1c1b20', 0.3, 0.2, 28, 5);
    R.pipe(line([[92, 236], [96, 262]]), 8, '#a8a8b0', 0.3, 0.06, 3);
    R.dome(rrect(78, 260, 54, 100, 3), '#151418', 0.3, 0.08, 4, 5);
    R.flat(poly([[118, 262], [132, 268], [132, 358], [118, 360]]), '#c8c8d0', 0.36, 3);
    for (const [y, c] of [[287, '#d8d8de'], [307, '#d8c890'], [328, '#d8c890']]) R.bead(97, y, 8, c, 0.38, 0.06, 3);
    R.pipe(line([[102, 360], [102, 400]]), 10, '#28272c', 0.3, 0.05, 5);

    // ── zebra block ──
    const ZB = poly([[118, 440], [200, 436], [230, 418], [420, 420], [422, 560], [120, 562]]);
    R.flat(ZB, null, 0.12, 0);
    clipA(ZB, () => img(ZEB));

    // ── stone slab, grid panel and pool ──
    const SLAB = sm([[402, 430], [436, 384], [490, 352], [550, 340], [612, 344], [652, 372], [666, 424], [660, 484], [640, 540], [600, 582], [530, 604], [450, 612], [412, 592], [398, 520]]);
    R.dome(SLAB, null, 0.12, 0.08, 14, 4);
    clipA(SLAB, () => img(STONE));
    const GP = sm([[500, 350], [552, 342], [612, 346], [648, 370], [658, 420], [652, 470], [620, 500], [560, 520], [490, 540], [470, 500], [478, 430], [490, 380]]);
    R.flat(GP, null, 0.22, 4);
    clipA(GP, () => img(GRID));
    const POOL = sm([[405, 652], [420, 600], [450, 566], [500, 536], [560, 516], [620, 488], [650, 445], [662, 470], [656, 540], [632, 590], [600, 612], [560, 622], [500, 632], [450, 642]]);
    R.dome(POOL, '#9896a6', 0.18, 0.04, 12, 4);

    // ── gold swoosh ──
    const SW = sm([[404, 290], [412, 272], [432, 256], [462, 236], [500, 218], [540, 206], [580, 205], [620, 214], [655, 232], [683, 262], [701, 298], [712, 342], [714, 392], [708, 446], [695, 500], [675, 552], [650, 596], [620, 628], [582, 650], [540, 664], [500, 678], [462, 692], [436, 714], [418, 746], [400, 764], [380, 752], [366, 728], [346, 714], [306, 708], [268, 712], [238, 722], [214, 712], [224, 690], [262, 672], [302, 660], [352, 650], [402, 642], [452, 630], [500, 618], [548, 604], [592, 586], [626, 552], [646, 500], [654, 440], [654, 384], [644, 340], [626, 306], [600, 284], [570, 272], [530, 268], [492, 276], [456, 288], [430, 296]]);
    R.dome(SW, lin(400, 220, 700, 600, [[0, '#e6dcc4'], [0.5, '#e2d4b2'], [1, '#d4c294']]), 0.26, 0.16, 22, 2);
    // thin gold rim around the pool
    R.pipe(line([[660, 440], [640, 470], [600, 494], [540, 512], [490, 530], [450, 560], [420, 600]]), 7, '#d8c69a', 0.3, 0.06, 2);

    // ── milk base under the spheres ──
    const BASE = sm([[60, 600], [100, 580], [140, 600], [200, 640], [300, 680], [430, 700], [520, 690], [560, 700], [580, 760], [560, 820], [520, 860], [440, 880], [340, 880], [240, 862], [160, 826], [100, 780], [64, 720], [52, 660]]);
    R.dome(BASE, '#e8e6e6', 0.08, 0.1, 24, 1);
    R.flat(sm([[150, 826], [260, 862], [360, 872], [450, 862], [440, 892], [330, 904], [220, 896], [170, 868]]), '#a4a4b2', 0.06, 4);
    R.flat(sm([[505, 705], [540, 698], [562, 720], [566, 760], [542, 776], [520, 760], [510, 730]]), '#2a2a30', 0.05, 4);
    // red + blue inner rings peeking under the base
    soft(x => { stroke(line([[110, 740], [150, 790], [200, 830], [270, 860], [345, 872]]), '#d83a2c', 7, x); stroke(line([[96, 760], [130, 810], [180, 846], [230, 866]]), '#3a5cb8', 12, x); }, 1, 1);
    // gold spheres
    const ball = (x, y, r) => {
      R.dome(circleP(x, y, r), rad(x - r * 0.1, y - r * 0.2, r * 1.25, [[0, '#efe7ce'], [0.22, '#e6d6aa'], [0.45, '#cdb27c'], [0.7, '#a2834f'], [1, '#7a5f40']], a, x - r * 0.2, y - r * 0.38), 0.2, 0.3, r * 0.9, 0);
    };
    ball(134, 676, 58);
    ball(242, 768, 90);
    ball(424, 770, 92);

    // ── silver blob + drips ──
    const SB = sm([[104, 584], [140, 556], [200, 544], [262, 550], [306, 564], [340, 588], [372, 604], [410, 612], [440, 630], [430, 660], [392, 672], [344, 668], [300, 682], [258, 682], [218, 668], [176, 656], [138, 638], [110, 614]]);
    const CD = sm([[250, 650], [300, 636], [350, 630], [400, 630], [450, 640], [500, 640], [560, 628], [600, 612], [624, 636], [584, 664], [524, 680], [484, 692], [462, 712], [470, 742], [448, 760], [420, 752], [400, 770], [380, 744], [358, 724], [328, 714], [296, 706], [266, 700], [244, 688], [238, 668]]);
    R.dome(CD, lin(300, 640, 520, 760, [[0, '#e4dac6'], [0.5, '#d8caa8'], [1, '#bca47c']]), 0.28, 0.12, 18, 2);
    R.dome(SB, rad(220, 590, 200, [[0, '#b4b0b4'], [0.6, '#9e999e'], [1, '#86828a']]), 0.3, 0.16, 26, 1);
    specks(SB, 900, 21, '#ffffff', 0.8);
    // gold drip strand from the oval
    R.dome(sm([[210, 418], [226, 418], [222, 450], [224, 480], [236, 515], [250, 548], [256, 566], [170, 566], [190, 540], [204, 505], [208, 470], [207, 445]]), '#e2d6bc', 0.3, 0.1, 9, 2);
    R.pipe(line([[62, 478], [80, 500], [100, 524]]), 16, '#e4e2e0', 0.26, 0.12, 1);
    R.dome(sm([[90, 530], [120, 522], [160, 532], [200, 545], [212, 580], [180, 612], [140, 622], [108, 610], [94, 580]]), '#e4e2e0', 0.24, 0.14, 18, 1);
    // eyeball + pearls
    R.bead(347, 575, 27, '#e8e8ee', 0.42, 0.18, 3);
    fill(circleP(350, 576, 12), '#101014');
    R.bead(392, 556, 30, '#dcdce8', 0.42, 0.22, 3);
    for (const [x, y, r] of [[658, 540, 26], [92, 470, 14], [434, 322, 11], [342, 312, 10], [270, 352, 8], [536, 758, 11], [394, 816, 13], [346, 790, 9], [458, 744, 8], [592, 732, 8]]) R.bead(x, y, r, '#e4e4ee', 0.4, 0.14, 3);
    // gold beads
    { const r = rng(5); for (let i = 0; i < 26; i++) R.bead(430 + r() * 60, 330 + r() * 40, 4 + r() * 5, '#d8b860', 0.36, 0.08, 2); }
    for (const [x, y, r] of [[480, 516, 16], [254, 420, 7], [347, 134, 7], [356, 128, 6], [600, 254, 5], [612, 300, 6], [580, 324, 6], [650, 420, 5]]) R.bead(x, y, r, '#d8b860', 0.38, 0.1, 2);
    // gold ring handle
    R.pipe(sm(blob(580, 625, 30, 34, 3, 12, 0.05, 0.2)), 11, '#d8c08a', 0.36, 0.1, 2);
    R.pipe(sm(blob(580, 680, 20, 22, 4, 12, 0.05)), 10, '#d8c08a', 0.36, 0.1, 2);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 26, wrap: 0.5, ao: 0.5, coat: 0.05 }),                              // 1 milk
        E.mat({ dif: 0.8, metal: 0.35, spec: 0.7, shin: 30, rim: 0.2, ao: 0.4, tint: [1.08, 1.0, 0.8], wrap: 0.3 }), // 2 pale gold
        E.mat({ dif: 0.8, metal: 0.4, spec: 1.0, shin: 60, rim: 0.3, ao: 0.3, coat: 0.2 }),                     // 3 pearl / chrome
        E.mat({ dif: 1, spec: 0.1, shin: 12, wrap: 0.5, ao: 0.4 }),                                              // 4 matte grey
        E.mat({ dif: 1, spec: 0.9, shin: 50, coat: 0.2, ao: 0.3 }),                                              // 5 black gloss
      ],
      light: [-0.45, 0.55, 0.7], lc: [0.7, 0.7, 0.7], amb: [0.42, 0.42, 0.44],
      envTop: [1, 1, 1], envHor: [0.6, 0.6, 0.62], envBot: [0.2, 0.2, 0.22], envK: [0.2, 0.6, 0.2, 0],
      r1: 2, r2: 9, k: [0, 0.6, 0.4, 90], shadow: [-4, 6, 0.4, 8]
    });
    E.grain(0.04, 7);
  }
});
