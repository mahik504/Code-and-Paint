'use strict';
// s29 — "Medallion sticker on a blue relief": a tilted photo (yellow cloth, sage mountain) carrying a
// zig-zag purple sticker — bronze medallion, glossy orange lattice creature, pearl, pink worms on
// black — laid on a glossy cobalt relief of doodles and dots, cut out with a black sticker edge.
REC.register('s29', {
  w: 922, h: 1024,
  draw(E) {
    const W = 922, H = 1024, S = E.S;
    const R = E.relief(), a = R.a, hx = R.h;
    const both = f => { a.save(); hx.save(); f(a); f(hx); };
    const restore = () => { a.restore(); hx.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    // resample a closed smooth outline and wave it along its normal (sun-ray zig-zag)
    const wave = (pts, period, amp) => {
      const n = pts.length, dense = [];
      for (let i = 0; i < n; i++) {
        const p0 = pts[(i - 1 + n) % n], p1 = pts[i], p2 = pts[(i + 1) % n], p3 = pts[(i + 2) % n];
        for (let t = 0; t < 1; t += 0.05) {
          const t2 = t * t, t3 = t2 * t, f = (a0, a1, a2, a3) => 0.5 * (2 * a1 + (-a0 + a2) * t + (2 * a0 - 5 * a1 + 4 * a2 - a3) * t2 + (-a0 + 3 * a1 - 3 * a2 + a3) * t3);
          dense.push([f(p0[0], p1[0], p2[0], p3[0]), f(p0[1], p1[1], p2[1], p3[1])]);
        }
      }
      const out = []; let s = 0;
      for (let i = 0; i < dense.length; i++) {
        const p = dense[i], q = dense[(i + 1) % dense.length], o = dense[(i - 1 + dense.length) % dense.length];
        const dx = q[0] - o[0], dy = q[1] - o[1], L = Math.hypot(dx, dy) || 1, k = amp * Math.sin(s / period * Math.PI * 2);
        out.push([p[0] + dy / L * k, p[1] - dx / L * k]); s += Math.hypot(q[0] - p[0], q[1] - p[1]);
      }
      return out;
    };
    const worm = (r, x, y, n, step) => { const pts = [[x, y]]; let ang = r() * 6.28; for (let k = 0; k < n; k++) { ang += (r() - 0.5) * 2.2; x += Math.cos(ang) * step; y += Math.sin(ang) * step; pts.push([x, y]); } return pts; };

    // ── cobalt relief background (white card behind a black cut edge) ──
    R.flat(rrect(-10, -10, W + 20, H + 20, 0), '#e4eefc', 0, 0);
    const card = rrect(8, 8, W - 16, H - 16, 26);
    R.flat(card, '#050c20', 0.02, 1);
    const cardIn = rrect(18, 16, W - 34, H - 34, 20);
    R.flat(cardIn, '#0c4ef0', 0.05, 1);
    both(x => x.clip(cardIn));
    const br = rng(29);
    const tubeB = (path, wd, col = '#1e66f8') => { a.save(); a.lineWidth = wd + 8; a.strokeStyle = '#061640'; a.lineCap = a.lineJoin = 'round'; a.stroke(path); a.restore(); R.pipe(path, wd, col, 0.05, 0.1, 1); };
    // dark doodle grooves over the whole plate
    for (let i = 0; i < 90; i++) R.groove(P(worm(br, br() * W, br() * H, 4, 26), false), 6, '#041030', 0.07, 0.04, 1, 1);
    for (let i = 0; i < 60; i++) R.groove(circleP(br() * W, br() * H, 8 + br() * 30), 5, '#041030', 0.07, 0.04, 1, 1);
    // big shapes: rings, capsules, blobs
    for (const [x, y, r] of [[80, 900, 110], [760, 60, 70], [880, 420, 90], [40, 400, 70], [300, 960, 70], [880, 690, 80], [200, 40, 60], [480, 940, 60]]) {
      tubeB(circleP(x, y, r), 34);
      R.dome(circleP(x, y, r * 0.55), '#165cf0', 0.06, 0.08, 20, 1);
    }
    a.save(); a.lineWidth = 10; a.strokeStyle = '#061640'; a.stroke(rrect(610, 880, 330, 110, 55)); a.restore();
    R.dome(rrect(610, 880, 330, 110, 55), '#2a74f8', 0.05, 0.12, 30, 1);
    for (let i = 0; i < 5; i++) R.bead(660 + i * 55, 912, 12, '#6aa0fa', 0.17, 0.06, 1);
    R.dome(ellipseP(860, 250, 70, 50, 0.3), '#2e78fa', 0.05, 0.12, 24, 1);
    // doodle tubes everywhere
    for (let i = 0; i < 120; i++) {
      const pts = worm(br, br() * W, br() * H, 3 + (br() * 4 | 0), 18 + br() * 16);
      tubeB(P(pts, false), 14 + br() * 16, br() < 0.8 ? '#1e66f8' : '#4a8af8');
    }
    for (let i = 0; i < 140; i++) { const x = br() * W, y = br() * H, r = 4 + br() * 10; a.fillStyle = '#061640'; a.fill(circleP(x, y, r + 3)); R.bead(x, y, r, br() < 0.5 ? '#3a80fa' : '#9abcfc', 0.06, 0.06, 1); }
    // fingerprint whorl on the right
    for (let k = 0; k < 9; k++) R.groove(ellipseP(890, 680, 20 + k * 11, 30 + k * 13, 0.2), 4, '#06163a', 0.12, 0.05, 1, 0.9);
    restore();
    R.groove(card, 10, '#02050e', 0.03, 0.02, 1, 1);

    // ── the tilted photo: yellow cloth, sage mountain ──
    const sq = P([[138, 52], [530, 58], [690, 110], [858, 228], [852, 560], [834, 842], [70, 766], [96, 420]], true, false);
    R.flat(sq, '#8ab89a', 0.1, 2);
    a.save(); a.clip(sq);
    soft(x => {
      x.fillStyle = '#6a9a7e'; x.fillRect(0, 0, W, H);
      x.fillStyle = '#f8dc58'; x.fill(P([[100, 40], [560, 40], [720, 120], [870, 230], [870, 330], [760, 260], [640, 200], [520, 170], [300, 120], [100, 140]], true, false));
      x.fillStyle = '#9ed0b0'; x.fill(P([[420, 150], [560, 170], [700, 230], [860, 330], [860, 560], [760, 560], [640, 440]], true, false));
      x.fillStyle = '#3c6452'; x.fill(P([[600, 330], [700, 300], [780, 360], [860, 440], [860, 540], [760, 500], [680, 420]]));
      x.fillStyle = '#4a644e'; x.fill(P([[60, 440], [200, 420], [280, 560], [260, 700], [120, 640], [60, 600]]));
      x.fillStyle = '#fae878'; x.fill(P([[60, 640], [160, 620], [260, 700], [300, 790], [60, 790]]));
      x.fillStyle = '#e8d860'; x.fill(ellipseP(160, 740, 90, 40, 0.3));
      x.fillStyle = '#aad2b8'; x.fill(ellipseP(120, 300, 50, 80, 0));
    }, 10);
    // mountain ridge texture
    const mr = rng(3); a.strokeStyle = 'rgba(40,70,55,0.35)'; a.lineWidth = 2;
    for (let i = 0; i < 90; i++) { const x0 = 560 + mr() * 300, y0 = 160 + mr() * 400; a.beginPath(); a.moveTo(x0, y0); a.lineTo(x0 + 14 + mr() * 20, y0 + 20 + mr() * 30); a.stroke(); }
    a.restore();

    // ── purple zig-zag sticker ──
    const stBase = [[190, 150], [260, 110], [360, 95], [470, 110], [560, 150], [630, 220], [680, 300], [700, 380], [720, 460], [790, 500], [830, 560], [826, 660], [820, 780], [770, 818], [600, 830], [420, 810], [300, 790], [262, 700], [240, 610], [210, 560], [160, 520], [140, 440], [150, 340], [160, 240]];
    const stP = P(wave(stBase, 30, 11));
    a.save(); a.lineJoin = 'round'; a.strokeStyle = 'rgba(232,226,236,0.85)'; a.lineWidth = 30; a.stroke(stP); a.restore();
    hx.save(); hx.lineJoin = 'round'; hx.strokeStyle = hc(0.13, 3); hx.lineWidth = 30; hx.stroke(stP); hx.restore();
    R.flat(stP, '#7a4a9a', 0.14, 3);
    a.save(); a.lineJoin = 'round'; a.strokeStyle = '#3050d8'; a.lineWidth = 7; a.stroke(stP); a.restore();
    a.save(); a.clip(stP);
    const pg = a.createLinearGradient(150, 100, 700, 800); pg.addColorStop(0, '#b0508c'); pg.addColorStop(0.3, '#8a4a9e'); pg.addColorStop(0.7, '#6a3a90'); pg.addColorStop(1, '#5a3aa0');
    a.fillStyle = pg; a.fillRect(0, 0, W, H);
    const sr = rng(9); a.strokeStyle = 'rgba(200,90,150,0.7)'; a.lineWidth = 2;
    for (let i = 0; i < 200; i++) { let x = 140 + sr() * 690, y = 90 + sr() * 740; a.beginPath(); a.moveTo(x, y); for (let k = 0; k < 3; k++) { x += (sr() - 0.5) * 18; y += (sr() - 0.5) * 18; a.lineTo(x, y); } a.stroke(); }
    a.restore();

    // ── black sticker with pale pink worms ──
    const bk = P([[270, 540], [330, 520], [420, 560], [520, 600], [640, 600], [720, 540], [790, 530], [812, 600], [806, 760], [770, 806], [600, 812], [420, 790], [300, 770], [270, 680]]);
    R.flat(bk, '#0e0c10', 0.15, 4);
    both(x => x.clip(bk));
    const wr = rng(17);
    for (let i = 0; i < 34; i++) {
      const pts = worm(wr, 270 + wr() * 540, 520 + wr() * 290, 3 + (wr() * 3 | 0), 22);
      R.pipe(P(pts, false), 22, '#e6b8b6', 0.15, 0.08, 4);
    }
    restore();

    // ── bronze medallion: upper lobe + pearl lobe ──
    const bro = E.fx(`vec3 fx(vec2 uv, vec2 px){
      float s = hash(floor(px * 0.7)), n = fbm(px * 0.03);
      vec3 c = mix(vec3(0.46, 0.34, 0.14), vec3(0.70, 0.55, 0.24), n);
      c *= 0.62 + 0.6 * step(0.55, s) * s;
      return c; }`);
    const lobeU = P([[196, 196], [240, 158], [320, 146], [420, 150], [510, 170], [580, 220], [610, 300], [600, 380], [560, 420], [480, 440], [360, 440], [240, 410], [190, 330]]);
    const lobeL = ellipseP(560, 525, 118, 112, 0);
    const med = new Path2D(); med.addPath(lobeU); med.addPath(lobeL);
    a.save(); a.clip(med); a.drawImage(bro, 0, 0, W, H); a.restore();
    R.flat(med, null, 0.2, 5);
    both(x => x.clip(med));
    a.lineWidth = 70; a.strokeStyle = '#0d0c09'; a.stroke(lobeU); a.stroke(lobeL);
    hx.lineWidth = 70; hx.strokeStyle = hc(0.17, 5); hx.stroke(lobeU); hx.stroke(lobeL);
    restore();
    const notU = new Path2D(); notU.rect(-50, -50, W + 100, H + 100); notU.addPath(lobeL);
    const notL = new Path2D(); notL.rect(-50, -50, W + 100, H + 100); notL.addPath(lobeU);
    both(x => x.clip(notU, 'evenodd')); R.pipe(lobeU, 28, '#c8983c', 0.2, 0.08, 5); restore();
    both(x => x.clip(notL, 'evenodd')); R.pipe(lobeL, 28, '#c8983c', 0.2, 0.08, 5); restore();
    // inner raised bronze plate + curl at top-left
    const plate = P([[240, 210], [320, 186], [420, 190], [500, 212], [556, 260], [566, 330], [530, 390], [440, 410], [330, 400], [250, 370], [226, 290]]);
    a.save(); a.clip(plate); a.drawImage(bro, 0, 0, W, H); a.restore();
    R.dome(plate, null, 0.21, 0.03, 12, 5);
    R.pipe(P([[200, 250], [230, 206], [280, 196], [300, 230], [270, 262], [240, 250]], false), 20, '#b89040', 0.24, 0.06, 5);
    // pearl
    R.flat(circleP(560, 525, 62), '#0e0f12', 0.2, 5);
    for (let i = 0; i < 4; i++) R.groove(P([[480 + i * 8, 540 + i * 9], [500 + i * 8, 580 + i * 6]], false), 5, '#0d0c09', 0.22, 0.03, 5, 1);
    R.bead(560, 522, 44, '#b8bcb4', 0.22, 0.22, 7);

    // yellow wavy hair + pink block
    const hairs = [[[400, 256], [430, 244], [460, 256], [490, 246], [520, 262], [546, 290], [558, 320], [540, 336]], [[430, 270], [470, 280], [500, 300], [520, 330]], [[505, 450], [530, 440], [552, 456], [540, 470]]];
    for (const hp of hairs) { a.save(); a.lineCap = a.lineJoin = 'round'; a.lineWidth = 34; a.strokeStyle = '#0d0c09'; a.stroke(P(hp, false)); a.restore(); }
    for (const hp of hairs) R.pipe(P(hp, false), 20, '#ecd83c', 0.23, 0.06, 7);
    const pinkB = P([[378, 300], [470, 296], [490, 330], [480, 420], [390, 426], [372, 380]], true, false);
    a.save(); a.lineJoin = 'round'; a.lineWidth = 16; a.strokeStyle = '#0d0c09'; a.stroke(pinkB); a.restore();
    R.flat(pinkB, '#f65078', 0.23, 7);
    R.groove(P([[420, 310], [420, 390]], false), 10, '#301018', 0.23, 0.03, 7, 1);

    // ── glossy orange lattice creature ──
    const OR = '#fb9a0c', HOLE = '#140c10';
    const tube = (pts, w = 30, h0 = 0.28, dh = 0.12) => R.pipe(P(pts, false), w, OR, h0, dh, 6);
    // head/lattice: black ground crossed by thick orange tubes (glyph-like lattice)
    const mass = P([[146, 330], [190, 292], [260, 280], [340, 286], [420, 282], [482, 292], [506, 330], [500, 400], [510, 450], [522, 482], [470, 500], [380, 492], [300, 482], [220, 470], [168, 430]]);
    R.flat(mass, HOLE, 0.22, 6);
    R.flat(P([[382, 300], [470, 296], [490, 330], [480, 420], [392, 426], [376, 380]], true, false), '#f65078', 0.23, 7);
    R.pipe(mass, 30, OR, 0.26, 0.12, 6);
    const lr = rng(12);
    for (let i = 0; i < 8; i++) tube([[180 + i * 42, 296 + lr() * 10], [176 + i * 42 + lr() * 24, 390], [184 + i * 40, 474]], 22);
    for (let j = 0; j < 3; j++) tube([[160, 336 + j * 44], [300, 330 + j * 46 + lr() * 10], [380, 340 + j * 40]], 20);
    for (let i = 0; i < 8; i++) { const x = 180 + lr() * 180, y = 320 + lr() * 130; tube([[x, y], [x + 20 + lr() * 20, y + (lr() - 0.5) * 40]], 16); }
    tube([[146, 330], [118, 300], [150, 280], [196, 296]], 26);
    tube([[160, 300], [200, 256], [250, 268]], 22);
    tube([[372, 340], [400, 326], [424, 352]], 20);
    tube([[340, 300], [350, 266], [372, 276]], 18);
    // long body curling round the pearl, with an inner lattice
    const loop = P([[392, 480], [470, 486], [492, 530], [480, 600], [510, 680], [580, 740], [660, 748], [702, 690], [700, 610], [668, 578]], false);
    const loopIn = P([[480, 540], [500, 610], [540, 680], [600, 720], [660, 716], [680, 650], [660, 600], [600, 600], [540, 590]]);
    R.flat(loopIn, HOLE, 0.22, 6);
    R.pipe(loop, 42, OR, 0.26, 0.14, 6);
    tube([[500, 470], [540, 468], [560, 440]], 24);
    tube([[490, 600], [560, 612], [620, 640], [680, 640]], 20);
    tube([[520, 660], [570, 640], [600, 700]], 18);
    tube([[610, 700], [640, 660], [670, 700]], 16);
    tube([[560, 590], [600, 620]], 16);
    R.pipe(circleP(470, 506, 20), 16, OR, 0.28, 0.08, 6);
    R.flat(circleP(470, 506, 9), HOLE, 0.22, 6);
    R.pipe(circleP(560, 690, 14), 12, OR, 0.28, 0.06, 6);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.8, emis: 0.12, spec: 1.2, shin: 60, wrap: 0.1, coat: 0.1, ao: 0.9 }),                  // 1 cobalt gloss relief
        E.mat({ dif: 0.7, emis: 0.25, spec: 0.1, shin: 10, wrap: 0.3 }),                                     // 2 photo
        E.mat({ dif: 0.8, emis: 0.3, spec: 0.4, shin: 30, wrap: 0.2 }),                                     // 3 purple vinyl
        E.mat({ dif: 0.85, emis: 0.15, spec: 0.3, shin: 20, grain: 0.2, wrap: 0.1, ao: 0.8 }),                         // 4 black sticker + worms
        E.mat({ dif: 0.5, metal: 0.5, spec: 0.8, shin: 40, grain: 0.35, emis: 0.2, tint: [1.1, 0.9, 0.6], ao: 0.6 }), // 5 bronze
        E.mat({ dif: 0.9, emis: 0.25, spec: 1.0, shin: 50, wrap: 0.15, coat: 0.12, ao: 0.6 }),                // 6 glossy orange
        E.mat({ dif: 0.8, emis: 0.3, spec: 0.7, shin: 35, wrap: 0.2 })                                      // 7 pearl / yellow / pink
      ],
      light: [-0.5, 0.62, 0.6], lc: [0.95, 0.93, 0.9], amb: [0.16, 0.17, 0.22],
      envTop: [1, 0.97, 0.92], envHor: [0.32, 0.38, 0.55], envBot: [0.04, 0.05, 0.1], envK: [0.4, 1.1, 0.4, 0],
      shadow: [-8, 8, 0.6, 12], r1: 2, r2: 8, k: [0, 0.6, 0.4, 90]
    });
    E.grain(0.035, 29);
  }
});
