'use strict';
// g103 — "Sherbet board on zebra": a tilted orange-to-lilac board with a blue eye, gold rim and bronze tiles
// over a sweeping zebra floor, with melted chrome, an orange worm, a copper ribbon and a neon-pink circuit plate.
REC.register('g103', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const poly = pts => P(pts, true, false);

    // ── zebra floor: three fitted stripe zones (upright / fold / sweeping) ──
    R.flat(rrect(-10, -10, 746, 1044, 0), null, 0, 0);
    img(E.fx(`
      float zA(vec2 p){ float X = (p.x - 100.) / 100., Y = (p.y - 450.) / 100.; return 0.90177 + 0.00174 * Y - 0.0005 * Y * Y + 1.26184 * X - 0.11044 * X * Y - 0.02331 * X * X; }
      float zB(vec2 p){ float X = (p.x - 200.) / 100., Y = (p.y - 640.) / 100.; return 1.15593 + 1.43608 * Y - 0.28698 * Y * Y + 1.17858 * X - 0.55539 * X * Y - 0.07588 * X * X; }
      float zC(vec2 p){ float X = (p.x - 150.) / 100., Y = (p.y - 880.) / 100.;
        return 1.57963 + 0.36919 * Y - 0.14684 * Y * Y + 0.00105 * Y * Y * Y + 0.97448 * X + 0.01682 * X * Y - 0.04035 * X * Y * Y - 0.07375 * X * X + 0.02851 * X * X * Y + 0.001 * X * X * X; }
      float dk(float ph){ return smoothstep(-0.1, 0.1, cos(6.2832 * ph)); }
      vec3 fx(vec2 uv, vec2 p){
        float yAB = p.x < 300. ? 600. - 0.133 * p.x : 560.;
        float yBC = p.x < 250. ? 706. : 706. - (p.x - 250.) * 0.6;
        float d = mix(dk(zA(p)), dk(zB(p)), smoothstep(yAB - 3., yAB + 3., p.y));
        d = mix(d, dk(zC(p)), smoothstep(yBC - 3., yBC + 3., p.y));
        vec3 cream = vec3(.95, .93, .87) * (0.92 + 0.08 * fbm(p * 0.01));
        vec3 blk = vec3(.04, .04, .05) + vec3(.12) * smoothstep(0.6, 0.8, fbm(p * 0.008 + 3.));
        return mix(cream, blk, d); }`));
    // grommets
    for (const [x, y, r] of [[110, 560, 22], [95, 617, 13], [175, 732, 22], [55, 772, 10], [95, 920, 25], [275, 967, 18], [5, 437, 10], [8, 630, 6]]) {
      R.dome(circleP(x, y, r), '#e8e6ea', 0.04, 0.05, r * 0.4, 2);
      R.dome(circleP(x, y, r * 0.55), '#3a3a6a', 0.06, 0.04, r * 0.3, 6);
    }

    // ── background behind the board (top right) ──
    R.flat(poly([[240, 0], [740, 0], [740, 160], [430, 160], [400, 113], [300, 40]]), '#4a4e4a', 0.0, 0);
    clipA(poly([[240, 0], [740, 0], [740, 160], [430, 160], [400, 113], [300, 40]]), () => {
      a.fillStyle = '#d4ccbc'; a.fill(poly([[400, 0], [740, 0], [740, 70], [560, 66], [470, 74], [420, 90]]));
      a.fillStyle = '#2a3230'; a.fill(poly([[430, 85], [560, 72], [740, 76], [740, 110], [560, 118], [450, 130]]));
      a.fillStyle = '#1e7a90'; a.fill(P([[500, 140], [600, 112], [740, 98], [740, 160], [480, 160]], true, true));
      a.lineWidth = 26; a.strokeStyle = '#c4c8cc'; a.stroke(P([[360, 0], [395, 40], [400, 90], [420, 130]], false, true));
    });
    R.flat(rrect(-10, -10, 746, 32, 0), '#050505', 0.0, 0);

    // ── navy yarn under the board ──
    const yarn = P([[200, 380], [267, 392], [333, 380], [400, 360], [467, 338], [505, 330], [482, 382], [450, 420], [418, 440], [378, 452], [334, 474], [302, 522], [282, 580], [250, 592], [226, 540], [212, 470], [204, 420]], true, true);
    R.dome(yarn, '#141a48', 0.04, 0.08, 20, 7);
    clipA(yarn, () => {
      const yr = rng(31);
      a.lineCap = 'round';
      for (let i = 0; i < 420; i++) {
        const x = 200 + yr() * 300, y = 330 + yr() * 270, an = 0.4 + (yr() - 0.5) * 1.6, L = 16 + yr() * 26;
        a.lineWidth = 1.6 + yr() * 2.2; a.strokeStyle = yr() < 0.5 ? '#3a4cb8' : yr() < 0.7 ? '#5468d0' : '#22307a';
        a.beginPath(); a.moveTo(x, y); a.quadraticCurveTo(x + Math.cos(an) * L * 0.5 + 6, y + Math.sin(an) * L * 0.5 - 6, x + Math.cos(an) * L, y + Math.sin(an) * L); a.stroke();
      }
    });

    // ── the board ──
    const edge = [[0, 95], [7, 100], [40, 167], [73, 227], [113, 287], [153, 333], [187, 357], [220, 363], [267, 363], [333, 353], [400, 333], [467, 313], [533, 293], [600, 268], [640, 255], [740, 244]];
    const band = P([...edge, [740, 270], [640, 282], [600, 294], [533, 319], [467, 340], [400, 361], [333, 381], [267, 394], [220, 396], [178, 388], [138, 360], [98, 312], [58, 252], [24, 190], [0, 142]], true, true);
    R.flat(band, '#2638b4', 0.14, 1);
    clipA(band, () => { a.lineWidth = 5; a.strokeStyle = '#ff5020'; a.stroke(P([[0, 142], [24, 190], [58, 252], [98, 312], [138, 360], [178, 388], [220, 396], [267, 394], [333, 381], [400, 361], [467, 340], [533, 319], [600, 294], [640, 282], [740, 270]], false, true)); });
    for (const [x, y, w, h, r] of [[320, 380, 74, 30, -0.17], [424, 340, 60, 28, -0.28], [508, 307, 58, 26, -0.3], [590, 276, 52, 24, -0.3]]) {
      const t = new Path2D(); t.addPath(rrect(-w / 2, -h / 2, w, h, 6), new DOMMatrix().translate(x, y).rotate(r * 57.3));
      R.dome(t, '#a8743c', 0.2, 0.06, 6, 3);
      clipA(t, () => { const tr = rng(x); a.strokeStyle = '#5a3818'; a.lineWidth = 2; for (let i = 0; i < 7; i++) { a.beginPath(); a.arc(x - w / 2 + tr() * w, y - h / 2 + tr() * h, 3 + tr() * 6, 0, 4); a.stroke(); } });
    }
    const board = P([[0, 22], [232, 22], [253, 40], [300, 60], [353, 88], [400, 120], [430, 138], [480, 148], [560, 152], [640, 150], [740, 148], ...edge.slice().reverse()], true, false);
    R.dome(board, null, 0.2, 0.04, 14, 1);
    clipA(board, () => {
      a.fillStyle = lin(120, 100, 420, 330, [[0, '#f8a878'], [0.4, '#f4ac90'], [0.62, '#c8b4d4'], [1, '#b4b8ec']]); a.fillRect(0, 0, 740, 400);
      a.fillStyle = lin(480, 150, 740, 250, [[0, 'rgba(184,188,236,0)'], [0.3, '#b8bcec'], [1, '#aeb4e8']]); a.fillRect(420, 140, 320, 140);
      soft(x => { x.fillStyle = '#ec9cae'; x.fill(ellipseP(40, 80, 90, 60, 0)); x.fill(ellipseP(150, 60, 90, 40, 0)); }, 30, 0.85);
      // orange puddles
      const pr = rng(7);
      for (let i = 0; i < 34; i++) {
        const x = 70 + pr() * 300, y = 40 + pr() * 230; if (y > 280 - x * 0.2 || (x > 260 && y > 130)) continue;
        a.fillStyle = pr() < 0.6 ? '#f39048' : '#f6a058'; a.fill(P(blob(x, y, 6 + pr() * 16, 4 + pr() * 8, 100 + i, 9, 0.35), true, true));
      }
      // brushed streaks + glitter
      a.globalAlpha = 0.12; a.strokeStyle = '#ffffff'; a.lineWidth = 1;
      for (let i = 0; i < 120; i++) { const x = pr() * 700, y = 30 + pr() * 330; a.beginPath(); a.moveTo(x, y); a.lineTo(x + 40 + pr() * 60, y - 6 - pr() * 6); a.stroke(); }
      a.globalAlpha = 1;
      for (let i = 0; i < 160; i++) { const x = 140 + pr() * 420, y = 150 + pr() * 200; a.fillStyle = `rgba(255,255,255,${0.4 + pr() * 0.6})`; a.fill(circleP(x, y, 0.6 + pr() * 1.4)); }
    });
    // gold rim
    R.pipe(P(edge, false, true), 13, '#ecd690', 0.26, 0.08, 4);
    R.pipe(P([[0, 70], [22, 66], [34, 80], [24, 100], [7, 100]], false, true), 12, '#ecd690', 0.26, 0.08, 4);
    // blue triangle + orange tab at the top
    R.dome(P([[68, 30], [162, 30], [150, 50], [112, 66], [78, 56]], true, true), '#3a64e0', 0.24, 0.06, 10, 6);
    for (const [x, y, r] of [[108, 42, 6], [124, 32, 4], [96, 54, 4]]) R.bead(x, y, r, '#f0d040', 0.3, 0.03, 6);
    R.dome(P([[160, 22], [232, 22], [222, 34], [170, 34]], true, true), '#f28030', 0.24, 0.03, 4, 5);
    R.flat(rrect(0, 32, 30, 8, 4), '#2a40c0', 0.24, 6);
    // holes
    for (const [x, y, r] of [[242, 68, 9], [227, 302, 7], [500, 248, 5], [474, 236, 4]]) R.flat(ellipseP(x, y, r * 1.2, r, 0), '#0a0812', 0.18, 0);
    // blue eye
    R.dome(ellipseP(372, 205, 92, 62, -0.06), '#4c6ae2', 0.24, 0.16, 30, 6);
    R.dome(ellipseP(360, 226, 72, 38, -0.04), '#c4c8f2', 0.24, 0.06, 8, 6);
    R.flat(ellipseP(356, 218, 62, 33, -0.04), '#05060e', 0.26, 6);
    for (const [x, y, r] of [[330, 232, 8], [370, 216, 3], [300, 220, 2]]) R.flat(circleP(x, y, r), '#40d8ff', 0.27, 0);
    R.bead(497, 170, 35, '#3a58d8', 0.22, 0.26, 6);
    // cream Y-stick
    for (const pts of [[[566, 166], [612, 196], [650, 228], [684, 258], [700, 270]], [[612, 196], [680, 186], [740, 178]]]) R.pipe(P(pts, false, true), 22, '#f2e2a4', 0.32, 0.12, 4);
    R.bead(695, 266, 15, '#f2e2a4', 0.34, 0.1, 4);

    // ── dark well + blue circuit plate (right) ──
    const ribC = [[760, 425], [690, 470], [640, 505], [600, 540], [570, 572], [540, 606], [520, 650], [505, 700], [487, 750], [467, 800], [450, 850], [435, 900], [420, 950], [408, 1000], [402, 1040]];
    R.flat(poly([...ribC, [740, 1040]]), '#1c0a12', 0.04, 0);
    const plate = P([[740, 606], [700, 630], [662, 662], [638, 692], [605, 740], [585, 790], [565, 840], [545, 890], [530, 940], [515, 990], [508, 1040], [740, 1040]], true, true);
    R.dome(plate, '#5262cc', 0.06, 0.04, 10, 1);
    clipA(plate, () => soft(x => { x.fillStyle = '#9a6a68'; x.fill(P([[740, 780], [690, 790], [658, 830], [650, 900], [652, 960], [656, 1040], [740, 1040]], true, true)); }, 6, 1));
    for (const pts of [[[740, 545], [690, 570], [650, 605], [625, 640], [605, 680], [600, 705], [612, 726], [650, 735], [692, 725]],
      [[625, 640], [600, 680], [578, 730], [562, 780], [556, 800]],
      [[740, 755], [650, 765], [635, 782], [640, 820], [650, 860], [660, 920], [640, 960], [590, 990], [560, 980], [545, 965]],
      [[540, 865], [515, 900], [495, 940], [485, 980], [485, 1040]], [[555, 1000], [592, 1030]], [[706, 992], [740, 978]]])
      R.pipe(P(pts, false, true), 9, '#ff5cb4', 0.12, 0.06, 5);
    for (const [x, y, r] of [[682, 658, 33], [560, 830, 35], [596, 911, 36], [712, 832, 30]]) {
      R.dome(circleP(x, y, r), '#ff6a1c', 0.12, 0.2, r * 0.7, 5);
      for (const dy of [-6, 6]) R.groove(P([[x - r * 0.4, y + dy], [x + r * 0.4, y + dy]], false), 5, '#c84010', 0.3, 0.05, 5);
    }

    // ── taupe melt + copper ribbon ──
    const taupe = P([[405, 500], [440, 482], [470, 494], [520, 502], [556, 540], [600, 520], [650, 470], [700, 445], [740, 425], ...ribC.slice(0, 10), [452, 800], [446, 760], [440, 710], [430, 660], [420, 610], [410, 560]], true, true);
    R.dome(P([[330, 830], [380, 812], [432, 818], [458, 850], [450, 892], [400, 902], [350, 890], [318, 862]], true, true), '#bcaaa6', 0.1, 0.1, 14, 1);
    R.dome(taupe, '#c2aeaa', 0.1, 0.1, 18, 1);
    clipA(taupe, () => soft(x => { x.fillStyle = '#e8e0e0'; x.fill(ellipseP(495, 590, 40, 40, 0)); x.fillStyle = '#9e8a88'; x.fill(ellipseP(450, 720, 20, 60, 0)); }, 10, 0.9));
    R.dome(circleP(495, 556, 11), '#d8d4d8', 0.24, 0.05, 4, 2); R.flat(circleP(495, 556, 4), '#4a4050', 0.28, 0);
    const rib = P(ribC, false, true);
    R.pipe(rib, 84, '#ff4a10', 0.1, 0.06, 5);
    a.save(); R.h.save(); a.translate(-8, 0); R.h.translate(-8, 0);
    R.pipe(rib, 66, lin(700, 480, 420, 1000, [[0, '#f2c6a8'], [0.35, '#fad8bc'], [0.6, '#e8b694'], [1, '#f6d0b0']]), 0.16, 0.08, 3);
    a.restore(); R.h.restore();

    // ── melted chrome ──
    const chrome1 = P([[525, 300], [560, 276], [640, 270], [700, 278], [740, 280], [740, 334], [690, 342], [640, 334], [600, 334], [560, 326], [532, 316]], true, true);
    R.dome(chrome1, '#f4f6fa', 0.3, 0.2, 16, 2);
    const chrome2 = P([[446, 382], [462, 352], [500, 342], [540, 346], [580, 332], [622, 322], [684, 330], [740, 340], [740, 452], [712, 452], [688, 440], [664, 420], [640, 424], [612, 446], [592, 476], [592, 528], [576, 546], [552, 540], [540, 504], [520, 482], [498, 492], [478, 500], [458, 480], [450, 440]], true, true);
    R.dome(chrome2, '#f4f6fa', 0.3, 0.3, 24, 2);
    clipA(chrome2, () => soft(x => { x.fillStyle = '#7a7e88'; x.fill(ellipseP(565, 480, 14, 50, 0.3)); x.fillStyle = '#ffffff'; x.fill(ellipseP(520, 420, 34, 16, -0.4)); x.fill(ellipseP(600, 360, 40, 14, -0.2)); }, 10, 0.8));
    for (const [x, y, rx, ry, rot] of [[515, 376, 38, 18, -0.1], [588, 294, 30, 12, -0.05], [508, 465, 26, 30, 0.3], [652, 386, 20, 30, -0.3]]) {
      R.flat(ellipseP(x, y, rx, ry, rot), '#06070c', 0.34, 7);
      R.pipe(ellipseP(x, y, rx + 4, ry + 4, rot), 9, '#e4e8ee', 0.5, 0.06, 2);
    }
    R.dome(circleP(712, 306, 26), '#d8dce4', 0.4, 0.06, 6, 2);
    clipA(circleP(712, 306, 20), () => { const cr = rng(3); for (let i = 0; i < 24; i++) { a.fillStyle = ['#ff8030', '#ffd040', '#e050a0', '#40a0ff'][i % 4]; a.fill(circleP(694 + cr() * 36, 292 + cr() * 28, 1.5 + cr() * 2.5)); } });

    // ── orange worm, cream disc, chrome teardrop ──
    R.pipe(P([[452, 492], [420, 470], [386, 460], [352, 468], [332, 494], [328, 530], [318, 558], [298, 580], [286, 602]], false, true), 38, '#ff7418', 0.34, 0.24, 5);
    R.dome(P([[266, 598], [300, 590], [304, 620], [290, 640], [274, 634]], true, true), '#14141c', 0.34, 0.08, 8, 7);
    R.flat(ellipseP(285, 618, 7, 9, 0), '#f0c818', 0.4, 0); R.flat(circleP(285, 622, 3), '#3060e0', 0.41, 0);
    R.dome(ellipseP(287, 672, 36, 26, -0.1), '#efe6aa', 0.2, 0.14, 14, 5);
    const tear = P([[262, 705], [285, 688], [322, 690], [362, 712], [402, 744], [426, 780], [430, 812], [412, 830], [380, 824], [348, 800], [318, 770], [290, 746], [268, 728]], true, true);
    R.dome(tear, '#c4c8d0', 0.2, 0.36, 28, 2);
    clipA(tear, () => soft(x => { x.lineWidth = 16; x.strokeStyle = '#2a2c34'; x.stroke(P([[290, 740], [340, 776], [390, 810]], false, true)); x.fillStyle = '#f8f8ff'; x.fill(ellipseP(320, 712, 26, 10, 0.5)); }, 6, 0.8));

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.7, shin: 50, wrap: 0.4, ao: 0.4, coat: 0.12 }),                      // 1 glossy plastic (board, taupe, plate)
        E.mat({ dif: 0.55, metal: 0.7, spec: 1.4, shin: 90, ao: 0.2, coat: 0.25, emis: 0.22 }),                   // 2 chrome
        E.mat({ dif: 0.85, metal: 0.25, spec: 1.0, shin: 40, ao: 0.3, wrap: 0.4, tint: [1.08, 0.92, 0.8], emis: 0.18 }),     // 3 copper / bronze
        E.mat({ dif: 0.8, metal: 0.3, spec: 0.9, shin: 50, wrap: 0.3, tint: [1.05, 1.0, 0.8] }),      // 4 gold rim / cream
        E.mat({ dif: 1, spec: 1.0, shin: 70, wrap: 0.4, ao: 0.3, coat: 0.15, emis: 0.08 }),          // 5 glossy orange / pink
        E.mat({ dif: 1, spec: 1.2, shin: 80, wrap: 0.3, ao: 0.3, coat: 0.25 }),                       // 6 glossy blue
        E.mat({ dif: 1, spec: 0.15, shin: 12, wrap: 0.4, ao: 0.6 })                                   // 7 yarn
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.85, 0.84, 0.82], amb: [0.36, 0.36, 0.38],
      envTop: [1, 1, 1], envHor: [0.72, 0.72, 0.75], envBot: [0.05, 0.05, 0.06], envK: [0.4, 1.4, 0.05, 0],
      r1: 1.8, r2: 10, k: [0, 0.6, 0.4, 70], shadow: [-8, 10, 0.6, 6]
    });
    E.grain(0.03, 103);
  }
});
