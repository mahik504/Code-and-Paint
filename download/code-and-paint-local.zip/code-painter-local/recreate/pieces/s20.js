'use strict';
// s20 — "Debris room": a dark gallery hall seen in perspective — pale curved ceiling blades,
// wire-frame cages and lit panels on black walls, giant orange planks crashing in on the
// right, and a floor buried in scattered magazine pages, shards and glossy scraps.
REC.register('s20', {
  w: 1024, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const r = rng(20);
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; if (blur) a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fillB = (x, pts, col, smooth = false) => { x.fillStyle = col; x.fill(P(pts, true, smooth)); };
    const strk = (x, pts, w, col, smooth = false) => { x.strokeStyle = col; x.lineWidth = w; x.stroke(P(pts, false, smooth)); };
    const grid = (x, x0, y0, x1, y1, nx, ny, col, w = 1) => {   // wire grid on a quad (x0,y0)-(x1,y1)
      x.strokeStyle = col; x.lineWidth = w; x.beginPath();
      for (let i = 0; i <= nx; i++) { const u = x0 + (x1 - x0) * i / nx; x.moveTo(u, y0); x.lineTo(u, y1); }
      for (let j = 0; j <= ny; j++) { const v = y0 + (y1 - y0) * j / ny; x.moveTo(x0, v); x.lineTo(x1, v); }
      x.stroke();
    };
    const PAL = [['#d8c050', 7], ['#e8dc90', 4], ['#d6cdb4', 4], ['#c89a40', 3], ['#d87a30', 2], ['#b8402a', 2], ['#8a8478', 4], ['#ece8dc', 3], ['#16120f', 10],
      ['#2a2420', 8], ['#6a6040', 4], ['#5a4a3a', 4], ['#3a5aa8', 0.7], ['#7a2a24', 2], ['#a8b060', 1.5], ['#4a3a30', 4]];
    const DARK = new Set(['#16120f', '#2a2420', '#4a3a30', '#5a4a3a', '#7a2a24']);
    const pick = (dk = 1) => { const wt = PAL.map(([c, w]) => DARK.has(c) ? w * dk : w), tot = wt.reduce((s2, v) => s2 + v, 0); let v = r() * tot; for (let i = 0; i < PAL.length; i++) { v -= wt[i]; if (v <= 0) return PAL[i][0]; } return PAL[0][0]; };

    // ── room shell ──
    R.flat(rrect(-10, -10, 1044, 1044, 0), '#1b1718', 0, 0);
    soft(x => {
      const g = x.createLinearGradient(0, 340, 0, 1024); g.addColorStop(0, '#3a3228'); g.addColorStop(0.3, '#2e2822'); g.addColorStop(1, '#241e1b');
      fillB(x, [[-10, 372], [300, 356], [620, 350], [880, 345], [1034, 350], [1034, 1034], [-10, 1034]], g);
    }, 2);
    // ceiling blades
    soft(x => {
      const b1 = x.createLinearGradient(40, 60, 500, 120); b1.addColorStop(0, '#d8d0a8'); b1.addColorStop(0.5, '#b8b09a'); b1.addColorStop(1, '#8a8a86');
      fillB(x, [[20, 132], [90, 86], [230, 58], [380, 50], [470, 60], [505, 80], [470, 100], [400, 96], [290, 92], [170, 104], [70, 132]], b1, true);
      fillB(x, [[70, 132], [170, 104], [290, 92], [400, 96], [470, 100], [440, 112], [300, 108], [160, 120], [90, 140]], '#4a4640', true);
      fillB(x, [[130, 128], [260, 110], [400, 114], [458, 136], [430, 152], [300, 150], [160, 142]], '#cfc690', true);
      fillB(x, [[250, 116], [300, 112], [320, 130], [270, 134]], '#d88a50', true);
      fillB(x, [[190, 170], [320, 164], [450, 176], [440, 190], [300, 186], [200, 180]], '#6a6660', true);
      strk(x, [[460, 70], [510, 50]], 10, '#b8b8b0');
      fillB(x, [[0, 90], [30, 96], [26, 230], [0, 240]], '#c07050');
      fillB(x, [[0, 110], [20, 112], [18, 200], [0, 206]], '#4a6aa8');
    }, 1.5);
    // lit wall strip + panels
    soft(x => {
      const g = x.createLinearGradient(135, 170, 330, 210); g.addColorStop(0, '#f0a040'); g.addColorStop(0.5, '#e8c070'); g.addColorStop(1, '#8a6a40');
      fillB(x, [[135, 162], [330, 204], [330, 218], [135, 184]], g);
      fillB(x, [[65, 278], [162, 276], [162, 330], [65, 332]], '#e6d68c');
      fillB(x, [[392, 218], [456, 218], [456, 342], [392, 344]], '#e2dcb4');
      fillB(x, [[300, 232], [312, 232], [312, 340], [300, 340]], '#e8e0b0');
      fillB(x, [[180, 196], [298, 212], [298, 350], [180, 366]], '#2a2a2c');
      fillB(x, [[740, 216], [832, 222], [832, 330], [740, 326]], '#3a5aa0');
      fillB(x, [[750, 222], [826, 226], [800, 270], [760, 300], [750, 290]], '#e8d890');
      fillB(x, [[760, 300], [826, 250], [832, 330], [770, 326]], '#1a1a20');
      fillB(x, [[580, 330], [720, 322], [720, 350], [580, 356]], '#8a7a60');
    }, 1);
    soft(x => {
      grid(x, 182, 198, 296, 352, 7, 9, 'rgba(210,210,200,0.6)');
      grid(x, 62, 226, 112, 400, 3, 10, 'rgba(200,200,190,0.45)');
      grid(x, 456, 150, 560, 380, 7, 14, 'rgba(225,225,215,0.7)');
      grid(x, 548, 84, 630, 300, 5, 12, 'rgba(225,225,215,0.6)');
      grid(x, 830, 222, 872, 330, 3, 7, 'rgba(210,210,200,0.6)');
      grid(x, 640, 180, 740, 330, 5, 8, 'rgba(200,200,190,0.35)');
      strk(x, [[456, 380], [700, 360]], 2, 'rgba(220,220,210,0.6)'); strk(x, [[690, 325], [800, 322]], 2, 'rgba(220,220,210,0.6)');
      // collage cluster in the back
      x.fillStyle = '#7a9ac8'; x.beginPath(); x.ellipse(700, 222, 28, 30, 0, 0, 6.3); x.fill();
      x.fillStyle = '#c8c0c8'; x.beginPath(); x.ellipse(665, 300, 32, 44, 0.2, 0, 6.3); x.fill();
      x.fillStyle = '#6a5a60'; x.fillRect(560, 220, 60, 70); x.fillStyle = '#b89ab0'; x.fillRect(600, 250, 40, 50);
      x.fillStyle = '#e8e8f0'; x.beginPath(); x.ellipse(570, 206, 20, 14, 0, 0, 6.3); x.fill();
    }, 0.6);

    // ── floor debris (perspective scatter) ──
    const floorY = y => 350 + (y - 350);
    const scatter = (n, y0, y1, sMin, sMax, alpha, dk = 1) => soft(x => {
      for (let i = 0; i < n; i++) {
        const t = Math.pow(r(), 0.8), y = y0 + (y1 - y0) * t, persp = (y - 330) / 700;
        const xx = -40 + r() * 1100, sz = (sMin + (sMax - sMin) * r()) * (0.25 + persp * 1.4), rot = r() * 6.283, sq = 0.35 + persp * 0.6;
        x.save(); x.translate(xx, floorY(y)); x.scale(1, sq); x.rotate(rot);
        x.globalAlpha = alpha; x.fillStyle = pick(dk);
        const w = sz * (0.6 + r()), hh = sz * (0.4 + r() * 0.8), sk = (r() - 0.5) * 0.6 * sz;
        x.beginPath(); x.moveTo(-w / 2, -hh / 2); x.lineTo(w / 2 + sk, -hh / 2); x.lineTo(w / 2, hh / 2); x.lineTo(-w / 2 - sk, hh / 2); x.closePath(); x.fill();
        if (r() < 0.45) { x.fillStyle = pick(dk); x.fillRect(-w * 0.35, -hh * 0.3, w * (0.3 + r() * 0.3), hh * (0.2 + r() * 0.3)); } if (r() < 0.3) { x.fillStyle = pick(dk * 2); x.beginPath(); x.arc(w * 0.1, hh * 0.1, Math.min(w, hh) * 0.25, 0, 6.3); x.fill(); }
        if (r() < 0.15) { x.strokeStyle = 'rgba(240,240,230,0.7)'; x.lineWidth = 1 / sq; x.stroke(); }
        x.restore();
      }
    }, 0.5);
    scatter(5000, 355, 620, 8, 22, 0.92, 0.45);
    scatter(3200, 480, 1030, 12, 34, 0.92, 1.8);
    scatter(1100, 680, 1040, 22, 50, 0.95, 2.2);
    // magazine clippings: gradient photos with blobs and white borders
    soft(x => {
      for (let i = 0; i < 80; i++) {
        const y = 640 + Math.pow(r(), 0.7) * 400, xx = -30 + r() * 1080, sz = 30 + r() * 60 * ((y - 500) / 500), rot = (r() - 0.5) * 2.4, sq = 0.55 + (y - 640) / 1000;
        x.save(); x.translate(xx, y); x.scale(1, sq); x.rotate(rot);
        const w = sz * (0.8 + r() * 0.6), hh = sz * (0.7 + r() * 0.5), g = x.createLinearGradient(-w / 2, -hh / 2, w / 2, hh / 2);
        g.addColorStop(0, pick(1.2)); g.addColorStop(1, pick(1.2)); x.fillStyle = g; x.fillRect(-w / 2, -hh / 2, w, hh);
        for (let k = 0; k < 3; k++) { x.fillStyle = pick(1); x.globalAlpha = 0.85; x.beginPath(); x.ellipse((r() - 0.5) * w * 0.6, (r() - 0.5) * hh * 0.6, w * (0.08 + r() * 0.2), hh * (0.08 + r() * 0.2), r() * 3, 0, 6.3); x.fill(); }
        x.globalAlpha = 1; if (r() < 0.35) { x.strokeStyle = 'rgba(235,232,220,0.85)'; x.lineWidth = 2; x.strokeRect(-w / 2, -hh / 2, w, hh); }
        x.restore();
      }
    }, 0.6);
    soft(x => { const g = x.createLinearGradient(0, 520, 0, 1024); g.addColorStop(0, 'rgba(20,14,10,0)'); g.addColorStop(0.3, 'rgba(20,14,10,0.3)'); g.addColorStop(1, 'rgba(20,14,10,0.35)'); x.fillStyle = g; x.fillRect(0, 520, 1024, 504);
      x.fillStyle = 'rgba(15,10,8,0.45)'; x.fill(P([[80, 560], [300, 560], [470, 640], [420, 720], [200, 700], [60, 640]])); }, 30);

    // ── foreground furniture, shards and big scraps ──
    soft(x => {
      // bed / sofa
      fillB(x, [[420, 470], [470, 452], [600, 448], [678, 462], [666, 520], [600, 536], [470, 528], [424, 504]], '#5a2622', true);
      fillB(x, [[450, 470], [520, 460], [560, 480], [540, 510], [470, 505]], '#8a3a30', true);
      fillB(x, [[560, 470], [640, 462], [650, 500], [590, 512]], '#2a1614', true);
      strk(x, [[430, 510], [430, 555], [550, 562], [660, 530], [662, 480]], 3, 'rgba(210,205,195,0.8)');
      fillB(x, [[420, 405], [440, 400], [466, 440], [462, 468], [440, 460]], '#d8d8d8', true);
      // glass shard pile (translucent)
      for (let i = 0; i < 40; i++) {
        const cx = 400 + r() * 260, cy = 600 + r() * 170, s2 = 20 + r() * 50, an = r() * 6.28;
        const pts = [[cx, cy], [cx + Math.cos(an) * s2, cy + Math.sin(an) * s2 * 0.6], [cx + Math.cos(an + 1.8) * s2 * 0.7, cy + Math.sin(an + 1.8) * s2 * 0.4]];
        x.fillStyle = `rgba(${150 + r() * 60},${160 + r() * 60},${170 + r() * 60},0.25)`; x.fill(P(pts, true, false));
        x.strokeStyle = 'rgba(235,240,240,0.7)'; x.lineWidth = 1.2; x.stroke(P(pts, true, false));
      }
      fillB(x, [[420, 740], [470, 712], [490, 760], [450, 770]], '#3a70c8', true);
      // left shelves
      fillB(x, [[0, 370], [60, 360], [80, 390], [0, 400]], '#d8c8a0');
      fillB(x, [[20, 420], [100, 424], [104, 500], [24, 498]], '#c85a30');
      fillB(x, [[0, 520], [40, 540], [60, 600], [0, 620]], '#8a7a60');
      grid(x, 40, 560, 110, 660, 3, 4, 'rgba(210,210,200,0.6)');
      grid(x, 90, 600, 190, 700, 4, 4, 'rgba(210,210,200,0.6)');
      fillB(x, [[60, 700], [190, 660], [200, 740], [80, 780]], '#4a4038');
      // magazine covers bottom-left
      fillB(x, [[0, 600], [30, 590], [50, 700], [10, 720]], '#e8d8c8');
      fillB(x, [[0, 720], [40, 700], [60, 800], [0, 830]], '#c8a080');
      fillB(x, [[60, 720], [110, 716], [110, 790], [60, 796]], '#e8e8f0'); x.fillStyle = '#3a60b0'; x.beginPath(); x.arc(84, 758, 16, 0, 6.3); x.fill();
      fillB(x, [[200, 690], [250, 670], [275, 760], [220, 780]], '#e0d8d0'); fillB(x, [[210, 700], [245, 690], [262, 750], [225, 760]], '#6a5a58');
      fillB(x, [[60, 880], [190, 860], [220, 960], [90, 990]], '#8a3a2a'); fillB(x, [[80, 890], [170, 876], [190, 940], [100, 960]], '#1a1418');
      fillB(x, [[270, 930], [430, 910], [450, 1030], [290, 1030]], '#b85a30'); fillB(x, [[300, 950], [410, 940], [420, 1010], [310, 1015]], '#6a3020');
      fillB(x, [[220, 860], [300, 850], [310, 900], [230, 910]], '#e8e0d0');
      // right side frames / objects
      fillB(x, [[930, 620], [1034, 600], [1034, 740], [920, 720]], '#3a2e28'); fillB(x, [[945, 630], [1020, 618], [1020, 720], [940, 710]], '#1c1614');
      fillB(x, [[850, 880], [912, 876], [915, 968], [852, 972]], '#1a1a1a'); strk(x, [[850, 880], [912, 876], [915, 968], [852, 972], [850, 880]], 2, '#d0d0c8');
      fillB(x, [[830, 790], [880, 780], [905, 830], [850, 840]], '#e0c8c0', true);
      x.fillStyle = '#6a3a2a'; x.beginPath(); x.ellipse(560, 845, 34, 26, 0, 0, 6.3); x.fill();
      fillB(x, [[660, 850], [740, 830], [760, 900], [680, 910]], '#b87858');
      fillB(x, [[680, 930], [760, 930], [780, 1030], [690, 1030]], '#d0a060');
      fillB(x, [[950, 780], [990, 770], [1000, 830], [960, 840]], '#c8b098');
      fillB(x, [[900, 620], [950, 610], [960, 660], [910, 670]], '#c89040');
      fillB(x, [[760, 590], [800, 575], [810, 610], [770, 620]], '#c8c0b8');
    }, 0.7);

    // ── giant orange planks on the right ──
    soft(x => {
      const g = x.createLinearGradient(760, 0, 1024, 200); g.addColorStop(0, '#d0502c'); g.addColorStop(0.6, '#c04428'); g.addColorStop(1, '#8a2a20');
      fillB(x, [[745, 90], [770, 40], [840, 8], [940, -10], [1034, -10], [1034, 200], [980, 216], [940, 180], [890, 160], [820, 150], [760, 130]], g, true);
      fillB(x, [[870, 40], [960, 20], [1000, 80], [930, 110]], '#a83424', true);
      const g2 = x.createLinearGradient(850, 460, 1024, 220); g2.addColorStop(0, '#e2743c'); g2.addColorStop(1, '#d06030');
      fillB(x, [[850, 440], [900, 360], [960, 280], [1010, 216], [1034, 210], [1034, 380], [980, 440], [920, 470], [860, 470]], g2);
      fillB(x, [[980, 250], [1034, 240], [1034, 300], [990, 300]], '#e8a080');
      const g3 = x.createLinearGradient(850, 440, 960, 580); g3.addColorStop(0, '#e67040'); g3.addColorStop(1, '#d05a30');
      fillB(x, [[845, 562], [920, 436], [968, 460], [890, 580]], g3);
      fillB(x, [[992, 532], [1034, 522], [1034, 620], [996, 616]], '#d86a38');
      fillB(x, [[970, 410], [1010, 400], [1034, 440], [1034, 500], [980, 490]], '#2a2420');
      strk(x, [[900, 520], [930, 480]], 2, 'rgba(250,220,190,0.8)'); strk(x, [[980, 300], [1010, 270]], 2, 'rgba(250,220,190,0.8)');
    }, 0.8);

    soft(x => { const g = x.createRadialGradient(420, 470, 20, 420, 480, 380); g.addColorStop(0, 'rgba(240,210,90,0.28)'); g.addColorStop(1, 'rgba(240,210,90,0)'); x.fillStyle = g; x.save(); x.beginPath(); x.rect(0, 372, 1024, 700); x.clip(); x.scale(1, 0.55); x.translate(0, 390); x.fillRect(0, 0, 1024, 1024); x.restore(); }, 3, 1, 'screen');
    // warm light pooling and vignette
    soft(x => { const g = x.createRadialGradient(560, 520, 30, 560, 560, 520); g.addColorStop(0, 'rgba(255,220,150,0.18)'); g.addColorStop(1, 'rgba(255,220,150,0)'); x.fillStyle = g; x.fillRect(0, 0, 1024, 1024); }, 0, 1, 'screen');

    R.shade({ mats: [E.mat({})], shadow: [0, 0, 0, 0] });
    E.vignette(0.3, '10,8,6', 0.6, 1.1);
    E.draw(E.blur(E.snapshot(), 0.6), 0.7);
    E.grain(0.05, 20);
  }
});
