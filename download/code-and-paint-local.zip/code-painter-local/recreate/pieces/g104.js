'use strict';
// g104 — "Golden dial in orbit": a spiked pale-gold sphere wrapped in a grey plastic keyhole frame around a
// toothed black-and-gold dial, a white S-tube in a starry nebula, gold rings, zebra plate and spiral discs.
REC.register('g104', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const GOLD = '#f0c050', GREY = '#aca8ac';

    // ── blurred city background ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#4a6ea8', 0, 0);
    const city = x => {
      x.fillStyle = lin(0, 0, 0, 450, [[0, '#3e64a4'], [1, '#5a7cb0']], x); x.fillRect(80, 0, 420, 480);
      x.fillStyle = '#8aa2c4'; x.fill(ellipseP(330, 90, 60, 24, -0.2)); x.fill(ellipseP(400, 120, 50, 20, -0.2));
      x.fillStyle = '#bab8b4'; x.fill(P([[-10, -10], [180, -10], [180, 120], [90, 220], [90, 300], [-10, 300]], true, false));
      x.fillStyle = lin(0, 0, 0, 1024, [[0.25, '#e6dfc8'], [0.4, '#faf6ea'], [1, '#f8f2e4']], x); x.fillRect(-10, 300, 90, 740); x.fillRect(30, 240, 30, 70);
      x.fillStyle = '#b4acae'; x.fill(circleP(10, 590, 46));
      x.fillStyle = lin(0, 300, 0, 1024, [[0, '#3a3a40'], [0.4, '#2a2826'], [1, '#161414']], x); x.fillRect(80, 240, 54, 800);
      x.fillStyle = '#9ad0d4'; x.fill(ellipseP(150, 330, 16, 90, 0));
      x.fillStyle = '#1e2230'; x.fillRect(130, 470, 620, 580);
      x.fillStyle = '#5a646a'; x.fillRect(130, 480, 70, 560);
    };
    city(a);
    soft(city, 10, 1);

    // ── gold drop (top left) ──
    R.dome(P([[78, 160], [84, 118], [108, 92], [150, 80], [180, 58], [200, 28], [222, 6], [246, -10], [340, -10], [292, 18], [252, 48], [228, 88], [216, 130], [210, 172], [194, 202], [164, 216], [120, 212], [90, 192]], true, true), GOLD, 0.2, 0.4, 40, 2);
    soft(x => { x.fillStyle = '#5a3a10'; x.fill(ellipseP(185, 175, 22, 30, 0.3)); x.fill(ellipseP(245, 60, 12, 30, 0.6)); x.fillStyle = '#fff4c0'; x.fill(ellipseP(118, 128, 22, 16, -0.5)); x.fill(ellipseP(205, 40, 10, 18, 0.6)); }, 8, 0.8);

    // ── the pale gold sphere + spikes ──
    for (const deg of [-122, -152, 176, 148, 110]) {
      const an = deg / 57.3, dx = Math.cos(an), dy = Math.sin(an), bx = 450 + dx * 318, by = 610 + dy * 318, w = 22;
      R.dome(P([[bx - dy * w, by + dx * w], [bx + dx * 50, by + dy * 50], [bx + dy * w, by - dx * w]], true, false), GOLD, 0.15, 0.12, 12, 2);
    }
    for (const [x, y] of [[408, 162], [474, 84]]) R.dome(P([[x + 14, y - 8], [x - 22, y - 22], [x + 2, y + 14]], true, false), GOLD, 0.3, 0.1, 8, 2);
    const ball = P([[130, 640], [148, 525], [190, 432], [250, 345], [300, 296], [362, 260], [450, 240], [560, 250], [700, 350], [760, 600], [700, 850], [560, 930], [420, 942], [330, 915], [250, 870], [180, 800], [140, 720]], true, true);
    R.dome(ball, '#e0cc90', 0.1, 0.4, 150, 3);
    clipA(ball, () => soft(x => {
      x.fillStyle = '#f4e8c0'; x.fill(ellipseP(240, 640, 80, 200, 0.2));
      x.fillStyle = '#b89850'; x.fill(ellipseP(300, 860, 120, 60, 0.3));
      x.fillStyle = '#f0e0a0'; x.fill(ellipseP(500, 200, 80, 60, 0));
    }, 40, 0.8));
    // ── starry nebula (right) ──
    const space = P([[470, 270], [560, 240], [740, 220], [740, 1040], [490, 1040], [470, 940], [440, 820], [420, 720], [440, 640], [470, 560], [470, 470], [460, 400]], true, false);
    R.flat(space, '#06060a', 0.02, 0);
    clipA(space, () => {
      soft(x => {
        x.fillStyle = '#b8d0a0'; x.fill(ellipseP(470, 520, 70, 150, 0));
        x.fillStyle = '#4a3480'; x.fill(ellipseP(490, 870, 50, 110, 0.2));
        x.fillStyle = '#2a4a6a'; x.fill(ellipseP(540, 600, 60, 80, 0));
        x.lineWidth = 26; x.strokeStyle = '#e0b030'; x.stroke(P([[600, 250], [650, 380], [700, 520], [740, 600]], false)); x.lineWidth = 16; x.stroke(P([[560, 290], [610, 430]], false)); x.stroke(P([[680, 250], [740, 400]], false));
      }, 22, 0.9);
      const sr = rng(4);
      for (let i = 0; i < 500; i++) { const x = 420 + sr() * 320, y = 220 + sr() * 820; a.fillStyle = sr() < 0.6 ? `rgba(255,${200 + sr() * 55 | 0},120,${0.4 + sr() * 0.6})` : `rgba(255,255,255,${0.5 + sr() * 0.5})`; a.fill(circleP(x, y, 0.5 + sr() * 1.1)); }
    });
    for (const [x, y, r] of [[632, 513, 7], [624, 612, 7], [530, 795, 7], [526, 868, 5], [598, 840, 4], [700, 580, 5], [520, 940, 4], [506, 980, 4], [660, 470, 3], [590, 560, 3]]) R.bead(x, y, r, '#f4f4f0', 0.05, 0.04, 1);


    // ── grey keyhole frame ──
    const band = P([[480, 316], [400, 338], [330, 358], [262, 383], [208, 425], [176, 490], [168, 560], [178, 630], [205, 690], [250, 722], [310, 742], [362, 772], [398, 822], [420, 892], [440, 962], [456, 1040]], false, true);
    R.dome(P([[262, 380], [330, 356], [400, 336], [480, 314], [482, 404], [420, 422], [345, 432], [282, 452], [232, 486], [206, 470]], true, true), GREY, 0.3, 0.08, 14, 1);
    R.pipe(band, 48, GREY, 0.3, 0.14, 1);
    R.groove(P([[450, 334], [400, 350], [330, 370], [268, 394], [222, 432], [194, 492], [188, 560], [196, 626], [220, 680], [260, 708], [316, 726]], false, true), 8, '#8a868c', 0.42, 0.06, 1, 0.9);
    // inner gold field around the dial
    R.flat(circleP(345, 563, 150), null, 0.3, 3);
    clipA(circleP(345, 563, 150), () => { a.fillStyle = rad(300, 520, 170, [[0, '#f0e0a8'], [0.6, '#e4cc8a'], [1, '#c8b070']]); a.fill(circleP(345, 563, 150)); soft(x => { x.fillStyle = '#c8dcb0'; x.fill(ellipseP(470, 560, 60, 120, 0)); }, 20, 0.85); });
    // gold arc rod + balls
    { const p = new Path2D(); p.arc(345, 563, 137, -68 / 57.3, 113 / 57.3 - 2 * Math.PI, true); R.pipe(p, 10, GOLD, 0.36, 0.06, 2); }
    for (const [x, y, r] of [[397, 435, 15], [213, 594, 15], [293, 688, 17]]) R.bead(x, y, r, GOLD, 0.38, 0.14, 2);
    // the dial
    R.flat(circleP(345, 563, 119), '#3a68c8', 0.4, 4);
    R.flat(circleP(345, 563, 115), '#08080a', 0.4, 0);
    for (let i = 0; i < 26; i++) {
      const an = i / 26 * Math.PI * 2, x = 345 + Math.cos(an) * 101, y = 563 + Math.sin(an) * 101;
      const t = new Path2D(); t.addPath(rrect(-8, -11, 16, 22, 7), new DOMMatrix().translate(x, y).rotate(an * 57.3 + 90));
      R.dome(t, '#f4f2ec', 0.42, 0.04, 4, 4);
    }
    clipA(circleP(345, 563, 86), () => {
      a.fillStyle = rad(340, 560, 90, [[0, '#e8b860'], [0.5, '#a07030'], [1, '#2a1a0a']]); a.fill(circleP(345, 563, 86));
      a.strokeStyle = 'rgba(255,214,140,0.75)'; a.lineWidth = 0.9;
      for (let i = 0; i < 120; i++) { const an = i / 120 * Math.PI * 2; a.beginPath(); a.moveTo(345 + Math.cos(an) * 20, 563 + Math.sin(an) * 20); a.lineTo(345 + Math.cos(an) * 86, 563 + Math.sin(an) * 86); a.stroke(); }
    });
    { const cap = new Path2D(); cap.addPath(rrect(-27, -72, 54, 144, 27), new DOMMatrix().translate(336, 553).rotate(-27)); R.dome(cap, '#f0b848', 0.42, 0.14, 22, 2); }

    // ── zebra plate (top right) ──
    const plate = P([[352, 306], [356, 248], [400, 160], [440, 102], [482, 50], [524, 8], [544, -10], [740, -10], [740, 210], [640, 200], [580, 222], [532, 248], [468, 282], [400, 300]], true, false);
    R.dome(plate, GREY, 0.28, 0.06, 10, 1);
    const zz = P([[366, 298], [368, 252], [408, 168], [448, 110], [490, 58], [532, 16], [552, 0], [740, 0], [740, 200], [640, 192], [580, 212], [530, 238], [466, 272], [400, 290]], true, false);
    clipA(zz, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float X = (p.x - 450.) / 100., Y = (p.y - 200.) / 100.;
      float ph = 1.27626 + 1.8783 * Y + 0.07711 * Y * Y + 0.31942 * Y * Y * Y + 2.50578 * X - 0.99584 * X * Y - 0.13351 * X * Y * Y
               + 0.01475 * X * X - 0.01224 * X * X * Y - 0.1776 * X * X * X;
      float k = smoothstep(-0.12, 0.12, cos(6.2832 * ph));
      return mix(vec3(.95, .95, .96), vec3(.03), k); }`)));
    R.flat(zz, null, 0.3, 4);
    soft(x => { x.fillStyle = '#fff6d0'; x.fill(ellipseP(545, 190, 40, 34, 0)); }, 16, 0.85);
    // spiral button
    R.dome(circleP(450, 360, 54), GREY, 0.34, 0.08, 12, 1);
    R.flat(circleP(450, 360, 40), null, 0.36, 4);
    clipA(circleP(450, 360, 40), () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p - vec2(452., 362.); float r = length(q), an = atan(q.y, q.x);
      float v = abs(fract(r / 8.5 + an / 6.2832) - 0.5);
      return mix(vec3(.08), vec3(.86, .86, .88), smoothstep(0.2, 0.26, v)); }`)));

    // ── white S-tube ──
    R.pipe(P([[452, 642], [490, 680], [540, 692], [580, 665], [598, 600], [590, 520], [576, 440], [586, 380], [630, 348], [690, 360], [745, 400]], false, true), 70, '#c8c8ce', 0.3, 0.4, 5);
    R.dome(circleP(452, 640, 35), '#c8c8ce', 0.3, 0.3, 30, 5);

    // ── gold rings (top right) ──
    R.pipe(P([[470, -10], [464, 18], [456, 38]], false, true), 26, GOLD, 0.5, 0.18, 2);
    R.pipe(P([[504, -10], [500, 50], [530, 100], [590, 122], [650, 104], [700, 72], [745, 66]], false, true), 46, GOLD, 0.5, 0.26, 2);
    R.pipe(ellipseP(700, 232, 76, 116, 0.15), 42, GOLD, 0.5, 0.26, 2);
    R.bead(712, 352, 16, GOLD, 0.5, 0.2, 2);

    // ── zebra target (bottom right) ──
    const tgt = P(blob(726, 909, 196, 222, 21, 16, 0.03), true, true);
    R.dome(tgt, '#9a9a9c', 0.2, 0.06, 10, 1);
    clipA(tgt, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p - vec2(725., 904.); q.x /= 0.9;
      float r = length(q) + 3. * sin(atan(q.y, q.x) * 3. + 1.);
      float v = abs(fract((r - 34.) / 40. + 0.5) - 0.5);
      vec3 c = mix(vec3(.04), vec3(.96), smoothstep(0.25, 0.29, v));
      return mix(c, vec3(.55), smoothstep(208., 216., r)); }`)));
    R.flat(P(blob(726, 909, 186, 210, 21, 16, 0.03), true, true), null, 0.24, 4);
    // spiral discs
    for (const [x, y, rr] of [[226, 930, 108], [10, 590, 42]]) {
      R.dome(circleP(x, y, rr), rr < 60 ? '#b4acae' : '#bcb8b8', 0.2, 0.08, 12, 1);
      clipA(circleP(x, y, rr * 0.86), () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
        vec2 q = p - vec2(${x}., ${y}.); float r = length(q), an = atan(q.y, q.x);
        float v = abs(fract(r / ${(rr / 9).toFixed(1)} + an / 6.2832) - 0.5);
        return mix(vec3(.38, .37, .38), vec3(.8, .78, .78), smoothstep(0.1, 0.2, v)); }`)));
      R.flat(circleP(x, y, rr * 0.86), null, 0.22, 4);
    }
    R.dome(P([[110, 1040], [130, 1004], [190, 992], [250, 998], [282, 1040]], true, true), '#d8d0cc', 0.2, 0.1, 16, 5);
    // black hole + green channel
    R.flat(P([[388, 690], [404, 690], [424, 800], [440, 900], [446, 960], [432, 960], [416, 900], [398, 800]], true, true), '#4aa860', 0.42, 0);
    soft(x => { x.fillStyle = '#000'; x.fill(circleP(462, 748, 30)); }, 3, 1);
    R.h.save(); R.h.fillStyle = hc(0.0, 0); R.h.fill(circleP(462, 748, 28)); R.h.restore();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.45, shin: 40, wrap: 0.45, ao: 0.5, coat: 0.08 }),                        // 1 grey plastic
        E.mat({ dif: 0.6, metal: 0.75, spec: 1.3, shin: 70, ao: 0.3, tint: [1.15, 0.95, 0.55], emis: 0.1 }), // 2 gold
        E.mat({ dif: 0.95, metal: 0.25, spec: 0.8, shin: 30, wrap: 0.5, ao: 0.3, tint: [1.05, 1.0, 0.85], emis: 0.1 }), // 3 pale gold sphere
        E.mat({ dif: 0.9, spec: 0.5, shin: 40, wrap: 0.5, emis: 0.1 }),                                   // 4 inlays
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.5, ao: 0.3, coat: 0.2, emis: 0.05 })                 // 5 white gloss
      ],
      light: [-0.45, 0.62, 0.64], lc: [0.8, 0.8, 0.78], amb: [0.38, 0.38, 0.4],
      envTop: [1, 0.98, 0.94], envHor: [0.6, 0.6, 0.62], envBot: [0.1, 0.09, 0.08], envK: [0.3, 1.2, 0.15, 0],
      r1: 1.8, r2: 10, k: [0, 0.6, 0.4, 70], shadow: [-8, 10, 0.55, 6]
    });
    // warm glare on the zebra plate
    soft(x => { x.fillStyle = '#fff2c0'; x.fill(ellipseP(540, 200, 34, 40, 0)); x.fillStyle = '#ffe9a0'; x.fill(ellipseP(530, 210, 70, 70, 0)); }, 18, 0.7, 'screen', o);
    E.grain(0.03, 104);
  }
});
