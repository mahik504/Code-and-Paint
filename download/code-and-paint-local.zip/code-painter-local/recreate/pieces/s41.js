'use strict';
// s41 — "Jar in space": a torn, burnt-edged paper collage — starfield, op-art
// zebra corners, a blue creature with a red eye, a tilted glass jar in a
// scalloped yellow cloud, pink glows, grey leaves and white twigs.
REC.register('s41', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024, S = E.S, o = E.out;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const fill = (path, c) => { o.fillStyle = c; o.fill(path); };
    const stroke = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const clipped = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const blurred = (px, fn) => { o.save(); o.filter = `blur(${px * S}px)`; fn(); o.restore(); };
    // ragged rectangle outline (torn paper): inset per side, jitter amplitude, step
    const tornRect = (l, t, r, b, amp, step, seed) => {
      const rr = rng(seed), pts = [];
      const side = (x0, y0, x1, y1) => { const L = Math.hypot(x1 - x0, y1 - y0), n = Math.max(2, Math.round(L / step)); for (let i = 0; i < n; i++) { const u = i / n; pts.push([x0 + (x1 - x0) * u + (rr() - 0.5) * amp, y0 + (y1 - y0) * u + (rr() - 0.5) * amp]); } };
      side(l, t, r, t); side(r, t, r, b); side(r, b, l, b); side(l, b, l, t);
      return P(pts, true, false);
    };

    // ── paper frame: navy ground, cream torn paper, burnt brown edge, grey haze
    fill(rrect(0, 0, W, H, 0), '#252444');
    fill(tornRect(2, 20, 726, 996, 10, 7, 1), '#f2dcc2');
    fill(tornRect(12, 33, 718, 984, 9, 6, 2), '#773406');
    blurred(4, () => fill(tornRect(22, 48, 712, 966, 6, 8, 3), '#8a8888'));

    // starfield
    const stars = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 c = floor(p/3.); float h = hash(c), h2 = hash(c+17.3);
      vec2 q = fract(p/3.) - vec2(hash(c+3.1), hash(c+5.7));
      float d = length(q*3.);
      float s = step(.86, h) * smoothstep(.9, .3, d) * (.45 + .55*h2);
      vec2 c2 = floor(p/9.); float g = hash(c2+41.);
      vec2 q2 = p/9. - c2 - vec2(hash(c2+7.), hash(c2+9.))*.8 - .1;
      s += step(.9, g) * smoothstep(.22, .12, length(q2));
      return vec3(.03) + vec3(min(s,1.)) * .92; }`));
    const field = rrect(52, 78, 632, 870, 18);
    blurred(6, () => fill(field, '#0b0b0b'));
    fill(rrect(58, 84, 620, 858, 14), stars);
    // bottom-left: soft cream / grey instead of a burnt edge
    blurred(5, () => { fill(rrect(-10, 948, 470, 46, 8), '#efe4d6'); fill(rrect(30, 928, 430, 24, 8), '#8a8888'); fill(rrect(-10, 840, 30, 130, 6), '#f4ead8'); });
    // grey haze patches on the frame
    blurred(10, () => { fill(rrect(290, 50, 160, 28, 10), '#7e7e7e'); fill(rrect(662, 300, 44, 100, 20), '#454545'); fill(rrect(652, 420, 54, 280, 20), '#7e7e7e'); fill(rrect(40, 930, 420, 34, 10), '#8a8888'); });

    // ── pink-red glow puffs behind the cloud
    const puff = (x, y, r) => {
      const g = o.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, 'rgba(250,220,220,0.95)'); g.addColorStop(0.35, 'rgba(236,160,165,0.8)'); g.addColorStop(0.7, 'rgba(120,20,40,0.55)'); g.addColorStop(1, 'rgba(60,0,10,0)');
      fill(circleP(x, y, r), g);
      const pr = rng(x);
      o.save(); o.globalAlpha = 0.35;
      for (let i = 0; i < 40; i++) { const a = pr() * 6.283, r0 = r * 0.3, r1 = r * (0.7 + pr() * 0.35); stroke(P([[x + Math.cos(a) * r0, y + Math.sin(a) * r0], [x + Math.cos(a) * r1, y + Math.sin(a) * r1]], false), '#f4c8c8', 1.5); }
      o.restore();
    };
    puff(130, 440, 80); puff(225, 590, 90); puff(362, 258, 55);

    // ── top-left zebra (flowing stripes converging to the right)
    const zebraTL = P([[0, 30], [250, 30], [236, 70], [214, 120], [200, 180], [202, 240], [210, 300], [204, 345], [172, 370], [110, 384], [0, 386]], true, false);
    // black stripes traced with a ruler (centrelines through measured stripe centres)
    clipped(zebraTL, () => {
      fill(rrect(0, 0, 260, 400, 0), '#f6f6f6');
      // [centreline (left -> right), root width, tip width]
      const zs = [
        [[[30, 20], [45, 36], [60, 48]], 18, 12], [[[62, 20], [80, 36], [100, 60], [125, 102], [145, 131], [165, 160], [182, 188], [196, 212]], 20, 5],
        [[[100, 18], [118, 36], [136, 60], [148, 82], [165, 118], [184, 160], [196, 208]], 19, 5], [[[140, 18], [152, 36], [168, 62], [182, 100], [192, 150], [197, 206]], 17, 4],
        [[[178, 22], [188, 52], [195, 100], [198, 160], [198, 206]], 12, 3], [[[206, 28], [205, 70], [202, 120], [199, 200]], 9, 3], [[[228, 28], [219, 70], [208, 120], [200, 195]], 8, 3],
        [[[246, 30], [234, 60], [220, 100], [206, 150]], 7, 3],
        [[[0, 30], [25, 46], [45, 70], [65, 83], [85, 101], [105, 124], [125, 144], [145, 162], [165, 184], [182, 200], [196, 214]], 20, 5],
        [[[90, 140], [105, 156], [125, 178], [145, 193], [165, 212], [185, 222], [200, 226]], 16, 8],
        [[[-10, 40], [5, 51], [25, 86], [45, 107], [65, 125], [85, 160], [105, 192], [125, 215], [145, 230], [165, 250], [185, 256], [205, 262]], 20, 11],
        [[[-10, 94], [5, 106], [25, 132], [45, 157], [65, 188], [85, 206], [105, 229], [125, 251], [145, 278], [165, 300], [185, 296], [205, 290]], 20, 12],
        [[[-10, 150], [5, 163], [25, 179], [45, 206], [65, 238], [85, 257], [105, 281], [125, 303], [145, 330], [165, 336], [185, 326], [205, 318]], 20, 12],
        [[[-10, 196], [5, 210], [25, 230], [45, 255], [65, 290], [85, 324], [105, 348], [125, 368], [145, 376], [175, 368], [200, 350]], 20, 14],
        [[[-10, 258], [5, 272], [25, 293], [45, 321], [65, 362], [85, 385]], 20, 18], [[[-10, 322], [5, 337], [25, 363], [45, 388]], 20, 20]];
      for (const [pts, w0, w1] of zs) fill(P(lock(pts, w0, w1, 1.4), true, true), '#0a0a0a');
    });
    // blue crescent under it
    const cres = P([[197, 208], [226, 236], [244, 272], [246, 306], [236, 336], [214, 360], [176, 378], [130, 390], [88, 396], [100, 384], [160, 368], [194, 348], [208, 316], [210, 280], [203, 240]]);
    blurred(8, () => fill(ellipseP(150, 392, 90, 16, -0.12), 'rgba(40,230,240,0.8)'));
    const cg = o.createLinearGradient(240, 240, 150, 400); cg.addColorStop(0, '#3a58ea'); cg.addColorStop(0.7, '#3050e0'); cg.addColorStop(1, '#30d8f0');
    fill(cres, cg);

    // ── blue creature (top right) with red eye
    const blue = P([[455, 48], [566, 50], [640, 49], [710, 50], [712, 258], [690, 262], [650, 272], [632, 290], [620, 330], [602, 352], [575, 340], [520, 300], [470, 262], [445, 240],
      [450, 215], [465, 192], [482, 168], [478, 140], [462, 105], [468, 80]], true, false);
    fill(blue, '#3552eb');
    stroke(P([[470, 82], [462, 106], [478, 140], [482, 168], [465, 192], [450, 216], [446, 244]], false), '#48e0f0', 5);
    fill(ellipseP(526, 82, 40, 27, 0.05), '#fd4b01');
    clipped(ellipseP(526, 82, 40, 27, 0.05), () => fill(ellipseP(494, 84, 18, 30), '#f8a9a3'));
    fill(circleP(542, 94, 7), '#050505');
    fill(circleP(667, 99, 11), '#fbfbfb'); fill(circleP(507, 180, 6), '#f8f8f8');
    stroke(P([[508, 146], [515, 150], [522, 148]], false), '#f8f8f8', 4);
    // white tooth-branch on the creature
    const wb = (pts, wd) => stroke(P(pts, false), '#f6f6f6', wd);
    wb([[575, 224], [610, 219], [650, 216], [695, 214]], 13); wb([[628, 218], [632, 195]], 11); wb([[603, 222], [600, 246]], 11); wb([[656, 216], [658, 240]], 10); wb([[692, 214], [694, 234]], 9);

    // ── yellow scalloped cloud with its dark rainbow-edged window
    const cloudBase = [[330, 322], [450, 314], [540, 294], [566, 320], [566, 420], [560, 520], [540, 570], [470, 578], [360, 578], [252, 578], [200, 565],
      [182, 530], [180, 450], [196, 420], [240, 392], [290, 350]];
    const cloud = P(cloudBase, true, false);
    fill(cloud, '#fff40c');
    for (let i = 0; i < cloudBase.length; i++) {
      const [x0, y0] = cloudBase[i], [x1, y1] = cloudBase[(i + 1) % cloudBase.length], n = Math.max(1, Math.round(Math.hypot(x1 - x0, y1 - y0) / 42));
      for (let k = 0; k < n; k++) fill(circleP(x0 + (x1 - x0) * k / n, y0 + (y1 - y0) * k / n, 25), '#fff40c');
    }
    const winP = P([[204, 446], [214, 410], [252, 394], [505, 302], [534, 306], [548, 332], [552, 480], [546, 560], [522, 586], [262, 592], [216, 582], [205, 560]], true, true);
    for (const [c, wd] of [['#ff9a20', 18], ['#ff5ec0', 12], ['#28e4f0', 7], ['#3040f0', 3]]) stroke(winP, c, wd);
    fill(winP, stars);

    // jar contents
    clipped(winP, () => {
      fill(P(ragged([[300, 372], [352, 356], [390, 372], [405, 420], [398, 470], [360, 488], [312, 478], [296, 430]], 0, 8, 7, 9, 4), true, false), '#959aa0');
      fill(ellipseP(424, 405, 44, 60, 0.35), '#f4f4f4');
      fill(P(ragged([[366, 440], [440, 428], [446, 470], [420, 494], [372, 488]], 0, 2, 5, 8, 9), true, false), '#060606');
      o.save(); o.globalAlpha = 0.8; stroke(P([[392, 386], [400, 376], [410, 384], [406, 396], [414, 404]], false), '#9aa0a8', 2.5); o.restore();
      for (const [a, b, wd] of [[[455, 520], [505, 390]], [[440, 500], [480, 410]], [[470, 470], [520, 440]]].map(([a, b], i) => [a, b, 12 - i * 2]))
        stroke(P([a, b], false), '#3050e0', wd);
      fill(circleP(498, 412, 13), '#f4f4f4');
    });

    // ── glass jar (tilted), silver base at lower left
    const jarBody = P([[282, 520], [300, 440], [338, 360], [386, 290], [420, 250], [470, 222], [530, 215], [556, 222], [585, 262], [592, 318], [580, 400], [556, 470],
      [520, 540], [478, 600], [440, 612], [380, 596]]);
    o.save(); o.globalAlpha = 0.18; fill(jarBody, '#e8eef4'); o.restore();
    clipped(jarBody, () => { o.save(); o.globalAlpha = 0.9; fill(P([[380, 230], [600, 200], [600, 300], [540, 290], [470, 290], [400, 300]]), '#f2f2f2'); o.restore(); });
    stroke(jarBody, '#f0f0f0', 3); stroke(jarBody, '#303030', 1);
    stroke(P([[392, 318], [520, 280]], false), '#101010', 4);
    const base = ellipseP(346, 546, 78, 42, 0.6);
    const sg = o.createLinearGradient(290, 500, 400, 590); sg.addColorStop(0, '#fafafa'); sg.addColorStop(0.5, '#c8c8c8'); sg.addColorStop(1, '#f0f0f0');
    fill(base, sg); stroke(base, '#202020', 2); stroke(ellipseP(346, 546, 66, 33, 0.6), '#909090', 2);
    // cap + string
    fill(P([[528, 206], [548, 196], [560, 216], [540, 228]]), '#f0e0b0'); stroke(P([[528, 206], [548, 196], [560, 216], [540, 228]]), '#403020', 1.5);
    stroke(P([[598, 0], [548, 200]], false), '#e8e8e8', 2.5); stroke(P([[598, 0], [548, 200]], false), '#303030', 0.8);
    stroke(P([[548, 220], [490, 420], [470, 520], [480, 560]], false), '#505050', 1.5);
    // bursts of white spikes
    const burst = (x, y, a0, a1, n, r) => { const br = rng(x * 7); for (let i = 0; i < n; i++) { const a = a0 + (a1 - a0) * br(), L = r * (0.4 + br() * 0.6); stroke(P([[x, y], [x + Math.cos(a) * L, y + Math.sin(a) * L]], false), '#f4f4f4', 1.5); } };
    burst(310, 452, Math.PI * 0.9, Math.PI * 1.25, 26, 60); burst(436, 574, -0.4, 0.7, 20, 40);
    // pink splat
    fill(P([[392, 596], [420, 574], [456, 568], [486, 580], [492, 604], [470, 620], [462, 640], [446, 628], [430, 642], [416, 626], [398, 636], [396, 614]]), '#fe2e83');
    // grey banana with the white critter
    const ban1 = P([[472, 604], [470, 585], [500, 560], [540, 540], [590, 515], [628, 502], [626, 530], [610, 565], [580, 592], [540, 606], [500, 612]]);
    fill(ban1, '#6a6d70'); for (let i = 1; i < 5; i++) stroke(P([[480 + i * 4, 606 - i * 3], [540, 596 - i * 4], [600, 556 - i * 5], [622, 516]], false), '#8a8d90', 1.5);
    fill(P(ragged([[482, 546], [510, 520], [548, 510], [560, 528], [540, 552], [500, 560]], 0, 6, 5, 5, 3), true, false), '#f0f0f0');

    // ── pink smiley ball
    fill(circleP(254, 331, 34), '#fdbfcf'); fill(circleP(245, 322, 5), '#101010'); fill(circleP(268, 337, 4), '#101010');

    // ── bottom-right zebra + blue half-dome
    const zebraBR = P([[466, 978], [468, 860], [490, 838], [540, 831], [580, 818], [620, 780], [645, 755], [662, 720], [662, 680], [714, 686], [714, 978]], true, false);
    const zb = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(440., 740.);           // gently spiralling rays, fitted to ruler-measured stripe centres
      float th = atan(d.y, d.x);
      float s = -cos(41.*th - 0.02*length(d) + 0.815);
      return vec3(smoothstep(-.15, .15, s))*.95 + .02; }`));
    fill(zebraBR, zb);
    stroke(P([[484, 836], [494, 790], [520, 740], [560, 704], [620, 680], [712, 678]], false), '#8a4a3a', 3);
    const dome = P([[490, 838], [498, 815], [508, 780], [530, 742], [560, 712], [600, 692], [662, 680], [662, 720], [645, 755], [620, 780], [580, 818], [540, 831]]);
    fill(dome, '#3858ea'); stroke(P([[490, 838], [498, 815], [508, 780], [530, 742], [560, 712], [600, 692], [662, 680]], false), '#48e0f0', 3);
    fill(circleP(590, 714, 9), '#fbfbfb');
    fill(circleP(480, 838, 14), '#fff4f6'); stroke(circleP(480, 838, 14), '#e03060', 3);
    const ban2 = P([[380, 880], [420, 870], [470, 872], [505, 862], [516, 880], [505, 910], [470, 928], [430, 926], [396, 910]]);
    fill(ban2, '#6a6d70'); for (let i = 1; i < 5; i++) stroke(P([[392, 882 + i * 7], [450, 880 + i * 8], [508, 870 + i * 7]], false), '#8e9194', 1.5);
    for (const [x, y, r] of [[425, 866, 10], [446, 860, 12], [468, 856, 10], [488, 858, 9]]) fill(circleP(x, y, r), '#7a7d80');

    // ── leaves: [x, y, len, width, angle]
    const leaf = (x, y, L, w, a) => {
      const c = Math.cos(a), s = Math.sin(a), T = (u, v) => [x + u * c - v * s, y + u * s + v * c];
      const pts = []; for (let i = 0; i <= 12; i++) { const u = -L / 2 + L * i / 12; pts.push(T(u, -w / 2 * Math.sin(Math.PI * i / 12))); }
      for (let i = 11; i >= 1; i--) { const u = -L / 2 + L * i / 12; pts.push(T(u, w / 2 * Math.sin(Math.PI * i / 12))); }
      const p = P(pts, true, false); fill(p, '#cfd0d2'); stroke(p, '#5a5a5a', 1);
      stroke(P([T(-L * 0.4, 0), T(L * 0.4, -w * 0.08)], false), '#f8f8f8', w * 0.22);
    };
    for (const [x, y, L, w, a] of [[305, 182, 62, 22, -0.2], [170, 655, 62, 24, 0.22], [190, 702, 64, 22, -0.85], [233, 758, 62, 24, 0.62], [190, 810, 66, 24, -0.2],
      [282, 839, 60, 22, -0.62], [298, 710, 62, 22, -0.62], [344, 630, 58, 20, -0.95], [378, 678, 56, 20, 0.35], [478, 650, 58, 20, -0.5], [412, 830, 60, 22, -0.25],
      [660, 537, 56, 20, -1.2], [657, 620, 60, 20, -1.45], [560, 60, 0, 0, 0]])
      if (L) leaf(x, y, L, w, a);

    // ── white twigs and crosses
    wb([[352, 830], [372, 800], [398, 776], [430, 754], [462, 740], [492, 733]], 9);
    for (const [p0, p1] of [[[372, 800], [356, 786]], [[398, 776], [388, 756]], [[430, 754], [436, 732]], [[462, 740], [470, 758]], [[410, 766], [424, 784]], [[480, 736], [488, 722]]]) wb([p0, p1], 7);
    wb([[618, 430], [645, 418], [670, 408], [692, 398]], 8); wb([[640, 420], [636, 404]], 6); wb([[664, 410], [668, 426]], 6); wb([[684, 402], [680, 388]], 6);
    wb([[344, 212], [356, 206], [366, 214]], 6); wb([[356, 206], [354, 196]], 5);
    for (const [x, y] of [[242, 98], [270, 124]]) { fill(rrect(x - 17, y - 7, 34, 14, 3), '#fafafa'); fill(rrect(x - 7, y - 17, 14, 34, 3), '#fafafa'); }

    // ── big white dots
    for (const [x, y, r] of [[97, 660, 18], [81, 905, 12], [108, 761, 8], [92, 710, 5], [88, 810, 5], [132, 741, 5], [176, 768, 5], [184, 866, 6], [233, 891, 5],
      [205, 938, 5], [266, 693, 5], [343, 744, 6], [335, 857, 5], [518, 698, 6], [545, 662, 5], [458, 788, 5], [403, 940, 7], [416, 672, 4], [605, 470, 16],
      [603, 592, 6], [555, 607, 6], [653, 480, 5], [598, 405, 6], [360, 146, 7], [388, 80, 5], [125, 587, 8], [75, 410, 5], [62, 472, 5], [104, 505, 5], [233, 506, 7],
      [300, 556, 6], [262, 544, 5], [318, 268, 6], [424, 150, 5], [430, 96, 4], [640, 330, 5], [570, 660, 4], [640, 760, 4]])
      fill(circleP(x, y, r), '#fbfbfb');

    E.grain(0.04, 41);
  }
});
