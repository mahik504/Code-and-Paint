'use strict';
// g084 — "Spiral dusk encounter": a wide-eyed black bearded man reaches over a white ribbed accordion-beast
// toward a TV-headed orange woman, under a pink-and-cyan sunset with spiral discs and pale tree pipes.
REC.register('g084', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, r1, stops) => { const g = a.createRadialGradient(x, y, r0, x, y, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const flat = (path, c) => R.flat(path, c, 0, 0);
    const poly = pts => P(pts, true, false);
    const BLK = '#08070a';

    // spiral fields (centre, ring period, squash)
    const spiral = (cx, cy, per, sy) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = (p - vec2(${cx.toFixed(1)}, ${cy.toFixed(1)})) * vec2(1., ${sy.toFixed(2)});
      float r = length(d), an = atan(d.y, d.x);
      float ph = r / ${per.toFixed(1)} + an / 6.2832 + 0.12 * sin(an * 9. + r * 0.08);
      float v = sin(6.2832 * ph);
      return mix(vec3(.04), vec3(.93, .93, .92), smoothstep(-.25, .15, v)); }`));

    // ── sky, sunset band, slate ground ──
    flat(rrect(-10, -10, 746, 1044, 0), lin(0, 0, 0, 640, [[0, '#748e9a'], [0.3, '#6a8998'], [0.42, '#5e6f86'], [0.45, '#9a598b'], [0.5, '#cb87c9'], [0.53, '#fb72a6'], [0.58, '#fc7aa8'], [0.61, '#f6b0d8'], [0.63, '#c4ecfb'], [0.69, '#c0f0fb'], [0.71, '#5e7888'], [1, '#5a7482']]));
    // dark cloud banks
    const cr = rng(84);
    for (const [x0, x1, y] of [[230, 726, 236], [240, 420, 262], [560, 726, 205], [420, 600, 218], [120, 360, 456]]) {
      for (let x = x0; x < x1; x += 26 + cr() * 18) a.fillStyle = BLK, a.fill(ellipseP(x, y + (cr() - 0.5) * 10, 24 + cr() * 24, 10 + cr() * 9, 0));
    }
    for (const [x, y, rx, ry] of [[160, 498, 40, 9], [260, 494, 50, 12], [330, 520, 40, 10], [150, 584, 50, 10], [250, 570, 60, 12], [120, 540, 22, 6], [300, 600, 40, 9]]) { a.fillStyle = '#0c1014'; a.fill(ellipseP(x, y, rx, ry, 0)); }
    keep();

    // ── tree pipes ──
    R.pipe(P([[300, 60], [350, 140], [400, 200], [420, 230]], false, true), 10, BLK, 0.1, 0.03, 0);
    R.pipe(P([[470, 160], [508, 196], [530, 250], [542, 350], [552, 452]], false, true), 26, '#6c5c5a', 0.12, 0.12, 2);
    R.pipe(P([[440, -10], [438, 80], [424, 170], [404, 250], [404, 330], [430, 396], [470, 432], [520, 444]], false, true), 24, '#b4c6d0', 0.14, 0.14, 2);
    R.pipe(P([[436, 150], [470, 168], [500, 196]], false, true), 22, '#aec2ce', 0.14, 0.12, 2);
    // white cloud puff
    R.dome(P([[282, 30], [300, 0], [420, 0], [436, 40], [444, 82], [420, 100], [380, 108], [340, 100], [300, 80], [280, 58]], true, true), '#e8e8e6', 0.1, 0.1, 22, 1);
    // hook pipe right
    R.pipe(P([[676, 260], [684, 226], [710, 216], [736, 220]], false, true), 16, '#d8dcdc', 0.14, 0.1, 2);
    keep();

    // ── big spiral disc (top right) ──
    const disc = ellipseP(592, 88, 136, 108, -0.08);
    R.dome(disc, spiral(600, 66, 13, 1.2), 0.12, 0.12, 30, 3);
    keep();

    R.pipe(P([[-10, 20], [14, 10], [30, -10]], false, true), 16, '#e8e8e8', 0.1, 0.08, 2);
    // ── black bearded man ──
    const head = P([[-10, 30], [30, 8], [90, -10], [210, -10], [244, 22], [282, 58], [252, 72], [258, 110], [244, 140], [254, 160], [256, 200], [240, 216], [228, 240], [244, 262], [232, 272], [222, 300], [224, 338], [216, 372], [214, 402], [198, 386], [180, 404], [160, 392], [140, 412], [118, 400], [96, 384], [60, 400], [-10, 420]], true, false);
    flat(head, BLK);
    for (let i = 0; i < 9; i++) { const x = 20 + i * 26; R.flat(poly([[x, 0], [x + 30, -26], [x + 18, 6]]), BLK, 0, 0); }
    R.flat(poly([[230, 30], [300, 40], [270, 58]]), BLK, 0, 0);
    // body: dark jacket and pale shirt
    flat(poly([[-10, 360], [100, 380], [110, 640], [96, 770], [-10, 780]]), '#0c0b0e');
    flat(poly([[0, 360], [40, 380], [76, 420], [64, 470], [40, 430], [0, 420]]), '#8fa6b2');
    flat(poly([[0, 300], [20, 300], [30, 380], [0, 400]]), '#7c94a2');
    flat(poly([[96, 400], [110, 470], [104, 520], [90, 470]]), '#5a7080');
    // eyes, nose, mouth, ear
    R.dome(circleP(172, 173, 23), '#f4f2ee', 0.1, 0.06, 10, 1); R.dome(circleP(185, 182, 10), BLK, 0.14, 0.02, 4, 1);
    R.dome(circleP(236, 180, 16), '#f4f2ee', 0.1, 0.06, 8, 1); R.dome(circleP(230, 186, 7.5), BLK, 0.14, 0.02, 3, 1);
    R.dome(P([[196, 218], [212, 196], [238, 208], [246, 250], [232, 260], [204, 248], [192, 232]], true, true), '#f0844a', 0.1, 0.06, 10, 1);
    R.dome(ellipseP(182, 290, 30, 9, 0), '#f0884e', 0.1, 0.03, 5, 1);
    R.flat(P([[30, 186], [44, 168], [64, 166], [72, 190], [62, 180], [46, 178], [36, 192]], true, true), '#f0904e', 0.08, 1);
    // beard tufts
    for (let i = 0; i < 12; i++) { const x = 100 + i * 10; R.flat(poly([[x, 390], [x + 4, 410 + (i % 3) * 8], [x + 8, 392]]), BLK, 0, 0); }
    // sleeve cuff + orange hand
    R.dome(poly([[20, 642], [74, 646], [70, 754], [16, 756]]), '#a8bcc8', 0.08, 0.06, 10, 2);
    const hand = P([[64, 650], [110, 640], [160, 630], [190, 622], [228, 628], [270, 636], [290, 646], [272, 652], [240, 650], [268, 670], [282, 708], [270, 712], [244, 690], [210, 682], [180, 692], [140, 704], [100, 708], [70, 700]], true, true);
    R.dome(hand, '#f0743a', 0.12, 0.06, 14, 1);
    for (const p of [[[190, 652], [240, 662], [270, 690]], [[180, 640], [230, 646], [270, 660]]]) R.groove(P(p, false, true), 4, '#a8441c', 0.16, 0.04, 1, 0.7);
    keep();

    // ── TV-headed woman ──
    const tv = poly([[596, 250], [700, 270], [736, 300], [736, 640], [620, 640], [566, 600], [562, 420]]);
    R.dome(tv, '#2a1c1c', 0.12, 0.08, 12, 4);
    const scr = poly([[604, 278], [690, 300], [700, 330], [690, 620], [610, 618], [584, 590], [580, 420]]);
    R.flat(scr, '#f07a3c', 0.18, 1);
    clipA(scr, () => {
      a.fillStyle = '#f8b45c'; a.fill(P([[640, 330], [690, 340], [690, 470], [660, 500], [620, 470], [610, 400]], true, true));
      a.fillStyle = '#0a0808'; a.fill(poly([[650, 370], [690, 380], [690, 600], [640, 600], [630, 520], [650, 480]]));
      a.fillStyle = '#e8702e'; a.fill(poly([[656, 380], [672, 384], [672, 470], [656, 470]]));
    });
    const face = P([[590, 400], [620, 420], [632, 470], [628, 520], [630, 560], [610, 600], [588, 612], [576, 586], [566, 560], [570, 540], [556, 530], [546, 518], [560, 500], [570, 470], [578, 430]], true, true);
    R.dome(face, '#f08a48', 0.2, 0.05, 10, 1);
    R.groove(P([[580, 430], [600, 424], [614, 440]], false, true), 3, '#2a1410', 0.24, 0.03, 1, 1);
    R.dome(ellipseP(594, 466, 7, 10, 0), BLK, 0.24, 0.02, 3, 1);
    R.groove(P([[560, 552], [574, 556]], false, false), 3, '#6a2a1a', 0.24, 0.03, 1, 1);
    // orange shoulder
    R.dome(P([[600, 640], [660, 600], [736, 580], [736, 700], [680, 702], [620, 690]], true, true), '#e8662e', 0.12, 0.08, 18, 1);
    keep();

    // ── maroon ground + concentric disc (bottom right) ──
    R.flat(poly([[380, 780], [600, 700], [736, 690], [736, 1034], [420, 1034]]), '#7a3e46', 0.05, 1);
    R.dome(circleP(604, 890, 124), '#0c0a0c', 0.06, 0.04, 8, 1);
    R.dome(circleP(604, 890, 106), rad(600, 884, 10, 106, [[0, '#a8a6a8'], [0.45, '#8a8888'], [0.75, '#4a4848'], [1, '#2a2828']]), 0.1, 0.06, 30, 3);
    R.dome(circleP(604, 890, 52), rad(596, 880, 2, 52, [[0, '#a8a8a8'], [0.8, '#7a7878'], [1, '#3a3838']]), 0.16, 0.08, 20, 3);
    keep();

    // ── accordion beast: black body, teeth, white lobes ──
    const body = P([[-10, 760], [100, 700], [220, 660], [330, 590], [430, 540], [520, 520], [580, 540], [560, 640], [500, 710], [440, 780], [380, 840], [320, 900], [260, 960], [200, 1034], [-10, 1034]], true, true);
    R.flat(body, BLK, 0.05, 0);
    const tr = rng(41);
    for (let i = 0; i < 26; i++) {
      const t = tr(), x = 90 + t * 340 + (tr() - 0.5) * 30, y = 1000 - t * 230 + (tr() - 0.5) * 40, an = (tr() - 0.5) * 1.2;
      R.dome(ellipseP(x, y, 6 + tr() * 4, 16 + tr() * 12, an), '#e8e8e6', 0.08, 0.05, 5, 1);
    }
    const lobes = [[540, 584, 23, 46], [502, 604, 27, 58], [462, 626, 30, 70], [422, 650, 32, 80], [382, 676, 34, 88], [338, 704, 35, 96], [292, 732, 37, 104], [244, 760, 38, 110], [192, 788, 39, 115], [138, 818, 40, 120], [84, 848, 40, 125], [30, 878, 40, 128], [-20, 905, 40, 130]];
    for (const [x, y, w, hl] of lobes) {
      const e = ellipseP(x, y, w, hl, -0.14);
      R.dome(e, lin(x - w, 0, x + w, 0, [[0, '#6a6a6e'], [0.3, '#d0d0d0'], [0.7, '#f2f2f0'], [1, '#e4e4e2']]), 0.12, 0.22, w * 0.95, 1);
    }
    keep();
    // spiral rolls
    for (const [x, y, rx, ry] of [[424, 472, 56, 46], [502, 506, 46, 38]]) {
      R.dome(P([[x - rx, y], [x + rx * 0.8, y + 10], [x + rx * 0.5, y + ry * 1.5], [x - rx * 0.2, y + ry * 1.7], [x - rx * 0.9, y + ry * 1.1]], true, true), '#dcdcda', 0.14, 0.14, 18, 1);
      R.dome(ellipseP(x, y, rx, ry * 0.85, 0), spiral(x, y, 9, 1.15), 0.2, 0.08, 10, 3);
    }
    // knife + small dark hand
    R.dome(poly([[486, 740], [584, 664], [606, 682], [516, 772], [486, 772]]), '#e4e6ea', 0.14, 0.05, 6, 1);
    R.dome(circleP(506, 742, 5), BLK, 0.2, 0.02, 2, 1);
    R.dome(poly([[594, 640], [660, 600], [668, 612], [606, 656]]), '#d8dadc', 0.14, 0.04, 4, 1);
    R.dome(P([[500, 668], [526, 646], [560, 640], [588, 646], [584, 664], [560, 668], [544, 690], [520, 700], [504, 690]], true, true), '#5a4848', 0.16, 0.06, 10, 1);
    keep();
    // bottom spiral disc
    R.dome(ellipseP(314, 1012, 124, 92, 0), spiral(314, 1040, 12, 1.25), 0.1, 0.1, 26, 3);
    // pale tube on the left
    R.pipe(P([[-10, 840], [20, 880], [44, 940], [70, 1000], [86, 1040]], false, true), 22, '#a8b8c4', 0.16, 0.12, 2);
    R.dome(ellipseP(10, 600, 30, 36, 0), '#d8d8d8', 0.1, 0.1, 16, 1);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.45, shin: 30, wrap: 0.35, ao: 0.5, coat: 0.06 }),       // 1 matte clay
        E.mat({ dif: 1, spec: 0.6, shin: 40, wrap: 0.4, ao: 0.4, coat: 0.1 }),         // 2 pipes
        E.mat({ dif: 1, spec: 0.35, shin: 30, wrap: 0.5, ao: 0.5, coat: 0.05 }),        // 3 spiral discs
        E.mat({ dif: 1, spec: 0.5, shin: 40, wrap: 0.3, ao: 0.4, coat: 0.08 })          // 4 tv shell
      ],
      light: [0.45, 0.55, 0.7], lc: [0.6, 0.6, 0.6], amb: [0.5, 0.5, 0.5],
      envTop: [1, 1, 1], envHor: [0.5, 0.55, 0.6], envBot: [0.15, 0.15, 0.18], envK: [0.15, 0.8, 0.3, 0],
      r1: 1.6, r2: 8, k: [0, 0.6, 0.4, 90], shadow: [5, 6, 0.6, 7]
    });
    E.grain(0.04, 84);
  }
});
