'use strict';
// g209 — "Shell platter with zebra crown": a slate-blue clay platter ringed with ribbed shells, a zebra-striped crown
// under white clay clouds, chrome eyes on a pink face, a teal striped ball, a grin, pink discs, milk puddles and pearls.
REC.register('g209', {
  w: 578, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const Q = (f, sm = true, cl = true) => { const q = []; for (let i = 0; i < f.length; i += 2) q.push([f[i], f[i + 1]]); return P(q, cl, sm); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', clipP = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); if (clipP) a.clip(clipP); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const lg = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rg = (x0, y0, r0, x1, y1, r1, stops) => { const g = a.createRadialGradient(x0, y0, r0, x1, y1, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    // union outline of a set of circles, ray-cast from (cx, cy)
    const lumps = (cx, cy, cl) => {
      const pts = [];
      for (let i = 0; i < 120; i++) {
        const t = i / 120 * 6.283, ux = Math.cos(t), uy = Math.sin(t); let best = 4;
        for (const [x, y, r] of cl) { const dx = x - cx, dy = y - cy, ud = ux * dx + uy * dy, d = ud * ud - dx * dx - dy * dy + r * r; if (d > 0) best = Math.max(best, ud + Math.sqrt(d)); }
        pts.push([cx + ux * best, cy + uy * best]);
      }
      return P(pts, true, false);
    };

    // ── 1. background ──
    R.flat(rrect(-10, -10, 600, 1050, 0), lg(0, 0, 0, 1024, [[0, '#1e0a0c'], [0.3, '#0c0708'], [1, '#050409']]), 0, 0);
    R.flat(Q([300, -10, 600, -10, 600, 1040, 300, 1040], false), lg(300, 0, 578, 400, [[0, '#5e5460'], [0.35, '#6c7484'], [0.7, '#5f8ea4'], [1, '#2a86b8']]), 0, 0);
    soft(x => { fe(x, 578, 330, 40, 90, 0, '#1c70b0'); fe(x, 560, 800, 60, 260, 0, '#06081c'); fe(x, 560, 1000, 70, 60, 0, '#3c434d'); }, 20, 1);
    soft(x => { fe(x, 280, 1012, 190, 34, -0.05, '#36a2cc'); fe(x, 165, 985, 60, 30, 0, '#0e3c98'); fe(x, 140, 935, 50, 40, 0.5, '#2e84c0'); fe(x, 70, 840, 16, 60, 0.3, '#245aa0'); }, 16, 1);
    // salmon panel and chrome pole at the top
    R.flat(Q([80, -10, 290, -10, 290, 125, 200, 118, 110, 125, 70, 110], false), lg(80, 0, 290, 120, [[0, '#f6a294'], [1, '#f09888']]), 0.02, 0);
    clipA(Q([80, -10, 290, -10, 290, 125, 70, 110], false), () => { a.strokeStyle = 'rgba(60,20,20,0.6)'; a.lineWidth = 1.5; const r = rng(4); for (let i = 0; i < 14; i++) { const x = 100 + r() * 170, y = 10 + r() * 100; a.beginPath(); a.moveTo(x, y); a.lineTo(x + 4, y + 12); a.stroke(); } });
    R.pipe(Q([300, -10, 300, 150], true, false), 34, '#a0a4b0', 0.1, 0.2, 3);
    R.flat(Q([318, -10, 470, -10, 470, 40, 330, 50], false), '#5c4c56', 0.02, 0);

    // ── 2. ribbed shells around the rim ──
    const shell = (x, y, ang, r) => {
      const p = new Path2D(); p.moveTo(x, y); p.arc(x, y, r, ang - 1.1, ang + 1.1); p.closePath();
      R.dome(p, '#bca6ae', 0.1, 0.1, r * 0.5, 1);
      for (let k = -4; k <= 4; k++) { const t = ang + k * 0.24; R.groove(Q([x + Math.cos(t) * r * 0.25, y + Math.sin(t) * r * 0.25, x + Math.cos(t) * r * 0.95, y + Math.sin(t) * r * 0.95], true, false), 3, '#8a8090', 0.22, 0.05, 1); }
    };
    for (const [x, y, ang, r] of [[120, 160, 3.6, 52], [92, 240, 3.4, 52], [74, 330, 3.25, 54], [62, 420, 3.15, 50], [56, 520, 3.12, 48], [58, 620, 3.08, 48], [66, 720, 3.0, 48], [84, 810, 2.9, 48],
      [190, 110, 4.2, 48], [470, 140, -0.6, 48], [500, 215, -0.4, 50], [525, 300, -0.2, 46], [410, 105, 5.2, 44]]) shell(x, y, ang, r);

    // ── 3. the slate platter ──
    const plate = (k) => { const pts = []; for (let i = 0; i < 72; i++) { const t = i / 72 * 6.283, s = Math.sin(t); const c = Math.cos(t); pts.push([300 + 262 * k * Math.sign(c) * Math.pow(Math.abs(c), 0.85), 525 + 455 * k * s]); } return P(pts, true, true); };
    const outer = plate(1), inner = plate(0.94);
    R.dome(outer, '#aebcc8', 0.08, 0.12, 14, 1);
    R.dome(inner, lg(0, 120, 0, 980, [[0, '#7a8498'], [0.5, '#748aa2'], [1, '#7088a2']]), 0.14, 0.02, 6, 2);
    clipA(inner, () => { a.strokeStyle = 'rgba(210,225,240,0.45)'; a.lineWidth = 0.9; const r = rng(7);
      for (let i = 0; i < 200; i++) { const x = 60 + r() * 480, y = 130 + r() * 840; a.beginPath(); a.moveTo(x, y); for (let k = 1; k < 6; k++) a.lineTo(x + k * 5, y + Math.sin(k * 1.6 + r() * 6) * 3); a.stroke(); } });

    // ── 4. pink face ──
    const pinkP = Q([150, 240, 200, 190, 300, 170, 380, 185, 420, 230, 430, 300, 425, 400, 445, 470, 470, 560, 410, 600, 300, 590, 240, 570, 190, 470, 150, 360]);
    R.flat(pinkP, lg(150, 200, 470, 560, [[0, '#ec8a90'], [0.5, '#f4969c'], [1, '#ee9aa0']]), 0.16, 0);
    soft(x => { fe(x, 420, 420, 60, 100, 0, '#a8b8cc'); }, 10, 0.9, 'source-over', pinkP);

    // ── 5. zebra crown ──
    const zeb = Q([140, 250, 150, 200, 190, 140, 232, 110, 280, 100, 320, 110, 342, 160, 346, 230, 322, 290, 270, 330, 200, 332, 152, 300]);
    const ZB = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float w = sin(p.x * 0.045 + p.y * 0.01) * 9. + sin(p.x * 0.11 + 1.3) * 3.;
      float s = sin(6.2832 * ((p.y + w + 0.25 * (p.x - 240.)) / 17.));
      return mix(vec3(0.97, 0.97, 0.98), vec3(0.03, 0.03, 0.04), smoothstep(-0.12, 0.12, s)); }`);
    R.dome(zeb, '#ffffff', 0.2, 0.14, 26, 4);
    clipA(zeb, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(ZB); a.restore(); });

    // ── 6. white clay clouds ──
    const cloudSet = (cx, cy, cl) => { R.dome(lumps(cx, cy, cl), '#e8eff8', 0.3, 0.12, 12, 1); for (const [x, y, r] of cl) R.dome(circleP(x, y, r * 0.75), null, 0.38, 0.05, r * 0.7, 1); };
    cloudSet(175, 120, [[190, 40, 18], [215, 30, 16], [228, 48, 14], [180, 70, 16], [200, 100, 18], [160, 120, 16], [145, 150, 15], [135, 175, 14], [158, 190, 12], [125, 205, 12], [170, 160, 12], [215, 120, 12]]);
    cloudSet(365, 90, [[345, 40, 16], [368, 30, 16], [380, 60, 18], [360, 100, 20], [395, 110, 16], [400, 140, 15], [370, 130, 14], [330, 80, 12]]);
    cloudSet(270, 290, [[210, 300, 14], [240, 282, 18], [270, 272, 20], [300, 280, 18], [325, 290, 14], [255, 300, 14], [295, 300, 12]]);
    R.dome(ellipseP(244, 94, 13, 9, 0), '#e0202a', 0.4, 0.06, 4, 5);

    // ── 7. chrome eyes, red drips ──
    const chrome = (x, y, r) => { R.dome(circleP(x, y, r), rg(x - r * 0.3, y - r * 0.4, 1, x, y, r, [[0, '#ffffff'], [0.35, '#d8d8de'], [0.7, '#9a9aa4'], [1, '#e8e8ee']]), 0.24, Math.min(0.3, r * 0.006 + 0.06), r * 0.9, 3); };
    chrome(258, 352, 56); chrome(372, 362, 40);
    R.dome(Q([238, 318, 262, 304, 292, 306, 312, 318, 300, 330, 272, 328, 250, 330]), '#e01e24', 0.44, 0.06, 4, 5);
    R.dome(Q([282, 300, 300, 292, 318, 298, 324, 316, 312, 324]), '#e02228', 0.46, 0.05, 4, 5);

    // ── 8. yellow bead chains ──
    const chain = (pts, n, r) => { const path = Q(pts, true, false); const L = []; for (let i = 0; i < pts.length - 2; i += 2) L.push(Math.hypot(pts[i + 2] - pts[i], pts[i + 3] - pts[i + 1]));
      let total = L.reduce((s, v) => s + v, 0); for (let k = 0; k < n; k++) { let d = k / (n - 1) * total, i = 0; while (i < L.length - 1 && d > L[i]) { d -= L[i]; i++; } const t = Math.min(1, d / L[i]);
        R.bead(pts[i * 2] + (pts[i * 2 + 2] - pts[i * 2]) * t, pts[i * 2 + 1] + (pts[i * 2 + 3] - pts[i * 2 + 1]) * t, r, '#f2b032', 0.42, 0.06, 5); } };
    chain([296, 0, 300, 40, 320, 80, 352, 110, 372, 150, 378, 200, 382, 250, 388, 300], 46, 5.5);
    chain([388, 300, 418, 320, 428, 350, 420, 385, 395, 400, 365, 405, 335, 395, 315, 370, 320, 335, 350, 312, 388, 300], 40, 5.5);
    chain([300, 400, 300, 450, 302, 500, 285, 535, 255, 540, 228, 525, 215, 480, 222, 430, 248, 405, 280, 398, 300, 400], 46, 5.5);

    // ── 9. spine, Y-stick ──
    R.pipe(Q([258, 410, 258, 470, 258, 540], true, false), 36, '#e8eaea', 0.3, 0.14, 1);
    for (let y = 418; y < 540; y += 13) R.groove(Q([242, y, 274, y], true, false), 2.5, '#a8acb0', 0.42, 0.05, 1);
    R.pipe(Q([192, 342, 130, 462], true, false), 15, '#eceee8', 0.3, 0.12, 1);
    R.pipe(Q([78, 462, 130, 472, 190, 626], true, false), 15, '#eceee8', 0.3, 0.12, 1);
    R.pipe(Q([190, 612, 240, 596], true, false), 13, '#eceee8', 0.3, 0.1, 1);
    R.pipe(Q([230, 520, 232, 545], true, false), 6, '#101014', 0.3, 0.04, 2);

    // ── 10. striped ball + grin ──
    const ballP = circleP(390, 472, 60);
    R.dome(ballP, '#ffffff', 0.26, 0.3, 50, 3);
    const BS = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float y = (p.y - 472.) / 60.; float b = fract((y + 1.) * 2.6);
      vec3 c = b < 0.35 ? vec3(0.04, 0.05, 0.06) : (b < 0.7 ? vec3(0.22, 0.55, 0.62) : vec3(0.05, 0.06, 0.08));
      if (abs(y + 0.35) < 0.07 || abs(y - 0.42) < 0.06) c = vec3(0.9, 0.92, 0.94);
      return c; }`);
    clipA(ballP, () => img(BS));
    soft(x => { fe(x, 372, 440, 18, 12, -0.3, '#ffffff'); }, 3, 0.85);
    const grin = Q([340, 540, 380, 532, 430, 530, 462, 536, 455, 566, 425, 588, 390, 592, 360, 582, 345, 560]);
    R.dome(grin, '#e8302e', 0.24, 0.06, 6, 5);
    R.flat(Q([356, 548, 390, 542, 440, 540, 448, 556, 428, 572, 392, 578, 364, 568]), '#c00c10', 0.28, 0);
    for (let i = 0; i < 9; i++) { const t = i / 8; R.dome(rrect(352 + t * 92 - 5, 538 - Math.sin(t * 3.14) * 3, 10, 12, 3), '#f2f2ee', 0.32, 0.04, 2, 5); R.dome(rrect(362 + t * 74 - 4, 572 + Math.sin(t * 3.14) * 6, 9, 10, 3), '#f2f2ee', 0.32, 0.04, 2, 5); }

    // ── 11. milk puddles (with brown halos) ──
    const pud1 = Q([200, 590, 240, 576, 262, 560, 300, 560, 316, 590, 318, 640, 300, 670, 330, 700, 350, 720, 330, 740, 300, 735, 300, 770, 280, 800, 252, 800, 245, 760, 252, 720, 232, 700, 238, 660, 218, 640, 210, 610]);
    const pud2 = Q([380, 700, 400, 670, 440, 650, 470, 640, 500, 630, 520, 660, 500, 690, 470, 700, 440, 720, 420, 750, 395, 755, 375, 730]);
    const pud3 = Q([395, 790, 420, 770, 460, 768, 480, 790, 470, 830, 450, 870, 440, 910, 420, 940, 404, 930, 410, 880, 400, 840]);
    const pud4 = Q([318, 810, 340, 795, 355, 810, 352, 840, 330, 850, 316, 835]);
    for (const p of [pud1, pud2, pud3, pud4]) soft(x => { x.fillStyle = '#5a4840'; x.fill(p); x.lineWidth = 9; x.strokeStyle = '#5a4840'; x.stroke(p); }, 2, 0.85);
    for (const p of [pud1, pud2, pud3, pud4]) R.dome(p, '#bccad6', 0.18, 0.06, 7, 1);

    // ── 12. pink discs ──
    for (const [x, y, r] of [[100, 560, 27], [130, 640, 18], [190, 680, 27], [175, 725, 18], [235, 725, 27], [115, 765, 22], [158, 782, 16], [200, 780, 23], [162, 812, 11], [185, 835, 15], [222, 826, 21], [152, 867, 28]]) {
      soft(x2 => { x2.fillStyle = '#3a3a48'; x2.fill(circleP(x + 4, y + 5, r)); }, 3, 0.5);
      R.dome(circleP(x, y, r), '#e2a090', 0.22, 0.05, 4, 1);
    }
    R.flat(circleP(130, 640, 3), '#3a2020', 0.27, 0);

    // ── 13. pearls / chrome balls ──
    for (const [x, y, r] of [[515, 520, 18], [512, 568, 20], [515, 672, 20], [482, 752, 30], [386, 846, 30], [510, 805, 10], [420, 935, 8], [176, 405, 8], [210, 440, 4], [250, 645, 4], [318, 892, 18], [530, 380, 8]]) chrome(x, y, r);
    R.dome(circleP(258, 930, 56), rg(240, 905, 4, 258, 930, 58, [[0, '#f4f8fa'], [0.6, '#d4e0e8'], [1, '#a8b8c4']]), 0.26, 0.3, 46, 1);

    // ── 14. white goo tubes (right) ──
    const tube1 = Q([350, 225, 380, 212, 420, 225, 455, 250, 485, 290, 505, 340, 520, 385, 545, 430, 558, 500, 563, 580, 558, 650], true, false);
    R.pipe(tube1, 40, '#c4d0da', 0.26, 0.2, 1);
    R.bead(548, 410, 14, '#d0dce4', 0.3, 0.12, 1);
    const tube2 = Q([360, 1040, 380, 990, 430, 950, 470, 920, 500, 880, 530, 850, 560, 830, 600, 800], true, false);
    R.pipe(tube2, 62, '#c4d2dc', 0.26, 0.22, 1);
    clipA(new Path2D('M0 0H600V1100H0Z'), () => { a.strokeStyle = 'rgba(120,140,160,0.5)'; a.lineWidth = 0.8; for (let i = 0; i < 18; i++) { const t = i / 18; a.beginPath(); a.moveTo(390 + t * 180, 990 - t * 170); a.lineTo(410 + t * 180, 975 - t * 170); a.stroke(); } });

    // ── 15. orange fish ──
    R.dome(Q([340, 646, 352, 630, 372, 622, 384, 610, 392, 622, 410, 622, 424, 608, 436, 602, 432, 620, 438, 640, 426, 638, 410, 630, 396, 640, 380, 650, 362, 654]), '#f6981a', 0.26, 0.04, 4, 5);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.45, shin: 30, wrap: 0.5, ao: 0.4, coat: 0.08, rim: 0.2 }),                 // 1 clay
        E.mat({ dif: 1, spec: 0.2, shin: 20, wrap: 0.5, ao: 0.4, grain: 0.05 }),                           // 2 slate plate
        E.mat({ dif: 0.8, metal: 0.3, spec: 1.3, shin: 70, wrap: 0.4, ao: 0.2, coat: 0.25, emis: 0.15 }), // 3 chrome / glossy ball
        E.mat({ dif: 0.6, spec: 0.5, shin: 40, wrap: 0.6, emis: 0.42, coat: 0.1 }),                        // 4 zebra
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.3, coat: 0.12, ao: 0.2 }),                            // 5 beads / gloss
        E.mat({}), E.mat({})
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.72, 0.72, 0.76], amb: [0.42, 0.42, 0.46],
      envTop: [1.05, 1.02, 1.0], envHor: [0.55, 0.6, 0.66], envBot: [0.15, 0.18, 0.24], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.1, 0.12, 0.16], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 70], shadow: [-5, 6, 0.45, 6]
    });
  }
});
