'use strict';
// g043 — "Chrome grub with skull": a chrome caterpillar with a striped chrome helmet, a cream skull face with
// glossy blue eyes and rainbow-chrome antennae, its segmented body coiling round a black pit of copper
// beads, before a blurred zebra swirl, a red / cyan / pink paint splash on violet and a blue glow.
REC.register('g043', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = (cv, alpha = 1, op = 'source-over') => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.drawImage(cv, 0, 0); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    const fp = (x, pts, c) => { x.fillStyle = c; x.fill(P(pts)); };
    const rr = rng(43);
    keep();
    const cr = (pts, seg = 10) => {
      const out = [], n = pts.length;
      for (let i = 0; i < n - 1; i++) {
        const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(n - 1, i + 2)];
        for (let j = 0; j < seg; j++) { const t = j / seg, t2 = t * t, t3 = t2 * t;
          out.push([0, 1].map(k => 0.5 * (2 * p1[k] + (-p0[k] + p2[k]) * t + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * t2 + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * t3))); }
      }
      out.push(pts[n - 1]); return out;
    };
    // resample a polyline at a fixed arc-length step -> [{x,y,tx,ty}]
    const walk = (pts, step) => {
      const q = cr(pts, 24), out = []; let acc = 0;
      for (let i = 1; i < q.length; i++) {
        const dx = q[i][0] - q[i - 1][0], dy = q[i][1] - q[i - 1][1], d = Math.hypot(dx, dy);
        acc += d; if (acc >= step) { acc -= step; out.push({ x: q[i][0], y: q[i][1], tx: dx / d, ty: dy / d }); }
      }
      return out;
    };

    // ── background (flat albedo) ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#f6f5f1', 0, 0);
    // bottom-right grey haze, bottom-left dark
    soft(x => {
      const g = x.createLinearGradient(560, 640, 726, 1024); g.addColorStop(0, '#d8d6d4'); g.addColorStop(0.5, '#a8a6a6'); g.addColorStop(1, '#8a8888');
      x.fillStyle = g; x.fill(P([[540, 700], [726, 640], [736, 1034], [480, 1034], [470, 900]]));
      fp(x, [[620, 760], [660, 700], [700, 760], [690, 1000], [640, 1020], [600, 900]], '#e8e8ec');
      fp(x, [[0, 930], [200, 950], [480, 940], [480, 1034], [-10, 1034]], '#5a5254');
      for (let k = 0; k < 3; k++) { x.strokeStyle = '#e8e6e2'; x.lineWidth = 9; x.beginPath(); x.moveTo(-10, 960 + k * 26); x.quadraticCurveTo(60, 950 + k * 30, 110, 1034); x.stroke(); }
    }, 14);
    // violet field, top right
    soft(x => {
      fp(x, [[490, -10], [736, -10], [736, 720], [660, 700], [640, 560], [640, 420], [600, 300], [540, 200], [480, 140], [470, 60]], '#535088');
      fp(x, [[630, 46], [668, 38], [700, 52], [692, 84], [650, 90]], '#a898e6');
      fp(x, [[478, 70], [520, 50], [560, 70], [540, 100], [500, 96]], '#d6f040');
      fp(x, [[500, 230], [540, 160], [610, 124], [660, 130], [664, 200], [640, 290], [600, 320], [540, 300]], '#f07ed2');
      fp(x, [[700, 120], [726, 110], [726, 160], [706, 150]], '#f04020');
    }, 10);
    soft(x => {
      fp(x, [[330, 330], [380, 280], [430, 240], [490, 220], [540, 250], [520, 300], [470, 330], [440, 400], [470, 440], [420, 460], [360, 440], [340, 390]], '#f41208');
      fp(x, [[440, 360], [500, 330], [580, 320], [650, 340], [660, 400], [640, 470], [560, 480], [480, 470], [440, 420]], '#22f2f0');
      fp(x, [[400, 410], [450, 400], [470, 440], [430, 470], [390, 450]], '#f070d0');
      fp(x, [[520, 360], [560, 350], [580, 380], [540, 400]], '#a8f060');
      fp(x, [[370, 230], [400, 200], [430, 230], [400, 260]], '#40f080');
    }, 8);
    // zebra swirl: fanned bands on the right (multiplied over the splash), arcs at the top and left
    const fan = E.blur(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(-430., 280.);
      float ang = atan(d.y, d.x) * 57.2958;
      float s = cos(6.2832 * (ang - 0.96) / 2.97);
      float b = smoothstep(-0.2, 0.25, s);
      float m = smoothstep(0.42, 0.6, fbm(p * vec2(0.012, 0.03) + 4.));
      b = max(b, 1. - m);
      return vec3(mix(0.02, 1.0, b)); }`), 2);
    clipA(P([[400, 270], [470, 250], [560, 270], [650, 300], [680, 420], [670, 480], [400, 480]]), () => img(fan, 1, 'multiply'));
    const fanW = E.blur(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(-430., 280.);
      float ang = atan(d.y, d.x) * 57.2958;
      float s = cos(6.2832 * (ang - 0.96) / 2.97);
      return vec3(mix(0.02, 0.97, smoothstep(-0.2, 0.25, s))); }`), 2.5);
    clipA(P([[380, 480], [470, 470], [560, 480], [640, 470], [650, 560], [690, 600], [680, 640], [640, 600], [610, 700], [600, 780], [520, 762], [470, 742], [380, 640]]), () => img(fanW));
    const arcs = E.blur(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float r1 = length((p - vec2(420., 470.)) * vec2(0.85, 1.));
      float s1 = cos(6.2832 * r1 / 36.);
      float r2 = length(p - vec2(330., 640.));
      float s2 = cos(6.2832 * r2 / 30.);
      float s = p.y < 300. ? s1 : s2;
      return vec3(mix(0.04, 0.97, smoothstep(-0.25, 0.25, s))); }`), 3);
    clipA(P([[250, 140], [262, 60], [300, -10], [500, -10], [490, 60], [460, 130], [430, 160], [330, 150]]), () => img(arcs, 0.95, 'multiply'));
    clipA(P([[-10, 470], [40, 470], [70, 560], [60, 660], [30, 720], [-10, 720]]), () => img(arcs, 0.9));
    soft(x => { for (let k = 0; k < 4; k++) { x.strokeStyle = 'rgba(120,118,118,0.5)'; x.lineWidth = 8; x.beginPath(); x.arc(330, 640, 290 + k * 30, 3.4, 3.9); x.stroke(); } }, 3);
    // right edge: white chrome streaks on violet
    soft(x => { x.strokeStyle = '#dcdcf2'; x.lineWidth = 16; x.beginPath(); x.moveTo(700, 300); x.quadraticCurveTo(650, 480, 668, 700); x.stroke(); }, 6);
    // green blob, right edge
    soft(x => { x.fillStyle = '#2ec244'; x.fill(ellipseP(748, 830, 50, 90, 0)); }, 10);
    // black pit behind the coil
    const pit = P([[-10, 580], [60, 590], [130, 556], [200, 520], [300, 512], [400, 540], [452, 600], [482, 700], [472, 820], [436, 890], [380, 925], [300, 940], [180, 940], [60, 920], [-10, 900]]);
    R.flat(pit, '#050505', 0.02, 0);
    soft(x => { x.fillStyle = 'rgba(0,0,0,0.6)'; x.fill(pit); }, 18);
    keep();

    // ── copper beads in the pit ──
    for (const [x, y, r] of [[60, 730, 22], [115, 722, 22], [172, 712, 21], [228, 703, 19], [272, 685, 13], [312, 677, 13], [354, 667, 16], [275, 733, 16], [315, 722, 12],
      [350, 708, 12], [228, 750, 16], [186, 763, 17], [142, 768, 15], [103, 800, 23], [175, 823, 22], [214, 797, 10], [250, 788, 12], [285, 775, 11], [318, 757, 11],
      [188, 540, 17], [232, 552, 11]]) R.bead(x, y, r, '#b0603e', 0.1, Math.min(0.3, r * 0.008 + 0.1), 3);
    keep();

    // ── the chrome coil body ──
    const coilPts = [[300, 470], [230, 450], [160, 438], [110, 452], [78, 488], [72, 536], [92, 580], [132, 608], [190, 618], [250, 610], [310, 596], [370, 590],
      [424, 604], [458, 640], [474, 694], [470, 752], [452, 810], [420, 860], [374, 902], [316, 930], [252, 942], [186, 940], [120, 928], [60, 908], [0, 882], [-50, 856]];
    const coil = P(coilPts, false, true);
    R.pipe(coil, 100, '#1a1a1e', 0.2, 0.28, 1);
    keep();
    const barrel = (cx, cy, tx, ty, L, Wd) => { const nx = -ty, ny = tx, pts = [];
      for (let i = 0; i < 28; i++) { const t = i / 28 * 6.2832, c = Math.cos(t), sn = Math.sin(t);
        const u = Math.sign(c) * Math.pow(Math.abs(c), 0.45) * L / 2, v = Math.sign(sn) * Math.pow(Math.abs(sn), 0.45) * Wd / 2;
        pts.push([cx + tx * u + nx * v, cy + ty * u + ny * v]); }
      return P(pts, true, true); };
    // barrels: short round-capped pipes squashed along the path -> rounded barrel ends
    { let n = 0;
      for (const sg of walk(coilPts, 42)) {
        if (sg.x < -60) continue;
        for (const c of [a, R.h]) { c.save(); c.translate(sg.x, sg.y); c.rotate(Math.atan2(sg.ty, sg.tx)); c.scale(0.3, 1); }
        R.pipe(P([[-18, 0], [18, 0]], false, false), 102, '#d8d8de', 0.3, 0.36, 1);
        R.pipe(P([[-18, 0], [18, 0]], false, false), 72, null, 0.5, 0.18, 1);
        for (const c of [a, R.h]) c.restore();
        if (++n % 4 === 0) keep();
      }
    }
    keep();

    // ── rainbow chrome antennae ──
    const hues = ['#ff3030', '#ff9a20', '#f0e020', '#40e040', '#20c0f0', '#4060ff', '#c040f0'];
    for (const [pts, w0, off] of [[[[250, 126], [214, 128], [182, 152], [162, 190], [150, 232], [138, 268], [122, 290], [112, 306], [118, 318]], 40, 0],
                                  [[[462, 130], [494, 140], [520, 168], [536, 208], [534, 252], [522, 290], [524, 318], [536, 330]], 36, 2]]) {
      const ss = walk(pts, 12), n = ss.length;
      for (let i = 0; i < n; i++) {
        const sg = ss[i], w = w0 * 1.15 * (1 - 0.65 * i / n);
        R.dome(barrel(sg.x, sg.y, sg.tx, sg.ty, 13, w), hues[Math.floor((i / n * 8 + off)) % 7], 0.4, 0.14 * (1 - 0.5 * i / n), w * 0.4, 2);
      }
    }
    keep();

    // ── striped chrome helmet ──
    const helm = P([[180, 330], [176, 270], [186, 210], [214, 162], [258, 132], [304, 122], [352, 124], [398, 140], [426, 180], [436, 240], [434, 300], [420, 352], [300, 360]]);
    R.dome(helm, '#d8d8de', 0.36, 0.3, 90, 1);
    clipA(helm, () => { for (let k = 0; k < 6; k++) { const y = 150 + k * 27 + k * k * 0.8, t = 15 - k * 1.2; a.fillStyle = '#08080a';
      a.fill(P([[150, y + 14], [250, y - 6], [350, y - 6], [450, y + 12], [450, y + 12 + t], [350, y - 6 + t * 0.8], [250, y - 6 + t * 0.8], [150, y + 14 + t]], true, true)); } });
    R.groove(P([[214, 300], [300, 296], [390, 304]], false), 3, '#303036', 0.62, 0.03, 1, 0.7);
    R.groove(P([[214, 310], [300, 306], [390, 314]], false), 3, '#303036', 0.62, 0.03, 1, 0.7);
    keep();

    // ── skull face ──
    const skull = P([[186, 360], [200, 330], [250, 318], [300, 316], [350, 318], [394, 334], [404, 370], [396, 410], [370, 436], [330, 448], [290, 450], [250, 444], [212, 428], [190, 400]]);
    R.dome(skull, '#ecdcc0', 0.5, 0.12, 30, 4);
    clipA(skull, () => soft(x => {
      x.fillStyle = '#141010'; x.fill(ellipseP(220, 382, 38, 30, 0.1)); x.fill(ellipseP(344, 382, 38, 30, -0.1));
      x.fill(P([[232, 342], [258, 352], [270, 368], [250, 360]])); x.fill(P([[332, 342], [306, 352], [294, 368], [314, 360]]));
      x.fillStyle = '#c8a888'; x.fill(ellipseP(282, 408, 20, 12, 0));
    }, 4));
    for (const [x, y] of [[218, 385], [345, 385]]) {
      R.dome(circleP(x, y, 25), '#2a5cc0', 0.6, 0.1, 22, 5);
      R.dome(circleP(x, y, 13), '#0a1020', 0.69, 0.02, 6, 5);
      R.flat(circleP(x + 6, y - 9, 5), '#ffffff', 0.72, 0);
    }
    R.dome(ellipseP(276, 418, 5, 7, 0.2), '#3a2a20', 0.56, 0.02, 3, 4); R.dome(ellipseP(290, 418, 5, 7, -0.2), '#3a2a20', 0.56, 0.02, 3, 4);
    keep();

    // ── chrome mandibles and mouthparts ──
    R.dome(P([[186, 446], [210, 428], [238, 438], [250, 466], [236, 494], [212, 498], [192, 478]]), '#c8c8d0', 0.5, 0.18, 22, 1);
    R.dome(circleP(222, 462, 12), '#e02818', 0.62, 0.08, 10, 5);
    R.dome(P([[290, 480], [320, 452], [370, 444], [410, 452], [422, 474], [410, 496], [370, 504], [320, 500]]), '#c8c8d0', 0.5, 0.2, 26, 1);
    R.dome(ellipseP(366, 484, 30, 8, -0.05), '#80e020', 0.66, 0.04, 6, 5);
    R.dome(circleP(414, 440, 14), '#2050e0', 0.5, 0.12, 12, 5);
    for (let k = 0; k < 7; k++) { R.pipe(P([[246 + k * 3, 446 + k * 11], [268, 450 + k * 11], [292 - k * 3, 446 + k * 11]], false), 7, '#b8b8c0', 0.48, 0.08, 1); }
    R.pipe(P([[250, 440], [270, 470], [262, 510], [276, 528]], false), 8, '#c0c0c8', 0.46, 0.1, 1);
    R.pipe(P([[300, 440], [284, 476], [294, 512], [282, 530]], false), 8, '#c0c0c8', 0.46, 0.1, 1);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.25, metal: 1.0, spec: 1.6, shin: 90, ao: 0.4, rim: 0.6 }),                          // 1 chrome
        E.mat({ dif: 0.35, metal: 0.85, spec: 1.6, shin: 80, ao: 0.3, rim: 0.4, emis: 0.25 }),            // 2 rainbow chrome
        E.mat({ dif: 0.85, spec: 1.2, shin: 70, wrap: 0.2, ao: 0.4, coat: 0.25 }),                         // 3 copper beads
        E.mat({ dif: 1.0, spec: 0.5, shin: 30, wrap: 0.4, ao: 0.5 }),                                     // 4 skull
        E.mat({ dif: 0.9, spec: 1.4, shin: 90, wrap: 0.2, coat: 0.5, emis: 0.1 })                          // 5 glass eyes
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.9, 0.9, 0.92], amb: [0.32, 0.32, 0.34],
      envTop: [1.45, 1.45, 1.48], envHor: [0.95, 0.95, 1.0], envBot: [0.1, 0.1, 0.12], envK: [-0.5, 1.6, 0.0, 0],
      rimC: [0.3, 0.26, 0.28], rimD: [0, 1, 0.4], r1: 1.4, r2: 6, k: [0, 0.6, 0.4, 200], shadow: [-5, 7, 0.55, 6]
    });

    // blue glow
    o.save(); o.globalCompositeOperation = 'screen';
    { const g = o.createRadialGradient(546, 962, 2, 546, 962, 70); g.addColorStop(0, 'rgba(230,255,255,1)'); g.addColorStop(0.2, 'rgba(60,200,255,0.9)'); g.addColorStop(0.6, 'rgba(40,60,255,0.45)'); g.addColorStop(1, 'rgba(40,40,255,0)');
      o.fillStyle = g; o.fillRect(460, 880, 180, 144); }
    o.restore();
    E.grain(0.03, 43);
  }
});
