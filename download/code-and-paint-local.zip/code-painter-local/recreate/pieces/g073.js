'use strict';
// g073 — "Spiral-cheeked paper dreamer": a cut-paper clay portrait — mint face in a blue turtleneck, yellow
// spiky fringe, black-and-cream zebra hair with a hypnotic spiral, puffy mauve clouds, spiral cheek discs,
// a glowing black ring disc and soap bubbles over a blurred blue / grey backdrop with a floating cow.
REC.register('g073', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    keep();
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, st) => { const g = a.createRadialGradient(x, y, 0, x, y, r0); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fp = (x, path, c) => { x.fillStyle = c; x.fill(path); };
    const CREAM = '#f2ead6';
    // paper layer: cream rim (outside) + inflated fill
    const layer = (path, alb, h0, dh, wd, m, rim = 6, rimC = CREAM) => {
      if (rim > 0) R.pipe(path, rim * 2, rimC, h0, dh * 0.6, 1);
      R.dome(path, alb, h0, dh, wd, m);
    };
    // star-shaped outline around a union of circles
    const union = (cx, cy, circles, n = 120) => {
      const pts = [];
      for (let i = 0; i < n; i++) {
        const t = i / n * Math.PI * 2, ux = Math.cos(t), uy = Math.sin(t); let best = 0;
        for (const [x, y, rr] of circles) { const dx = x - cx, dy = y - cy, b = dx * ux + dy * uy, q = rr * rr - (dx * dx + dy * dy) + b * b; if (q > 0) best = Math.max(best, b + Math.sqrt(q)); }
        pts.push([cx + ux * best, cy + uy * best]);
      }
      return P(pts, true, false);
    };

    // ── blurred backdrop (unlit) ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#5f5a57', 0, 0);
    soft(x => {
      fp(x, P([[-20, -20], [270, -20], [290, 300], [270, 600], [250, 820], [-20, 820]], true, false), '#207ab9');
      fp(x, P([[270, -20], [340, -20], [330, 300], [290, 320]], true, false), '#6a665e');
      fp(x, P([[330, -20], [470, -20], [460, 140], [340, 140]], true, false), '#7a948e');
      fp(x, P([[470, -20], [560, -20], [560, 110], [470, 110]], true, false), '#fbfbfa');
      fp(x, P([[560, -20], [620, -20], [626, 300], [570, 300]], true, false), '#6e6660');
      fp(x, P([[620, -20], [746, -20], [746, 520], [630, 520]], true, false), '#16110f');
      fp(x, P([[630, 500], [746, 500], [746, 760], [640, 760]], true, false), '#5a5452');
      fp(x, P([[560, 740], [746, 740], [746, 1044], [560, 1044]], true, false), '#c2bcb8');
      fp(x, P([[420, 760], [600, 760], [600, 1044], [420, 1044]], true, false), '#d8d2ce');
      for (const [cx, cy, rr] of [[40, 860, 90], [140, 830, 70], [210, 880, 70], [60, 960, 90], [170, 980, 80]]) fp(x, circleP(cx, cy, rr), '#e2dcd8');
      fp(x, circleP(110, 890, 40), '#bdb6b2');
      // floating cow
      fp(x, ellipseP(160, 70, 130, 75, 0.45), '#efe6e6');
      x.lineCap = 'round'; x.strokeStyle = '#1a1414'; x.lineWidth = 30; x.stroke(P([[80, -10], [110, 60], [170, 100]], false));
      fp(x, ellipseP(250, 130, 34, 30, 0.2), '#f2b0b4');
      fp(x, ellipseP(210, 200, 40, 14, -0.3), '#cfe4f4');
    }, 9);

    // ── zebra hair with spiral ──
    const hairPts = [[300, 335], [302, 280], [312, 215], [330, 160], [355, 118], [390, 92], [430, 80], [470, 78], [484, 62], [493, 50], [499, 62], [494, 86], [520, 90], [552, 96],
      [564, 84], [574, 74], [581, 82], [572, 100], [600, 125], [622, 165], [635, 215], [638, 270], [632, 330], [645, 395], [658, 450], [662, 520], [654, 590], [636, 640],
      [600, 682], [560, 704], [500, 712], [450, 702], [410, 680], [390, 560], [380, 430], [330, 380]];
    const hair = P(hairPts, true, false);
    const zeb = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 14. * vec2(vnoise(p * 0.01) - .5, vnoise(p * 0.01 + 5.) - .5);
      float L = 300. + 90. * exp(-(max(q.y, 80.) - 80.) / 70.);
      float R = 560. + 80. * smoothstep(70., 200., q.y) + 22. * smoothstep(330., 480., q.y) - 30. * smoothstep(560., 690., q.y);
      float u = (q.x - L) / max(R - L, 30.);
      float ph = u * 12.5 + 0.35 * sin(q.y * 0.028 + u * 4.) + 0.15 * sin(q.y * 0.07);
      float f = fract(ph);
      vec3 cr = vec3(0.95, 0.93, 0.88), bk = vec3(0.03, 0.03, 0.03), ed = vec3(0.55, 0.52, 0.48);
      vec3 c = mix(bk, ed, smoothstep(0.40, 0.43, f));
      c = mix(c, cr, smoothstep(0.45, 0.49, f)); c = mix(c, ed, smoothstep(0.96, 0.99, f));
      return c; }`));
    layer(hair, zeb, 0.06, 0.05, 10, 2, 7);
    R.dome(P([[444, 104], [490, 96], [506, 196], [470, 202]], true, false), lin(444, 0, 506, 0, [[0, '#b4aa9c'], [1, '#8e867a']]), 0.12, 0.02, 4, 1);
    keep();

    // spiral discs (one shader for all)
    const SP = [[515, 275, 76, 9.5], [200, 718, 48, 8], [380, 602, 30, 7], [455, 486, 32, 7], [500, 515, 12, 5], [387, 437, 10, 4.5], [576, 290, 7, 3.5], [402, 578, 6, 3]];
    const spir = pat(E.fx(`const vec4 SPD[8] = vec4[8](${SP.map(([x, y, rr, pp]) => `vec4(${x}., ${y}., ${rr}., ${pp})`).join(',')});
      vec3 fx(vec2 uv, vec2 p){
        vec3 cr = vec3(0.95, 0.93, 0.86), bk = vec3(0.05, 0.03, 0.03);
        for (int i = 0; i < 8; i++) { vec4 s = SPD[i]; vec2 d = p - s.xy; float l = length(d);
          if (l < s.z + 2.) { float f = fract(l / s.w - atan(d.y, d.x) / 6.2832);
            float k = smoothstep(0.30, 0.36, f) * smoothstep(0.78, 0.72, f);
            return mix(cr, bk, k * smoothstep(s.w * 0.6, s.w * 1.1, l) * smoothstep(s.z - 2., s.z - 5., l)); } }
        return cr; }`));
    for (const [x, y, rr] of SP.slice(0, 1)) layer(circleP(x, y, rr), spir, 0.12, 0.04, Math.min(8, rr * 0.4), 2, rr > 20 ? 6 : 2.5);
    keep();

    // ── black underside + disc ──
    layer(P([[392, 636], [470, 640], [486, 700], [470, 776], [424, 794], [398, 760]]), '#0a0808', 0.04, 0.02, 6, 2, 0);
    soft(x => { x.strokeStyle = 'rgba(0,0,0,0.6)'; x.lineWidth = 24; x.stroke(circleP(545, 818, 108)); }, 10, 0.8);
    layer(circleP(545, 812, 98), rad(545, 812, 98, [[0, '#2a2422'], [0.55, '#1a1514'], [0.8, '#0c0a0a'], [1, '#2a2422']]), 0.1, 0.05, 20, 2, 7);
    R.pipe(circleP(545, 812, 72), 3, '#4a4240', 0.15, 0.01, 2);
    R.dome(circleP(545, 812, 52), CREAM, 0.15, 0.04, 6, 1);
    R.dome(circleP(545, 812, 45), rad(545, 812, 45, [[0, '#ffffff'], [0.7, '#fffef6'], [1, '#f4eedc']]), 0.18, 0.02, 4, 6);
    keep();

    // ── neck, turtleneck ──
    R.dome(P([[196, 856], [236, 834], [386, 834], [430, 856], [420, 880], [206, 880]]), '#0e1a7a', 0.1, 0.02, 6, 3);
    layer(P([[238, 760], [382, 750], [386, 900], [232, 900]], true, false), lin(0, 760, 0, 900, [[0, '#7d948e'], [0.25, '#9ab2ac'], [1, '#8aa29c']]), 0.1, 0.03, 10, 1, 5);
    const sweaterTex = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = fbm(p * 0.15) * 0.5 + fbm(p * 0.03) * 0.5;
      return vec3(0.13, 0.22, 0.84) * (0.9 + 0.16 * n); }`));
    layer(P([[-10, 1034], [-10, 1008], [80, 982], [150, 960], [190, 948], [310, 944], [440, 948], [490, 958], [570, 978], [650, 1000], [736, 1014], [736, 1034]]), sweaterTex, 0.08, 0.1, 40, 3, 5);
    layer(P([[176, 958], [174, 900], [182, 862], [204, 842], [238, 834], [250, 866], [310, 874], [372, 866], [386, 834], [420, 842], [444, 862], [454, 900], [452, 958], [400, 972], [310, 976], [222, 972]]), sweaterTex, 0.16, 0.14, 30, 3, 0);
    R.groove(P([[182, 928], [240, 942], [310, 946], [380, 942], [450, 928]], false), 10, '#0c1880', 0.3, 0.06, 3, 0.7);
    keep();

    // ── yellow fringe ──
    const strands = [
      [[290, 300], [230, 296], [150, 318], [62, 348]], [[284, 318], [210, 330], [130, 372], [58, 410]], [[270, 330], [200, 360], [120, 420], [58, 440]],
      [[260, 336], [190, 380], [130, 440], [86, 484]], [[250, 345], [180, 400], [140, 480], [118, 560]], [[288, 290], [240, 278], [170, 280], [108, 296]],
      [[290, 284], [250, 262], [210, 250], [182, 240]], [[292, 290], [262, 272], [230, 262], [200, 262]], [[300, 280], [282, 266], [262, 258], [244, 262]],
      [[240, 350], [180, 360], [120, 340], [70, 356]], [[230, 360], [170, 420], [120, 500], [100, 520]], [[250, 330], [160, 330], [100, 380], [60, 380]],
    ];
    const hy = rng(731);
    const mass = P([[300, 268], [250, 258], [196, 246], [210, 270], [140, 286], [112, 296], [150, 316], [70, 344], [58, 356], [110, 366], [66, 408], [60, 440], [96, 432], [86, 482],
      [104, 530], [118, 572], [136, 520], [150, 460], [180, 410], [226, 368], [270, 340], [300, 330]]);
    R.pipe(mass, 10, CREAM, 0.12, 0.03, 1);
    R.dome(mass, '#f2c81c', 0.12, 0.04, 10, 5);
    for (const s of strands) { const pp = P(lock(s, 44 + hy() * 14, 3, 0.8)); R.pipe(pp, 6, CREAM, 0.14, 0.03, 1); }
    for (const s of strands) { const pp = P(lock(s, 44 + hy() * 14, 3, 0.8)); R.dome(pp, lin(60, 0, 300, 0, [[0, '#f6d020'], [0.5, '#fbdc30'], [1, '#f0c418']]), 0.16, 0.06, 6, 5); }
    for (let i = 0; i < 26; i++) { const s = strands[i % strands.length], o2 = (hy() - 0.5) * 18;
      R.groove(P(s.map(([x, y], k) => [x + (k === 0 ? 0 : o2 * 0.4), y + o2 * (k / 3)]), false), 2.2, '#c89408', 0.2, 0.02, 5, 0.9); }
    keep();

    // ── face ──
    const face = P([[190, 388], [260, 350], [330, 352], [400, 380], [430, 440], [446, 520], [442, 600], [446, 650], [432, 704], [400, 760], [350, 794], [300, 800], [240, 782],
      [196, 756], [162, 700], [142, 640], [130, 580], [126, 520], [134, 460], [158, 414]]);
    layer(face, rad(260, 560, 300, [[0, '#c4ddd4'], [0.6, '#b8d2c8'], [1, '#a2bab2']]), 0.14, 0.05, 18, 1, 6);
    const ear = P([[152, 584], [122, 574], [98, 590], [94, 622], [108, 650], [134, 666], [154, 656]]);
    layer(ear, '#b4cec4', 0.13, 0.04, 10, 1, 5);
    R.pipe(P([[140, 600], [120, 596], [112, 616], [124, 640], [146, 650]], false), 4, CREAM, 0.18, 0.02, 1);
    // freckles
    const fr = rng(733);
    for (let i = 0; i < 70; i++) { const x = 160 + fr() * 260, y = 420 + fr() * 260; if ((x - 300) ** 2 / 140 ** 2 + (y - 560) ** 2 / 150 ** 2 > 1) continue; R.bead(x, y, 1.2 + fr() * 1.6, '#f6f2e6', 0.2, 0.02, 1); }
    keep();
    // brows
    R.dome(P(lock([[136, 532], [170, 506], [210, 494], [236, 500]], 14, 6, 0.6)), '#0c0a0a', 0.2, 0.04, 5, 2);
    R.dome(P(lock([[396, 478], [360, 464], [326, 464], [298, 482]], 14, 6, 0.6)), '#0c0a0a', 0.2, 0.04, 5, 2);
    // eyes
    const eye = (cx, cy, w, h, rot, ix, iy) => {
      const al = P([[cx - w, cy + 4], [cx - w * 0.45, cy - h], [cx + w * 0.3, cy - h * 1.05], [cx + w, cy - 2], [cx + w * 0.4, cy + h * 0.9], [cx - w * 0.4, cy + h * 0.9]]);
      R.pipe(al, 6, '#5a6a64', 0.2, 0.01, 1);
      R.dome(al, '#f4eedc', 0.2, 0.03, 6, 1);
      R.bead(ix, iy, 16, rad(ix - 4, iy - 5, 20, [[0, '#3ac08a'], [0.6, '#1a8a5a'], [1, '#0a4a30']]), 0.22, 0.05, 4);
      R.bead(ix, iy, 6.5, '#050505', 0.27, 0.02, 4);
      R.bead(ix - 5, iy - 6, 2.4, '#ffffff', 0.3, 0.01, 4);
      R.pipe(P([[cx - w * 0.9, cy - h * 0.6], [cx - w * 0.2, cy - h * 1.35], [cx + w * 0.6, cy - h * 1.2]], false), 4, '#7a8c86', 0.17, 0.01, 1);
    };
    eye(210, 578, 46, 22, 0, 210, 576);
    eye(356, 534, 46, 26, 0, 356, 535);
    // nose + nostrils, lips
    layer(P([[272, 548], [296, 544], [300, 600], [306, 640], [296, 646], [284, 600]]), CREAM, 0.18, 0.04, 5, 1, 0);
    layer(P([[282, 648], [300, 638], [318, 640], [336, 650], [326, 664], [292, 664]]), CREAM, 0.18, 0.04, 5, 1, 0);
    R.bead(298, 656, 4, '#2a2a28', 0.21, 0.01, 1); R.bead(322, 656, 4, '#2a2a28', 0.21, 0.01, 1);
    layer(P([[284, 712], [306, 696], [326, 700], [346, 694], [362, 712], [338, 728], [306, 730]]), CREAM, 0.17, 0.03, 5, 1, 0);
    R.groove(P([[290, 712], [322, 714], [356, 710]], false), 3, '#3a3a36', 0.2, 0.03, 1);
    keep();

    // ── mauve clouds ──
    const cloudL = union(320, 380, [[240, 318, 22], [262, 350, 30], [300, 356, 32], [345, 362, 34], [392, 372, 30], [422, 396, 22], [372, 410, 30], [330, 420, 30], [285, 410, 32], [250, 394, 30], [232, 360, 26]]);
    layer(cloudL, rad(300, 360, 160, [[0, '#ddcfcc'], [1, '#c4b2ae']]), 0.2, 0.1, 24, 1, 5);
    const cloudR = union(540, 530, [[470, 440, 36], [522, 420, 32], [576, 414, 36], [620, 430, 32], [646, 470, 26], [642, 530, 30], [626, 590, 32], [590, 630, 36], [540, 650, 30], [490, 642, 32], [452, 612, 32], [426, 560, 30], [430, 500, 30], [452, 466, 26]]);
    layer(cloudR, rad(540, 520, 200, [[0, '#d6c6c2'], [1, '#c0aca8']]), 0.2, 0.1, 30, 1, 6);
    for (const [x, y, rr] of [[565, 524, 33], [441, 612, 22], [470, 600, 16], [324, 420, 22], [372, 404, 16], [268, 386, 22], [430, 392, 18], [222, 318, 12], [236, 304, 8]]) R.bead(x, y, rr, rad(x - rr * 0.4, y - rr * 0.4, rr * 1.4, [[0, '#ece2e0'], [1, '#c4b2ae']]), 0.3, rr * 0.01 + 0.04, 1);
    for (const [x, y, rr] of [[632, 501, 8], [608, 605, 8], [525, 430, 5], [646, 446, 6], [258, 398, 4]]) R.bead(x, y, rr, '#e4dad6', 0.32, 0.04, 1);
    // spirals sitting on the clouds / face again on top
    for (const [x, y, rr] of SP.slice(1)) layer(circleP(x, y, rr), spir, 0.34, 0.04, Math.min(8, rr * 0.4), 2, rr > 20 ? 6 : 2.5);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.25, shin: 20, wrap: 0.45, ao: 0.45, rim: 0.15 }),      // 1 matte clay
        E.mat({ dif: 1, spec: 0.55, shin: 40, wrap: 0.35, ao: 0.4 }),                  // 2 satin black/cream
        E.mat({ dif: 1, spec: 0.15, shin: 14, wrap: 0.45, ao: 0.5, grain: 0.1 }),        // 3 knit sweater
        E.mat({ dif: 1, spec: 1.2, shin: 80, wrap: 0.2, coat: 0.2, ao: 0.3 }),          // 4 glossy eyes
        E.mat({ dif: 1, spec: 0.5, shin: 34, wrap: 0.35, ao: 0.4 }),                   // 5 yellow strands
        E.mat({ dif: 0, emis: 0.05 }),                                                 // 6 glowing white
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.75, 0.74, 0.72], amb: [0.42, 0.42, 0.44],
      envTop: [1, 1, 1.02], envHor: [0.55, 0.55, 0.58], envBot: [0.12, 0.12, 0.14], envK: [0.2, 0.8, 0.3, 0],
      rimC: [0.15, 0.15, 0.18], rimD: [0.3, 0.6, 0.3], r1: 1.4, r2: 6, k: [0, 0.6, 0.4, 50], shadow: [-4, 6, 0.5, 8]
    });

    // ── glow + soap bubbles ──
    const o = E.out;
    o.save(); o.globalCompositeOperation = 'screen'; o.filter = `blur(${16 * S}px)`; o.fillStyle = 'rgba(255,250,230,0.7)'; o.fill(circleP(545, 812, 50)); o.restore();
    const bub = (x, y, rr) => {
      o.save();
      const g = o.createRadialGradient(x, y, rr * 0.55, x, y, rr);
      g.addColorStop(0, 'rgba(255,255,255,0.05)'); g.addColorStop(0.75, 'rgba(200,230,255,0.25)'); g.addColorStop(1, 'rgba(255,255,255,0.75)');
      o.fillStyle = g; o.fill(circleP(x, y, rr));
      const ir = o.createLinearGradient(x - rr, y - rr, x + rr, y + rr);
      ir.addColorStop(0, 'rgba(255,120,200,0.55)'); ir.addColorStop(0.35, 'rgba(120,200,255,0.5)'); ir.addColorStop(0.65, 'rgba(255,230,120,0.45)'); ir.addColorStop(1, 'rgba(140,255,200,0.5)');
      o.lineWidth = Math.max(1.2, rr * 0.12); o.strokeStyle = ir; o.stroke(circleP(x, y, rr * 0.92));
      o.fillStyle = 'rgba(255,255,255,0.9)'; o.fill(ellipseP(x - rr * 0.38, y - rr * 0.4, rr * 0.22, rr * 0.12, -0.7));
      o.restore();
    };
    for (const [x, y, rr] of [[72, 218, 25], [62, 322, 10], [50, 526, 15], [66, 684, 21], [691, 316, 23], [692, 508, 15], [664, 710, 13], [672, 898, 20], [646, 50, 21], [664, 140, 13],
      [428, 66, 6], [280, 212, 6], [238, 252, 5], [672, 222, 8], [690, 382, 7], [138, 732, 7], [190, 815, 7], [146, 798, 5], [36, 594, 4], [60, 746, 5], [626, 640, 5], [440, 798, 4], [654, 754, 6]]) bub(x, y, rr);
    E.grain(0.03, 3);
  }
});
