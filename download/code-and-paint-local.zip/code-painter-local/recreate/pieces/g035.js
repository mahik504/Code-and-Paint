'use strict';
// g035 — "Zebra tea ceremony": a masked figure in a black-pink hood and zebra-swirl robe pours from an orange
// and white teapot into a swirling black-and-white pool on an orange table; lilac smoke and cream foam clouds
// rise past green tiles, with soap bubbles, a paper cup and a glass bottle.
REC.register('g035', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const F = (path, c) => { o.fillStyle = c; o.fill(path); };
    const K = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const C = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const lin = (x0, y0, x1, y1, st) => { const g = o.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st) => { const g = o.createRadialGradient(x, y, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const blurred = (px, fn) => { o.save(); o.filter = `blur(${px * S}px)`; fn(); o.restore(); };
    // cloud: union of circles, soft shading
    const cloud = (cs, base, shade, hi, flat) => {
      const p = new Path2D(); for (const [x, y, r] of cs) p.addPath(circleP(x, y, r));
      if (flat) p.addPath(rrect(flat[0], flat[1], flat[2], flat[3], flat[3] / 2));
      F(p, base);
      C(p, () => { blurred(8, () => { for (const [x, y, r] of cs) F(circleP(x + r * 0.25, y + r * 0.35, r * 0.75), shade); }); blurred(6, () => { for (const [x, y, r] of cs) F(circleP(x - r * 0.25, y - r * 0.3, r * 0.45), hi); }); });
      return p;
    };
    const smoke = (pts, w, col) => { const r = rng(pts.length * 7 + w); for (let i = 0; i < pts.length - 1; i++) { const [x0, y0] = pts[i], [x1, y1] = pts[i + 1];
      for (let k = 0; k < 4; k++) { const u = k / 4, x = x0 + (x1 - x0) * u, y = y0 + (y1 - y0) * u; F(P(blob(x + (r() - 0.5) * w * 0.5, y, w * (0.45 + r() * 0.3), w * 0.35, i * 9 + k, 9, 0.35)), col); } } };

    // ── textures ──
    const swirl = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(440., 740.); float r = length(d * vec2(1., 2.6)), a = atan(d.y * 2.6, d.x);
      float s = sin(a * 22. + r * 0.02 + 4. * fbm(p * 0.012) + /*sw*/0.);
      float v = smoothstep(-.6, -.3, s) * (0.8 + 0.2 * fbm(p * 0.02));
      return mix(vec3(.10, .09, .09), vec3(.90, .88, .87), v); }`));
    const robe = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float w = p.y + 14. * sin(p.x * 0.045 + p.y * 0.01) + 22. * fbm(p * 0.012);
      float s = sin(6.2832 * w / 30.);
      return mix(vec3(.03), vec3(.97, .96, .95), smoothstep(-.1, .1, s)); }`));
    const zebR = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float w = p.x + 0.5 * p.y + 12. * sin(p.y * 0.04 + p.x * 0.02) + 22. * fbm(p * 0.012);
      float s = sin(6.2832 * w / 19.);
      float glow = exp(-pow(length((p - vec2(650., 470.)) * vec2(1., 0.8)) / 160., 2.));
      float duty = mix(.93, .2, glow);
      vec3 base = mix(vec3(.08, .07, .07), vec3(.30, .27, .27), glow);
      return mix(base, vec3(.86, .80, .76), smoothstep(duty - .1, duty + .1, s)); }`));
    const zebL = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float w = p.y * 0.8 - p.x * 0.6 + 20. * sin(p.x * 0.03) + 26. * fbm(p * 0.01) + /*zl*/27.;
      float s = sin(6.2832 * w / 70.);
      return mix(vec3(.12, .11, .11), vec3(.92, .89, .86), smoothstep(-.4, .1, s)); }`));
    const tiles = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + vec2(0.06 * p.y, 0.); vec2 g = abs(fract(q / vec2(64., 66.)) - .5);
      float line = smoothstep(.485, .495, max(g.x, g.y));
      vec3 c = mix(vec3(.24, .50, .40), vec3(.36, .64, .52), fbm(p * 0.006));
      return mix(c, vec3(.12, .22, .18), line); }`));

    // ── wall: green tiles, zebra wall on the right, pale band on the left ──
    F(rrect(0, 0, 726, 1024, 0), tiles);
    const right = P([[574, -10], [736, -10], [736, 740], [574, 740]], true, false);
    F(right, zebR);
    F(rrect(560, -10, 30, 750, 0), lin(560, 0, 590, 0, [[0, '#6c6260'], [0.5, '#b8aaa4'], [1, '#3a3434']]));
    const leftZ = P([[-10, 360], [40, 380], [70, 440], [90, 520], [120, 560], [60, 640], [20, 700], [-10, 760]]);
    F(leftZ, zebL);

    // ── lilac smoke columns ──
    const LIL = '#c4cbe8';
    smoke([[150, 0], [130, 60], [150, 130], [180, 190], [170, 260], [200, 330], [220, 390], [250, 450], [260, 520], [270, 600]], 70, LIL);
    smoke([[130, 270], [150, 300], [160, 350], [140, 380], [180, 400]], 26, LIL);
    smoke([[350, 0], [360, 50], [380, 100], [400, 160], [420, 220], [440, 280], [446, 340], [430, 400]], 70, LIL);
    smoke([[110, 0], [100, 40], [110, 80]], 40, LIL);
    smoke([[230, 520], [240, 580], [250, 640]], 26, LIL);

    // ── black reeds + diffuser bottle ──
    for (const [x0, x1] of [[236, 296], [262, 304], [300, 308], [330, 314], [356, 318]]) K(P([[x0, -10], [(x0 + x1) / 2, 100], [x1, 214]], false), '#060506', 7);
    F(P([[290, 210], [326, 210], [334, 246], [346, 262], [270, 262], [282, 246]]), '#0a0808');

    // ── foam clouds up top ──
    cloud([[140, 110, 40], [110, 90, 26], [176, 90, 30], [196, 140, 30], [130, 168, 38], [96, 140, 24], [160, 196, 22], [196, 176, 20]], '#fbeee6', 'rgba(230,200,190,0.7)', 'rgba(255,255,255,0.9)');
    cloud([[440, 50, 42], [480, 24, 36], [416, 100, 36], [470, 106, 34], [420, 150, 28], [500, 70, 30], [450, 170, 18], [400, 40, 26]], '#fbeee6', 'rgba(230,200,190,0.7)', 'rgba(255,255,255,0.9)');
    F(circleP(446, 295, 18), '#f2e4dc'); F(circleP(166, 352, 12), '#f2e4dc');
    // pink sleeve top-left + spoon
    F(P([[-10, -10], [140, -10], [120, 20], [80, 30], [20, 40], [-10, 60]]), '#f0d6c4');
    F(P([[60, -10], [140, -10], [130, 20], [100, 34], [80, 20]]), '#8a4c3c');
    K(P([[40, 50], [90, 30]], false), '#e8e8f0', 5);

    // ── table: orange top + swirling pool ──
    const back = P([[560, 640], [736, 610], [736, 790], [560, 790]]);
    F(back, swirl);
    const table = new Path2D(); table.addPath(ellipseP(378, 786, 393, 80, -0.095)); table.addPath(rrect(-10, 786, 746, 250, 0));
    F(table, lin(0, 760, 0, 1024, [[0, '#f37e30'], [1, '#f88428']]));
    const pool = ellipseP(378, 788, 386, 68, -0.095);
    F(pool, swirl);
    C(table, () => blurred(10, () => F(ellipseP(80, 900, 60, 18, 0), 'rgba(120,40,0,0.45)')));
    // swirl continues behind the figure into the right wall

    // ── figure: hood, robe, arms ──
    const body = P([[20, 700], [24, 640], [60, 600], [130, 560], [200, 520], [240, 470], [250, 380], [260, 320], [290, 280], [330, 264], [380, 274], [410, 310], [420, 380],
      [430, 440], [480, 470], [560, 500], [590, 540], [580, 600], [520, 640], [400, 700], [200, 740], [80, 740]]);
    F(body, '#0a0708');
    // pink hood lining highlights
    C(body, () => {
      F(P([[262, 330], [290, 290], [330, 276], [370, 282], [394, 300], [370, 296], [330, 290], [296, 302], [276, 330], [266, 370]]), '#e8b4b4');
      F(P([[200, 540], [230, 520], [250, 600], [240, 660], [216, 640], [206, 590]]), '#e0aaa8');
      F(P([[60, 640], [120, 610], [180, 600], [150, 640], [100, 660], [60, 680]]), '#d8a0a0');
      F(P([[100, 600], [150, 570], [180, 560], [160, 590], [120, 610]]), '#f0c4c0');
      F(P([[540, 520], [580, 540], [600, 580], [570, 570], [540, 550]]), '#d8a8a8');
    });
    // zebra robe front
    const front = P([[270, 470], [300, 430], [350, 440], [400, 450], [440, 470], [480, 500], [520, 520], [540, 560], [520, 620], [470, 640], [400, 650], [320, 660], [280, 640], [262, 580], [250, 520]]);
    F(front, robe);
    // face: white mask, orange band, red cheeks, red tongue, spiral
    const face = P([[300, 330], [330, 316], [372, 318], [396, 336], [398, 380], [388, 420], [372, 450], [352, 466], [330, 456], [312, 430], [302, 390]]);
    F(face, '#f4f2f0');
    F(P([[302, 328], [332, 318], [372, 320], [394, 336], [396, 366], [370, 372], [330, 372], [304, 366]]), '#f08a30');
    F(P([[300, 322], [334, 312], [376, 314], [398, 330], [394, 338], [370, 326], [332, 326], [302, 334]]), '#b8b4b4');
    for (const x of [326, 372]) { F(ellipseP(x, 348, 10, 6, 0), '#f8f4f0'); F(circleP(x, 348, 4.5), '#0a0a0a'); }
    K(P([[314, 336], [330, 332], [342, 336]], false), '#2a1410', 3); K(P([[358, 336], [372, 332], [388, 336]], false), '#2a1410', 3);
    F(circleP(320, 364, 9), '#f03a30'); F(circleP(384, 364, 9), '#f03a30');
    F(ellipseP(352, 392, 4, 6, 0), '#0a0a0a');
    F(P([[350, 410], [364, 410], [366, 446], [358, 462], [348, 452]]), '#ee1c18');
    for (let k = 1; k <= 4; k++) K(circleP(318, 392, k * 4.5), '#2a2224', 1.5);

    // ── foam clouds in front of the shoulders ──
    cloud([[100, 486, 22], [140, 476, 26], [186, 470, 28], [232, 474, 26], [272, 482, 20], [304, 480, 14], [70, 492, 18], [120, 520, 20], [170, 526, 22], [216, 524, 20], [256, 516, 18]], '#d8c4c2', 'rgba(170,140,140,0.6)', 'rgba(245,232,228,0.9)', [62, 478, 254, 42]);
    cloud([[452, 450, 30], [496, 432, 36], [540, 452, 30], [566, 480, 22], [436, 486, 20], [470, 530, 22], [516, 536, 22], [552, 516, 20]], '#d8c4c2', 'rgba(170,140,140,0.6)', 'rgba(245,232,228,0.9)', [426, 450, 152, 96]);
    K(P([[500, 420], [510, 390], [522, 370], [530, 350]], false), '#d8c4c2', 10);

    // ── arms + gloved hands ──
    const armL = P([[14, 640], [30, 580], [80, 545], [150, 525], [220, 505], [252, 560], [256, 680], [230, 740], [160, 756], [60, 760], [20, 730]]);
    F(armL, '#0a0708');
    C(armL, () => {
      F(P([[40, 600], [90, 566], [150, 550], [120, 580], [70, 610]]), '#c89a9a'); F(P([[100, 620], [170, 590], [220, 590], [170, 620], [120, 640]]), '#e8b8b4');
      F(P([[30, 680], [80, 650], [120, 660], [60, 700]]), '#a87c80'); F(P([[200, 540], [236, 530], [244, 600], [226, 650], [214, 600]]), '#e0aaa8');
      blurred(6, () => { F(P([[20, 640], [70, 590], [140, 566], [190, 560], [150, 600], [90, 630], [40, 670]]), 'rgba(236,190,190,0.55)'); F(P([[60, 720], [120, 690], [180, 680], [140, 720], [80, 740]]), 'rgba(220,200,206,0.5)'); });
    });
    const handL = P([[150, 680], [200, 660], [250, 664], [280, 690], [270, 730], [230, 740], [200, 740], [170, 720]]);
    F(handL, '#0a0708');
    C(handL, () => { F(P(blob(200, 700, 28, 14, 3, 10, 0.3)), '#f2ecea'); F(P(blob(250, 690, 16, 12, 4, 9, 0.3)), '#f2ecea'); F(circleP(225, 728, 8), '#f2ecea'); });
    for (const [x, y, rx, ry, sd] of [[176, 690, 26, 16, 21], [214, 672, 22, 12, 22], [200, 730, 14, 18, 23], [262, 712, 12, 16, 24], [236, 748, 8, 10, 25], [160, 720, 10, 8, 26]]) F(P(blob(x, y, rx, ry, sd, 9, 0.35)), '#f4eeec');
    F(P(blob(286, 670, 22, 26, 5, 10, 0.25)), '#d8c4c2');
    const armR = P([[540, 560], [600, 540], [680, 540], [736, 520], [736, 660], [680, 660], [620, 640], [580, 620], [560, 600]]);
    F(armR, '#0a0708');
    F(P([[690, 548], [736, 530], [736, 660], [700, 662]]), '#f0c0c4');
    C(armR, () => { F(P([[560, 580], [600, 560], [640, 566], [600, 590]]), '#7a6a70'); });

    // ── teapot: orange/white body, spout, black hand silhouette ──
    const pot = circleP(450, 707, 132);
    F(pot, '#f6f2ee');
    C(pot, () => {
      F(P([[318, 700], [330, 640], [370, 600], [420, 580], [470, 584], [440, 620], [410, 660], [400, 720], [420, 780], [380, 800], [340, 780]]), '#f2862e');
      F(P([[430, 640], [480, 620], [540, 640], [580, 690], [560, 740], [510, 760], [460, 740], [440, 700]]), '#cbbfba');
      F(P([[480, 600], [520, 590], [560, 620], [540, 630]]), '#cbbfba');
      F(P([[480, 780], [540, 770], [560, 800], [500, 820]]), '#cbbfba');
      blurred(14, () => F(ellipseP(380, 640, 60, 50, 0), 'rgba(255,190,120,0.35)'));
    });
    F(P([[380, 690], [392, 680], [400, 700], [410, 684], [418, 700], [426, 690], [430, 720], [436, 760], [420, 790], [396, 790], [384, 760], [372, 740], [366, 712]]), '#080606');
    const spout = P([[330, 780], [370, 760], [404, 776], [410, 810], [380, 836], [340, 830], [322, 806]]);
    F(spout, '#f6f2ee'); K(spout, '#8a8282', 1.5);
    F(ellipseP(345, 806, 18, 14, 0.6), '#d8d2d0'); F(ellipseP(345, 806, 9, 7, 0.6), '#f8f6f4');
    F(P([[560, 620], [590, 600], [610, 620], [600, 650]]), '#f6f2ee');
    K(P([[430, 590], [436, 570]], false), '#d8d2d0', 6);

    // ── paper cup + glass bottle ──
    const cup = P([[72, 822], [170, 822], [162, 960], [84, 960]], true, false);
    F(cup, lin(72, 0, 170, 0, [[0, '#d8d4d6'], [0.4, '#fbfbfb'], [1, '#c8c4c6']])); F(ellipseP(121, 822, 49, 10, 0), '#e8e6e8'); F(ellipseP(121, 822, 44, 7, 0), '#cfcacc');
    F(ellipseP(123, 960, 39, 7, 0), '#b8b4b6');
    const bottle = P([[650, 890], [700, 890], [700, 920], [726, 940], [736, 1034], [596, 1034], [604, 960], [640, 920], [650, 910]]);
    F(bottle, lin(596, 0, 736, 0, [[0, '#8ab4c8'], [0.5, '#d8eef4'], [1, '#7aa8bc']]));
    C(bottle, () => F(P([[600, 990], [640, 970], [680, 980], [736, 975], [736, 1034], [596, 1034]]), '#5aa8c8'));
    F(rrect(646, 870, 72, 24, 10), '#c8dcd8'); F(P([[674, 870], [684, 830], [692, 870]]), '#4aa0a0');

    // ── soap bubbles ──
    const bub = (x, y, r) => {
      F(circleP(x, y, r), 'rgba(255,255,255,0.12)');
      K(circleP(x, y, r), lin(x - r, y - r, x + r, y + r, [[0, 'rgba(255,180,120,0.9)'], [0.4, 'rgba(160,240,255,0.9)'], [0.7, 'rgba(255,150,220,0.9)'], [1, 'rgba(120,200,120,0.9)']]), Math.max(1.5, r * 0.18));
      F(ellipseP(x - r * 0.35, y - r * 0.35, r * 0.25, r * 0.15, -0.7), 'rgba(255,255,255,0.95)');
    };
    for (const [x, y, r] of [[96, 418, 23], [30, 157, 15], [18, 270, 14], [86, 711, 18], [238, 826, 18], [186, 607, 13], [380, 565, 14], [340, 503, 12], [596, 228, 12], [543, 258, 13], [626, 478, 13],
      [657, 446, 9], [670, 510, 9], [592, 739, 8], [376, 912, 5], [618, 866, 5], [238, 216, 6], [556, 160, 6], [470, 470, 5]]) bub(x, y, r);
    { const r = rng(35); o.fillStyle = 'rgba(255,255,255,0.8)'; for (let i = 0; i < 60; i++) o.fill(circleP(r() * 726, r() * 900, 0.8 + r() * 2)); }

    E.grain(0.035, 35);
  }
});
