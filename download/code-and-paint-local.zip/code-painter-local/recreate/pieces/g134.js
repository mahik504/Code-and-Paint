'use strict';
// g134 — "Gold baubles elephant": a white clay creature with black spots carries a stack of mirror-gold
// spheres (each reflecting a sky, a town and a golden ground), chrome pipes and a white stick, against
// a blue backdrop and a lilac board printed with brown wavy blobs, standing in a milky puddle.
REC.register('g134', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024, S = E.S;
    const R = E.relief(), a = R.a;
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const radg = (x, y, r0, r1, st, x1 = x, y1 = y) => { const g = a.createRadialGradient(x, y, r0, x1, y1, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const soft = (fn, blur, alpha = 1, op = 'source-over', clip) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clip) a.clip(clip); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const all = rrect(-10, -10, W + 20, H + 20, 0);

    // ── backdrop ──
    R.flat(all, lin(0, 0, 200, 1000, [[0, '#406ec6'], [0.7, '#436ec2'], [1, '#5070b8']]), 0, 0);
    // lilac board with brown wavy blobs
    const board = P([[578, -10], [736, -10], [736, 720], [600, 720], [530, 560], [505, 400], [485, 300], [472, 200], [472, 103], [479, 58], [496, 32], [528, 17], [569, 21]]);
    R.flat(board, lin(480, 0, 726, 600, [[0, '#d2cce8'], [1, '#c4bcdc']]), 0, 0);
    const brown = '#3a1924';
    for (const pts of [
      [[725, 96], [710, 112], [695, 207], [677, 216], [634, 191], [621, 192], [614, 204], [620, 264], [610, 271], [581, 270], [570, 280], [574, 298], [640, 340], [652, 341], [659, 333], [664, 287], [672, 275], [703, 281], [711, 274], [736, 229], [736, 96]],
      [[736, -10], [625, -10], [624, 71], [617, 88], [600, 101], [576, 97], [537, 62], [522, 63], [515, 92], [532, 126], [522, 149], [528, 173], [553, 165], [569, 131], [603, 133], [631, 122], [647, 103], [681, 28], [697, 19], [736, 20]],
      [[736, 344], [707, 359], [698, 423], [682, 434], [651, 423], [642, 478], [662, 482], [683, 475], [708, 484], [736, 468]],
      [[617, 488], [593, 495], [586, 507], [591, 541], [607, 549], [613, 561], [621, 555], [640, 511], [638, 503]],
      [[599, 385], [587, 388], [535, 434], [532, 443], [577, 443], [582, 437], [577, 410], [600, 393]]])
      R.flat(P(pts), brown, 0, 0);
    // dark shadowed foot of the board
    R.flat(P([[736, 540], [690, 545], [662, 600], [668, 700], [655, 760], [640, 830], [600, 820], [560, 845], [510, 860], [520, 890], [600, 880], [700, 860], [736, 860]]), lin(600, 600, 726, 860, [[0, '#2e2646'], [1, '#262038']]), 0, 0);

    // ── floor ──
    R.flat(P([[0, 860], [200, 880], [400, 905], [600, 870], [736, 860], [736, 1034], [0, 1034]]), lin(0, 860, 0, 1024, [[0, '#4e6cb6'], [1, '#6a7cbc']]), 0, 0);
    R.flat(P([[560, 868], [736, 850], [736, 935], [640, 925], [560, 900]]), '#404e71', 0, 0);
    R.flat(P([[200, 905], [420, 905], [600, 890], [700, 935], [736, 940], [736, 1034], [0, 1034], [0, 1000], [100, 975], [200, 950]]), lin(200, 900, 600, 1000, [[0, '#b8aecb'], [0.5, '#bbb1ca'], [1, '#a6c6d0']]), 0, 0);
    R.flat(P([[470, 950], [600, 930], [736, 945], [736, 1034], [430, 1034]]), lin(470, 940, 726, 1024, [[0, '#a5cad2'], [1, '#8ab8cc']]), 0, 0);
    R.paint(P([[600, 882], [736, 912], [736, 926], [600, 896]], true, false), '#c8622c');
    R.paint(P([[600, 876], [736, 905], [736, 909], [600, 880]], true, false), '#f0e8e0');
    R.flat(P([[0, 1000], [60, 992], [140, 1004], [220, 1012], [260, 1034], [0, 1034]]), '#f2e4c6', 0, 0);
    const milk = P([[0, 1002], [52, 987], [50, 967], [91, 951], [121, 957], [152, 945], [209, 938], [260, 932], [330, 928], [420, 918], [500, 905], [560, 900], [620, 884], [650, 888], [636, 905], [560, 930], [520, 945], [500, 962], [470, 958], [440, 975], [470, 990], [420, 998], [350, 990], [300, 985], [260, 998], [200, 1004], [130, 1000], [60, 1010], [0, 1012]]);
    R.dome(milk, '#f4f0f0', 0.02, 0.04, 10, 3);
    { const r = rng(134); for (let i = 0; i < 110; i++) { const x = r() * 230, y = 840 + r() * 120; R.bead(x, y, 0.8 + r() * 2.6, '#f4f2f4', 0.03, 0.02, 3); }
      for (let i = 0; i < 50; i++) { const x = 560 + r() * 166, y = 830 + r() * 50; R.bead(x, y, 0.8 + r() * 2.4, '#f4f2f4', 0.03, 0.02, 3); } }

    // ── the white creature ──
    const body = P([[276, -10], [353, -10], [353, 50], [340, 95], [305, 150], [224, 238], [207, 275], [203, 311], [260, 290], [320, 280], [400, 300], [480, 330], [520, 420], [525, 560], [450, 610], [420, 720], [405, 880], [330, 922], [235, 932], [209, 905], [163, 860], [120, 790], [89, 726], [76, 687], [71, 614], [79, 571], [60, 500], [49, 433], [46, 352], [59, 290], [92, 221], [128, 175], [195, 117], [240, 80], [268, 40]]);
    R.dome(body, lin(40, 400, 420, 400, [[0, '#c4b4e0'], [0.2, '#e4dae8'], [0.45, '#f4eee6'], [1, '#f8f2e8']]), 0.05, 0.4, 90, 1);
    soft(x => { x.fillStyle = '#b8a8d8'; x.fill(ellipseP(100, 700, 40, 150, 0)); x.fill(ellipseP(120, 300, 30, 130, 0.4)); x.fillStyle = '#fbf6ee'; x.fill(ellipseP(330, 120, 18, 120, 0.5)); x.fill(ellipseP(330, 640, 60, 120, 0)); }, 30, 0.7, 'source-over', body);
    // cream wavy patch
    R.paint(P([[104, 456], [140, 446], [190, 462], [240, 476], [290, 478], [330, 488], [342, 512], [318, 526], [270, 520], [232, 532], [225, 570], [246, 610], [238, 650], [205, 640], [196, 600], [205, 560], [180, 520], [140, 500], [112, 482]]), '#ede4c8');
    // black spots (glossy holes)
    const spotA = P([[121, 279], [111, 302], [110, 327], [118, 351], [132, 367], [182, 387], [219, 390], [238, 385], [239, 375], [207, 355], [170, 306], [150, 272]]);
    const spotB = P([[175, 535], [163, 534], [155, 542], [152, 584], [131, 617], [132, 637], [145, 640], [164, 633], [185, 634], [195, 613], [196, 586], [190, 560]]);
    for (const sp of [spotA, spotB]) R.groove(sp, 6, null, 0.4, 0.15, 4, 0), R.flat(sp, '#08060a', 0.38, 4);
    soft(x => { x.fillStyle = '#6a3018'; x.fill(ellipseP(195, 372, 30, 8, 0.4)); x.fill(ellipseP(180, 610, 10, 18, 0.3)); }, 5, 0.9, 'source-over', spotA);
    // striped comb
    const comb = P([[205, 322], [222, 300], [250, 286], [282, 278], [305, 276], [312, 300], [302, 345], [290, 364], [240, 362], [214, 348]]);
    R.dome(comb, '#f4f0ec', 0.4, 0.06, 10, 4);
    a.save(); a.clip(comb); a.fillStyle = '#0a0a0c'; for (let k = 0; k < 10; k++) { const x0 = 208 + k * 11; a.beginPath(); a.moveTo(x0, 280); a.lineTo(x0 + 5, 280); a.lineTo(x0 + 22, 370); a.lineTo(x0 + 16, 370); a.fill(); } a.restore();

    // ── chrome pipes, gold spool, white stick, small balls ──
    R.pipe(P([[505, 285], [505, 540]], false), 30, '#d0d4dc', 0.5, 0.2, 2);
    R.dome(rrect(478, 270, 52, 36, 4), '#8a8c90', 0.55, 0.15, 10, 2);
    R.dome(rrect(486, 380, 40, 20, 4), '#8a8c90', 0.55, 0.12, 8, 2);
    R.pipe(P([[503, 495], [508, 450], [530, 410], [575, 385], [612, 372], [636, 384], [642, 420], [636, 470], [655, 500], [668, 530], [660, 570], [645, 600]], false), 24, '#d8dce4', 0.45, 0.2, 2);
    for (const [y, rx, ry] of [[432, 38, 10], [455, 46, 12], [497, 50, 14]]) R.dome(ellipseP(420, y, rx, ry, 0), '#f0cc70', 0.5, 0.12, 8, 5);
    R.pipe(P([[418, 420], [420, 505]], false), 34, '#f0cc70', 0.5, 0.15, 5);
    R.dome(ellipseP(420, 500, 54, 16, 0), '#f4d27a', 0.55, 0.12, 8, 5);
    R.pipe(P([[338, 584], [500, 497]], false), 24, '#f6f4f0', 0.55, 0.18, 6);
    R.dome(P([[322, 572], [338, 566], [352, 590], [336, 600]]), '#8a8a90', 0.6, 0.1, 6, 2);
    R.pipe(P([[352, 630], [366, 690]], false), 8, '#d06030', 0.5, 0.06, 6);
    R.bead(240, 451, 11, '#c8e030', 0.45, 0.1, 6);
    R.bead(290, 555, 11, '#e0e040', 0.45, 0.1, 6);
    R.bead(232, 575, 19, '#f01810', 0.45, 0.14, 6);
    R.bead(298, 615, 25, '#f8b8a0', 0.45, 0.16, 1);
    { const r = rng(7); a.save(); a.clip(circleP(298, 615, 25)); for (let i = 0; i < 40; i++) { a.fillStyle = r() < 0.7 ? '#e85030' : '#f0e040'; a.beginPath(); a.arc(275 + r() * 46, 592 + r() * 46, 1 + r() * 2, 0, 6.3); a.fill(); } a.restore(); }
    R.bead(38, 642, 9, '#e8f0f8', 0.2, 0.08, 6);
    R.pipe(P([[44, 700], [86, 708]], false), 9, '#f070a0', 0.2, 0.06, 6);
    // red + grey cylinders at the base
    R.pipe(P([[566, 852], [636, 846]], false), 50, '#8a8890', 0.3, 0.2, 2);
    R.dome(ellipseP(538, 862, 26, 28, 0), '#d81818', 0.3, 0.2, 12, 6);
    R.dome(ellipseP(532, 862, 12, 14, 0), '#3a0808', 0.42, 0.04, 4, 6);
    R.pipe(P([[630, 800], [636, 860]], false), 12, '#c8ccd4', 0.4, 0.1, 2);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.55, ao: 0.4, rim: 0.2 }),                         // 1 white clay
        E.mat({ dif: 0.4, metal: 0.9, spec: 1.4, shin: 80, ao: 0.3, rim: 0.2, tint: [0.92, 0.97, 1.08] }), // 2 chrome
        E.mat({ dif: 1, spec: 0.2, shin: 16, wrap: 0.5, ao: 0.2 }),                                     // 3 milk / floor
        E.mat({ dif: 0.6, spec: 1.2, shin: 70, wrap: 0.2, coat: 0.25, ao: 0.3 }),                       // 4 gloss black
        E.mat({ dif: 0.6, metal: 0.8, spec: 1.6, shin: 50, ao: 0.2, emis: 0.15, tint: [1.15, 0.95, 0.6] }), // 5 gold
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.3, coat: 0.15, ao: 0.3 })                          // 6 gloss plastic
      ],
      light: [0.45, 0.55, 0.7], lc: [0.55, 0.53, 0.5], amb: [0.56, 0.54, 0.6],
      envTop: [1.0, 0.97, 0.92], envHor: [0.95, 0.85, 0.62], envBot: [0.6, 0.45, 0.22], envK: [0.3, 1.0, 0.3, 0],
      rimC: [0.25, 0.3, 0.6], rimD: [-0.6, 0.3, 0.5], r1: 1.5, r2: 9, k: [0, 0.6, 0.4, 70], shadow: [8, 6, 0.4, 5]
    });

    // ── mirror-gold spheres (reflection mapped in GLSL) ──
    const o = E.out;
    const SPH = [[221, 98, 29, 4], [440, 180, 86, 8], [385, 342, 90, 8], [522, 244, 28, 0], [668, 606, 14, 0], [529, 682, 151, 10], [277, 778, 113, 9],
      [365, 722, 28, 0], [415, 712, 32, 0], [455, 768, 27, 0], [380, 796, 22, 0], [430, 812, 38, 5], [453, 866, 24, 0]];
    const src = SPH.map(s => `vec4(${s.map(v => v.toFixed(1)).join(',')})`).join(',');
    const chrome = E.fx(`
      const vec4 SPS[${SPH.length}] = vec4[${SPH.length}](${src});
      vec3 env(vec3 R){
        float t = -.25, y = R.y * cos(t) - R.z * sin(t), z = R.z * cos(t) + R.y * sin(t);
        float az = atan(R.x, z);
        vec3 sky = mix(vec3(.94,.91,.85), vec3(.72,.77,.81), smoothstep(.12, .8, y));
        sky = mix(sky, vec3(.32,.21,.10), smoothstep(-.15, -.7, z) * smoothstep(.02, .35, y) * (.6 + .4 * vnoise(vec2(az * 8., y * 6.))));
        float cell = floor(az * 5. + 2.), cell2 = floor(az * 23.);
        float bt = .0 + .2 * hash(vec2(cell, 3.)) * step(.45, hash(vec2(cell, 9.))) + .07 * hash(vec2(cell2, 5.)) + .03 * vnoise(vec2(az * 40., 1.));
        vec3 bld = mix(vec3(.50,.32,.16), vec3(.82,.60,.36), vnoise(vec2(az * 25., y * 14.)));
        bld *= 1. - .25 * step(.7, fract(az * 45. + .3 * hash(vec2(cell2, 1.)))) * step(.6, fract(y * 22.));
        vec3 gnd = mix(vec3(.84,.70,.30), vec3(.97,.80,.33), vnoise(vec2(az * 6., y * 4.)));
        gnd = mix(gnd, vec3(.55,.42,.25), smoothstep(-.75, -1., y));
        vec3 c = y > bt ? sky : (y > -.24 ? bld : gnd);
        c = mix(c, vec3(.96,.92,.80), smoothstep(.035, 0., abs(y - bt)) * .5);
        c = mix(c, vec3(.95,.93,.86), smoothstep(-.45, -.85, R.x) * smoothstep(-.35, -.05, y) * smoothstep(.55, .25, y) * .85);
        return c;
      }
      vec3 fx(vec2 uv, vec2 p){
        vec3 col = vec3(0.);
        for (int i = 0; i < ${SPH.length}; i++) {
          vec4 s = SPS[i];
          vec2 d = (p - s.xy) / s.z;
          float d2 = dot(d, d);
          if (d2 < 1.) {
            vec3 n = vec3(d.x, -d.y, sqrt(1. - d2));
            vec3 Rv = 2. * n.z * n - vec3(0., 0., 1.);
            vec3 c = env(Rv);
            c *= mix(1., .5, pow(1. - n.z, 2.));
            c = mix(c, c * vec3(1.05, .88, .55), .3);
            c += vec3(1., .95, .85) * pow(max(dot(n, normalize(vec3(-.3, .5, .8))), 0.), 60.) * .8;
            float hd = length(p - s.xy - s.z * vec2(.06, .06));
            c = mix(c, vec3(.03), smoothstep(s.w + .8, s.w - .8, hd) * step(.5, s.w));
            col = c;
          }
        }
        return col; }`);
    const sphClip = new Path2D(); for (const [x, y, r] of SPH) sphClip.addPath(circleP(x, y, r));
    o.save(); o.clip(sphClip); E.draw(chrome); o.restore();
    // green emblem on the small sphere
    o.fillStyle = '#58d838'; o.beginPath(); o.ellipse(528, 250, 13, 11, 0.3, 0, 6.3); o.fill();
    o.strokeStyle = '#d02828'; o.lineWidth = 2; o.beginPath(); o.arc(526, 250, 5, 0.5, 5.5); o.stroke();
    // pink glow between the spheres
    { const g = o.createRadialGradient(345, 670, 0, 345, 670, 70); g.addColorStop(0, 'rgba(255,90,120,0.75)'); g.addColorStop(1, 'rgba(255,90,120,0)'); o.fillStyle = g; o.fillRect(270, 590, 150, 160); }
    // glass ring
    o.save(); o.lineWidth = 12; o.strokeStyle = 'rgba(230,236,250,0.55)'; o.beginPath(); o.ellipse(85, 118, 27, 29, 0, 0, 6.3); o.stroke();
    o.lineWidth = 3; o.strokeStyle = 'rgba(255,255,255,0.8)'; o.beginPath(); o.ellipse(84, 116, 31, 33, 0, 3.4, 5.6); o.stroke();
    o.strokeStyle = 'rgba(240,200,150,0.6)'; o.beginPath(); o.ellipse(86, 120, 22, 24, 0, 0.2, 2.0); o.stroke(); o.restore();
    E.grain(0.035, 134);
  }
});
