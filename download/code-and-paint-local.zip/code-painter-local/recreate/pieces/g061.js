'use strict';
// g061 — "Clay planet spiral board": a cracked peach-and-tan clay planet with a blue eye beside a black/white
// zebra swirl, white spiral discs, an orange squiggle and pink tubes on black, blurred pale-blue balls and gold
// bottles in the foreground.
REC.register('g061', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x, x0, y0, x1, y1, st) => { const g = x.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, cx, cy, r0, r1, st, fx = cx, fy = cy) => { const g = x.createRadialGradient(fx, fy, r0, cx, cy, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };

    // ── ground: purple-black board ──
    R.flat(rrect(-10, -10, 746, 1044, 0), lin(a, 0, 400, 726, 700, [[0, '#120c14'], [0.6, '#1c1220'], [1, '#2e1c34']]), 0, 0);

    // ── zebra fields (top swirl + lower-left waves) ──
    const zcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 c = vec2(506., 122.), q = p - c;
      float r = length(q / vec2(1.18, 1.0));
      float ang = acos(clamp(q.y / (length(q) + 1e-3), -1., 1.));
      float d = r / (1. + 0.6 * pow(max(0., 1. - ang / 1.25), 1.6));
      float w = (fbm(p * 0.007) - .5) * 0.9;
      float s = sin(6.2832 * (d / 23. + w));
      vec3 zeb = mix(vec3(.03, .03, .04), vec3(.93, .93, .92), smoothstep(.2, .5, s));
      float dI = length(q / vec2(1.15, 0.92));
      float sf = sin(6.2832 * (dI / 10. + w * .3));
      vec3 fine = mix(vec3(.42, .42, .43), vec3(.80, .80, .80), smoothstep(-.6, .6, sf));
      vec3 top = mix(zeb, fine, smoothstep(90., 74., dI));
      float w2 = (fbm(p * 0.009 + 3.) - .5) * 2.2 + .5 * sin(p.y * .025);
      float s2 = sin(6.2832 * (dot(p, vec2(.86, .5)) / 24. + w2));
      vec3 low = mix(vec3(.03, .03, .04), vec3(.94, .94, .93), smoothstep(.36, .62, s2));
      return p.y < 440. ? top : low; }`);
    const topZ = P([[150, -10], [740, -10], [740, 190], [640, 382], [480, 352], [350, 356], [330, 430], [150, 430]], true, false);
    clipA(topZ, () => img(zcv));
    const lowZ = P([[100, 482], [180, 484], [250, 482], [292, 492], [236, 512], [205, 600], [175, 720], [160, 820], [-10, 820], [-10, 690], [22, 640], [62, 560]], true, true);
    clipA(lowZ, () => img(zcv));
    // light-blue glass slab, top right
    R.flat(P([[636, -10], [740, -10], [740, 205], [712, 180]], true, false), lin(a, 640, 0, 726, 180, [[0, '#a8d6e8'], [0.5, '#7cc0d8'], [1, '#c4e4ee']]), 0.05, 4);
    // cream frame
    R.pipe(P([[476, 358], [560, 368], [630, 378], [666, 272], [708, 176], [740, 150]], false, false), 30, '#f2dc9c', 0.06, 0.1, 3);
    R.pipe(P([[634, 366], [668, 272], [712, 172]], false, false), 40, '#f2dc9c', 0.06, 0.1, 3);
    R.dome(P([[436, -12], [530, -12], [520, 18], [450, 14]], true, false), '#e8d098', 0.05, 0.06, 6, 3);
    R.dome(P([[556, -12], [646, -12], [640, 14], [566, 20]], true, false), '#e8d098', 0.05, 0.06, 6, 3);
    // top-left sky blue
    R.flat(P([[-10, -10], [112, -10], [70, 30], [24, 70], [-10, 96]], true, true), '#1680ea', 0, 0);
    // white sheet at the left edge
    R.flat(P([[-10, 400], [70, 420], [104, 466], [62, 560], [22, 640], [-10, 690]], true, true), lin(a, 0, 420, 0, 690, [[0, '#f0e2d6'], [0.5, '#f6ece6'], [1, '#cdb8b4']]), 0.02, 4);
    R.pipe(P([[112, 462], [84, 512], [62, 560], [34, 616], [10, 660], [-10, 690]], false), 12, '#f27218', 0.06, 0.08, 2);
    R.bead(8, 598, 24, '#8e9ee2', 0.06, 0.06, 2);
    keep();

    // ── clay planet ──
    const disc = P([[-40, 110], [0, 88], [50, 40], [100, 2], [130, -20], [212, -24], [292, 78], [360, 172], [390, 284], [376, 350], [340, 392], [290, 420], [200, 452], [110, 466], [30, 452], [-40, 420]], true, true);
    R.pipe(P([[340, 400], [290, 430], [250, 446], [190, 466], [120, 474]], false), 12, '#ec5a26', 0.04, 0.06, 2);
    R.dome(disc, rad(a, 150, 230, 20, 330, [[0, '#f8c4a6'], [0.6, '#f6b294'], [1, '#f2a07a']]), 0.06, 0.32, 90, 1);
    clipA(disc, () => {
      soft(x => { x.lineWidth = 46; x.strokeStyle = '#f2802c'; x.stroke(P([[-20, 150], [20, 112], [70, 66], [130, 22], [180, -10]], false)); x.lineWidth = 30; x.stroke(P([[-10, 104], [50, 50], [110, 4]], false)); }, 8, 0.95);
      // tan clay plates
      const tan = '#dcb274';
      soft(x => {
        x.fillStyle = tan;
        x.fill(P([[110, 150], [160, 136], [215, 124], [268, 108], [330, 146], [376, 240], [376, 330], [330, 392], [230, 444], [140, 452], [104, 420], [120, 370], [96, 330], [126, 290], [110, 250], [140, 220], [114, 186]], true, true));
        for (const [cx, cy, rx, ry, sd] of [[146, 58, 16, 9, 1], [176, 116, 26, 12, 2], [262, 112, 18, 9, 3], [214, 98, 12, 6, 4], [108, 104, 10, 6, 5], [60, 278, 24, 10, 6], [124, 352, 16, 8, 7], [30, 320, 12, 6, 8], [280, 70, 14, 6, 9]])
          x.fill(P(blob(cx, cy, rx, ry, sd, 10, 0.35)));
      }, 1.2, 1);
      soft(x => { x.fillStyle = '#c49660'; x.fill(P([[300, 330], [360, 300], [366, 360], [320, 400], [260, 430]], true, true)); }, 14, 0.5);
    });
    // cracks
    const crack = pts => R.groove(P(pts, false), 6, '#2a1608', 0.38, 0.14, 1, 0.95);
    R.groove(P([[256, 246], [262, 274], [258, 300]], false), 16, '#1a0e06', 0.38, 0.2, 1, 1);
    crack([[256, 300], [220, 310], [180, 316], [150, 380], [120, 460]]);
    crack([[254, 246], [300, 226], [340, 214], [374, 206]]);
    crack([[262, 300], [290, 330], [314, 348], [340, 380]]);
    crack([[252, 252], [200, 250], [150, 262], [120, 280]]);
    crack([[252, 246], [200, 210], [150, 176], [114, 154]]);
    crack([[230, 312], [250, 360], [262, 420]]);
    // cream rim on the right
    R.pipe(P([[200, -14], [262, 40], [318, 112], [368, 196], [388, 284], [376, 346], [338, 390], [290, 418], [210, 446], [112, 460]], false), 20, '#f4e4ac', 0.2, 0.14, 3);
    // blue eye
    R.pipe(P([[-10, 140], [30, 116], [76, 102]], false), 11, '#2148b4', 0.3, 0.1, 2);
    R.dome(ellipseP(62, 198, 62, 42, -0.55), '#1a44c6', 0.3, 0.12, 14, 2);
    R.dome(ellipseP(82, 172, 30, 17, -0.55), '#f6f6f2', 0.4, 0.05, 6, 2);
    R.bead(50, 180, 8, '#f2d02a', 0.45, 0.06, 2);
    R.bead(70, 207, 8, '#f2d02a', 0.45, 0.06, 2);
    R.bead(40, 201, 5, '#d8e0ff', 0.45, 0.04, 2);
    // lavender dots
    R.bead(310, 190, 28, '#8c9ee4', 0.36, 0.06, 2);
    R.bead(64, 410, 31, '#8c9ee4', 0.36, 0.06, 2);
    keep();

    // ── blue strip with chips, hole and scribbles ──
    soft(x => {
      const r = rng(5); x.strokeStyle = '#2a58d8';
      for (let i = 0; i < 60; i++) {
        const ang = 1.2 + (r() - 0.5) * 2.4, L = 30 + r() * 80, x0 = 360 + r() * 110, y0 = 425 + r() * 20;
        x.lineWidth = 0.8 + r() * 1.6; x.beginPath(); x.moveTo(x0, y0);
        x.quadraticCurveTo(x0 + Math.cos(ang) * L * 0.5 + (r() - 0.5) * 20, y0 + Math.sin(ang) * L * 0.5, x0 + Math.cos(ang) * L, y0 + Math.sin(ang) * L); x.stroke();
      }
    }, 0.6, 0.85);
    const strip = P([[352, 354], [470, 350], [560, 372], [604, 386], [612, 412], [592, 424], [360, 420], [344, 392]], true, true);
    R.pipe(P([[360, 418], [470, 420], [590, 424], [612, 404]], false), 10, '#f26c16', 0.1, 0.08, 2);
    R.dome(strip, lin(a, 350, 360, 610, 420, [[0, '#2c50c8'], [1, '#2240b0']]), 0.1, 0.06, 8, 2);
    R.flat(ellipseP(456, 426, 46, 22, 0), '#050406', 0.06, 0);
    for (const [cx, cy, sd] of [[372, 390, 1], [456, 388, 2], [536, 397, 3]]) {
      R.dome(rrect(cx - 22, cy - 13, 44, 26, 3), '#c49c68', 0.17, 0.04, 3, 4);
      clipA(rrect(cx - 22, cy - 13, 44, 26, 3), () => { const r = rng(sd); a.strokeStyle = '#7a5434'; a.lineWidth = 1.5; for (let k = 0; k < 4; k++) { a.beginPath(); a.moveTo(cx - 20, cy - 8 + k * 5 + r() * 2); a.bezierCurveTo(cx - 6, cy - 12 + k * 5, cx + 6, cy - 2 + k * 5, cx + 20, cy - 8 + k * 5 + r() * 3); a.stroke(); } });
    }
    keep();

    // ── spiral discs ──
    const SP = [[345, 530, 90, 9.6], [190, 538, 52, 8.6], [252, 672, 94, 10.4], [110, 704, 42, 8.2]];
    const scv = E.fx(`const vec4 SP[4] = vec4[4](${SP.map(s => `vec4(${s.map(v => v.toFixed(1)).join(',')})`).join(',')});
      vec3 fx(vec2 uv, vec2 p){
        for (int i = 0; i < 4; i++) {
          vec2 q = p - SP[i].xy; float r = length(q);
          if (r < SP[i].z) {
            float th = atan(q.y, q.x);
            float s = sin(6.2832 * (r / SP[i].w - th / 6.2832));
            float c = smoothstep(-.05, .3, s) * smoothstep(3., 9., r);
            return mix(vec3(.03, .03, .04), vec3(.95, .95, .94), c);
          }
        }
        return vec3(.03); }`);
    R.pipe(circleP(345, 532, 92), 8, '#f2741c', 0.1, 0.08, 2);
    for (const [cx, cy, rr] of SP) {
      const c = circleP(cx, cy, rr);
      R.dome(c, null, 0.08, 0.06, 6, 5);
      clipA(c, () => img(scv));
    }
    R.pipe(circleP(252, 672, 95), 4, '#f0f0ee', 0.12, 0.04, 5);
    keep();

    // ── orange squiggle, orange discs ──
    const sq = [[486, 474], [500, 500], [504, 530], [490, 556], [462, 574], [438, 598], [434, 628], [440, 650], [424, 676], [404, 700], [390, 728], [376, 752]];
    R.pipe(P(sq, false), 32, '#f8740c', 0.12, 0.16, 2);
    R.bead(486, 482, 22, '#f8740c', 0.12, 0.18, 2);
    R.bead(722, 366, 16, '#f6720e', 0.1, 0.12, 2);
    R.bead(476, 650, 5, '#5ab8f0', 0.12, 0.06, 2);

    // ── blue-violet panel bottom right ──
    const panel = P([[576, 620], [640, 598], [700, 520], [740, 440], [740, 1040], [600, 1040], [584, 860], [570, 790], [562, 720], [568, 660]], true, false);
    R.flat(panel, lin(a, 540, 600, 726, 900, [[0, '#6670c4'], [0.5, '#5c6cd0'], [1, '#4a62c0']]), 0.03, 6);
    clipA(panel, () => soft(x => {
      x.fillStyle = '#867068'; x.fill(P(blob(690, 765, 56, 78, 11, 12, 0.18)));
      x.fill(P(blob(612, 612, 40, 18, 12, 10, 0.3)));
      x.fillStyle = '#7a5a6a'; x.fill(P(blob(560, 640, 30, 30, 13, 10, 0.3)));
    }, 3, 1));
    clipA(panel, () => { const r = rng(9); a.fillStyle = '#1a1218'; for (let i = 0; i < 40; i++) { a.beginPath(); a.arc(640 + r() * 90, 690 + r() * 160, 0.8 + r() * 2.4, 0, 6.283); a.fill(); } });

    R.dome(circleP(694, 545, 38), '#fb7410', 0.1, 0.08, 14, 2);
    // ── pink tubes ──
    const PK = '#f26ec6';
    for (const pts of [
      [[654, 352], [698, 358], [716, 384], [706, 418], [672, 446], [620, 470], [580, 490], [546, 506]],
      [[600, 486], [650, 466], [700, 448], [740, 434]],
      [[506, 640], [530, 618], [570, 608], [630, 600], [690, 596], [740, 588]],
      [[512, 632], [504, 680], [506, 730], [516, 770], [524, 792]],
      [[580, 610], [566, 660], [562, 720], [572, 790], [584, 860]],
      [[740, 690], [690, 694], [652, 716], [640, 766], [660, 818], [700, 842], [740, 850]]])
      R.pipe(P(pts, false), 13, PK, 0.14, 0.1, 2);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.12, shin: 14, wrap: 0.45, ao: 0.6, grain: 0.12, rim: 0.2 }),                 // 1 clay
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.3, coat: 0.12, ao: 0.4, rim: 0.3 }),                    // 2 glossy plastic
        E.mat({ dif: 1, spec: 0.4, shin: 30, wrap: 0.45, ao: 0.4, rim: 0.2 }),                               // 3 cream plastic
        E.mat({ dif: 0.9, spec: 0.3, shin: 20, wrap: 0.5, emis: 0.1 }),                                      // 4 glass / wood chips
        E.mat({ dif: 0.85, spec: 0.5, shin: 40, wrap: 0.6, emis: 0.18, ao: 0.3 }),                           // 5 spiral discs
        E.mat({ dif: 0.8, spec: 0.2, shin: 20, wrap: 0.6, emis: 0.25 })                                      // 6 panel
      ],
      light: [-0.5, 0.62, 0.6], lc: [0.78, 0.76, 0.74], amb: [0.42, 0.4, 0.42],
      envTop: [1.05, 1.02, 1.0], envHor: [0.6, 0.55, 0.6], envBot: [0.15, 0.12, 0.15], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.35, 0.35, 0.5], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 90], shadow: [-6, 7, 0.6, 6]
    });

    // ── soft focus at the top ──
    { const c = E.snapshot(), c2 = E.newCanvas(), x = c2.getContext('2d');
      x.filter = `blur(${1.6 * S}px)`; x.drawImage(c, 0, 0);
      const m = E.newCanvas(), mx = m.getContext('2d'); mx.fillStyle = lin(mx, 0, 0, 0, 280 * S, [[0, 'rgba(0,0,0,1)'], [1, 'rgba(0,0,0,0)']]); mx.fillRect(0, 0, m.width, m.height);
      mx.globalCompositeOperation = 'source-in'; mx.drawImage(c2, 0, 0);
      E.draw(m); }

    // ── blurred foreground: pale-blue balls, gold ball, gold bottles with grey caps, zebra dome ──
    const fg = E.newCanvas(), f = fg.getContext('2d'); f.setTransform(S, 0, 0, S, 0, 0);
    const ball = (cx, cy, r) => { f.fillStyle = rad(f, cx, cy, 0, r, [[0, '#dcf0f2'], [0.55, '#b4dce2'], [0.85, '#94c4cc'], [1, '#6c9ca6']], cx - r * 0.3, cy - r * 0.35); f.fill(circleP(cx, cy, r)); };
    // zebra dome
    { const dome = ellipseP(450, 1060, 210, 200, -0.12);
      f.fillStyle = '#1a1418'; f.fill(dome);
      f.save(); f.clip(dome); f.lineCap = 'butt';
      for (const [y0, y1, wd] of [[968, 870, 46], [1052, 944, 46]]) { f.strokeStyle = '#ece4de'; f.lineWidth = wd; f.beginPath(); f.moveTo(220, y0 + 10); f.quadraticCurveTo(440, (y0 + y1) / 2 - 22, 690, y1); f.stroke(); }
      f.restore(); }
    for (const [cx, cy, r] of [[300, 800, 42], [20, 770, 50], [118, 796, 80], [290, 856, 74], [420, 806, 54], [30, 996, 62], [180, 980, 56], [126, 950, 30]]) ball(cx, cy, r);
    // gold ball
    f.fillStyle = rad(f, 80, 886, 0, 68, [[0, '#fff6c0'], [0.15, '#f8cc48'], [0.5, '#c07c10'], [0.85, '#7a4808'], [1, '#4a2a06']], 64, 868); f.fill(circleP(80, 886, 68));
    const bottle = (cx, top, bx, bot, w0, w1) => {
      const pth = P([[cx - w0 / 2, top], [cx + w0 / 2, top], [bx + w1 / 2, bot], [bx - w1 / 2, bot]], true, false);
      f.fillStyle = lin(f, bx - w1 / 2, 0, bx + w1 / 2, 0, [[0, '#5a3006'], [0.3, '#d08a18'], [0.5, '#ffd060'], [0.7, '#b06a10'], [1, '#4a2804']]); f.fill(pth);
    };
    const cap = (cx, cy, r) => { f.fillStyle = rad(f, cx, cy, 0, r, [[0, '#b0b2b8'], [0.6, '#84868c'], [1, '#505056']], cx - r * 0.3, cy - r * 0.4); f.fill(circleP(cx, cy, r)); };
    for (const [cx, cy, r, bx, bot, w0, w1] of [[186, 690, 28, 214, 810, 18, 42], [346, 702, 30, 362, 880, 18, 46], [508, 780, 30, 480, 1000, 22, 84], [186, 882, 30, 222, 1030, 20, 52], [656, 886, 30, 634, 1040, 20, 52], [10, 712, 26, 36, 850, 16, 40]]) {
      bottle(cx, cy + r * 0.6, bx, bot, w0, w1); cap(cx, cy, r);
    }
    const fb = E.newCanvas(), fbx = fb.getContext('2d'); fbx.filter = `blur(${3.5 * S}px)`; fbx.drawImage(fg, 0, 0);
    E.draw(fb);

    E.bloom(0.08, 10);
    E.grain(0.03, 61);
  }
});
