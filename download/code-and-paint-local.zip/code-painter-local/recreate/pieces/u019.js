'use strict';
// u019 — "Zebra cartridge relic": a white clay slab on dark satin, flowing zebra grooves curling round a
// raised tongue, a glowing cyan-edged cartridge with a red window and a lamp, thorny drips and a bone lattice.
REC.register('u019', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };

    // ── dark satin backdrop: red glow bottom-left, violet top-right, steel blue bottom-right ──
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float f = fbm(p * vec2(0.004, 0.009) + vec2(3.1, 7.)) ;
      float fold = 0.5 + 0.5 * sin(p.y * 0.012 + p.x * 0.004 + f * 5.);
      vec3 c = vec3(0.235, 0.22, 0.225) * (0.72 + 0.55 * fold);
      c = mix(c, vec3(0.36, 0.34, 0.35), smoothstep(90., 0., p.x) * smoothstep(330., 450., p.y) * smoothstep(640., 560., p.y));
      c = mix(c, vec3(0.74, 0.74, 0.77), smoothstep(686., 712., p.x) * smoothstep(540., 600., p.y) * smoothstep(740., 680., p.y));
      c = mix(c, vec3(0.62, 0.61, 0.63), smoothstep(690., 715., p.x) * smoothstep(270., 300., p.y) * smoothstep(390., 350., p.y));
      c = mix(c, vec3(0.70, 0.24, 0.22), smoothstep(380., 0., length((p - vec2(0., 1010.)) * vec2(1., 1.4))));
      c = mix(c, vec3(0.55, 0.17, 0.15), smoothstep(150., 0., length((p - vec2(0., 100.)) * vec2(1., 0.9))) * 0.85);
      c = mix(c, vec3(0.45, 0.47, 0.56), smoothstep(330., 0., length(p - vec2(726., 960.))) * 0.9);
      c = mix(c, vec3(0.33, 0.30, 0.50), smoothstep(260., 0., length(p - vec2(726., 40.))) * 0.8);
      return c; }`));

    // ── the slab: one outline for the board and its striped handle ──
    const O = [[22, 18], [296, 18], [299, 80], [296, 112], [300, 126], [335, 121], [372, 117], [408, 124], [430, 142], [440, 168], [446, 194], [640, 210], [648, 240],
      [640, 500], [636, 700], [646, 735], [652, 780], [640, 812], [600, 828], [540, 836], [490, 842], [462, 856], [440, 880], [418, 908], [380, 927], [320, 936],
      [250, 935], [195, 928], [140, 914], [120, 898], [85, 888], [62, 866], [50, 820], [50, 700], [54, 500], [62, 360], [72, 290], [86, 240], [98, 196], [104, 168], [96, 148],
      [70, 128], [45, 100], [28, 66]];
    const board = P(O, true, true);
    // thorny drips round the rim (base x, y -> tip x, y, base width)
    const thorn = (x0, y0, x1, y1, w) => {
      const dx = x1 - x0, dy = y1 - y0, L = Math.hypot(dx, dy), nx = -dy / L, ny = dx / L;
      const ux = dx / L, uy = dy / L, tw = w * 0.3;
      return P([[x0 - dx * 0.4 + nx * w * 0.9, y0 - dy * 0.4 + ny * w * 0.9], [x0 + nx * w * 0.5, y0 + ny * w * 0.5], [x0 + dx * 0.6 + nx * w * 0.3, y0 + dy * 0.6 + ny * w * 0.3],
        [x1 - ux * tw + nx * tw, y1 - uy * tw + ny * tw], [x1 + ux * tw * 0.6, y1 + uy * tw * 0.6], [x1 - ux * tw - nx * tw, y1 - uy * tw - ny * tw],
        [x0 + dx * 0.6 - nx * w * 0.3, y0 + dy * 0.6 - ny * w * 0.3], [x0 - nx * w * 0.5, y0 - ny * w * 0.5], [x0 - dx * 0.4 - nx * w * 0.9, y0 - dy * 0.4 - ny * w * 0.9]]);
    };
    const TH = [[70, 272, 36, 262, 16], [60, 345, 44, 352, 12], [62, 445, 40, 440, 12], [58, 515, 16, 506, 18], [58, 565, 34, 560, 12], [55, 605, 20, 598, 16],
      [55, 700, 26, 690, 14], [55, 768, 22, 758, 22], [52, 800, 28, 814, 12],
      [446, 190, 440, 152, 14], [470, 192, 462, 146, 14], [528, 196, 532, 146, 16], [568, 198, 572, 148, 18], [575, 170, 596, 146, 10], [612, 205, 640, 168, 14],
      [632, 212, 664, 186, 12], [645, 240, 690, 242, 14], [650, 262, 702, 272, 12], [662, 300, 712, 292, 14], [690, 330, 714, 344, 10],
      [698, 520, 716, 500, 10], [690, 640, 712, 660, 10], [660, 700, 690, 726, 12], [648, 760, 664, 784, 12],
      [462, 846, 458, 884, 12], [488, 840, 490, 890, 14], [515, 836, 512, 866, 10], [546, 834, 550, 870, 12], [580, 830, 578, 860, 10], [610, 824, 612, 852, 10], [636, 806, 660, 832, 12]];
    for (const [x0, y0, x1, y1, w] of TH) R.dome(thorn(x0, y0, x1, y1, w * 1.9), '#cfd1d4', 0.1, 0.16, w * 0.8, 1);
    // bone lattice down the right side
    const lat = P([[626, 255], [660, 262], [690, 300], [705, 340], [706, 420], [702, 500], [697, 560], [692, 620], [680, 662], [660, 702], [640, 726], [624, 720]]);
    R.dome(lat, '#d8dcdd', 0.1, 0.16, 12, 1);
    // holes measured in the bone lattice (x, y, rx, ry, rot) + a few paler see-through ones
    for (const [x, y, rx, ry, rot, c] of [[652, 272, 5, 5.7, 2.51], [682, 303, 8, 16.6, 2.87], [681, 361, 13.4, 23, 0.12], [648, 377, 2.6, 7, 0.06], [653, 439, 6.5, 15.5, 2.99],
      [699, 442, 6.2, 41.5, 0.08], [666, 485, 4, 13, 0.02], [644, 504, 5, 13, 0.06], [697, 532, 3.4, 26.9, 0.08], [654, 541, 4.5, 7, 0.24], [639, 603, 4, 11, 3.09],
      [635, 678, 8.3, 25.8, 0.36], [672, 410, 7, 14, 0.1, 1], [676, 590, 7, 18, 0.1, 1], [662, 640, 6, 14, 0.2, 1], [684, 480, 5, 12, 0, 1], [640, 330, 5, 10, 0.2, 1]]) {
      const hole = ellipseP(x, y, rx + 1, ry + 1, rot);
      clipA(lat, () => { a.fillStyle = c ? '#8a8a90' : '#3a383c'; a.fill(hole); });
      R.h.save(); R.h.clip(lat); R.h.fillStyle = hc(0.02, 0); R.h.fill(hole); R.h.restore();
    }
    // the slab
    R.dome(board, '#c9cacf', 0.1, 0.16, 26, 1);
    soft(x => { fe(x, 560, 780, 120, 60, -0.2, '#a8aab0'); fe(x, 300, 880, 160, 40, -0.1, '#b4b6ba'); fe(x, 90, 500, 40, 260, 0, '#c8c8cc'); }, 30, 0.6);
    // zebra grooves (centrelines measured from the reference: width, x/y pairs)
    const ST = [
      [36, [58, 10, 93, 44, 117, 85, 163, 149, 181, 165, 191, 164]],
      [14, [268, 277, 263, 285, 259, 306, 259, 334, 262, 347, 274, 366, 279, 387]],
      [24, [279, 387, 317, 417, 330, 432, 339, 452, 341, 470, 337, 490, 322, 518, 304, 539, 254, 581, 230, 618, 220, 651, 226, 704, 258, 779, 275, 812, 289, 832, 318, 858, 378, 893, 396, 898, 397, 904]],
      [19.6, [324, 734, 338, 747, 358, 779, 371, 793, 401, 812, 421, 820, 452, 819, 480, 802, 505, 794, 552, 793, 594, 798, 602, 792]],
      [13.2, [523, 760, 514, 759, 490, 763, 451, 783, 439, 785, 423, 782, 397, 767, 351, 716, 317, 694, 309, 684, 309, 660, 317, 640, 331, 621, 370, 585, 391, 558, 413, 516, 418, 493, 417, 462, 402, 425, 382, 397, 332, 350, 325, 341, 315, 318, 310, 294, 312, 262, 325, 224, 339, 210]],
      [7.2, [302, 239, 306, 224, 317, 203, 325, 195, 335, 191]],
      [21.2, [294, 269, 288, 281, 288, 308, 295, 341, 308, 363, 343, 393, 369, 423, 382, 451, 385, 481, 378, 507, 361, 538, 343, 561, 299, 604, 287, 621, 277, 642, 272, 661, 271, 674, 275, 700, 290, 740, 312, 783, 327, 808, 343, 825, 405, 859, 413, 861, 434, 854]],
      [30.8, [160, 10, 190, 42, 239, 119, 243, 123, 255, 126]],
      [20, [221, 790, 198, 763, 196, 750, 172, 690, 165, 659, 164, 629, 171, 596, 180, 577, 195, 556, 227, 530, 274, 505, 285, 493, 291, 477, 290, 458, 277, 443, 265, 437]],
      [20, [290, 100, 275, 46, 248, 10]],
      [29.2, [64, 798, 71, 810, 78, 816, 118, 831, 188, 876, 215, 888, 231, 892, 246, 892]],
      [8, [346, 229, 336, 243, 328, 272, 330, 297, 337, 316]],
      [8.4, [292, 226, 290, 222, 299, 191, 308, 180, 318, 176]],
      [11.2, [333, 663, 332, 667, 335, 672, 374, 705, 415, 746, 435, 756, 448, 756, 455, 753]],
      [14, [224, 396, 233, 400, 238, 406, 248, 433]],
      [24.4, [326, 897, 312, 896, 284, 885, 179, 809, 139, 773, 114, 760, 75, 749, 64, 731]],
      [16, [631, 723, 613, 749, 608, 754, 596, 758, 582, 752, 562, 736, 539, 726, 489, 723, 461, 727, 445, 726, 416, 713, 408, 712]],
      [8.4, [345, 280, 349, 259, 364, 239]],
      [8.4, [270, 224, 285, 177, 297, 165, 311, 159]],
      [12.4, [226, 328, 224, 314, 232, 297]]];
    const stripes = ST.map(([w, f]) => { const pts = []; for (let i = 0; i < f.length; i += 2) pts.push([f[i], f[i + 1]]); return [w, P(pts, false, true)]; });
    clipA(board, () => {
      a.lineCap = a.lineJoin = 'round'; a.strokeStyle = '#1d1d22';
      for (const [w, p] of stripes) { a.lineWidth = w * 1.08 + 1; a.stroke(p); }
    });
    R.h.save(); R.h.clip(board); for (const [w, p] of stripes) R.groove(p, w * 1.15 + 2, null, 0.26, 0.025, 2); R.h.restore();
    // pin holes in the plain left field
    for (const [x, y] of [[150, 210], [197, 209], [127, 245], [175, 250], [109, 321], [121, 393], [142, 435], [183, 446], [109, 487], [160, 488], [220, 481], [126, 528], [131, 580], [101, 627], [127, 671]]) {
      R.flat(ellipseP(x, y, 3.2, 5, 0.4), '#2a2420', 0.12, 0);
    }
    // raised curl tongue and the rippled crest at the top
    const tongue = P([[306, 248], [296, 232], [268, 226], [236, 230], [204, 240], [176, 256], [152, 278], [138, 306], [134, 336], [142, 362], [162, 380], [196, 390], [230, 394],
      [246, 402], [252, 420], [256, 436], [263, 436], [265, 412], [262, 392], [250, 378], [228, 366], [214, 350], [208, 326], [212, 300], [226, 282], [250, 270], [280, 264], [300, 262]]);
    R.dome(tongue, '#d4d5d9', 0.26, 0.3, 30, 1);
    const crest = P([[296, 128], [330, 120], [372, 116], [408, 122], [432, 140], [444, 168], [446, 200], [438, 226], [420, 236], [400, 226], [386, 206], [366, 188], [340, 172], [312, 160], [298, 148]]);
    R.dome(crest, '#d2d3d7', 0.26, 0.16, 24, 1);
    for (let i = 0; i < 4; i++) R.groove(P([[352 + i * 8, 150 + i * 6], [385 + i * 8, 152 + i * 9], [410 + i * 6, 170 + i * 8]], false), 5, null, 0.36, 0.03, 1);

    // ── the cartridge ──
    const cart = P([[436, 198], [640, 212], [614, 722], [426, 708]], true, false);
    R.dome(cart, '#c6caca', 0.3, 0.06, 6, 3);
    R.groove(P([[440, 316], [632, 324]], false), 5, '#9fe8e4', 0.36, 0.03, 3);
    // slot
    const slot = P([[456, 252], [526, 252], [530, 272], [592, 274], [592, 290], [508, 290], [504, 270], [456, 270]], true, false);
    R.groove(slot, 8, '#8a9090', 0.36, 0.05, 3);
    R.flat(slot, '#c8d0d0', 0.31, 3);
    // inner plate and window frame
    const plate = P([[446, 336], [628, 344], [614, 704], [432, 694]], true, false);
    R.dome(plate, '#c8cece', 0.34, 0.03, 4, 3);
    const frameIn = P([[456, 352], [596, 360], [590, 672], [450, 668]], true, false);
    R.dome(frameIn, '#d4dcdc', 0.37, 0.03, 4, 3);
    const win = P([[468, 378], [580, 384], [576, 656], [466, 652]], true, false);
    R.flat(win, '#e6e9e8', 0.38, 3);
    // red cut-outs
    const REDS = [[[484, 644], [485, 647], [495, 647], [494, 643]], [[491, 591], [477, 593], [474, 596], [466, 619], [466, 631], [485, 619], [492, 599]],
      [[524, 584], [513, 592], [504, 624], [512, 638], [525, 651], [529, 651], [534, 587], [531, 584]],
      [[476, 500], [500, 492], [530, 488], [540, 496], [536, 561], [530, 565], [478, 575], [471, 574], [468, 567], [468, 547], [473, 519]],
      [[494, 447], [489, 447], [476, 473], [479, 479], [487, 476], [501, 464], [501, 458]], [[544, 389], [529, 401], [505, 432], [521, 465], [528, 472], [542, 476], [547, 407]],
      [[508, 385], [490, 404], [477, 408], [483, 419], [491, 418], [502, 402]]];
    for (const pts of REDS) R.flat(P(pts, true, false), '#cf5a50', 0.33, 5);
    R.dome(circleP(497, 545, 12), '#f0f2f2', 0.38, 0.06, 6, 3);
    R.dome(circleP(560, 527, 5), '#f0f2f2', 0.4, 0.04, 3, 3); R.dome(circleP(562, 410, 4), '#f0f2f2', 0.4, 0.04, 3, 3);

    // stray red specks on the cartridge top
    { const r = rng(5); for (let i = 0; i < 18; i++) R.paint(circleP(616 + r() * 18, 250 + r() * 14, 0.8 + r() * 1.2), '#a0302c'); }
    R.dome(circleP(655, 268, 7), '#b4483c', 0.3, 0.04, 4, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.45, shin: 30, wrap: 0.45, ao: 0.6, coat: 0.08, rim: 0.4 }),       // 1 white clay
        E.mat({ dif: 1, spec: 0.4, shin: 40, wrap: 0.3, ao: 0.3, coat: 0.05 }),                   // 2 glossy black grooves
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.5, ao: 0.4, rim: 0.3 }),                      // 3 cartridge plastic
        E.mat({}),
        E.mat({ dif: 0.8, spec: 0.3, shin: 20, wrap: 0.5, emis: 0.25 })                           // 5 red window
      ],
      light: [-0.35, 0.55, 0.75], lc: [0.6, 0.6, 0.63], amb: [0.5, 0.5, 0.53],
      envTop: [0.95, 0.96, 0.97], envHor: [0.52, 0.53, 0.55], envBot: [0.2, 0.18, 0.2], envK: [0.25, 0.8, 0.3, 0],
      rimC: [0.35, 0.38, 0.4], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 100], shadow: [5, 8, 0.6, 6]
    });

    // ── cyan glow edges, lamp ──
    const glow = (path, col, wd, px, al = 1) => { o.save(); o.globalAlpha = al; o.filter = `blur(${px * S}px)`; o.lineWidth = wd; o.strokeStyle = col; o.stroke(path); o.restore(); };
    for (const pth of [cart, plate, frameIn, win]) { glow(pth, '#7ff8f0', 5, 3, 0.45); glow(pth, '#e8fffc', 1.4, 0.5, 0.8); }
    glow(P([[440, 316], [632, 324]], false), '#7ff8f0', 4, 2, 0.8);
    o.save(); o.globalCompositeOperation = 'screen';
    for (const [r, c] of [[70, 'rgba(255,120,40,0.35)'], [34, 'rgba(255,200,80,0.7)'], [16, 'rgba(255,255,230,1)']]) {
      const g = o.createRadialGradient(512, 494, 0, 512, 494, r); g.addColorStop(0, c); g.addColorStop(1, 'rgba(255,120,40,0)'); o.fillStyle = g; o.fillRect(512 - r, 494 - r, 2 * r, 2 * r);
    }
    o.restore();
    E.grain(0.035, 19);

    // ── the card frame: iridescent border with scooped corners ──
    const fr = new Path2D(); fr.rect(-2, -2, 730, 1028);
    const R0 = 37, X0 = 3, X1 = 722, Y0 = 28, Y1 = 996;
    fr.moveTo(X0 + R0, Y0); fr.lineTo(X1 - R0, Y0); fr.arc(726, Y0, R0 - 4, Math.PI, Math.PI / 2, true); fr.lineTo(X1, Y1 - R0);
    fr.arc(726, Y1, R0 - 4, -Math.PI / 2, Math.PI, true); fr.lineTo(X0 + R0, Y1); fr.arc(0, Y1, R0 - 3, 0, -Math.PI / 2, true);
    fr.lineTo(X0, Y0 + R0); fr.arc(0, Y0, R0 - 3, Math.PI / 2, 0, true); fr.closePath();
    const fcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 tl = vec3(0.96, 0.92, 0.36), tc = vec3(0.90, 0.82, 0.83), tr = vec3(0.87, 0.53, 0.86);
      vec3 bl = vec3(0.95, 0.53, 0.56), bc = vec3(0.95, 0.83, 0.79), br = vec3(0.83, 0.89, 0.92);
      float x = p.x / 726.;
      vec3 top = x < 0.5 ? mix(mix(tl, vec3(0.94, 0.87, 0.72), smoothstep(0., 0.08, x)), tc, smoothstep(0.08, 0.5, x)) : mix(tc, tr, smoothstep(0.5, 1., x));
      vec3 bot = x < 0.5 ? mix(bl, bc, smoothstep(0.02, 0.5, x)) : mix(bc, br, smoothstep(0.5, 1., x));
      return mix(top, bot, smoothstep(0.25, 0.75, p.y / 1024.)); }`);
    o.save(); o.clip(fr, 'evenodd'); o.setTransform(1, 0, 0, 1, 0, 0); o.drawImage(fcv, 0, 0); o.restore();
    o.save(); o.setTransform(S, 0, 0, S, 0, 0);
    const inner = new Path2D(); inner.moveTo(X0 + R0, Y0); inner.lineTo(X1 - R0, Y0); inner.arc(726, Y0, R0 - 4, Math.PI, Math.PI / 2, true); inner.lineTo(X1, Y1 - R0);
    inner.arc(726, Y1, R0 - 4, -Math.PI / 2, Math.PI, true); inner.lineTo(X0 + R0, Y1); inner.arc(0, Y1, R0 - 3, 0, -Math.PI / 2, true); inner.lineTo(X0, Y0 + R0); inner.arc(0, Y0, R0 - 3, Math.PI / 2, 0, true); inner.closePath();
    o.lineWidth = 2; o.strokeStyle = 'rgba(200,160,70,0.7)'; o.stroke(inner); o.restore();
  }
});
