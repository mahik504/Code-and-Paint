'use strict';
// g039 — "Porcelain cell in glass": a glossy white porcelain mass under a gold-rimmed glass dome —
// a zebra-striped shell, a beige plate of gold-veined cells dotted with milk drops, a gold
// spiral shell with an eye, and a pile of pearly spheres, on a navy-to-pale studio backdrop.
REC.register('g039', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const W = 726, H = 1024, rr = rng(39);
    const PORC = '#cfcdd0', GOLD = '#e0b050';
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };

    // ── backdrop: black top, navy, blue, pale floor ──
    { const g = a.createLinearGradient(0, 0, 0, 1024);
      g.addColorStop(0, '#060709'); g.addColorStop(0.16, '#0a1020'); g.addColorStop(0.3, '#20407c'); g.addColorStop(0.55, '#6890bc'); g.addColorStop(0.78, '#b6c0d0'); g.addColorStop(1, '#c4c0c0');
      R.flat(rrect(-10, -10, W + 20, H + 20, 0), g, 0, 0); }
    R.flat(rrect(-10, 955, W + 20, 80, 0), '#bdb6b4', 0, 0);
    soft(x => { x.fillStyle = '#d8d4d4'; x.fill(ellipseP(640, 975, 140, 18, 0)); }, 12, 0.6);

    // ── glass dome (dark through the glass at the top), gold rim ──
    const glassPts = [[-10, 190], [8, 124], [40, 74], [100, 52], [180, 48], [250, 78], [300, 116], [350, 92], [410, 60], [470, 56], [530, 76], [576, 118], [612, 188], [640, 280], [656, 400], [664, 520], [664, 650], [656, 780], [640, 880], [606, 950], [560, 975], [-10, 975]];
    const glass = P(glassPts);
    R.flat(glass, '#0d1424', 0.02, 0);
    { const g = a.createLinearGradient(560, 0, 726, 0); g.addColorStop(0, 'rgba(40,70,130,0)'); g.addColorStop(1, 'rgba(70,110,170,0.6)'); clipA(glass, () => { a.fillStyle = g; a.fillRect(560, 100, 170, 900); }); }
    clipA(glass, () => { for (let i = 0; i < 160; i++) { const x = 190 + rr() * 380, y = 70 + rr() * 110; a.fillStyle = `rgba(255,255,255,${0.4 + rr() * 0.6})`; a.fill(circleP(x, y, 0.5 + rr() * 1.2)); } });

    // ── the porcelain body ──
    const body = P([[-10, 210], [14, 146], [40, 112], [80, 88], [160, 72], [200, 84], [240, 112], [290, 150], [340, 148], [378, 112], [404, 96], [440, 128], [470, 108], [502, 132], [540, 150], [574, 186], [604, 246], [626, 330], [638, 430], [644, 540], [646, 650], [640, 760], [622, 860], [592, 930], [550, 962], [-10, 970]]);
    { const g = a.createLinearGradient(0, 100, 600, 900); g.addColorStop(0, '#d4d2d2'); g.addColorStop(0.5, '#c4c2c2'); g.addColorStop(1, '#b4b0b2'); R.dome(body, g, 0.06, 0.16, 40, 1); }
    // brushed streaks on the porcelain
    clipA(body, () => { for (let i = 0; i < 80; i++) { const x = rr() * 620, y = 120 + rr() * 820; a.strokeStyle = `rgba(255,255,255,${0.08 + rr() * 0.12})`; a.lineWidth = 0.8; a.beginPath(); a.moveTo(x, y); a.lineTo(x + 40, y - 14); a.stroke(); } });
    clipA(body, () => { a.save(); a.globalCompositeOperation = 'multiply';
      const g = a.createLinearGradient(0, 0, 160, 0); g.addColorStop(0, 'rgba(70,70,84,1)'); g.addColorStop(1, 'rgba(255,255,255,0)'); a.fillStyle = g; a.fillRect(-10, 0, 170, 1024);
      const g2 = a.createRadialGradient(120, 760, 40, 120, 760, 300); g2.addColorStop(0, 'rgba(120,116,124,1)'); g2.addColorStop(1, 'rgba(255,255,255,0)'); a.fillStyle = g2; a.fillRect(-10, 450, 460, 580);
      a.restore(); });
    // spikes on the crown
    R.dome(P([[150, 110], [176, 54], [192, 108]]), '#e8e6ea', 0.2, 0.08, 10, 1);
    R.dome(P([[370, 150], [400, 92], [428, 150]]), '#e8e6ea', 0.2, 0.08, 12, 1);
    { const cone = P([[446, 196], [462, 128], [474, 104], [486, 128], [500, 196]]); R.dome(cone, '#c6c2c4', 0.2, 0.16, 18, 1);
      for (let y = 120; y < 196; y += 6) R.groove(P([[474 - (y - 104) * 0.36, y], [474 + (y - 104) * 0.36, y]], false), 2, '#8a8486', 0.34, 0.03, 1); }

    // ── zebra shell ──
    const zeb = P([[18, 330], [30, 250], [60, 190], [110, 158], [170, 150], [230, 170], [272, 210], [292, 268], [286, 330], [256, 370], [200, 396], [130, 406], [60, 396], [24, 370]]);
    R.dome(zeb, null, 0.12, 0.2, 60, 1);
    const zcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(236., 328.);
      float r = length(d), th = atan(d.y, d.x);
      float ph = th * 2.7 + 0.016 * r + 0.2 * sin(r * 0.015);
      float s = sin(6.2832 * ph);
      vec3 c = mix(vec3(.03,.03,.05), vec3(.97,.97,.98), smoothstep(-0.2, 0.2, s));
      return mix(vec3(.02), c, smoothstep(6., 16., r)); }`);
    clipA(zeb, () => img(zcv));
    R.dome(P([[40, 372], [62, 352], [96, 358], [120, 350], [134, 372], [120, 394], [124, 412], [104, 416], [88, 400], [62, 396], [44, 390]]), '#e6dcc8', 0.26, 0.08, 10, 1);

    // ── beige plate of gold-veined cells ──
    const plate = P([[350, 250], [400, 230], [470, 216], [530, 214], [570, 250], [600, 300], [610, 360], [600, 420], [580, 470], [576, 520], [590, 580], [600, 640], [580, 682], [540, 702], [470, 702], [420, 722], [350, 722], [290, 702], [250, 692], [215, 652], [205, 600], [230, 540], [248, 500], [230, 450], [240, 400], [280, 370], [320, 330], [345, 290]]);
    R.dome(plate, '#d8c4a4', 0.14, 0.04, 10, 3);
    clipA(plate, () => soft(x => { x.fillStyle = '#c8b090'; for (let i = 0; i < 10; i++) x.fill(circleP(240 + rr() * 360, 240 + rr() * 460, 30 + rr() * 30)); }, 20, 0.35));
    const cells = [[372, 292, 40, 34], [450, 262, 34, 26], [520, 300, 48, 40], [300, 400, 50, 34], [400, 372, 54, 46], [512, 392, 48, 40], [570, 360, 22, 40],
      [282, 478, 34, 30], [370, 470, 50, 38], [470, 470, 46, 36], [548, 470, 26, 34], [258, 576, 40, 46], [350, 560, 50, 40], [450, 556, 46, 38], [540, 560, 34, 42],
      [300, 660, 46, 30], [400, 650, 48, 40], [500, 650, 40, 36], [560, 640, 22, 26]];
    for (let i = 0; i < cells.length; i++) {
      const [x, y, rx, ry] = cells[i];
      const pth = P(blob(x, y, rx * 1.18, ry * 1.18, 100 + i, 12, 0.16, rr() * 0.6 - 0.3));
      R.pipe(pth, 8, GOLD, 0.2, 0.06, 2);
    }
    for (let i = 0; i < 320; i++) {   // milk drops
      const x = 220 + rr() * 390, y = 230 + rr() * 480; a.save(); const inside = a.isPointInPath(plate, x * S, y * S); a.restore(); if (!inside) continue;
      const rx = 3 + rr() * 8, ry = rx * (0.45 + rr() * 0.4);
      R.dome(ellipseP(x, y, rx, ry, rr() * 3), '#f0eef0', 0.2, 0.05, Math.min(rx, ry), 1);
    }
    // gold knobs
    R.bead(522, 232, 22, GOLD, 0.24, 0.12, 2);
    R.bead(64, 168, 10, GOLD, 0.26, 0.08, 2); R.bead(232, 160, 7, GOLD, 0.26, 0.06, 2);

    // ── gold shell with an eye ──
    const shell = P([[390, 770], [410, 730], [450, 712], [500, 712], [540, 724], [580, 750], [600, 790], [596, 840], [570, 880], [530, 900], [480, 896], [440, 870], [410, 832]]);
    R.dome(shell, '#e0a858', 0.22, 0.16, 40, 2);
    for (let k = 1; k <= 12; k++) R.groove(P([[420 + k * 4, 860 - k * 3], [470, 800 + k * 2], [530 + k * 4, 740 + k * 4], [590 - k * 2, 780 + k * 4]], false), 3, '#8a5a20', 0.36, 0.04, 2);
    R.dome(P([[396, 718], [430, 696], [474, 700], [494, 722], [470, 740], [430, 740]]), '#3c4c8c', 0.26, 0.06, 10, 3);
    for (let k = 0; k < 6; k++) R.pipe(P([[404 + k * 3, 720 + k * 2], [440, 708 + k * 4], [480, 716 + k * 3]], false), 2, '#e8ecf8', 0.34, 0.02, 3);
    R.dome(circleP(486, 764, 30), '#f2f0f4', 0.34, 0.1, 14, 3);
    R.dome(circleP(486, 764, 18), '#2a3240', 0.42, 0.04, 6, 3);
    R.dome(circleP(486, 764, 11), '#050508', 0.44, 0.04, 6, 3);
    R.bead(480, 756, 4, '#ffffff', 0.5, 0.03, 3);
    R.dome(P([[352, 760], [380, 750], [400, 780], [390, 806], [360, 808], [348, 786]]), '#141418', 0.2, 0.02, 6, 3);

    // ── pearly spheres and holes ──
    const holes = [[40, 640, 18], [66, 600, 12], [30, 700, 10], [140, 905, 22], [240, 895, 28], [56, 860, 18], [176, 850, 18], [20, 910, 14], [36, 505, 9], [16, 600, 10], [608, 492, 6]];
    for (const [x, y, r] of holes) { R.groove(circleP(x, y, r), 6, '#9a9498', 0.2, 0.06, 1); R.flat(circleP(x, y, r), '#0e0c10', 0.08, 0); }
    const spheres = [[165, 445, 30], [95, 462, 20], [24, 462, 15], [140, 562, 38], [216, 562, 26], [158, 656, 36], [72, 700, 22], [40, 790, 40], [100, 760, 20],
      [184, 750, 62], [300, 776, 48], [330, 862, 40], [360, 940, 56], [92, 980, 46], [196, 986, 44], [424, 966, 38], [266, 960, 30], [250, 820, 20],
      [600, 560, 36], [606, 700, 26], [622, 630, 20], [566, 430, 16], [580, 650, 14], [430, 192, 16], [366, 182, 16], [24, 220, 12], [40, 200, 10]];
    for (const [x, y, r] of spheres) R.bead(x, y, r, x < 300 && y > 600 ? '#a49a9e' : '#b8aeb2', 0.2, Math.min(0.35, r * 0.006 + 0.12), 1);
    for (const [x, y, r] of [[186, 614, 5], [262, 828, 7], [416, 890, 7], [394, 214, 9], [568, 516, 8], [566, 634, 7], [520, 452, 10]]) {
      R.bead(x, y, r, '#5a6a9c', 0.3, 0.05, 3); R.pipe(circleP(x, y, r * 0.6), 1.5, '#f0f0f8', 0.4, 0.01, 3);
    }
    // little zebra shell peeking at bottom right
    const z2 = P([[606, 848], [640, 830], [660, 870], [662, 930], [640, 950], [612, 930]]);
    R.dome(z2, '#d8d8dc', 0.1, 0.12, 20, 2);
    clipA(z2, () => { for (let k = 0; k < 6; k++) { a.strokeStyle = '#060608'; a.lineWidth = 6; a.beginPath(); a.moveTo(600 + k * 12, 960); a.quadraticCurveTo(640 + k * 6, 900, 610 + k * 14, 830); a.stroke(); } });

    // gold rim of the glass
    R.pipe(P(glassPts.slice(6, 20), false), 9, '#f0c060', 0.2, 0.1, 2);
    R.pipe(P(glassPts.slice(1, 7), false), 4, '#c8d0e0', 0.2, 0.05, 4);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.95, spec: 1.0, shin: 60, wrap: 0.3, ao: 0.6, coat: 0.3, rim: 0.6 }),                // 1 porcelain
        E.mat({ dif: 0.8, metal: 0.55, spec: 1.3, shin: 50, ao: 0.5, tint: [1.15, 0.95, 0.55], rim: 0.3, emis: 0.18 }), // 2 gold
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.5, ao: 0.4, grain: 0.1, emis: 0.15 }),               // 3 beige plate / matte
        E.mat({ dif: 0.3, spec: 1.2, shin: 90, coat: 0.5, rim: 0.4 })                                     // 4 glass
      ],
      light: [-0.4, 0.65, 0.65], lc: [0.92, 0.9, 0.88], amb: [0.32, 0.31, 0.3],
      envTop: [1.12, 1.1, 1.08], envHor: [0.58, 0.56, 0.56], envBot: [0.1, 0.09, 0.1], envK: [0.4, 1.3, 0.2, 0],
      rimC: [0.15, 0.17, 0.25], rimD: [0, 1, 0], l2: [0.85, 0.15, 0.45, 2], l2c: [0.45, 0.45, 0.46], r1: 1.4, r2: 7, k: [0, 0.6, 0.4, 100], shadow: [-4, 6, 0.6, 7]
    });
    E.bloom(0.1, 8);
    E.grain(0.025, 39);
  }
});
