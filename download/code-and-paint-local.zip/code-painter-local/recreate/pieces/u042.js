'use strict';
// u042 — "Gold-clawed star anemone": a pearly many-armed anemone with gold claw tips bursting from a cosmic
// collage — wavy zebra dunes, a striped tube, an orange-framed TV and grid, cream swirls, a diagonal rail.
REC.register('u042', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a, x1 = x, y1 = y) => { const g = ctx.createRadialGradient(x1, y1, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };
    const ALL = poly([[-10, -10], [736, -10], [736, 1034], [-10, 1034]]);
    const ZEBRA = (fn, name) => E.fx(fn + `
      vec3 fx(vec2 uv, vec2 p){ return mix(vec3(.94, .93, .92), vec3(.07, .06, .07), smoothstep(-.12, .12, ${name}(p))); }`);

    // ── starry black ground ──
    R.flat(ALL, null, 0, 0);
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(.14, .13, .15);
      vec2 g = floor(p / 13.), f = fract(p / 13.) - .5; float h = hash(g);
      c += step(.9, h) * smoothstep(.16, .06, length(f - (vec2(hash(g + 1.), hash(g + 2.)) - .5) * .6)) * .85;
      vec2 G = floor(p / 5.), F = fract(p / 5.) - .5;
      c += step(.985, hash(G + 7.)) * smoothstep(.3, .1, length(F)) * .5;
      return c; }`));
    // sky
    const SKYP = sm([[14, 62], [620, 62], [580, 72], [540, 95], [500, 116], [460, 136], [400, 148], [300, 154], [200, 162], [140, 184], [80, 222], [40, 300], [30, 420], [14, 470]]);
    fill(SKYP, lin(0, 60, 500, 160, [[0, '#4e6cc4'], [0.5, '#6896dc'], [1, '#78a6e0']]));
    { const r = rng(2); a.fillStyle = '#ffffff'; for (let i = 0; i < 60; i++) { const x = 40 + r() * 60, y = 90 + r() * 70; a.globalAlpha = 0.5 + r() * 0.5; a.fillRect(x, y, 1.6, 1.6); } a.globalAlpha = 1; }
    // dark swirl top right
    clipA(poly([[540, 62], [736, 62], [736, 200], [540, 200]]), () => { for (let k = 0; k < 9; k++) stroke(line([[520 + k * 12, 210], [570 + k * 12, 140], [640 + k * 10, 70]]), '#3a383e', 3); });

    // ── cream ribbons and the tusk ──
    const RIB = [[16, 560], [18, 480], [21, 400], [30, 340], [38, 284], [70, 240], [110, 212], [160, 192], [220, 177], [300, 171], [400, 166], [460, 152], [500, 136], [540, 110], [580, 84], [626, 60]];
    const RW = [20, 24, 22, 46, 48, 40, 22, 20, 24, 30, 36, 40, 44, 40, 32, 24];
    const ribbon = (cl, ws) => { const L = [], Rr = []; for (let i = 0; i < cl.length; i++) { const p = cl[i], q0 = cl[Math.max(0, i - 1)], q1 = cl[Math.min(cl.length - 1, i + 1)]; let dx = q1[0] - q0[0], dy = q1[1] - q0[1]; const d = Math.hypot(dx, dy); dx /= d; dy /= d; L.push([p[0] - dy * ws[i] / 2, p[1] + dx * ws[i] / 2]); Rr.push([p[0] + dy * ws[i] / 2, p[1] - dx * ws[i] / 2]); } return sm([...L, ...Rr.reverse()]); };
    const RIBP = ribbon(RIB, RW);
    R.dome(RIBP, lin(0, 100, 0, 240, [[0, '#f0e6d2'], [1, '#dccab0']]), 0.1, 0.14, 12, 1);
    clipA(RIBP, () => { for (let k = -2; k <= 2; k++) stroke(line(RIB.map(([x, y], i) => [x, y + k * RW[i] * 0.18])), 'rgba(150,120,100,0.35)', 1.5); });
    R.dome(sm(lock([[64, 236], [100, 190], [140, 150], [176, 110], [198, 80], [212, 62]], 44, 2)), '#ece2cc', 0.2, 0.16, 14, 1);
    fill(sm(lock([[190, 96], [200, 80], [210, 64]], 8, 1)), '#c89040');
    // black planet + yellow sun
    R.bead(97, 192, 30, '#1a181c', 0.3, 0.1, 5);
    R.bead(97, 297, 38, '#f6e06c', 0.2, 0.08, 4);
    // lilac grid dome
    const PD = sm([[96, 258], [110, 228], [150, 200], [200, 184], [250, 178], [274, 186], [266, 214], [250, 240], [230, 258]]);
    R.dome(PD, '#c8a0c6', 0.2, 0.1, 18, 4);
    clipA(PD, () => { for (let k = 0; k < 14; k++) { stroke(line([[90 + k * 14, 270], [130 + k * 12, 170]]), '#3a2a40', 1.2); stroke(line([[90, 186 + k * 7], [280, 176 + k * 7]]), '#3a2a40', 1.2); } });
    // grey ticked rail across the top
    const RL = poly([[256, 200], [736, 186], [736, 226], [256, 242]]);
    R.flat(RL, '#9a98a2', 0.12, 4);
    clipA(RL, () => { for (let x = 262; x < 736; x += 13) stroke(line([[x, 196], [x, 246]]), '#4a4850', 3); });
    stroke(line([[256, 242], [736, 226]]), '#2a282e', 3);
    // comb fringe under the dome
    for (let k = 0; k < 40; k++) { const t = k / 39, x = 120 + t * 300, y = 300 - Math.sin(t * 2.8) * 60 + t * 10; stroke(line([[x, y], [x + 4, y + 16]]), '#e8e8ec', 2.4); }
    // red / white / violet stripe band
    const SB = [[140, 395], [170, 360], [220, 330], [280, 300], [340, 278], [420, 258], [500, 246], [580, 244], [640, 256]];
    stroke(line(SB.map(([x, y]) => [x + 4, y + 18])), '#6a58c0', 12);
    stroke(line(SB.map(([x, y]) => [x + 2, y + 8])), '#d8303c', 8);
    stroke(line(SB), '#f4f2f2', 8);
    stroke(line(SB.map(([x, y]) => [x - 2, y - 8])), '#3a62c8', 8);

    // ── blue field, TV, orange frame, grid ──
    const BF = sm([[300, 262], [520, 250], [600, 262], [640, 300], [650, 420], [640, 520], [600, 560], [520, 560], [420, 540], [340, 520], [304, 460], [290, 340]]);
    fill(BF, '#2c4ab0');
    { const r = rng(6); a.fillStyle = '#0c0a10'; for (let i = 0; i < 70; i++) { a.beginPath(); a.arc(300 + r() * 50, 290 + r() * 200, 1.5 + r() * 3, 0, 6.283); a.fill(); } }
    fill(rrect(344, 316, 156, 146, 6), '#121016');
    fill(sm([[481, 332], [363, 334], [359, 424], [412, 445], [417, 439], [412, 420], [419, 410], [466, 403], [467, 393], [483, 383]]), '#959cb6');
    fill(sm([[420, 460], [470, 452], [510, 462], [500, 476], [450, 478]]), '#8a92b0');
    fill(sm([[440, 486], [560, 480], [640, 470], [650, 540], [600, 560], [470, 540]]), '#5a88d8');
    const ORA = (pts, seed) => { const pp = []; const r = rng(seed);
      for (let i = 0; i < pts.length; i++) { const p0 = pts[i], p1 = pts[(i + 1) % pts.length], L = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]), n = Math.max(1, Math.round(L / 9));
        for (let j = 0; j < n; j++) { const t = j / n, nx = (p1[1] - p0[1]) / L, ny = -(p1[0] - p0[0]) / L, d = (j % 2 ? 3.5 : -1) * (0.7 + r() * 0.6); pp.push([p0[0] + (p1[0] - p0[0]) * t + nx * d, p0[1] + (p1[1] - p0[1]) * t + ny * d]); } }
      return sm(pp); };
    R.dome(ORA([[330, 262], [380, 251], [504, 253], [544, 266], [544, 293], [335, 296]], 1), '#f89c36', 0.2, 0.08, 10, 4);
    R.dome(ORA([[518, 282], [636, 282], [636, 470], [632, 500], [614, 526], [500, 532], [492, 512], [518, 496]], 2), '#f69a36', 0.2, 0.08, 10, 4);
    R.flat(rrect(534, 296, 58, 192, 1), '#f4f4f6', 0.3, 4);
    for (let k = 0; k <= 16; k++) stroke(line([[534, 296 + k * 12], [592, 296 + k * 12]]), '#3a3a44', 1.2);
    for (const x of [534, 548, 578, 592]) stroke(line([[x, 296], [x, 488]]), '#3a3a44', 1.2);
    R.flat(rrect(555, 296, 10, 250, 2), '#a296cc', 0.32, 4);
    stroke(line([[384, 500], [500, 510]]), '#d8d8e0', 5);
    R.bead(368, 306, 8, '#f2e06a', 0.3, 0.06, 4);
    R.bead(322, 462, 9, '#e04830', 0.3, 0.06, 4);
    R.bead(370, 462, 11, '#c8e090', 0.3, 0.06, 4);
    // the cream eye on the right
    const EYE = sm([[640, 290], [690, 300], [736, 330], [736, 620], [700, 612], [640, 604], [612, 580], [604, 520], [626, 470], [630, 400], [626, 330]]);
    R.dome(EYE, lin(620, 300, 720, 600, [[0, '#f0e8d8'], [0.5, '#e0d0bc'], [1, '#c8b49c']]), 0.12, 0.12, 24, 1);
    clipA(EYE, () => soft(x => { stroke(line([[700, 300], [652, 340], [636, 420], [646, 500], [690, 560], [736, 590]]), 'rgba(70,50,40,0.85)', 22, x); }, 10, 0.85));
    R.dome(ellipseP(686, 408, 44, 66, 0), '#f4f6fa', 0.2, 0.08, 16, 3);
    soft(x => fill(ellipseP(692, 410, 30, 52, 0), '#a4c0ea', x), 3, 1);
    // black sun + blue suns
    { const p = []; for (let i = 0; i < 48; i++) { const t = i / 48 * 6.283, r = i % 2 ? 14 : 24; p.push([661 + Math.cos(t) * r, 257 + Math.sin(t) * r]); } fill(poly(p), '#0c0a0e'); }
    for (const [x, y, rr] of [[604, 658, 24], [650, 922, 30]]) { const p = []; for (let i = 0; i < 64; i++) { const t = i / 64 * 6.283, r = i % 2 ? rr * 0.7 : rr; p.push([x + Math.cos(t) * r, y + Math.sin(t) * r]); } fill(poly(p), '#c8dcf4'); fill(circleP(x, y, rr * 0.6), '#7aa8e8'); }

    // ── zebra dunes (fitted stripe phases) and the striped tube ──
    const ZD = sm([[8, 556], [50, 556], [74, 620], [64, 700], [84, 760], [150, 772], [200, 784], [240, 820], [272, 860], [302, 900], [306, 1004], [8, 1004]]);
    R.flat(ZD, null, 0.05, 0);
    clipA(ZD, () => img(ZEBRA(`const vec2 ZC[23] = vec2[23](vec2(40., 592.), vec2(40., 656.), vec2(40., 720.), vec2(104., 720.), vec2(40., 784.), vec2(104., 784.), vec2(168., 784.), vec2(232., 784.), vec2(40., 848.), vec2(104., 848.), vec2(168., 848.), vec2(232., 848.), vec2(296., 848.), vec2(40., 912.), vec2(104., 912.), vec2(168., 912.), vec2(232., 912.), vec2(296., 912.), vec2(40., 976.), vec2(104., 976.), vec2(168., 976.), vec2(232., 976.), vec2(296., 976.));
const float ZK[138] = float[138](0.7221, 3.1089, 0.7721, 1.2874, -0.3554, -0.1369, -19.8491, 3.7031, 0.5451, -4.5769, -3.1826, -1.1516, -4.5236, 5.6850, -1.6589, 0.0624, -3.8574, -1.2927, -0.5807, -6.4853, 5.2356, -0.9443, 4.1083, 0.5558, 6.2867, -4.4627, 4.7911, 2.6843, -0.2818, 0.2512, 2.4793, -2.0930, 3.8864, -0.0960, -2.6872, 0.7003, -1.7076, -4.7612, 1.7280, -1.7117, -4.5496, -0.8795, 2.3674, 4.1028, -1.6219, -4.1306, -2.9860, -0.0562, -4.6950, -3.8208, 4.1233, 1.6264, 1.3722, -0.8062, 1.3629, -2.2217, 4.0527, 1.4526, -0.4526, -1.3794, -5.4676, -5.4482, 1.2485, -0.0938, -2.4362, -0.2934, -3.2457, -3.4226, 1.7760, 0.1941, 0.2006, 0.6162, 1.1965, -2.4552, 2.2390, -1.7162, 2.1833, -1.1635, 0.4905, -3.8847, 2.8770, -0.4405, -0.7984, -0.2895, 5.2023, 4.4652, -2.8373, 0.3461, -0.7562, 0.6394, -4.2239, -4.0286, 4.4549, 0.8997, 1.1260, 0.2853, 4.8213, -2.4862, 5.0260, 0.0435, -1.5100, -1.6856, 1.1373, -4.0152, 2.0023, -2.3140, -3.6982, 0.4901, -0.8809, 4.2869, -1.7737, -1.3051, -1.9500, -0.6301, 1.3192, -4.5066, 2.4686, -0.9879, -0.0639, 0.6870, 0.0190, -4.4556, 5.4942, 1.5701, -1.2020, 0.1634, 1.5496, -4.1139, 4.0927, -0.5403, -3.2805, 0.2465, 0.4395, 5.8343, -2.1795, 1.9776, 2.6843, -0.1038);
float zv(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 23; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.2478);
    float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }`, 'zv')));
    stroke(line([[48, 640], [52, 700], [78, 748], [126, 778], [190, 790]]), '#f0c838', 15);
    const CYL = sm([[100, 430], [130, 402], [200, 398], [250, 418], [300, 456], [342, 498], [352, 540], [300, 562], [256, 552], [214, 534], [160, 514], [108, 500]]);
    R.dome(CYL, null, 0.12, 0.16, 30, 1);
    clipA(CYL, () => img(ZEBRA(`const vec2 CC[11] = vec2[11](vec2(160., 430.), vec2(220., 430.), vec2(280., 430.), vec2(160., 490.), vec2(220., 490.), vec2(280., 490.), vec2(340., 490.), vec2(160., 550.), vec2(220., 550.), vec2(280., 550.), vec2(340., 550.));
const float CK[66] = float[66](1.1561, 2.6125, 2.9378, -0.5097, 2.6592, -1.7602, -2.6048, 1.5615, 6.4114, -1.3635, 3.2694, -5.1852, 2.4180, 2.8083, -8.1491, 1.7176, -9.5980, 3.4451, 6.2287, 4.1856, 0.4652, -0.3324, 2.6797, -2.2546, 2.5487, 3.4883, 1.9698, -0.8144, 2.7521, -2.1683, 7.1940, 1.7906, 3.9822, -1.7872, 4.0296, -1.8074, -3.6761, 0.7792, -0.0262, 1.4267, 0.1524, -2.0840, 0.1126, 5.7226, -4.7069, 0.3968, 2.9523, -4.9272, 3.8259, 5.3638, -1.1817, -0.6943, 3.2253, -2.8354, 1.0473, 1.1086, 0.1938, -0.9064, 0.8593, -1.0511, 2.2454, -1.2013, 1.8646, 2.5488, -4.2981, 2.0585);
float cv(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 11; i++) { vec2 q = (p - CC[i]) / 100.; float w = exp(-dot(q, q) / 0.2178);
    float ph = CK[i*6] + CK[i*6+1] * q.x + CK[i*6+2] * q.y + CK[i*6+3] * q.x * q.x + CK[i*6+4] * q.x * q.y + CK[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }`, 'cv')));
    R.dome(ellipseP(116, 454, 18, 50, 0.1), '#2a2a32', 0.2, 0.06, 10, 5);
    // pink scraps, traffic light, grey hand
    fill(sm([[44, 340], [70, 336], [82, 400], [70, 470], [86, 520], [60, 540], [40, 480], [48, 420]]), '#c86a7c');
    fill(sm([[48, 560], [100, 566], [118, 640], [132, 680], [110, 670], [90, 640], [60, 610], [44, 590]]), '#e07090');
    R.flat(rrect(102, 364, 32, 60, 2), '#1c1a20', 0.3, 5);
    R.bead(118, 386, 7, '#f2d050', 0.36, 0.04, 4); R.bead(118, 406, 7, '#f2d050', 0.36, 0.04, 4);
    R.dome(ellipseP(118, 366, 14, 8, 0), '#d84040', 0.32, 0.06, 5, 4);
    R.pipe(line([[92, 330], [92, 600]]), 6, '#2a2830', 0.3, 0.04, 5);
    R.bead(92, 328, 8, '#3a70d0', 0.32, 0.06, 4);
    R.flat(rrect(110, 548, 150, 10, 2), '#c8c8d0', 0.2, 4);
    const HAND = sm([[104, 724], [130, 690], [180, 664], [230, 650], [270, 652], [290, 680], [250, 700], [210, 720], [170, 740], [140, 760], [110, 752]]);
    R.dome(HAND, '#7a7c90', 0.16, 0.08, 14, 4);

    // ── blue pool, rail and grey rings ──
    fill(sm([[306, 800], [360, 788], [430, 780], [480, 784], [500, 800], [440, 860], [380, 905], [330, 938], [306, 920], [300, 860]]), '#2c4eb8');
    fill(sm([[420, 560], [520, 568], [600, 580], [640, 620], [560, 640], [470, 620]]), '#3a5ec8');
    { const SB2 = [[380, 606], [450, 578], [510, 556], [570, 538], [620, 530]];
      stroke(line(SB2.map(([x, y]) => [x, y + 16])), '#3a5ec8', 10); stroke(line(SB2.map(([x, y]) => [x, y + 8])), '#d8303c', 8); stroke(line(SB2), '#f4f2f2', 8); }
    R.flat(poly([[736, 600], [736, 624], [289, 1000], [262, 1000]]), '#f2f0f0', 0.1, 4);
    R.flat(poly([[736, 624], [736, 640], [303, 1004], [289, 1000]]), '#8a8a92', 0.08, 4);
    for (let k = 0; k < 4; k++) {
      const d = k * 24;
      stroke(line([[424 + d, 1030], [452 + d * 0.9, 950 + d * 0.3], [510 + d * 0.8, 885 + d * 0.5], [590 + d * 0.6, 850 + d * 0.6], [736, 836 + d * 0.7]]), '#86848c', 12);
    }
    for (const [x, y, r, c] of [[528, 615, 15, '#f2d850'], [580, 626, 6, '#e85030'], [668, 758, 6, '#e85030'], [688, 926, 6, '#e85030'], [586, 990, 8, '#e85030'], [104, 540, 6, '#e85030']]) R.bead(x, y, r, c, 0.3, 0.06, 4);

    // ── the anemone ──
    const C0 = [455, 692];
    const tips = [[455, 482], [362, 498], [282, 505], [258, 548], [238, 596], [200, 628], [186, 668], [175, 712], [205, 760], [215, 790], [243, 826], [296, 862], [332, 815], [384, 790], [437, 830], [600, 570], [566, 548], [520, 536], [225, 650], [190, 740], [232, 808], [270, 846], [318, 842], [356, 818], [410, 806], [300, 560], [330, 620]];
    const arms = tips.map(([x, y], i) => {
      const mx = (C0[0] + x) / 2, my = (C0[1] + y) / 2, dx = x - C0[0], dy = y - C0[1], L = Math.hypot(dx, dy), bend = (i % 2 ? 1 : -1) * L * 0.07;
      return [[C0[0], C0[1]], [mx - dy / L * bend, my + dx / L * bend], [x, y], L];
    }).sort((p, q) => p[3] - q[3]);
    for (const cl of arms) {
      const pts = [], n = 14;
      for (let k = 0; k <= n; k++) { const t = k / n, u = 1 - t; pts.push([u * u * cl[0][0] + 2 * u * t * cl[1][0] + t * t * cl[2][0], u * u * cl[0][1] + 2 * u * t * cl[1][1] + t * t * cl[2][1]]); }
      const body = sm(lock(pts.slice(2, n), Math.min(52, cl[3] * 0.22), 14));
      R.dome(body, lin(pts[2][0], pts[2][1], pts[n][0], pts[n][1], [[0, '#c8b49a'], [0.25, '#e6e0d8'], [1, '#f2f0ee']]), 0.3, 0.22, 16, 1);
      R.dome(sm(lock(pts.slice(n - 2), 14, 0)), '#d6a04a', 0.36, 0.08, 4, 2);
    }
    soft(x => fill(circleP(470, 690, 46), 'rgba(216,170,80,0.9)', x), 12, 1);
    R.dome(sm([[474, 700], [500, 676], [530, 664], [552, 672], [546, 700], [530, 730], [516, 762], [488, 764], [474, 740]]), '#d8b050', 0.42, 0.1, 10, 2);
    R.pipe(line([[520, 668], [550, 654], [574, 664], [570, 690]]), 8, '#d8b050', 0.44, 0.06, 2);
    R.bead(498, 730, 26, '#e0e8f8', 0.46, 0.2, 3);

    // ── paper frame: cream torn edge, burnt corners ──
    const inner = []; { const r = rng(31);
      for (let x = 14; x <= 712; x += 14) inner.push([x, 64 + (r() - 0.5) * 8]);
      for (let y = 64; y <= 1000; y += 16) inner.push([740, y]);
      for (let x = 712; x >= 14; x -= 14) inner.push([x, 1004 + (r() - 0.5) * 8]);
      for (let y = 1000; y >= 64; y -= 16) inner.push([12 + (r() - 0.5) * 8, y]); }
    const IN = poly(inner);
    const frame = new Path2D(); frame.rect(-10, 40, 746, 1004); frame.addPath(poly(inner.slice().reverse()));
    fill(frame, '#efe6d0');
    fill(poly([[-10, -10], [736, -10], [736, 54], [-10, 50]]), '#242227');
    clipA(poly([[-10, -10], [736, -10], [736, 54], [-10, 50]]), () => { const r = rng(8); a.fillStyle = '#e8e8ee'; for (let i = 0; i < 40; i++) { a.beginPath(); a.arc(r() * 726, 6 + r() * 40, 0.8 + r() * 1.8, 0, 6.283); a.fill(); } });
    fill(sm([[300, 52], [340, 46], [380, 50], [410, 60], [400, 80], [360, 88], [320, 80]]), '#f2ead6');
    fill(sm([[-10, 50], [60, 50], [84, 60], [60, 76], [36, 92], [20, 116], [-10, 130]]), '#efe6d0');
    soft(x => { fill(poly([[640, 44], [736, 44], [736, 110], [700, 86], [660, 68]]), 'rgba(110,50,36,0.9)', x); fill(poly([[640, 1000], [736, 960], [736, 1034], [620, 1034]]), 'rgba(170,80,56,0.9)', x); }, 8, 1);
    soft(x => { x.lineWidth = 6; x.strokeStyle = 'rgba(160,110,80,0.7)'; x.stroke(IN); }, 3, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.7, shin: 40, wrap: 0.45, ao: 0.5, coat: 0.1 }),                                // 1 pearly cream
        E.mat({ dif: 0.8, metal: 0.45, spec: 1.0, shin: 40, rim: 0.2, ao: 0.4, tint: [1.15, 1.0, 0.7] }),       // 2 gold
        E.mat({ dif: 0.9, spec: 1.0, shin: 70, coat: 0.25, ao: 0.3 }),                                         // 3 pearl
        E.mat({ dif: 1, spec: 0.2, shin: 16, wrap: 0.4, ao: 0.3 }),                                            // 4 matte paint
        E.mat({ dif: 1, spec: 0.9, shin: 50, coat: 0.2, ao: 0.3 }),                                            // 5 black gloss
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.66, 0.66, 0.66], amb: [0.46, 0.46, 0.48],
      envTop: [1, 1, 1], envHor: [0.55, 0.55, 0.58], envBot: [0.15, 0.14, 0.16], envK: [0.25, 0.8, 0.2, 0],
      r1: 2, r2: 8, k: [0, 0.6, 0.4, 80], shadow: [-4, 6, 0.35, 8]
    });
    E.grain(0.035, 6);
  }
});
