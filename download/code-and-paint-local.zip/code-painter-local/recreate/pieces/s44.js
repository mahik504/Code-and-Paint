'use strict';
// s44 — "Pipe buddy": a matte white pipe creature — smiley ball head, chrome-banded
// looping pipe, big peanut-shaped bulb — in front of a green camo tile wall, beige
// planks and a dark door, on a black-and-white chevron floor; lavender cloth and a
// torn speckled paper strip with a little bearded-man badge on the left.
REC.register('s44', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const speck = (path, n, seed, col, rmax, al = 0.8) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = al * (0.3 + r() * 0.7); a.beginPath(); a.arc(r() * 726, r() * 1024, 0.3 + Math.pow(r(), 2) * rmax, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });

    // ── sky, camo wall, beige planks, door ──
    const sky = a.createLinearGradient(0, 0, 0, 130); sky.addColorStop(0, '#3a3c52'); sky.addColorStop(1, '#4a4d66');
    R.flat(rrect(-10, -10, 746, 1044, 0), sky, 0, 0);
    const wall = P([[20, 118], [236, 80], [443, 44], [640, 8], [640, 800], [20, 800]], true, false);
    const camo = E.fx(`vec3 fx(vec2 uv, vec2 p){
      // perspective-ish tiles: rows fall slightly to the left
      float yy = p.y + (p.x - 640.) * 0.16 * (1. - p.y / 900.);
      float row = floor(yy / 62.), col = floor((p.x + row * 37.) / 92.);
      vec2 t = vec2(fract((p.x + row * 37.) / 92.), fract(yy / 62.));
      float n = fbm(p * 0.018 + 3.1) + 0.35 * fbm(p * 0.05);
      float cam = smoothstep(0.74, 0.77, n);
      vec3 dark = vec3(0.11, 0.19, 0.14), light = vec3(0.24, 0.36, 0.25);
      vec3 c = mix(dark, light, cam);
      float edge = min(min(t.x, 1. - t.x) * 92., min(t.y, 1. - t.y) * 62.);
      c *= 0.82 + 0.18 * smoothstep(0., 3., edge);
      c *= 0.9 + 0.2 * hash(vec2(row, col));
      c *= 0.85 + 0.25 * smoothstep(900., 100., p.y);
      return c; }`);
    clipA(wall, () => img(camo));
    R.flat(P([[636, -10], [736, -10], [736, 780], [636, 780]], true, false), '#cdb896', 0.03, 5);
    clipA(rrect(636, -10, 100, 800, 0), () => {
      const pr = rng(4);
      for (let y = 30; y < 780; y += 62) { a.fillStyle = 'rgba(90,70,50,0.35)'; a.fillRect(636, y, 90, 2.5); }
      for (let i = 0; i < 900; i++) { a.fillStyle = `rgba(${pr() < 0.5 ? '240,230,210' : '150,125,95'},0.3)`; a.fillRect(636 + pr() * 90, pr() * 780, 8 + pr() * 30, 1); }
      const g = a.createLinearGradient(636, 0, 726, 0); g.addColorStop(0, 'rgba(255,250,240,0.35)'); g.addColorStop(1, 'rgba(90,70,50,0.15)'); a.fillStyle = g; a.fillRect(636, 0, 90, 780);
    });
    R.flat(rrect(684, 470, 50, 310, 0), '#050505', 0.02, 0);
    for (const [x, y] of [[607, 64], [592, 448], [596, 395], [705, 400], [600, 520], [468, 60]]) R.bead(x, y, 5, '#f0f0ee', 0.1, 0.08, 1);

    // copper plumbing at the top
    const CU = '#8c6a52';
    R.pipe(P([[124, 10], [124, 90]], false), 12, CU, 0.1, 0.12, 3); R.pipe(P([[124, 10], [215, 0]], false), 14, CU, 0.1, 0.12, 3);
    R.pipe(P([[291, -10], [291, 60]], false), 11, CU, 0.1, 0.12, 3); R.pipe(P([[500, -10], [500, 10]], false), 12, CU, 0.1, 0.12, 3);
    for (const [x, y] of [[132, 96], [291, 68], [500, 22]]) {
      R.dome(rrect(x - 16, y, 32, 28, 4), '#7e6048', 0.12, 0.1, 5, 3);
      for (let k = 0; k < 3; k++) R.groove(P([[x - 15, y + 8 + k * 7], [x + 15, y + 8 + k * 7]], false), 2, '#3a2a20', 0.2, 0.04, 3);
    }

    // ── chevron floor ──
    const floorP = P([[-10, 690], [640, 740], [736, 760], [736, 1044], [-10, 1044]], true, false);
    const flo = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float xa = 190. - 0.7 * (p.y - 715.);
      float d = p.x - xa;
      float u = d > 0. ? p.y - 0.42 * d : p.y - 2.2 * d;
      float per = 44. + (p.y - 700.) * 0.3 + max(d, 0.) * 0.05;
      float s = sin(6.2832 * u / per);
      float v = smoothstep(-0.25, -0.05, s);
      vec3 c = mix(vec3(0.05), vec3(0.9, 0.9, 0.88), v);
      // faint tile seams on the white
      float tl = smoothstep(0.02, 0., abs(fract((p.x + p.y * 0.8) / 60.) - 0.5) - 0.48);
      c -= v * tl * 0.08;
      return c; }`);
    R.flat(floorP, null, 0.0, 0);
    clipA(floorP, () => img(flo));
    // floor ring + contact shadows
    soft(x => { fe(x, 470, 905, 170, 30, -0.05, 'rgba(0,0,0,0.55)'); fe(x, 640, 880, 60, 20, -0.4, 'rgba(0,0,0,0.45)'); fe(x, 160, 780, 120, 30, 0, 'rgba(0,0,0,0.35)'); }, 18, 1);
    a.save(); a.strokeStyle = 'rgba(10,10,10,0.9)'; a.lineWidth = 5; a.stroke(P([[250, 1000], [380, 1004], [500, 985], [590, 940], [640, 880]], false)); a.restore();
    speck(floorP, 60, 11, '#c8c8c8', 3, 0.8);
    const floorRing = () => { a.save(); a.fillStyle = '#0a0a0a'; a.fill(ellipseP(600, 905, 46, 12, -0.3)); a.restore(); };

    // ── left: pink blob, dark tube, lavender cloth ──
    R.dome(P([[10, 36], [44, 44], [66, 100], [74, 170], [66, 250], [40, 300], [16, 300], [10, 150]]), '#eab8ac', 0.06, 0.2, 22, 1);
    R.pipe(P([[50, 290], [58, 320], [76, 350], [96, 366]], false), 40, '#2a221e', 0.1, 0.2, 6);
    const clothG = a.createLinearGradient(0, 280, 300, 780); clothG.addColorStop(0, '#ece6f2'); clothG.addColorStop(0.5, '#d2cbe8'); clothG.addColorStop(1, '#a89ed6');
    R.dome(P([[20, 290], [60, 300], [100, 320], [150, 360], [190, 395], [240, 425], [290, 470], [330, 520], [300, 600], [220, 700], [190, 770], [120, 790], [40, 790], [20, 700]]), clothG, 0.06, 0.26, 40, 1);
    for (const [cx, cy, rx, ry] of [[120, 690, 80, 70], [60, 740, 60, 50], [150, 610, 70, 55]]) R.dome(ellipseP(cx, cy, rx, ry, 0.3), '#b0a6dc', 0.1, 0.24, 36, 1);

    // ── peanut bulb ──
    const peanut = P([[29, 440], [40, 414], [71, 405], [143, 412], [214, 441], [271, 484], [300, 512], [343, 550], [386, 566], [420, 568], [500, 591], [550, 655], [571, 726], [564, 812],
      [529, 869], [457, 898], [371, 898], [300, 862], [271, 812], [264, 748], [214, 719], [143, 676], [86, 633], [43, 583], [30, 530]]);
    const pg = a.createLinearGradient(100, 420, 560, 900); pg.addColorStop(0, '#d4d4d0'); pg.addColorStop(1, '#d6d2c8');
    R.dome(peanut, pg, 0.1, 0.5, 110, 2);
    speck(peanut, 300, 21, '#555', 1.2, 0.6);
    // scratch-hair mark
    { const hr = rng(3), top = []; for (let x = 340; x <= 500; x += 6) top.push([x, 790 - Math.pow(hr(), 2) * 45 * (x > 380 && x < 470 ? 1 : 0.4)]);
      a.save(); a.strokeStyle = 'rgba(40,36,32,0.85)'; a.lineWidth = 1.4; a.stroke(P(top, false, false)); a.lineWidth = 0.8;
      for (let i = 0; i < 90; i++) { const x = 340 + hr() * 160, y = 790 - hr() * 20; a.globalAlpha = 0.3 + hr() * 0.4; a.beginPath(); a.moveTo(x, y); a.lineTo(x + 6, y + 30 + hr() * 20); a.stroke(); } a.restore(); }

    // ── the looping pipe with chrome bands ──
    const WHITE = '#ecebe6';
    const loop = [[560, 122], [480, 118], [400, 140], [330, 185], [280, 250], [262, 330], [280, 400], [330, 450], [400, 482], [470, 500], [530, 525], [585, 565], [625, 615], [652, 680], [658, 760], [640, 835], [612, 900]];
    R.pipe(P(loop, false), 74, WHITE, 0.2, 0.34, 1);
    // bellows elbow into the right wall
    R.pipe(P([[540, 138], [600, 140], [650, 160], [690, 200], [720, 250], [740, 280]], false), 118, WHITE, 0.24, 0.34, 1);
    for (const [x, y, ang] of [[600, 140, 0.1], [640, 156, 0.4], [676, 186, 0.7], [704, 224, 0.95]]) R.groove(ellipseP(x, y, 12, 56, ang), 7, '#c8c8c2', 0.52, 0.06, 1, 0.4);
    // bands: [t along loop (index), angle]
    const band = (bx, by) => {
      let bi = 0, bd = 1e9; for (let i = 0; i < loop.length - 1; i++) { const d = Math.hypot((loop[i][0] + loop[i + 1][0]) / 2 - bx, (loop[i][1] + loop[i + 1][1]) / 2 - by); if (d < bd) { bd = d; bi = i; } }
      const p = loop[bi], q = loop[bi + 1], x = bx, y = by;
      const dx = q[0] - p[0], dy = q[1] - p[1], L = Math.hypot(dx, dy), nx = -dy / L, ny = dx / L, hw = 40, t = 9;
      const pts = [[x + nx * hw - dx / L * t, y + ny * hw - dy / L * t], [x + nx * hw + dx / L * t, y + ny * hw + dy / L * t], [x - nx * hw + dx / L * t, y - ny * hw + dy / L * t], [x - nx * hw - dx / L * t, y - ny * hw - dy / L * t]];
      const g = a.createLinearGradient(x + nx * hw, y + ny * hw, x - nx * hw, y - ny * hw);
      g.addColorStop(0, '#3a3430'); g.addColorStop(0.25, '#a09688'); g.addColorStop(0.42, '#f4f0ea'); g.addColorStop(0.6, '#7a726a'); g.addColorStop(1, '#2a2420');
      R.dome(P(pts, true, false), g, 0.5, 0.06, 4, 3);
    };
    for (const [x, y] of [[529, 124], [468, 120], [407, 138], [336, 181], [286, 262], [268, 362], [352, 462], [582, 563], [648, 666], [652, 800]]) band(x, y);

    { const patch = P([[556, 912], [600, 905], [650, 884], [700, 890], [700, 990], [556, 990]], true, true); R.flat(patch, null, 0.0, 0); clipA(patch, () => img(flo)); }
    // ── head, ears, neck + flanges ──
    R.pipe(P([[493, 330], [482, 420], [470, 490]], false), 64, WHITE, 0.24, 0.3, 1);
    R.dome(ellipseP(478, 386, 54, 16, 0.05), '#e4e3de', 0.44, 0.08, 8, 1);
    R.pipe(P([[455, 505], [442, 548]], false), 62, WHITE, 0.2, 0.3, 1);
    R.dome(ellipseP(442, 552, 60, 17, 0.08), '#e4e3de', 0.44, 0.08, 8, 1);
    R.dome(ellipseP(400, 222, 26, 18, -0.5), WHITE, 0.3, 0.2, 14, 1);
    R.dome(ellipseP(596, 262, 22, 26, 0.3), WHITE, 0.3, 0.2, 14, 1);
    R.dome(ellipseP(493, 262, 80, 84, 0), WHITE, 0.3, 0.46, 70, 1);
    R.flat(ellipseP(466, 230, 5.5, 8, 0), '#0c0c0c', 0.72, 0);
    R.flat(ellipseP(516, 240, 5.5, 8, 0), '#0c0c0c', 0.72, 0);
    a.save(); a.strokeStyle = '#101010'; a.lineWidth = 2.5; a.lineCap = 'round'; a.beginPath(); a.moveTo(480, 262); a.quadraticCurveTo(490, 272, 499, 261); a.stroke(); a.restore();
    speck(P(loop.length ? lock(loop, 74, 74, 1) : [], true, true), 250, 5, '#333', 1.2, 0.7);

    // ── torn speckled paper strip + badge ──
    const strip = [[-10, -10], [26, -10], [28, 100], [24, 200], [28, 330], [30, 420], [26, 500], [36, 600], [52, 700], [60, 760], [70, 820], [72, 900], [66, 960], [60, 1044], [-10, 1044]];
    const stripP = P(ragged(strip, 1, 13, 5, 4, 7), true, false);
    R.flat(stripP, '#565654', 0.05, 7);
    speck(stripP, 4000, 13, '#1a1a1a', 3.5, 0.9);
    speck(stripP, 1500, 14, '#e8e8e6', 1.5, 0.7);
    a.save(); a.strokeStyle = '#f2f2f0'; a.lineWidth = 3; a.stroke(P(ragged(strip, 1, 13, 5, 4, 7).slice(1, 60), false, false)); a.restore();
    // badge
    R.dome(ellipseP(62, 934, 42, 62, 0), '#707478', 0.2, 0.14, 8, 3);
    R.flat(ellipseP(62, 934, 33, 52, 0), '#44b0b0', 0.3, 0);
    clipA(ellipseP(62, 934, 33, 52, 0), () => {
      a.fillStyle = '#d82020'; a.fill(P([[34, 990], [40, 950], [62, 944], [84, 950], [90, 990]]));
      a.fillStyle = '#f0c8a0'; a.fill(ellipseP(62, 925, 12, 14, 0));
      a.fillStyle = '#1a1210'; a.fill(P([[50, 925], [74, 925], [72, 948], [62, 954], [52, 948]]));
      a.fillStyle = '#1f6e50'; a.fill(P([[36, 916], [44, 896], [62, 890], [80, 896], [88, 916], [62, 912]]));
      a.fillStyle = '#e8c040'; a.fill(P(star(74, 896, 6, 2, 6), true, false)); a.fillStyle = '#e0c040'; a.fillRect(56, 966, 12, 6);
    });

    // white lightning scribbles
    a.save(); a.strokeStyle = '#f4f4f4'; a.lineWidth = 2.2; a.lineJoin = 'round';
    a.stroke(P([[0, 748], [29, 762], [57, 755], [71, 772], [96, 800], [120, 815], [140, 850], [148, 900], [157, 955]], false, false));
    a.stroke(P([[28, 470], [44, 462], [60, 490], [70, 480], [74, 530], [68, 560]], false, false));
    a.stroke(P([[40, 650], [52, 690], [48, 720], [60, 745]], false, false));
    a.restore();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.12, shin: 12, wrap: 0.55, ao: 0.7 }),                        // 1 matte white / cloth
        E.mat({ dif: 1, spec: 0.08, shin: 10, wrap: 0.25, ao: 0.8, grain: 0.05 }),             // 2 bulb (softer)
        E.mat({ metal: 0.6, dif: 0.5, spec: 1.1, shin: 60, ao: 0.3, emis: 0.2 }),               // 3 chrome bands / copper / badge rim
        E.mat({ dif: 1, spec: 0.1, shin: 10, wrap: 0.3 }),
        E.mat({ dif: 1, spec: 0.05, shin: 8, wrap: 0.5, emis: 0.15 }),                         // 5 beige planks
        E.mat({ dif: 1, spec: 0.9, shin: 50, wrap: 0.2, coat: 0.2 }),                          // 6 dark glossy tube
        E.mat({ dif: 1, spec: 0.05, shin: 8, wrap: 0.5, grain: 0.3, emis: 0.2 })               // 7 paper strip
      ],
      light: [0.3, 0.45, 0.84], lc: [0.62, 0.6, 0.58], amb: [0.42, 0.42, 0.46],
      envTop: [1, 1, 1], envHor: [0.55, 0.55, 0.55], envBot: [0.15, 0.15, 0.15], envK: [0.2, 0.9, 0.3, 0],
      rimC: [0.1, 0.1, 0.12], rimD: [0, 1, 0], r1: 2, r2: 10, k: [0, 0.6, 0.4, 90], shadow: [-9, 10, 0.55, 5]
    });
    E.grain(0.05, 44);
  }
});
