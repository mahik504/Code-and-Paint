'use strict';
// s36 — "Night-club collage": a holographic sticker panel (purple, teal, gold
// glitter, pink, a magenta brain) behind navy dancing silhouettes, set in a
// black shadow band on a dark teal mat.
REC.register('s36', {
  w: 869, h: 1024,
  draw(E) {
    const W = 869, H = 1024, S = E.S, o = E.out;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const fill = (path, c) => { o.fillStyle = c; o.fill(path); };
    const stroke = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const clipped = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const NAVY = '#000a23';

    // procedural textures
    const gold = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p*0.02), g = hash(floor(p*0.9));
      vec3 c = mix(vec3(.62,.50,.04), vec3(.86,.72,.12), n);
      c = mix(c, vec3(1.,.93,.55), step(.82, g)*.8);
      c *= .75 + .4*step(.35, hash(floor(p*0.9)+3.1));
      return c; }`));
    const holo = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p*0.006);
      return mix(vec3(.2,.92,.84), vec3(.12,.62,.70), n) + .12*iri(n*2.+p.y*.002)*.5; }`));

    // ── mat: dark teal with faint blobs, thin black outer edge
    fill(rrect(0, 0, W, H, 0), '#002235');
    const br = rng(36);
    for (let i = 0; i < 60; i++) {
      const x = br() * W, y = br() * H, r = 8 + br() * 26;
      fill(ellipseP(x, y, r, r * (0.7 + br() * 0.5), br() * 3), br() > 0.5 ? '#012a3e' : '#001828');
    }
    // dark squiggles in the lower mat
    for (let i = 0; i < 26; i++) {
      const x = br() * W, y = 700 + br() * 320, pts = [[x, y]];
      for (let k = 0; k < 4; k++) pts.push([pts[k][0] + (br() - 0.5) * 60, pts[k][1] + (br() - 0.5) * 40]);
      stroke(P(pts, false), '#051620', 3 + br() * 4);
    }
    // ragged black outer edge
    const edge = new Path2D(); edge.rect(-40, -40, W + 80, H + 80);
    const inner = []; const er = rng(7);
    const addEdge = (x0, y0, x1, y1, n) => { for (let i = 0; i < n; i++) { const t = i / n; inner.push([x0 + (x1 - x0) * t + (er() - 0.5) * 6, y0 + (y1 - y0) * t + (er() - 0.5) * 6]); } };
    addEdge(14, 12, W - 12, 10, 40); addEdge(W - 10, 10, W - 8, H - 14, 40); addEdge(W - 8, H - 12, 12, H - 10, 40); addEdge(10, H - 12, 12, 12, 40);
    edge.addPath(P(inner.reverse(), true, false));
    fill(edge, '#000000');

    // ── panel outline (sticker) + its black shadow band
    const panelPts = [[93, 50], [800, 50], [800, 700], [740, 700], [740, 760], [727, 780], [700, 800], [694, 820], [702, 860], [698, 893], [682, 925], [655, 950],
      [625, 965], [580, 982], [540, 988], [490, 982], [450, 960], [420, 925], [392, 880], [385, 850], [262, 848], [262, 900], [245, 925], [200, 935], [150, 925], [120, 900],
      [100, 850], [96, 800], [93, 760], [93, 560], [75, 540], [55, 500], [48, 440], [52, 380], [70, 345], [93, 330]];
    const panel = P(panelPts, true, false);
    o.save(); o.filter = `blur(${3 * S}px)`; stroke(panel, '#010104', 62); fill(panel, '#010104'); o.restore();

    clipped(panel, () => {
      // purple base
      fill(rrect(0, 0, W, H, 0), '#8c4cf6');
      // top-left glitter + black void top right
      o.save(); o.globalAlpha = 0.45; fill(P([[93, 70], [125, 80], [118, 150], [93, 170]]), gold); o.restore();
      fill(P([[130, 105], [150, 80], [185, 62], [215, 58], [224, 72], [200, 90], [186, 110], [200, 130], [216, 150], [222, 176], [196, 174], [172, 152], [158, 126]]), '#12161a');
      fill(ellipseP(186, 160, 12, 8, 0.4), '#baa0c1');
      const voidP = P([[430, 128], [800, 120], [800, 195], [760, 196], [728, 214], [700, 250], [690, 300], [640, 300], [600, 330], [560, 330], [430, 300]], true, false);
      fill(voidP, '#070809');
      // drips from the purple band into the void
      const dr = rng(3);
      for (let x = 446; x < 700; x += 11 + dr() * 6) {
        const L = 14 + dr() * 50, c = dr() < 0.28 ? '#1aa0a0' : '#8c4cf6';
        fill(rrect(x, 118, 7 + dr() * 5, L, 4), c);
      }
      fill(P([[430, 60], [800, 60], [800, 124], [700, 128], [600, 122], [500, 128], [430, 124]]), '#8c4cf6');
      // gold scrollwork on the band
      o.save(); o.globalAlpha = 0.55;
      for (const pp of [[[300, 110], [360, 80], [420, 70], [480, 95], [540, 110], [600, 90]], [[450, 60], [520, 75], [600, 70], [680, 60], [760, 75]], [[330, 60], [380, 95], [440, 115]]])
        stroke(P(pp, false), gold, 5);
      o.restore();
      // purple rings in the void
      for (const [x, y, r] of [[615, 212, 28], [690, 180, 21], [753, 160, 20]]) {
        fill(circleP(x, y, r), '#9448fc'); stroke(circleP(x, y, r - 2), '#7070a0', 3);
        o.save(); o.setLineDash([2, 3]); stroke(circleP(x, y, r + 2), '#a8a0c8', 2); o.restore();
      }
      // purple cloud at the right
      fill(P([[700, 300], [690, 262], [712, 232], [740, 214], [770, 206], [800, 190], [800, 320], [760, 330]]), '#9230fe');
      // right purple strip
      fill(rrect(760, 190, 60, 520, 0), '#8030d8');

      // pink creature with cream glow
      const pink = P([[640, 315], [655, 290], [660, 262], [684, 240], [716, 236], [748, 250], [762, 280], [752, 310], [732, 332], [732, 380], [722, 420], [690, 420],
        [660, 400], [630, 380], [618, 345]]);
      fill(pink, '#fb8ed2');
      fill(P([[740, 362], [770, 350], [800, 345], [800, 410], [770, 405], [745, 395]]), '#fe86d0');
      const cg = o.createRadialGradient(620, 335, 5, 620, 335, 70); cg.addColorStop(0, '#fffff0'); cg.addColorStop(0.55, 'rgba(250,250,215,0.9)'); cg.addColorStop(1, 'rgba(240,250,200,0)');
      fill(ellipseP(620, 335, 72, 34, -0.2), cg);
      fill(ellipseP(572, 302, 14, 10), '#caf659'); fill(ellipseP(640, 300, 16, 10), '#fec63f'); fill(ellipseP(664, 334, 12, 8), '#d5fe62');
      fill(ellipseP(692, 266, 10, 13, 0.3), '#10060e'); fill(ellipseP(744, 274, 8, 11, -0.2), '#10060e');
      stroke(P([[660, 300], [690, 330], [720, 320], [740, 345]], false), '#e8b030', 3);

      // magenta brain capsule
      const brainPts = [[560, 352], [600, 340], [650, 345], [690, 360], [720, 400], [745, 460], [770, 530], [795, 600], [800, 660], [785, 690], [730, 695], [700, 685],
        [670, 640], [640, 570], [605, 480], [575, 420]];
      const brain = P(brainPts);
      const bgr = o.createLinearGradient(600, 380, 780, 660);
      bgr.addColorStop(0, '#d850f0'); bgr.addColorStop(0.5, '#e030f4'); bgr.addColorStop(1, '#c010d0');
      fill(brain, bgr);
      clipped(brain, () => {
        const sr = rng(11);
        // folds on the upper half
        for (let i = 0; i < 16; i++) {
          const x = 580 + sr() * 140, y = 350 + sr() * 130, pts = [[x, y]];
          let ang = sr() * 6.28;
          for (let k = 0; k < 5; k++) { ang += (sr() - 0.5) * 2.4; pts.push([pts[k][0] + Math.cos(ang) * 16, pts[k][1] + Math.sin(ang) * 16]); }
          stroke(P(pts, false), '#40084a', 6);
        }
        // ribs across the lower body
        for (let t = 0; t < 1; t += 0.075) {
          const cx = 650 + t * 130, cy = 480 + t * 190;
          stroke(P([[cx - 80, cy + 30], [cx - 20, cy + 6], [cx + 40, cy - 22], [cx + 90, cy - 40]], false), '#3c0850', 6 + t * 8);
        }
        // glossy sheen
        o.save(); o.globalAlpha = 0.35; fill(ellipseP(630, 400, 50, 22, 0.7), '#ffd8ff'); fill(ellipseP(770, 610, 16, 50, -0.3), '#ffc8ff'); o.restore();
      });
      stroke(brain, 'rgba(255,220,255,0.35)', 6);

      // teal blob
      // sunburst circle behind the teal blob
      fill(ellipseP(385, 745, 136, 118), '#0a0a06');
      clipped(rrect(240, 600, 80, 240, 0), () => stroke(ellipseP(385, 745, 120, 104), '#f39ad6', 16));
      clipped(rrect(440, 600, 200, 200, 0), () => stroke(ellipseP(385, 745, 116, 104), '#8a4cf0', 12));
      const teal = P([[330, 480], [345, 445], [380, 400], [420, 400], [440, 440], [470, 440], [500, 420], [540, 420], [575, 460], [600, 520], [615, 600], [625, 700],
        [620, 790], [580, 800], [540, 790], [515, 760], [505, 700], [480, 680], [430, 670], [380, 670], [340, 660], [325, 600]]);
      fill(teal, '#16a887');
      clipped(teal, () => {
        fill(P([[395, 540], [470, 540], [480, 600], [400, 604]]), '#7a3ef0');
        fill(P([[545, 600], [600, 610], [620, 720], [560, 700]]), '#8a4cf0');
        stroke(P([[572, 540], [598, 610], [612, 690], [610, 760], [596, 800]], false), gold, 18);
        const dr2 = rng(5);
        for (let i = 0; i < 14; i++) { const x = 350 + dr2() * 280, y = 440 + dr2() * 320; stroke(P([[x - 12, y], [x, y + 8], [x + 12, y]], false), dr2() > 0.6 ? '#e04a80' : '#0a4a40', 3); }
      });
      // teal top disc
      fill(circleP(382, 426, 38), '#20c8a0');

      // gold strip with pink studs (left of the teal)
      const gstrip = P([[245, 470], [270, 452], [330, 440], [405, 428], [412, 446], [345, 470], [330, 500], [328, 640], [312, 700], [262, 702], [250, 640]], true, false);
      fill(gstrip, gold);
      fill(P([[240, 452], [300, 440], [345, 440], [338, 458], [290, 470], [245, 490]]), '#f070d0');
      for (const [x, y, r] of [[262, 500, 12], [300, 530, 13], [275, 580, 12], [300, 615, 14], [270, 660, 12], [375, 462, 13], [320, 468, 10]]) {
        fill(circleP(x, y, r), '#f24aa8'); stroke(circleP(x, y, r + 4), '#40c8b0', 3);
      }

      // sunburst: purple fan, teal dome with fingers, pink rays
      clipped(P([[250, 680], [470, 680], [470, 700], [530, 700], [530, 880], [250, 880]], true, false), () => {
        const cx = 345, cy = 738, ray = (a, r0, r1, c, wd) => stroke(P([[cx + Math.cos(a) * r0, cy + Math.sin(a) * r0], [cx + Math.cos(a) * r1, cy + Math.sin(a) * r1]], false), c, wd);
        const fan = new Path2D(); fan.moveTo(cx, cy); fan.arc(cx, cy, 108, -0.42 * Math.PI, 0.12 * Math.PI); fan.closePath(); fill(fan, '#8a44f4');
        for (let i = 0; i < 8; i++) ray(-0.38 * Math.PI + i * 0.07 * Math.PI, 64, 106, '#0a0808', 7);
        for (let i = 0; i < 5; i++) ray(0.16 * Math.PI + i * 0.06 * Math.PI, 64, 104, '#8a44f4', 9);
        for (let i = 0; i < 6; i++) ray(0.3 * Math.PI + i * 0.07 * Math.PI, 36, 80, '#18ae90', 13);
        for (let i = 0; i < 6; i++) ray(0.72 * Math.PI + i * 0.09 * Math.PI, 50, 92, '#f39ad6', 11);
        fill(ellipseP(350, 722, 46, 40), '#16ac90');
        for (let i = 0; i < 9; i++) ray(-0.95 * Math.PI + i * 0.11 * Math.PI, 26, 42, '#0a0a0a', 5);
      });
      // dark olive gap between the teal and the brain, yellow flecks on the rim
      fill(P([[588, 588], [640, 600], [680, 640], [700, 700], [690, 740], [650, 722], [622, 690], [600, 640]]), '#4c3a06');
      o.save(); o.globalAlpha = 0.25; fill(P([[588, 588], [640, 600], [680, 640], [700, 700], [690, 740], [650, 722], [622, 690], [600, 640]]), gold); o.restore();
      // gold bottom region with pink stud
      fill(P([[500, 800], [560, 770], [620, 760], [660, 755], [700, 760], [700, 820], [690, 850], [650, 860], [620, 880], [600, 920], [560, 935], [520, 940],
        [470, 945], [445, 935], [450, 900], [480, 880], [500, 850]]), gold);
      stroke(circleP(540, 855, 30), '#30c8b0', 6); fill(circleP(540, 855, 26), '#f040b0'); fill(circleP(534, 849, 9), '#ffb0e8');
      stroke(circleP(603, 812, 18), '#40c8b0', 6); fill(circleP(603, 812, 10), '#f48bd2');
      // purple lower-left of the bulge
      fill(P([[400, 860], [430, 830], [470, 835], [500, 860], [495, 900], [470, 930], [440, 950], [415, 930]]), '#8a4cf0');
      for (const [x, y] of [[430, 900], [460, 880], [420, 860]]) fill(circleP(x, y, 6), '#f070c0');
      fill(P([[450, 940], [520, 940], [600, 925], [650, 900], [680, 930], [640, 960], [580, 980], [520, 985], [470, 970]]), '#2ad0b4');
      for (let i = 0; i < 9; i++) stroke(P([[480 + i * 20, 950], [470 + i * 22, 985]], false), '#0a2a28', 5);
      // cyan/teal stripes on the bulge's right rim
      clipped(P([[640, 700], [740, 700], [740, 760], [700, 800], [694, 820], [702, 860], [690, 910], [650, 950], [600, 975], [540, 990], [520, 960], [600, 930], [650, 880], [640, 800]]), () => {
        fill(rrect(500, 690, 260, 320, 0), holo);
        for (let i = 0; i < 18; i++) stroke(P([[640 + i * 8, 690], [560 + i * 10, 1000]], false), i % 2 ? '#10403a' : '#e8e050', 3);
        fill(P([[690, 706], [736, 704], [730, 730], [686, 732]]), '#dce720'); fill(P([[664, 748], [700, 744], [696, 772], [660, 774]]), '#a0e040');
        stroke(P([[650, 790], [690, 820], [700, 870]], false), '#081414', 6); stroke(P([[610, 900], [650, 870], [680, 830]], false), '#081414', 5);
      });

      // left strip: pink with teal bars
      fill(P([[93, 540], [125, 525], [135, 560], [150, 600], [158, 640], [150, 700], [93, 715]]), '#f7a2dc');
      for (let y = 545; y < 700; y += 26) stroke(P([[100, y], [150, y + 8]], false), '#2aa88c', 9);
      // left bulge: cyan pattern
      fill(P([[93, 372], [118, 385], [110, 430], [112, 480], [124, 520], [93, 545], [70, 515], [55, 470], [50, 420], [58, 390], [75, 375]]), holo);
      stroke(P([[120, 390], [150, 360], [175, 345]], false), '#a040e0', 12);
      for (const pp of [[[60, 400], [90, 380], [120, 400]], [[58, 460], [90, 440], [130, 470]], [[70, 520], [100, 500], [140, 520]]]) stroke(P(pp, false), '#0c5a50', 5);
      // mask (purple/pink) top-left
      fill(P([[95, 180], [140, 168], [190, 176], [230, 190], [290, 196], [300, 210], [250, 225], [215, 250], [185, 262], [150, 282], [120, 300], [95, 300]]), '#7a38c8');
      stroke(P([[105, 200], [140, 196], [175, 210], [200, 200], [240, 198]], false), '#f7a2dc', 9);
      stroke(P([[110, 230], [130, 250], [150, 236], [170, 250]], false), '#200830', 6);
      fill(ellipseP(105, 210, 12, 20), '#f0e030');
    });

    // ── navy silhouettes
    const hand = [[206, 112], [212, 106], [226, 110], [234, 118], [236, 96], [242, 82], [250, 80], [258, 88], [262, 118], [264, 86], [268, 76], [278, 76], [286, 86],
      [290, 120], [296, 104], [306, 101], [316, 110], [322, 140], [330, 150], [345, 160], [352, 190], [330, 200], [300, 190], [270, 186], [240, 184], [226, 170],
      [222, 150], [214, 134]];
    fill(P(hand), NAVY);
    fill(circleP(385, 182, 52), NAVY);
    const s1 = [[140, 300], [150, 262], [185, 250], [215, 252], [240, 240], [300, 200], [330, 215], [360, 230], [440, 215], [470, 195], [520, 190], [560, 200],
      [580, 230], [590, 280], [585, 330], [560, 345], [548, 390], [560, 420], [540, 425], [500, 420], [470, 440], [440, 440], [420, 400], [380, 395], [345, 420],
      [330, 440], [300, 435], [260, 450], [245, 470], [250, 640], [262, 700], [262, 880], [245, 925], [200, 935], [150, 925], [120, 900], [100, 850], [98, 800],
      [100, 760], [110, 720], [150, 700], [158, 640], [148, 600], [135, 560], [124, 520], [112, 480], [110, 430], [118, 385], [130, 350]];
    fill(P(s1, true, false), NAVY);
    // the dancer in the teal: arc, fist, head, hand
    stroke(P([[340, 506], [330, 550], [334, 605], [352, 645], [390, 668], [440, 668], [490, 650]], false), NAVY, 30);
    fill(ellipseP(478, 604, 46, 28, -0.1), NAVY);
    fill(circleP(550, 483, 20), NAVY);
    fill(P([[580, 510], [600, 500], [640, 505], [665, 530], [667, 570], [650, 595], [620, 600], [590, 585], [578, 550]]), NAVY);

    // colour patches on top of the silhouettes
    fill(P([[345, 330], [410, 322], [398, 360], [350, 356]]), '#f590c8');
    const fan = new Path2D(); fan.moveTo(343, 277); fan.arc(343, 277, 26, Math.PI * 1.05, Math.PI * 1.95); fan.closePath(); fill(fan, '#9a60f8');
    const fan2 = new Path2D(); fan2.moveTo(265, 212); fan2.arc(265, 212, 20, Math.PI * 1.05, Math.PI * 1.95); fan2.closePath(); fill(fan2, '#30c0a0');
    fill(P([[360, 190], [400, 184], [396, 200], [362, 202]]), '#8c4cf6');
    // cyan blob (bottom left) over the leg
    fill(P([[100, 790], [130, 770], [175, 765], [205, 778], [212, 800], [196, 830], [206, 860], [212, 900], [196, 918], [160, 905], [140, 870], [110, 830]]), holo);
    fill(ellipseP(186, 790, 20, 16), '#f050a0');
    stroke(P([[120, 820], [150, 800], [175, 815]], false), '#0a4a60', 6);

    E.grain(0.05, 36);
  }
});
