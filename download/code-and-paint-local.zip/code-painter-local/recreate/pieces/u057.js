'use strict';
// u057 — "Spiked star in a framed void": a cream-rimmed panel of night space, zebra waves and blue sky holds a silver
// star of gold-tipped spikes, a satin-gold swan form, a gold ring, a pink coral lattice and a black eye-disc, over a rainbow ground.
REC.register('u057', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore(); };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a, x1 = x, y1 = y) => { const g = ctx.createRadialGradient(x1, y1, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const stars = (path, n, seed, x0, y0, w, h, rmax = 2.2) => clipA(path, () => { const r = rng(seed);
      for (let i = 0; i < n; i++) { const big = r() < 0.25; fill(circleP(x0 + r() * w, y0 + r() * h, big ? 1.8 + r() * rmax : 0.6 + r()), big ? '#f4f0ea' : 'rgba(255,255,255,0.7)'); } });

    // ── backdrop around the panel: blue/olive/grey top, yellow & magenta edges, rainbow floor ──
    const BG = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 top = mix(vec3(.45, .55, .78), vec3(.70, .70, .56), smoothstep(60., 300., p.x));
      top = mix(top, vec3(.64, .63, .67), smoothstep(300., 480., p.x));
      top = mix(top, vec3(.27, .26, .31), smoothstep(520., 700., p.x));
      vec3 c = top;
      float bt = smoothstep(860., 960., p.y);
      vec3 bot = mix(vec3(.96, .92, .70), vec3(.96, .80, .72), smoothstep(20., 120., p.x));
      bot = mix(bot, vec3(.96, .28, .24), smoothstep(110., 200., p.x));
      bot = mix(bot, vec3(.95, .20, .30), smoothstep(200., 300., p.x));
      bot = mix(bot, vec3(.95, .93, .92), exp(-pow((p.x - 150.) / 40., 2.) - pow((p.y - 945.) / 14., 2.)));
      bot = mix(bot, vec3(.76, .28, .60), smoothstep(320., 420., p.x));
      bot = mix(bot, vec3(.64, .30, .62), smoothstep(420., 520., p.x));
      bot = mix(bot, vec3(.26, .22, .30), smoothstep(520., 700., p.x));
      bot = mix(bot, bot * .75 + vec3(.1, .04, .12), smoothstep(1000., 1024., p.y));
      c = mix(c, bot, bt);
      vec3 le = mix(vec3(.85, .84, .55), vec3(.98, .90, .55), smoothstep(200., 800., p.y));
      c = mix(c, le, smoothstep(30., 10., p.x) * smoothstep(20., 60., p.y));
      vec3 ri = mix(vec3(.16, .15, .18), vec3(.38, .34, .36), smoothstep(20., 110., p.y));
      ri = mix(ri, vec3(.62, .30, .55), smoothstep(200., 330., p.y));
      ri = mix(ri, vec3(.76, .32, .62), smoothstep(330., 420., p.y));
      ri = mix(ri, vec3(.20, .10, .16), smoothstep(460., 620., p.y));
      ri = mix(ri, vec3(.86, .83, .84), smoothstep(700., 780., p.y));
      ri = mix(ri, vec3(.40, .40, .50), smoothstep(830., 880., p.y));
      c = mix(c, ri, smoothstep(700., 716., p.x) * (1. - bt));
      return c; }`);
    img(BG);
    soft(x => { x.fillStyle = '#4a4852'; x.fill(ellipseP(390, 12, 90, 30, 0)); x.fill(ellipseP(640, 14, 80, 30, 0)); }, 16, 0.85);
    // panel's cast shadow (purple) on the floor
    soft(x => { x.fillStyle = '#7a4a90'; x.fill(poly([[300, 930], [690, 880], [726, 900], [726, 960], [320, 960]])); }, 18, 0.6);

    // ── the panel: cream rim + dark space ──
    const rpoly = (pts, r) => { const p = new Path2D(), n = pts.length; p.moveTo((pts[0][0] + pts[1][0]) / 2, (pts[0][1] + pts[1][1]) / 2);
      for (let i = 1; i <= n; i++) { const c = pts[i % n], nx = pts[(i + 1) % n]; p.arcTo(c[0], c[1], (c[0] + nx[0]) / 2, (c[1] + nx[1]) / 2, r); } p.closePath(); return p; };
    const RIM = rpoly([[10, 38], [706, 42], [716, 868], [16, 946]], 14);
    R.dome(RIM, '#ece6d2', 0.05, 0.08, 6, 4);
    const PAN = rpoly([[22, 50], [694, 54], [702, 856], [28, 932]], 8);
    R.flat(PAN, lin(0, 50, 700, 300, [[0, '#3a1810'], [0.4, '#2a1010'], [1, '#0c070a']]), 0.08, 0);
    stars(PAN, 260, 3, 200, 50, 500, 400);
    // purple-blue sky top-left
    fill(sm([[24, 52], [170, 48], [150, 90], [80, 130], [24, 180]]), lin(20, 50, 150, 160, [[0, '#4a4b9e'], [1, '#5a4c98']]));
    stars(sm([[24, 52], [170, 48], [150, 90], [80, 130], [24, 180]]), 40, 5, 20, 50, 150, 120, 1);
    // inner cream loop top-right
    R.pipe(line([[548, 168], [600, 166], [650, 166], [680, 186], [694, 230], [697, 320], [700, 420], [702, 500]]), 20, '#ece6d2', 0.12, 0.08, 4);
    stroke(line([[630, 200], [640, 230], [650, 260], [664, 280], [672, 300]]), '#58a8e0', 2);

    // ── zebra waves top and bottom (fitted stripe phases) ──
    const ZT = sm([[150, 60], [230, 58], [300, 75], [380, 95], [440, 110], [500, 135], [555, 160], [540, 190], [480, 200], [420, 190], [370, 200], [365, 280], [330, 285], [300, 240], [230, 200], [200, 160],
      [160, 130], [140, 100]]);
    const ZTF = E.fx(`
const vec2 ZC[25] = vec2[25](vec2(215., 83.), vec2(265., 83.), vec2(315., 83.), vec2(365., 83.), vec2(415., 83.), vec2(215., 133.), vec2(265., 133.), vec2(315., 133.), vec2(365., 133.), vec2(415., 133.), vec2(465., 133.), vec2(515., 133.), vec2(215., 183.), vec2(265., 183.), vec2(315., 183.), vec2(365., 183.), vec2(415., 183.), vec2(465., 183.), vec2(515., 183.), vec2(565., 183.), vec2(265., 233.), vec2(315., 233.), vec2(365., 233.), vec2(315., 283.), vec2(365., 283.));
const float ZK[150] = float[150](-0.4520, 4.7370, 1.4580, -0.1869, -0.9674, -0.5263, 5.3424, -0.7317, 2.5744, -0.5902, 0.4071, 2.7602, 1.0006, 0.7118, -1.6338, -0.0262, -0.5932, 0.7367, -7.8802, 0.4595, 0.3926, -0.4719, 0.7728, -3.9717, 2.0718, 1.3601, -1.2829, 1.2540, -5.1306, 1.7128, -5.6540, 1.6456, 4.1192, 1.1923, -0.9958, -0.3704, 1.6979, -0.1424, 0.4032, -0.1675, 0.5235, -0.7744, 5.6188, -0.2936, 0.7376, -0.0651, 0.9422, -1.0949, 7.5769, 0.3664, -1.1267, 0.0994, -0.8998, 0.5635, 1.2858, 0.0443, 1.2083, 0.7324, -0.1831, -0.4205, 0.2610, -0.3043, 0.7576, 0.4564, -3.4114, 2.3539, 0.6274, -2.0374, 2.8905, -1.6233, 2.9539, 5.7639, -1.4349, 0.7083, 7.4544, 1.3925, -1.0723, 6.0465, 5.7843, -0.5821, -5.0857, 2.5851, 3.9817, -3.8081, 7.7881, -1.6062, 12.5383, 2.5900, -3.0879, 3.7690, -0.2646, -0.0059, -0.0234, 0.0538, -0.0740, -0.1575, -5.3880, -2.4813, 8.6216, -3.3681, 4.5505, 15.1384, -9.3627, 1.6115, 2.0885, 2.8064, -3.5803, -2.3938, -2.2444, 1.1562, 0.0593, -2.3551, -7.7420, -0.8743, -1.3413, -6.0582, 1.7932, -5.7179, -6.5938, -11.1137, 1.3346, 1.7286, 3.9228, -1.3299, 0.7935, 1.4258, 0.5354, -0.7333, 1.2985, -0.5896, 1.3212, -1.2318, 0.7044, -0.2933, 0.2535, -2.9300, -1.0372, -3.6546, -7.8406, -4.3273, 6.1611, 1.6169, -9.2875, 4.2427, 5.6436, -1.9988, 3.0641, -0.6425, 1.9491, 1.3866);
float zv(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 25; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.1513);
    float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }
      vec3 fx(vec2 uv, vec2 p){ return mix(vec3(.94, .93, .94), vec3(.06, .05, .06), smoothstep(-.3, -.06, zv(p))); }`);
    clipA(ZT, () => img(ZTF));
    const ZB = sm([[22, 580], [60, 598], [110, 615], [160, 640], [200, 690], [240, 720], [300, 760], [360, 790], [420, 810], [470, 830], [530, 855], [600, 880], [640, 895], [600, 905], [400, 920],
      [200, 930], [22, 935]]);
    const ZBF = E.fx(`
const vec2 ZC[38] = vec2[38](vec2(52., 610.), vec2(112., 610.), vec2(52., 670.), vec2(112., 670.), vec2(172., 670.), vec2(232., 670.), vec2(52., 730.), vec2(112., 730.), vec2(172., 730.), vec2(232., 730.), vec2(292., 730.), vec2(52., 790.), vec2(112., 790.), vec2(172., 790.), vec2(232., 790.), vec2(292., 790.), vec2(352., 790.), vec2(412., 790.), vec2(52., 850.), vec2(112., 850.), vec2(172., 850.), vec2(232., 850.), vec2(292., 850.), vec2(352., 850.), vec2(412., 850.), vec2(472., 850.), vec2(532., 850.), vec2(592., 850.), vec2(52., 910.), vec2(112., 910.), vec2(172., 910.), vec2(232., 910.), vec2(292., 910.), vec2(352., 910.), vec2(412., 910.), vec2(472., 910.), vec2(532., 910.), vec2(592., 910.));
const float ZK[228] = float[228](-6.2869, 1.3673, -1.7847, 0.4219, 0.0015, -3.4085, -2.2975, 3.0827, -7.2876, -0.6484, -5.4938, 2.7756, 1.2675, -1.0838, 3.3557, -1.6532, -0.1925, -0.6966, -18.7666, -2.2109, 3.8254, -1.8714, 3.9192, -2.1383, -1.2004, -2.3285, 3.9793, 0.2611, 1.1863, 0.3073, 3.6094, 1.6067, 7.4906, 2.2314, -3.8201, -5.5254, 0.0616, -0.4337, 2.7017, 1.3396, -0.7365, -0.1618, 0.0674, -0.5436, 2.9439, -1.4893, 1.5377, -0.2293, 9.2753, -1.5903, 3.9511, -0.0277, 1.4904, -0.4196, 21.4617, -1.0143, 4.1782, 0.2824, -0.1847, -0.0666, 0.7174, 0.3082, 0.1870, -0.0416, -2.3712, 5.2521, 7.4386, -1.9945, 2.5985, 0.2287, 0.0732, 0.1894, 3.5397, -0.5873, 2.2381, 0.5919, -2.5248, 0.0523, 1.4730, -1.1934, 3.3376, 0.3367, -0.0577, -0.6183, -5.0950, -0.9057, 3.5586, 0.0527, 0.7226, -1.1605, 0.4414, -0.2619, 3.7173, 1.0665, -0.0247, -1.2034, 5.2512, -0.5223, 4.3080, -0.4371, 1.0743, 0.0508, -5.2674, -1.4507, 4.7963, -0.8708, 1.5392, 0.6209, 6.0657, -2.0759, 3.2362, 0.6217, -0.0709, 1.1031, 0.0289, -1.4976, 3.0900, 0.3175, -0.3705, 1.0770, 1.2312, -1.3646, 2.8977, 0.1158, -0.2917, 0.5278, -4.4320, -1.1186, 2.3928, 0.0365, -1.1522, -0.2855, 2.4353, -1.2168, 3.6760, -1.2915, 0.5896, 0.5284, -6.4737, -1.2240, 3.4435, 0.3119, -2.3147, -0.3376, 0.8873, -0.8940, 5.2930, -2.0021, 0.9686, 0.0137, 9.2183, -0.3970, 6.2640, 1.4382, 2.4537, -0.6805, -4.7707, -0.4890, 5.8002, -0.9549, -2.3140, -0.1544, 1.8896, 5.3859, 4.5822, 4.4541, -13.8109, -9.2283, 6.3009, -1.7003, 3.2878, -0.0892, 0.8222, -1.2095, 2.2043, -1.8393, 3.3728, 0.1893, -0.7139, -1.0017, 0.1379, -1.7685, 2.9392, -0.0850, -0.8956, -0.7573, 0.0325, -1.7026, 2.6927, 0.3026, -0.3500, -0.2597, -6.9621, -1.4494, 4.9690, -1.5253, -1.0268, 0.9500, 5.1886, 1.9516, -4.6790, -0.3120, -0.4261, -0.6191, -0.0530, -1.1417, 4.9823, -0.0943, 1.1912, 0.2222, -2.1966, 1.1269, 5.1617, -1.0773, 1.1376, -1.4220, 4.6743, -0.6280, -7.3180, 0.4419, -4.4560, 0.7277, 5.2430, 0.4386, 3.5553, -0.3947, 2.9848, 0.9528);
float zv(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 38; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.2178);
    float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }
      vec3 fx(vec2 uv, vec2 p){ return mix(vec3(.95, .95, .96), vec3(.04, .04, .05), smoothstep(-.2, .04, zv(p))); }`);
    clipA(ZB, () => img(ZBF));
    R.flat(ZB, null, 0.1, 4);
    // zebra on the far left strip
    clipA(poly([[24, 150], [60, 140], [60, 600], [24, 600]]), () => { for (let y = 140; y < 600; y += 9) stroke(line([[20, y], [40, y - 4], [64, y + 2]]), '#0a0808', 3.5); });

    // ── grey rippled stripes in the middle ──
    const GS = sm([[240, 300], [300, 290], [360, 285], [400, 300], [400, 420], [380, 520], [360, 580], [300, 600], [250, 590], [238, 450]]);
    const GSF = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float w = sin(p.y * .025 + 1.) * 14. + sin(p.y * .06) * 5. + (p.y - 300.) * .12 + fbm(p * .02) * 20.;
      float b = sin((p.x - w) * .19);
      vec3 c = mix(vec3(.22, .21, .24), vec3(.55, .54, .58), smoothstep(-.6, .0, b));
      c = mix(c, vec3(.74, .72, .76), smoothstep(.5, .95, b));
      return c; }`);
    R.flat(GS, pat(GSF), 0.1, 0);

    // ── blue sky regions with red glow edges ──
    const BLUE1 = sm([[313, 309], [263, 333], [222, 334], [183, 311], [152, 262], [130, 254], [105, 260], [92, 277], [70, 369], [69, 424], [79, 462], [106, 485], [140, 470], [150, 420], [140, 384],
      [152, 358], [259, 361], [291, 342]]);
    const BLUE2 = sm([[120, 196], [200, 190], [260, 200], [300, 225], [330, 258], [316, 282], [270, 286], [248, 278], [200, 244], [180, 225]]);
    for (const B of [BLUE1, BLUE2]) { soft(x => { x.strokeStyle = '#ff4030'; x.lineWidth = 10; x.stroke(B); }, 3, 1); fill(B, lin(0, 190, 0, 490, [[0, '#3a6ad8'], [1, '#2a5ed0']])); stars(B, 40, 7, 60, 180, 280, 320, 2.5); }
    // red/orange glow left of the star and blue pool under it
    soft(x => { x.fillStyle = '#e8304a'; x.fill(sm([[70, 470], [130, 480], [190, 560], [210, 630], [160, 640], [100, 610], [60, 560]])); }, 14, 0.95);
    soft(x => { x.fillStyle = '#ff7a30'; x.fill(ellipseP(90, 600, 30, 20, 0)); }, 10, 0.8);
    const BLUE3 = sm([[180, 600], [230, 640], [300, 640], [380, 660], [440, 680], [490, 700], [520, 740], [480, 770], [420, 770], [340, 760], [280, 730], [220, 690]]);
    fill(BLUE3, '#3058c8'); stars(BLUE3, 20, 9, 180, 600, 340, 180, 2);
    soft(x => { x.fillStyle = '#ff3040'; x.fill(ellipseP(500, 730, 40, 26, 0)); x.fillStyle = '#8a50c0'; x.fill(ellipseP(520, 700, 30, 20, 0)); }, 12, 0.8);

    // ── grey floor with light beams (bottom right) ──
    const FL = sm([[380, 760], [520, 740], [620, 740], [700, 720], [700, 856], [600, 872], [520, 862], [460, 830], [400, 800]]);
    const FLF = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(500., 740.); float an = atan(d.x, d.y);
      float beam = .5 + .5 * sin(an * 9.);
      float fall = exp(-length(d) / 160.) * smoothstep(720., 520., p.x + (p.y - 740.) * .3);
      vec3 c = mix(vec3(.24, .23, .29), vec3(.66, .64, .68), clamp(fall * (.4 + .8 * beam), 0., 1.));
      return c; }`);
    fill(FL, pat(FLF));
    // ribbed grey disc edge
    clipA(sm([[360, 740], [560, 740], [640, 760], [560, 790], [420, 790], [360, 770]]), () => { for (let i = 0; i < 12; i++) stroke(ellipseP(500, 900, 220 - i * 4, 150 - i * 4, 0), i % 2 ? '#9a96a0' : '#5a5862', 2); });

    // ── orange glow + gold ring (right) ──
    soft(x => { x.fillStyle = '#5668c3'; x.fill(sm([[560, 420], [600, 430], [610, 520], [580, 560], [560, 520]])); }, 6, 0.9);
    soft(x => { x.strokeStyle = '#ff9a20'; x.lineWidth = 40; x.stroke(line([[560, 380], [610, 390], [660, 420], [690, 470], [700, 520]])); x.fillStyle = '#ffe860'; x.fill(ellipseP(640, 440, 26, 22, 0.5)); }, 12, 0.95);
    fill(sm([[560, 640], [620, 660], [690, 640], [700, 700], [640, 730], [580, 720], [540, 700]]), '#3a1410');
    const RING = sm([[650, 430], [620, 450], [604, 490], [598, 540], [600, 600], [590, 640], [560, 665], [542, 689], [563, 712], [600, 712], [640, 690], [680, 660], [700, 620], [706, 560],
      [702, 500], [686, 455]]);
    R.dome(RING, lin(560, 420, 710, 720, [[0, '#d8c494'], [0.4, '#b89c68'], [0.7, '#8a6c40'], [1, '#a88a58']]), 0.15, 0.2, 24, 1);
    R.dome(ellipseP(648, 575, 38, 54, 0.05), rad(648, 575, 54, [[0, '#ffffff'], [0.5, '#cdd0de'], [1, '#8a8ea4']], a, 635, 590), 0.2, 0.1, 10, 3);

    // ── pink coral lattice panel, lights, black capsule ──
    const PINK = sm([[392, 330], [430, 296], [470, 282], [530, 290], [575, 330], [590, 400], [584, 520], [578, 640], [540, 662], [480, 660], [430, 640], [400, 560], [388, 440]]);
    fill(sm([[446, 250], [466, 262], [440, 300], [410, 340], [396, 400], [386, 470], [366, 478], [360, 420], [372, 350], [400, 300]]), '#ece472');
    // white coral lattice: cellular mesh, white walls round pink / red cells
    const LAT = E.fx(`vec2 h2(vec2 q){ return vec2(hash(q), hash(q + 17.3)); }
      vec3 fx(vec2 uv, vec2 p){
        vec2 q = p / 17.; vec2 i = floor(q), f = fract(q); float d1 = 9., d2 = 9.; vec2 id = vec2(0.);
        for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) { vec2 g = vec2(float(x), float(y)), o = h2(i + g) * .8 + .1;
          float d = length(g + o - f); if (d < d1) { d2 = d1; d1 = d; id = i + g; } else if (d < d2) d2 = d; }
        float wall = smoothstep(.26, .16, d2 - d1);
        vec3 cell = hash(id + 3.1) < .3 ? vec3(.92, .40, .36) : vec3(.94, .76, .76);
        cell = mix(vec3(.05, .03, .04), cell, smoothstep(320., 370., p.y));
        return mix(cell, vec3(.95, .94, .95), wall); }`);
    R.flat(PINK, pat(LAT), 0.14, 3);
    clipA(PINK, () => {
      fill(rrect(406, 410, 30, 230, 8), lin(406, 0, 436, 0, [[0, '#f0503a'], [0.5, '#ff7050'], [1, '#e83a30']]));
      for (const y of [430, 495]) soft(x => { x.fillStyle = '#fff4b0'; x.fill(circleP(422, y, 12)); }, 4, 1);
    });
    { const r = rng(17);
      // branching coral twigs around the eye-disc and to the right of the lattice
      const twig = (x, y, t, L, d) => { const x2 = x + Math.cos(t) * L, y2 = y - Math.sin(t) * L; R.pipe(line([[x, y], [x2, y2]]), 5 - d, '#efedf0', 0.3, 0.05, 3);
        if (d < 2) { twig(x2, y2, t + 0.5 + r() * 0.3, L * 0.7, d + 1); twig(x2, y2, t - 0.5 - r() * 0.3, L * 0.7, d + 1); } };
      for (let i = 0; i < 14; i++) twig(545 + r() * 40, 320 + r() * 110, -0.5 + r() * 1.0, 14 + r() * 10, 0);
      for (let i = 0; i < 10; i++) twig(470 + r() * 90, 230 + r() * 60, 0.9 + r() * 1.3, 14 + r() * 10, 0);
      for (let i = 0; i < 8; i++) twig(400 + r() * 60, 300 + r() * 40, 1.4 + r() * 1.2, 12 + r() * 8, 0); }
    stroke(line([[450, 400], [446, 560]]), '#a8e8ff', 4);
    const CAPS = sm([[509, 385], [493, 405], [504, 437], [495, 469], [506, 481], [498, 516], [508, 529], [503, 563], [514, 590], [551, 584], [555, 565], [546, 545], [551, 521], [541, 504], [547, 475],
      [539, 463], [544, 443], [540, 392]]);
    R.flat(CAPS, '#0a080c', 0.18, 0);
    for (let i = 0; i < 6; i++) R.bead(520, 420 + i * 30, 6, '#a8dcf0', 0.2, 0.05, 3);
    R.pipe(line([[440, 616], [500, 600], [555, 586]]), 4, '#a8e8ff', 0.35, 0.03, 3);
    // yellow strip

    // ── white card with brown dots + tendrils ──
    const CARD = sm([[157, 357], [146, 362], [130, 400], [126, 450], [126, 563], [152, 572], [195, 573], [218, 571], [230, 589], [237, 574], [236, 526], [240, 493], [237, 436], [253, 376], [245, 364]]);
    { const r = rng(19); for (let i = 0; i < 26; i++) { const y = 380 + r() * 200, x0 = 128 - r() * 4; R.pipe(line([[x0, y], [x0 - 8 - r() * 14, y + (r() - 0.5) * 10]]), 4, '#ecebee', 0.12, 0.04, 3); } }
    R.dome(CARD, lin(130, 360, 250, 590, [[0, '#f2f2f6'], [1, '#d6d6de']]), 0.1, 0.1, 12, 4);
    { const r = rng(23); for (let i = 0; i < 34; i++) fill(P(blob(140 + r() * 95, 375 + r() * 195, 2.5 + r() * 2, 2 + r() * 1.5, i, 6, 0.3, r() * 3)), '#7a5a3a'); }

    // ── satin-gold swan form ──
    const GOLD = sm([[233, -10], [180, -10], [170, 26], [170, 47], [110, 100], [63, 155], [32, 216], [28, 300], [30, 375], [43, 410], [48, 482], [58, 506], [70, 508], [88, 500], [67, 473], [60, 419],
      [67, 344], [88, 274], [80, 252], [99, 241], [133, 249], [153, 257], [192, 313], [228, 330], [276, 323], [315, 299], [324, 287], [321, 281], [270, 286], [248, 278], [200, 244], [189, 220],
      [171, 231], [138, 229], [110, 213], [111, 198], [134, 167], [153, 166], [144, 145], [157, 124], [196, 87]]);
    soft(x => { x.strokeStyle = '#e83a28'; x.lineWidth = 8; x.stroke(GOLD); }, 3, 0.9);
    R.dome(GOLD, lin(30, 0, 330, 0, [[0, '#c8b48e'], [0.25, '#f4e8cc'], [0.5, '#e2d0aa'], [0.8, '#f0e2c0'], [1, '#d0b890']]), 0.15, 0.3, 28, 1);
    R.bead(150, 236, 10, '#c83a20', 0.3, 0.05, 3);

    // ── owl creature with eyes (left) ──
    soft(x => { x.fillStyle = '#ff6a28'; x.fill(sm([[60, 520], [110, 540], [140, 600], [120, 640], [80, 630]])); x.fillStyle = '#e83060'; x.fill(ellipseP(150, 590, 34, 40, 0)); }, 12, 0.9);
    const OWL = sm([[28, 528], [50, 508], [76, 512], [96, 540], [110, 578], [120, 610], [96, 618], [62, 604], [34, 578]]);
    R.dome(OWL, lin(30, 510, 120, 620, [[0, '#3a3036'], [1, '#5a4c50']]), 0.12, 0.1, 14, 2);
    clipA(OWL, () => { for (let i = 0; i < 16; i++) stroke(line([[30 + i * 6, 512], [40 + i * 6, 560], [54 + i * 6, 618]]), '#8a7e86', 1.4); });
    const ZC2 = sm([[112, 646], [132, 628], [160, 626], [186, 640], [198, 668], [190, 694], [160, 698], [130, 686], [116, 668]]);
    R.flat(ZC2, '#ecebee', 0.12, 4);
    clipA(ZC2, () => { for (let i = 0; i < 12; i++) stroke(line([[100 + i * 10, 700], [130 + i * 10, 640], [150 + i * 10, 620]]), '#0a0a0c', 4); });
    for (const [x, y, rr] of [[82, 513, 10], [150, 648, 13]]) { R.dome(circleP(x, y, rr), '#f0f4f8', 0.2, 0.08, 4, 3); fill(circleP(x, y, rr * 0.7), '#3ab0e8'); fill(circleP(x, y, rr * 0.35), '#0a1828'); }

    // ── top cluster: gold and silver horns, black eye disc ──
    const horn = (pts, w0, alb) => R.dome(P(lock(pts, w0, 1.5), true, true), alb, 0.25, 0.25, w0 * 0.45, alb === 'g' ? 1 : 2);
    const hornG = (pts, w0) => R.dome(P(lock(pts, w0, 1.5), true, true), lin(pts[0][0], pts[0][1], pts[pts.length - 1][0], pts[pts.length - 1][1], [[0, '#c8a868'], [1, '#e8d098']]), 0.25, 0.25, w0 * 0.45, 1);
    const hornS = (pts, w0) => R.dome(P(lock(pts, w0, 1.5), true, true), lin(pts[0][0], pts[0][1], pts[pts.length - 1][0], pts[pts.length - 1][1], [[0, '#a8a8b0'], [1, '#f0f0f4']]), 0.25, 0.25, w0 * 0.45, 2);
    hornS([[420, 275], [380, 258], [345, 250], [318, 258]], 26);
    hornS([[420, 265], [384, 228], [358, 200], [336, 172]], 26);
    hornS([[445, 255], [470, 215], [492, 185], [508, 152]], 22);
    hornS([[430, 262], [440, 220], [452, 190], [470, 160]], 20);
    hornG([[420, 262], [384, 232], [366, 200], [362, 162]], 26);
    hornG([[432, 262], [424, 220], [428, 180], [440, 136]], 28);
    hornG([[425, 268], [390, 252], [356, 240], [326, 232]], 22);
    hornG([[440, 258], [462, 222], [482, 190], [497, 156]], 20);
    R.dome(sm([[360, 270], [400, 262], [440, 268], [470, 250], [480, 270], [450, 290], [400, 292], [360, 288]]), '#c8c870', 0.3, 0.08, 6, 4);
    for (const [x, y] of [[420, 270], [432, 262], [445, 275], [410, 280]]) R.bead(x, y, 4, '#f0e8e8', 0.4, 0.05, 3);
    R.dome(circleP(508, 268, 37), rad(508, 268, 37, [[0, '#2a2830'], [1, '#0a0a0c']], a, 495, 250), 0.25, 0.15, 14, 5);
    R.dome(circleP(508, 266, 12), '#e8f4fa', 0.42, 0.04, 4, 3); fill(circleP(508, 266, 8), '#44b4e8'); fill(circleP(508, 266, 3.5), '#0a1828');

    // ── the big star: silver spikes with gold tips, gold inner star ──
    const C = [372, 620];
    const spike = (tx, ty, w, gold) => {
      const dx = tx - C[0], dy = ty - C[1], L = Math.hypot(dx, dy), ux = dx / L, uy = dy / L, nx = -uy, ny = ux;
      const bx = C[0] + ux * 10, by = C[1] + uy * 10; w *= 1.45;
      const body = sm([[bx + nx * w, by + ny * w], [bx + ux * L * 0.5 + nx * w * 0.8, by + uy * L * 0.5 + ny * w * 0.8], [tx - ux * 14 + nx * w * 0.35, ty - uy * 14 + ny * w * 0.35],
        [tx - ux * 14 - nx * w * 0.35, ty - uy * 14 - ny * w * 0.35], [bx + ux * L * 0.5 - nx * w * 0.8, by + uy * L * 0.5 - ny * w * 0.8], [bx - nx * w, by - ny * w]]);
      R.dome(body, gold ? lin(bx + nx * w, by + ny * w, bx - nx * w, by - ny * w, [[0, '#fcf2d4'], [0.5, '#e8d6a8'], [1, '#c0a676']])
        : lin(bx + nx * w, by + ny * w, bx - nx * w, by - ny * w, [[0, '#f6f6fa'], [0.5, '#d2d3dc'], [1, '#9a9ca8']]), 0.3, 0.3, w * 0.9, gold ? 1 : 2);
      if (!gold) R.dome(poly([[tx - ux * 22 + nx * w * 0.45, ty - uy * 22 + ny * w * 0.45], [tx, ty], [tx - ux * 22 - nx * w * 0.45, ty - uy * 22 - ny * w * 0.45]]), lin(tx - ux * 22 + nx * 8, ty - uy * 22 + ny * 8, tx - ux * 22 - nx * 8, ty - uy * 22 - ny * 8, [[0, '#f0c888'], [0.5, '#c88a40'], [1, '#8a5420']]), 0.45, 0.12, 5, 1);
    };
    for (const [x, y, w] of [[294, 456, 13], [255, 481, 14], [230, 506, 14], [194, 566, 14], [187, 609, 13], [201, 638, 13], [326, 713, 14], [198, 756, 15], [316, 809, 14], [401, 777, 13],
      [452, 740, 12], [309, 556, 12], [250, 690, 14]]) spike(x, y, w, false);
    for (const [x, y, w] of [[362, 449, 13], [387, 495, 12], [473, 509, 12], [516, 641, 11], [300, 640, 12], [420, 700, 12], [355, 700, 12]]) spike(x, y, w, true);
    R.dome(circleP(C[0], C[1], 22), rad(C[0], C[1], 22, [[0, '#fff6dc'], [1, '#d8c08c']], a, C[0] - 6, C[1] - 8), 0.45, 0.1, 10, 1);
    // blue needles
    R.pipe(line([[430, 620], [530, 596], [556, 588]]), 4, '#bfeaff', 0.5, 0.03, 3);
    // drips of gold
    R.pipe(line([[482, 650], [478, 690], [484, 720], [480, 744]]), 5, '#c8b830', 0.4, 0.04, 1);
    R.dome(P(blob(518, 680, 26, 12, 8, 9, 0.2, -0.3)), '#e8c440', 0.4, 0.1, 8, 1);

    // ── rim drips ──
    for (const [x, y, rr] of [[690, 50, 9], [702, 860, 8], [520, 905, 6]]) R.bead(x, y, rr, '#ece6d2', 0.1, 0.1, 4);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, metal: 0.2, spec: 1.2, shin: 26, rim: 0.25, ao: 0.5, tint: [1.08, 1.0, 0.82], coat: 0.06, wrap: 0.35, emis: 0.18 }), // 1 satin gold
        E.mat({ dif: 1, metal: 0.15, spec: 1.1, shin: 40, rim: 0.3, ao: 0.5, coat: 0.08, wrap: 0.2, emis: 0.02 }),                 // 2 silver
        E.mat({ dif: 1, spec: 0.6, shin: 40, wrap: 0.4, ao: 0.4 }),                                                                 // 3 glossy
        E.mat({ dif: 1, spec: 0.2, shin: 20, wrap: 0.5, ao: 0.3 }),                                                                 // 4 card / rim
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.3, ao: 0.4, coat: 0.15 })                                                      // 5 black gloss
      ],
      light: [-0.4, 0.55, 0.73], lc: [0.7, 0.69, 0.68], amb: [0.42, 0.42, 0.44],
      envTop: [1.05, 1.02, 0.98], envHor: [0.6, 0.55, 0.6], envBot: [0.2, 0.15, 0.2], envK: [0.3, 1.0, 0.3, 0],
      rimC: [0.3, 0.3, 0.35], rimD: [0, 1, 0], r1: 1.5, r2: 8, k: [0, 0.6, 0.4, 90], shadow: [-5, 7, 0.5, 6]
    });
    E.grain(0.03, 57);
  }
});
