'use strict';
// s08 — "Maze-tattooed mask": a glossy magenta/red sculpted face with black eye holes and a
// nose over an open mouth-sphere holding a green squiggle creature; blue/purple bands of
// yellow and pink maze-lines sweep in from the top right, teal and a rainbow glow below.
REC.register('s08', {
  w: 1024, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over', clip = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clip) a.clip(clip); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fillE = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const fillP = (x, pts, col) => { x.fillStyle = col; x.fill(P(pts)); };
    const texIn = (path, cv, alpha = 1) => { a.save(); a.clip(path); a.globalAlpha = alpha; a.drawImage(cv, 0, 0, 1024, 1024); a.restore(); };
    const full = rrect(-10, -10, 1044, 1044, 0);
    // soft cosine bumps painted straight into the height buffer (max-blended, R channel only)
    const bump = (x, y, rx, ry, rot, dh, base = 0.1) => {
      const hx = R.h; hx.save(); hx.globalCompositeOperation = 'lighten';
      hx.translate(x, y); hx.rotate(rot); hx.scale(rx, ry);
      const g = hx.createRadialGradient(0, 0, 0, 0, 0, 1);
      for (let i = 0; i <= 16; i++) { const t = i / 16, v = Math.round((base + dh * (0.5 + 0.5 * Math.cos(Math.PI * t))) * 255); g.addColorStop(t, `rgb(${v},32,0)`); }
      hx.fillStyle = g; hx.beginPath(); hx.arc(0, 0, 1, 0, Math.PI * 2); hx.fill(); hx.restore();
    };

    // maze-line texture: warped contour lines in yellow / pink / cyan over blue-violet
    const maze = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        vec2 q = px * 0.009;
        float f = fbm(q + vec2(fbm(q * 1.7), fbm(q * 1.7 + 9.1)) * 1.2);
        float c1 = abs(fract(f * 7.0) - 0.5), c2 = abs(fract(fbm(q * 1.4 + 4.0) * 6.0) - 0.5);
        float band = fbm(px * 0.006 + 2.0);
        vec3 base = mix(vec3(0.33, 0.30, 0.62), vec3(0.42, 0.55, 0.80), smoothstep(0.35, 0.7, band));
        base = mix(base, vec3(0.45, 0.28, 0.45), smoothstep(0.55, 0.75, fbm(px * 0.01 + 7.0)) * 0.6);
        vec3 lc = mix(vec3(0.95, 0.80, 0.35), vec3(0.95, 0.52, 0.62), step(0.5, fbm(px * 0.008 + 3.0)));
        lc = mix(lc, vec3(0.55, 0.85, 0.95), step(0.62, fbm(px * 0.009 + 11.0)));
        vec3 c = mix(base, lc, smoothstep(0.13, 0.07, c1));
        c = mix(c, base * 0.5, smoothstep(0.08, 0.03, c2) * 0.6);
        return c;
      }`);

    // ── the mask: one big glossy relief ──
    R.flat(full, '#b03c5c', 0.1, 1);
    // soft bulges (height only)
    for (const [x, y, rx, ry, rot, dh] of [[150, 280, 150, 240, 0.2, 0.2], [300, 90, 200, 80, 0, 0.18], [110, 840, 160, 240, 0.1, 0.2], [860, 800, 170, 170, 0, 0.16],
      [700, 110, 140, 90, 0, 0.18], [170, 560, 80, 130, 0, 0.2], [450, 200, 70, 260, 0, 0.3], [150, 250, 50, 170, 0.3, 0.25]])
      bump(x, y, rx * 1.3, ry * 1.3, rot, dh);
    // colour fields
    soft(x => {
      fillP(x, [[380, -20], [520, -20], [560, 200], [520, 400], [500, 520], [380, 520], [360, 380], [340, 200]], '#dc5a3c');   // nose ridge
      fillE(x, 150, 260, 130, 220, 0.2, '#a83a4c'); fillE(x, 300, 110, 160, 90, 0, '#b84460'); fillE(x, 600, 60, 70, 70, 0, '#6a2438');
      fillE(x, 660, 120, 150, 110, 0, '#d86a64'); fillE(x, 980, 170, 80, 150, 0, '#d63f52');
      fillE(x, 110, 820, 170, 260, 0.1, '#b48ea4'); fillE(x, 260, 960, 160, 80, 0, '#a85a78');
      fillE(x, 500, 950, 230, 110, 0, '#301c20'); fillE(x, 520, 870, 170, 60, 0, '#4a2028');
      fillE(x, 840, 760, 170, 150, -0.6, '#2a6e78'); fillE(x, 620, 780, 90, 90, 0, '#5a2232'); fillE(x, 960, 900, 110, 130, 0, '#a07184'); fillE(x, 760, 1000, 120, 60, 0, '#84536e');
      fillE(x, 170, 560, 90, 110, 0, '#b43c52'); fillE(x, 300, 450, 45, 60, 0, '#d8a8c0'); fillE(x, 800, 575, 120, 40, 0, '#2a2030'); fillE(x, 700, 60, 90, 60, 0, '#d06a60');
    }, 40, 1);
    soft(x => { fillE(x, 450, 250, 30, 200, 0, '#f48a58'); fillE(x, 140, 180, 30, 110, 0.4, '#ec9aa4'); fillE(x, 80, 760, 40, 160, 0.1, '#f0c0d4'); }, 30, 0.8);
    // rainbow glow band, lower right
    soft(x => {
      const cols = ['#c83a4a', '#e8a038', '#e8d850', '#58b060', '#2e8a8a'];
      cols.forEach((c, i) => { x.strokeStyle = c; x.lineWidth = 34; x.beginPath(); x.moveTo(600 + i * 30, 1060); x.quadraticCurveTo(720 + i * 30, 820, 1060, 660 + i * 30); x.stroke(); });
    }, 26, 0.45);

    // ── black background showing through ──
    const blackBits = [
      [[-10, -10], [300, -10], [200, 14], [120, 56], [70, 120], [40, 190], [-10, 200]],
      [[-10, 190], [18, 192], [40, 260], [62, 330], [92, 420], [112, 470], [84, 520], [40, 548], [-10, 555]],
      [[1034, 560], [960, 590], [930, 640], [940, 700], [965, 760], [1034, 780]],
    ];
    for (const b of blackBits) { R.flat(P(b), '#1a2320', 0.02, 0); a.save(); a.strokeStyle = '#e8eef0'; a.lineWidth = 3; a.stroke(P(b)); a.restore(); }
    // teal speckle at the far left
    { const tp = P([[-10, 540], [40, 548], [30, 640], [20, 760], [-10, 770]]); R.flat(tp, '#1f4e5c', 0.02, 0);
      const r = rng(4); a.save(); a.clip(tp); for (let i = 0; i < 400; i++) { a.fillStyle = r() < 0.5 ? '#4a8a9a' : '#123040'; a.fillRect(r() * 50, 540 + r() * 230, 2, 2); } a.restore(); }
    // eye holes (sunken into the relief)
    const eyeL = P([[215, 300], [222, 228], [250, 182], [300, 165], [345, 182], [362, 250], [356, 320], [330, 352], [280, 356], [236, 345]]);
    const eyeR = P([[530, 240], [556, 186], [620, 166], [680, 172], [730, 198], [790, 250], [806, 330], [770, 362], [720, 330], [680, 300], [630, 296], [580, 330], [540, 316]]);
    const holeL = P([[120, 430], [175, 410], [230, 440], [255, 520], [250, 620], [230, 700], [180, 710], [140, 660], [118, 560]]);
    R.dome(eyeL, '#141c1a', 0.1, -0.1, 40, 2);
    R.dome(eyeR, '#141c1a', 0.1, -0.1, 40, 2);
    R.dome(holeL, '#1c1a1c', 0.1, -0.1, 40, 2);
    R.dome(P([[170, 520], [215, 490], [240, 560], [235, 650], [200, 690], [168, 640]]), '#b83a4e', 0.08, 0.12, 30, 1);
    R.dome(P([[610, 250], [670, 240], [740, 270], [780, 320], [760, 352], [700, 330], [640, 310]]), '#c84050', 0.1, 0.1, 30, 1);

    // ── maze bands ──
    const band = P([[690, -10], [700, 40], [650, 60], [590, 30], [560, -10], [1034, -10], [1034, 30], [950, 60], [930, 180], [900, 290], [868, 340], [862, 470], [880, 560], [800, 565], [700, 535], [610, 478], [488, 468], [482, 405], [560, 392], [640, 378], [720, 365], [800, 340], [790, 250], [740, 180], [690, 120], [630, 60]]);
    R.dome(band, '#5a58a8', 0.3, 0.12, 60, 3); texIn(band, maze);
    R.dome(P([[940, 60], [1034, 30], [1034, 300], [960, 290]]), '#d64050', 0.3, 0.1, 40, 1);
    const crescent = P([[880, 280], [915, 262], [945, 300], [950, 400], [935, 480], [905, 555], [875, 540], [870, 440], [868, 340]]);
    R.dome(crescent, '#f0d65c', 0.36, 0.08, 30, 3);
    R.dome(P([[950, 380], [1034, 360], [1034, 560], [960, 560]]), '#c85a6a', 0.3, 0.08, 30, 3);
    { const pr = P([[950, 380], [1034, 360], [1034, 560], [960, 560]]); texIn(pr, maze, 0.5); }
    // yellow stripe fan
    for (let i = 0; i < 5; i++) R.pipe(P([[495, 408 + i * 14], [560, 400 + i * 16], [640, 420 + i * 14], [690, 452 + i * 10]], false), 9, '#f2d45a', 0.44, 0.03, 3);
    // small maze patches top-left and left edge
    const tl = P([[130, 60], [180, 30], [260, 12], [290, 30], [240, 70], [170, 90]]);
    R.dome(tl, '#d45a78', 0.5, 0.02, 10, 1); texIn(tl, maze, 0.8);
    const le = P([[10, 200], [40, 205], [80, 260], [100, 330], [60, 340], [20, 300]]);
    R.dome(le, '#6060b0', 0.1, 0.06, 10, 3); texIn(le, maze);

    // ── mouth sphere + squiggle creature ──
    const sph = ellipseP(484, 650, 232, 192, -0.05);
    const sg = a.createRadialGradient(560, 600, 20, 484, 650, 260);
    sg.addColorStop(0, '#a83468'); sg.addColorStop(0.6, '#8a2c58'); sg.addColorStop(1, '#5a2238');
    R.dome(sph, sg, 0.3, 0.3, 160, 4);
    soft(x => { fillE(x, 330, 650, 90, 150, 0, '#8ab880'); fillE(x, 330, 770, 70, 50, 0, '#e8c050'); fillE(x, 610, 520, 80, 50, 0, '#6a7ab8'); }, 40, 0.8, 'source-over', sph);
    const GR = '#78c08a';
    for (const t of [[[360, 600], [340, 640], [320, 690], [322, 740], [330, 790]], [[380, 690], [372, 740], [378, 790]], [[410, 700], [410, 750], [420, 790]], [[440, 695], [450, 740], [462, 780]],
      [[300, 560], [330, 600], [360, 620], [400, 640], [440, 660], [470, 680]], [[300, 520], [290, 560], [300, 600]], [[380, 560], [400, 600], [430, 610]], [[470, 640], [480, 690], [460, 700]]])
      R.pipe(P(t, false), 20, GR, 0.58, 0.04, 5);
    R.dome(P([[400, 520], [470, 470], [520, 480], [500, 560], [460, 600], [420, 600]]), '#5ab8b0', 0.56, 0.05, 20, 5);
    R.flat(ellipseP(425, 610, 16, 12, 0), '#a43266', 0.6, 5);
    R.flat(ellipseP(400, 620, 7, 6, 0), '#a43266', 0.6, 5);

    // ── nose ──
    const nose = P([[330, 460], [360, 420], [410, 380], [460, 390], [500, 440], [510, 500], [480, 540], [420, 550], [360, 545], [325, 510]]);
    R.dome(nose, '#d04a58', 0.4, 0.25, 70, 1);
    R.dome(ellipseP(345, 525, 22, 14, 0.3), '#2a1216', 0.62, -0.1, 12, 1);
    R.dome(ellipseP(410, 525, 22, 13, -0.2), '#2a1216', 0.62, -0.1, 12, 1);
    // soft cheek line + shading
    soft(x => { x.strokeStyle = '#5a1a2a'; x.lineWidth = 20; x.beginPath(); x.moveTo(250, 820); x.quadraticCurveTo(480, 900, 720, 800); x.stroke(); }, 16, 0.6);

    // dark frame
    a.save(); a.strokeStyle = '#141a18'; a.lineWidth = 18; a.strokeRect(0, 0, 1024, 1024); a.restore();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.85, emis: 0.2, spec: 0.55, shin: 28, wrap: 0.35, coat: 0.08, rim: 0.3 }),    // glossy mask
        E.mat({ dif: 0.6, emis: 0.2, spec: 0.3, shin: 20 }),                                         // holes
        E.mat({ dif: 0.85, emis: 0.25, spec: 0.35, shin: 25, wrap: 0.3, coat: 0.05 }),               // maze bands
        E.mat({ dif: 0.85, emis: 0.2, spec: 0.7, shin: 40, wrap: 0.3, coat: 0.1 }),                 // sphere
        E.mat({ dif: 0.85, emis: 0.3, spec: 0.4, shin: 30, wrap: 0.3 })                              // squiggle
      ],
      light: [-0.35, 0.55, 0.75], lc: [0.72, 0.7, 0.7], amb: [0.3, 0.28, 0.3],
      envTop: [1, 0.95, 0.95], envHor: [0.5, 0.4, 0.45], envBot: [0.1, 0.06, 0.08], envK: [0.3, 0.9, 0.4, 0],
      rimC: [0.3, 0.25, 0.3], shadow: [-8, 8, 0.5, 6], r1: 3, r2: 14, k: [0, 0.6, 0.4, 60]
    });
    E.grain(0.04, 8);
  }
});
