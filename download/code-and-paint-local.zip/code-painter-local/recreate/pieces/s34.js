'use strict';
// s34 — "Coral saint": a grey profile figure looking up to a starry sky, haloed by a cream
// disc with a golden lotus; its robe is a red panel grown over with grey coral lattice,
// flanked by a green field, beige pearl clusters, a terracotta pocket and white S-hooks.
REC.register('s34', {
  w: 578, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const r = rng(34);
    // coral lattice: albedo + height rendered on the GPU, composited inside a clip
    const coral = (clip, base, cell, thick, seed, mat) => {
      const G = `
        float nz(vec2 q){ return vnoise(q) * 0.62 + vnoise(q * 2.13 + 5.1) * 0.28 + vnoise(q * 4.7 + 1.3) * 0.1; }
        float rd(vec2 p, float f, float o){
          float e = 1.5, n = nz(p * f + o);
          vec2 g = vec2(nz((p + vec2(e, 0.)) * f + o) - n, nz((p + vec2(0., e)) * f + o) - n) / e;
          return abs(n - 0.5) / max(length(g), 1e-4);
        }
        float cd(vec2 p, out float d1){ d1 = 0.; return min(rd(p, uC, uS), rd(p, uC * 1.4, uS + 3.3)) ; }`;
      const alb = E.fx(G + `vec3 fx(vec2 uv, vec2 p){ float d1; float e = cd(p, d1); float t = uT0 * (0.7 + 0.6 * vnoise(p * 0.05));
          float m = smoothstep(t, t - 1.5, e); return mix(uB, vec3(.66,.63,.59) * (0.9 + 0.2 * vnoise(p * 0.2)), m); }`, { uS: seed, uC: cell, uT0: thick, uB: base });
      const hgt = E.fx(G + `vec3 fx(vec2 uv, vec2 p){ float d1; float e = cd(p, d1); float t = uT0 * (0.7 + 0.6 * vnoise(p * 0.05));
          float k = clamp(1. - e / t, 0., 1.); float h = 0.14 + 0.22 * sqrt(max(0., 1. - (1. - k) * (1. - k))) * step(0.001, k);
          float v = h * 255.; return vec3(floor(v) / 255., uM * 32. / 255., fract(v)); }`, { uS: seed, uC: cell, uT0: thick, uM: mat });
      for (const [ctx, cv] of [[a, alb], [R.h, hgt]]) { ctx.save(); ctx.clip(clip); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); }
    };

    // ── sky ──
    R.flat(rrect(-5, -5, 590, 1040, 0), '#0c0e0d', 0, 0);
    for (let i = 0; i < 60; i++) { const x = r() * 578, y = r() * 360; a.fillStyle = '#f4f4f0'; a.beginPath(); a.arc(x, y, 0.8 + Math.pow(r(), 3) * 3.5, 0, 6.283); a.fill(); }
    // halo disc + golden lotus
    R.dome(circleP(160, 108, 140), '#f3f1ea', 0.04, 0.06, 20, 2);
    R.pipe(circleP(160, 108, 138), 7, '#c8a040', 0.1, 0.04, 3);
    soft(x => { x.fillStyle = '#fff6a0'; x.fill(ellipseP(150, 70, 80, 45, 0)); }, 20, 0.9);
    for (const pp of [[[140, 70], [120, 30], [100, 5]], [[140, 70], [135, 20], [150, -5]], [[150, 70], [175, 30], [210, 10]], [[155, 72], [200, 60], [250, 55]], [[130, 70], [95, 45], [80, 20]], [[160, 75], [220, 75], [265, 60]]])
      R.pipe(P(pp, false), 4, '#d8b030', 0.1, 0.05, 3);
    R.dome(P([[70, 80], [90, 50], [125, 45], [150, 70], [135, 95], [95, 100]]), '#f2c83c', 0.1, 0.14, 20, 3);
    R.dome(P([[150, 65], [165, 25], [195, 10], [210, 30], [200, 70], [170, 85]]), '#f6d040', 0.1, 0.14, 20, 3);
    R.dome(P([[118, 60], [128, 30], [150, 40], [148, 70]]), '#f8e070', 0.12, 0.1, 10, 3);
    soft(x => { x.fillStyle = '#fffbe0'; x.fill(ellipseP(150, 75, 20, 14, 0)); }, 6, 1);
    R.dome(circleP(66, 130, 26), '#f0dca0', 0.08, 0.1, 12, 3);
    for (let k = 0; k < 22; k++) { const an = r() * 6.28, d = Math.sqrt(r()) * 20; a.fillStyle = '#d88a30'; a.beginPath(); a.arc(66 + Math.cos(an) * d, 130 + Math.sin(an) * d, 2.2, 0, 6.283); a.fill(); }
    // moon
    R.dome(circleP(413, 127, 44), '#b0aeab', 0.04, 0.05, 30, 2);

    // ── side fields ──
    R.flat(rrect(0, 368, 90, 660, 0), '#c21a10', 0.02, 1);
    R.flat(rrect(330, 345, 225, 675, 0), '#20cc12', 0.02, 1);
    soft(x => { x.fillStyle = '#50d840'; x.fill(ellipseP(470, 620, 60, 200, 0)); }, 40, 0.3);
    // page stack at the right
    const pages = P([[345, 338], [420, 325], [500, 318], [560, 318], [575, 322], [575, 1015], [548, 1015], [548, 340], [470, 342]]);
    R.dome(pages, '#c4c2bc', 0.06, 0.08, 10, 2);
    for (let k = 0; k < 7; k++) { a.strokeStyle = k % 2 ? '#8a8880' : '#e8e6e0'; a.lineWidth = 1.5; a.beginPath(); a.moveTo(551 + k * 3.4, 1015); a.lineTo(551 + k * 3.4, 330 - k); a.lineTo(360, 342 - k * 2); a.stroke(); }
    // big white S hook
    R.pipe(P([[542, 278], [528, 240], [492, 232], [462, 256], [450, 300], [446, 350], [428, 392], [396, 410], [368, 398]], false), 22, '#e4ecef', 0.2, 0.2, 2);
    R.bead(515, 410, 5, '#f4a8d8', 0.2, 0.05, 2);

    // ── left drape ──
    const drape = P([[104, 292], [62, 306], [28, 345], [10, 410], [4, 520], [4, 1030], [78, 1030], [78, 345], [104, 326]]);
    R.dome(drape, '#a8a49e', 0.08, 0.14, 30, 2);
    for (let k = 0; k < 16; k++) { const x0 = 10 + k * 4.2; R.groove(P([[x0 + 30, 318 + k * 1.2], [x0 + 8, 400], [x0, 600], [x0, 1030]], false), 2.4, '#6e6a64', 0.22, 0.04, 2, 0.8); }
    soft(x => { x.strokeStyle = '#f0eeea'; x.lineWidth = 8; x.stroke(P([[104, 296], [62, 310], [30, 350], [12, 420]], false)); }, 3, 0.9);

    // ── robe: coral panel + dashed column ──
    const robe = P([[72, 342], [212, 342], [212, 1022], [72, 1022]], true, false);
    R.flat(robe, '#c01a10', 0.08, 1);
    coral(robe, [0.78, 0.1, 0.06], 0.026, 6.8, 3.1, 5);
    R.dome(rrect(66, 342, 12, 680, 3), '#b8b4ae', 0.1, 0.1, 6, 2);
    R.flat(rrect(206, 342, 48, 680, 0), '#c41c12', 0.08, 1);
    for (let k = 0; k < 42; k++) { const x = 212 + (k % 3) * 13, y = 350 + ((k / 3) | 0) * 49 + (k % 3) * 16; R.dome(rrect(x, y, 6, 34, 3), '#b4b0a8', 0.12, 0.08, 3, 2); }
    R.dome(rrect(204, 342, 7, 680, 3), '#b8b4ae', 0.1, 0.08, 3, 2);
    R.dome(rrect(254, 342, 14, 520, 4), '#b8b4ae', 0.1, 0.08, 6, 2);

    // ── striped patch + red strip under the arm ──
    const strp = P([[280, 380], [345, 360], [360, 500], [290, 505]]);
    R.flat(strp, '#f0f0ee', 0.12, 2);
    clipA(strp, () => { a.strokeStyle = '#141414'; a.lineWidth = 3; for (let k = -10; k < 30; k++) { a.beginPath(); a.moveTo(260, 380 + k * 7); a.bezierCurveTo(300, 360 + k * 7, 330, 400 + k * 7, 370, 360 + k * 7); a.stroke(); } });
    R.flat(P([[262, 540], [300, 560], [300, 700], [262, 720]]), '#ae5448', 0.1, 1);

    // ── big grey arm ──
    const arm = P([[262, 570], [270, 480], [300, 425], [345, 378], [372, 368], [405, 405], [442, 470], [474, 560], [482, 640], [462, 692], [400, 712], [330, 700], [282, 668]]);
    R.dome(arm, '#878784', 0.1, 0.12, 50, 2);
    // terracotta pocket
    const pocket = P([[252, 700], [272, 652], [330, 700], [402, 716], [408, 770], [396, 836], [356, 876], [300, 884], [256, 862]]);
    R.dome(pocket, '#b0aca4', 0.1, 0.1, 12, 2);
    const pin = P([[266, 712], [280, 675], [330, 712], [392, 726], [396, 772], [386, 830], [352, 864], [302, 870], [266, 850]]);
    R.flat(pin, '#a85a36', 0.16, 1);
    clipA(pin, () => {
      a.strokeStyle = '#d8b8a0'; a.lineWidth = 2;
      a.beginPath(); a.moveTo(270, 800); a.bezierCurveTo(300, 760, 340, 760, 370, 800); a.stroke();
      a.beginPath(); a.moveTo(290, 830); a.lineTo(300, 800); a.lineTo(320, 830); a.lineTo(340, 800); a.lineTo(360, 835); a.stroke();
      a.fillStyle = '#eef4f8'; a.beginPath(); a.ellipse(300, 725, 12, 9, 0, 0, 6.283); a.fill();
      a.strokeStyle = '#d0a080'; a.beginPath(); a.arc(345, 745, 12, 0, 6.283); a.stroke();
    });

    // ── head + neck ──
    const head = P([[150, 300], [146, 262], [120, 222], [96, 182], [88, 140], [100, 100], [130, 76], [175, 64], [225, 68], [265, 86], [290, 108], [301, 128], [316, 140], [322, 150], [312, 160], [318, 172], [328, 183], [318, 191], [322, 201], [312, 215], [290, 228], [270, 240], [268, 272], [274, 300]], true, true);
    R.dome(head, '#8a8886', 0.12, 0.1, 40, 2);
    R.pipe(P([[258, 127], [268, 122]], false), 3, '#d8d6d4', 0.24, 0.02, 2);
    // collar pod
    const collar = P([[102, 318], [140, 296], [210, 286], [290, 288], [345, 298], [384, 316], [360, 330], [300, 342], [200, 342], [130, 336]]);
    R.dome(collar, '#9c9994', 0.18, 0.12, 22, 2);
    clipA(collar, () => { for (let k = 0; k < 12; k++) { a.strokeStyle = 'rgba(80,76,70,0.5)'; a.lineWidth = 1.5; a.beginPath(); a.moveTo(100, 296 + k * 4); a.bezierCurveTo(200, 282 + k * 4, 300, 284 + k * 4, 390, 306 + k * 3); a.stroke(); } });
    R.bead(298, 347, 15, '#c8201a', 0.24, 0.08, 3); R.bead(298, 347, 6, '#7a0a08', 0.3, 0.02, 3);

    // ── pearl clusters ──
    for (let k = 0; k < 16; k++) { const t = k / 15; R.pipe(P([[480 + t * 40, 540], [420 + t * 130, 700]], false), 4, '#a8a29a', 0.14, 0.04, 2); }
    for (const [x, y, rr] of [[484, 466, 38], [533, 503, 25], [492, 535, 32]]) R.bead(x, y, rr, '#bdb2a4', 0.16, 0.2, 4);
    for (let k = 0; k < 70; k++) { const x = 412 + r() * 145, y = 650 + Math.pow(r(), 0.8) * 210, rr = 6 + r() * 12; R.bead(x, y, rr, '#b8b0a4', 0.16, 0.14, 4); }

    // ── lower green field with coral + red scribbles ──
    const low = P([[252, 868], [548, 858], [548, 1016], [252, 1016]], true, false);
    R.flat(low, '#26c418', 0.06, 1);
    coral(low, [0.15, 0.78, 0.07], 0.028, 5.8, 8.7, 5);
    for (let k = 0; k < 45; k++) {
      const x = 260 + r() * 285, y = 870 + r() * 140, pts = [[x, y]];
      for (let j = 0; j < 5; j++) pts.push([pts[j][0] + (r() - 0.5) * 16, pts[j][1] + (r() - 0.5) * 12]);
      a.strokeStyle = '#c0301c'; a.lineWidth = 1.6; a.stroke(P(pts, false));
    }
    // small white S bottom-left
    R.pipe(P([[8, 820], [32, 838], [26, 868], [6, 888], [20, 918], [46, 934]], false), 18, '#e6eef2', 0.2, 0.2, 2);
    // frame
    R.flat(rrect(0, 1016, 578, 10, 0), '#9a9a98', 0.1, 2);
    R.flat(rrect(572, 0, 8, 1024, 0), '#6a6a68', 0.1, 2);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.9, emis: 0.25, spec: 0.1, shin: 10, wrap: 0.3 }),                                    // 1 flat colour fields
        E.mat({ dif: 1, spec: 0.35, shin: 24, wrap: 0.35, ao: 0.8, emis: 0.05 }),                          // 2 grey clay
        E.mat({ dif: 0.8, metal: 0.4, spec: 0.8, shin: 40, wrap: 0.3, emis: 0.15, tint: [1.1, 1.0, 0.7] }),  // 3 gold / red button
        E.mat({ dif: 1, spec: 0.6, shin: 30, wrap: 0.3, ao: 0.6 }),                                         // 4 pearls
        E.mat({ dif: 1, spec: 0.5, shin: 26, wrap: 0.5, ao: 0.2, emis: 0.1 })                              // 5 coral
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.8, 0.8, 0.8], amb: [0.36, 0.36, 0.36],
      envTop: [1, 1, 1], envHor: [0.55, 0.55, 0.55], envBot: [0.15, 0.15, 0.15], envK: [0.3, 0.8, 0.4, 0],
      rimC: [0.3, 0.3, 0.3], rimD: [-0.3, 0.5, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 60], shadow: [-4, 5, 0.5, 8]
    });
    E.grain(0.03, 34);
  }
});
