'use strict';
// g029 — "Zebra beasts, green moonfield": clay-white bubble mountains under a starry teal night, a zebra
// worm and a zebra hound on a gravel slope, grinning grey shark-heads, a red-eyed statue, and a black field
// of glossy green-and-white blobs below a cream thread.
REC.register('g029', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = (cv, op = 'source-over', al = 1) => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalCompositeOperation = op; a.globalAlpha = al; a.drawImage(cv, 0, 0); a.restore(); };
    const stripes = (path, ang, per, duty, seed, wob = 6) => clipA(path, () => {
      const r = rng(seed), c = Math.cos(ang), s = Math.sin(ang); a.fillStyle = '#0a0a0c';
      for (let t = -900; t < 900; t += per) {
        const w = per * duty * (0.75 + r() * 0.5), pts = [];
        for (let u = -700; u <= 700; u += 40) pts.push([363 + c * t - s * u + (r() - 0.5) * wob, 512 + s * t + c * u + (r() - 0.5) * wob]);
        const L = pts.map(([x, y]) => [x, y]), Rr = pts.map(([x, y]) => [x + c * w, y + s * w]).reverse();
        a.fill(P([...L, ...Rr], true, true));
      }
    });

    // ── night sky: stars + teal glow (unlit) ──
    const sky = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(.012);
      float g = exp(-pow(length((p - vec2(760., 60.)) * vec2(1., 0.8)) / 260., 2.));
      c += vec3(.1, .3, .3) * g;
      float g2 = exp(-pow(length(p - vec2(700., 330.)) / 140., 2.));
      c += vec3(.12, .25, .12) * g2;
      vec2 q = floor(p / 3.); float h = hash(q);
      c += vec3(.75) * step(0.988, h) * (0.4 + 0.6 * hash(q + 3.1));
      return c; }`);
    R.flat(rrect(-10, -10, 746, 1044, 0), '#000', 0, 0);
    img(sky);

    // ── bubbly cloud mountains ──
    const cloudPts = [[-10, 182], [20, 168], [45, 175], [62, 212], [84, 240], [100, 280], [126, 300], [145, 316], [162, 300], [185, 280], [216, 242], [246, 220], [252, 200], [265, 180], [298, 150], [318, 110], [338, 60], [368, 22], [400, 8], [432, 18], [456, 58], [478, 98], [510, 120], [520, 132], [456, 156], [404, 180], [372, 200], [346, 222], [326, 252], [308, 300], [300, 352], [304, 400], [314, 460], [300, 500], [260, 540], [200, 580], [150, 610], [120, 660], [90, 720], [-10, 730]];
    const cloud = P(cloudPts, true, true);
    R.dome(cloud, '#c2bfc0', 0.06, 0.14, 40, 1);
    { const r = rng(29); a.save(); a.clip(cloud); R.h.save(); R.h.clip(cloud);
      for (let i = 0; i < 520; i++) {
        const x = -10 + r() * 540, y = 0 + r() * 730;
        if (!a.isPointInPath(cloud, x * S, y * S)) continue;
        const rad = 9 + r() * 20;
        R.dome(ellipseP(x, y, rad * 1.15, rad * 0.9, (r() - 0.5) * 0.6), r() < 0.5 ? '#c8c5c6' : '#bcb9ba', 0.16 + r() * 0.06, 0.08 + r() * 0.06, rad, 1);
      }
      a.restore(); R.h.restore();
    }
    // orange coral twig in the sky pocket
    { a.strokeStyle = '#c8683a'; a.lineWidth = 2.2; a.lineCap = 'round'; const tw = rng(7);
      const br = (x, y, ang, len, d) => { const x2 = x + Math.cos(ang) * len, y2 = y + Math.sin(ang) * len; a.beginPath(); a.moveTo(x, y); a.lineTo(x2, y2); a.stroke(); if (d > 0) { br(x2, y2, ang - 0.35 - tw() * 0.3, len * 0.72, d - 1); br(x2, y2, ang + 0.35 + tw() * 0.3, len * 0.72, d - 1); } };
      br(130, 306, -1.75, 28, 3); br(160, 306, -1.35, 26, 3); }

    // ── statue (top right) ──
    R.dome(P([[566, 300], [576, 250], [606, 232], [660, 232], [700, 238], [726, 250], [736, 320], [566, 320]]), '#bdbcbe', 0.2, 0.12, 24, 4);
    R.dome(ellipseP(632, 196, 34, 46, 0), '#cfcacb', 0.24, 0.14, 26, 4);
    R.dome(P([[620, 162], [632, 128], [644, 162]]), '#c4c2c4', 0.3, 0.06, 6, 4);
    for (const x of [614, 642]) { R.paint(circleP(x, 196, 6), '#f02020'); R.paint(circleP(x, 196, 2.5), '#200000'); }
    R.paint(P([[624, 228], [640, 228], [636, 250], [628, 250]]), '#3a3434');
    a.strokeStyle = '#555'; a.lineWidth = 2; for (const y of [262, 274, 286]) { a.beginPath(); a.moveTo(600, y); a.quadraticCurveTo(632, y + 8, 664, y); a.stroke(); }

    // ── gravel slope ──
    const gravel = P([[126, 740], [150, 680], [196, 630], [240, 596], [300, 560], [380, 520], [440, 470], [500, 436], [560, 424], [624, 436], [650, 470], [630, 512], [560, 528], [480, 548], [400, 578], [320, 612], [260, 660], [200, 706], [150, 740]]);
    R.flat(gravel, '#6a6a6e', 0.08, 3);
    { const r = rng(9);
      for (let i = 0; i < 1400; i++) {
        const x = 120 + r() * 540, y = 420 + r() * 330;
        if (!a.isPointInPath(gravel, x * S, y * S)) continue;
        const rad = 3 + r() * 8, n = 5, pts = [];
        for (let k = 0; k < n; k++) { const t = k / n * 6.283 + r() * 0.8; pts.push([x + Math.cos(t) * rad * (0.7 + r() * 0.5), y + Math.sin(t) * rad * (0.7 + r() * 0.5)]); }
        const g = 140 + Math.floor(r() * 100);
        R.dome(P(pts, true, false), `rgb(${g},${g},${g + 4})`, 0.1 + r() * 0.06, 0.05, rad * 0.5, 3);
      }
    }
    for (const [x, y, rad] of [[528, 432, 22], [512, 460, 16], [556, 452, 14]]) R.dome(P(star(x, y, rad, rad * 0.8, 3, 0.3), true, false), '#c8c8cc', 0.14, 0.06, 6, 3);

    // ── zebra worm ──
    const worm = P([[186, 600], [196, 560], [222, 530], [262, 498], [300, 460], [340, 420], [372, 394], [404, 376], [434, 370], [462, 380], [482, 398], [490, 422], [484, 446], [458, 460], [418, 470], [380, 492], [344, 522], [306, 560], [266, 598], [232, 612], [204, 614]]);
    R.dome(worm, '#e8e6e6', 0.16, 0.2, 34, 1);
    clipA(worm, () => stripes(P([[150, 650], [150, 480], [300, 360], [425, 340], [430, 480], [300, 640]]), 0.15, 25, 0.42, 31, 8));
    R.dome(P([[318, 380], [346, 370], [338, 394]]), '#22c030', 0.3, 0.05, 4, 2);
    R.bead(470, 416, 7, '#0a0a0a', 0.36, 0.04, 2);

    // ── zebra hound ──
    const dogB = P([[548, 330], [570, 296], [610, 280], [664, 280], [704, 292], [736, 300], [736, 420], [704, 440], [666, 452], [628, 470], [596, 472], [574, 460], [560, 430], [550, 380]]);
    R.dome(dogB, '#e6e4e4', 0.16, 0.22, 40, 1);
    stripes(dogB, 0.05, 26, 0.36, 37, 10);
    const dogH = P([[432, 334], [446, 312], [480, 296], [512, 284], [540, 284], [564, 298], [574, 326], [556, 348], [524, 350], [506, 370], [482, 376], [470, 356], [442, 348]]);
    R.dome(dogH, '#eceaea', 0.2, 0.18, 22, 1);
    R.paint(P([[470, 344], [506, 336], [512, 352], [500, 372], [482, 374]]), '#5a1414');
    for (let i = 0; i < 4; i++) { R.paint(P([[476 + i * 8, 346], [480 + i * 8, 354], [484 + i * 8, 344]], true, false), '#f4f0ee'); R.paint(P([[484 + i * 6, 372], [487 + i * 6, 362], [490 + i * 6, 372]], true, false), '#f4f0ee'); }
    R.bead(438, 337, 8, '#0a0a0a', 0.36, 0.05, 2);
    R.paint(ellipseP(500, 312, 5, 3, 0), '#222');
    R.dome(P([[536, 290], [560, 284], [580, 300], [570, 330], [546, 312]]), '#d8d6d6', 0.3, 0.06, 8, 1);

    // ── shark heads ──
    const shark = (cx, cy, rx, ry) => {
      R.dome(P([[cx - rx * 0.22, cy - ry * 0.8], [cx - rx * 0.05, cy - ry * 1.45], [cx + rx * 0.12, cy - ry * 0.8]]), '#b4b2b6', 0.26, 0.06, 5, 4);
      const hd = ellipseP(cx, cy, rx, ry, 0);
      R.dome(hd, '#b0aeb2', 0.18, 0.22, rx * 0.8, 4);
      const mouth = P([[cx - rx * 0.88, cy - ry * 0.05], [cx, cy - ry * 0.2], [cx + rx * 0.88, cy - ry * 0.05], [cx + rx * 0.7, cy + ry * 0.45], [cx, cy + ry * 0.55], [cx - rx * 0.7, cy + ry * 0.45]]);
      R.flat(mouth, '#0c0a0c', 0.24, 4);
      a.fillStyle = '#f2f0ee';
      for (let i = 0; i < 9; i++) { const x = cx - rx * 0.75 + i * rx * 0.19; a.fill(P([[x - 5, cy - ry * 0.12], [x + 5, cy - ry * 0.12], [x, cy + ry * 0.18]], true, false)); a.fill(P([[x - 4, cy + ry * 0.47], [x + 4, cy + ry * 0.47], [x + 1, cy + ry * 0.22]], true, false)); }
      R.paint(circleP(cx + rx * 0.05, cy - ry * 0.45, 2.5), '#222');
    };
    shark(162, 604, 46, 52); shark(86, 672, 50, 54); shark(680, 470, 50, 44);

    // ── black ground with green blobs ──
    const ground = P([[-10, 842], [60, 800], [120, 762], [180, 724], [240, 682], [290, 642], [330, 614], [380, 590], [430, 572], [480, 555], [530, 538], [590, 524], [640, 520], [736, 516], [736, 1044], [-10, 1044]]);
    R.flat(ground, '#060606', 0.05, 5);
    { const r = rng(11);
      for (let i = 0; i < 150; i++) {
        const x = r() * 726, y = 520 + r() * 520;
        if (!a.isPointInPath(ground, x * S, y * S)) continue;
        const rad = 5 + r() * 9, pts = [];
        for (let k = 0; k < 5; k++) { const t = k / 5 * 6.283 + r() * 0.8; pts.push([x + Math.cos(t) * rad * (0.7 + r() * 0.5), y + Math.sin(t) * rad * (0.6 + r() * 0.4)]); }
        const g = 130 + Math.floor(r() * 80);
        R.dome(P(pts, true, false), `rgb(${g},${g},${g + 3})`, 0.08, 0.05, rad * 0.5, 3);
      }
    }
    const blobs = [[547, 550, 35, 28], [640, 554, 35, 27], [722, 530, 34, 27], [476, 590, 33, 31], [706, 592, 34, 28], [288, 630, 31, 29], [390, 606, 36, 28], [590, 611, 36, 31], [352, 667, 33, 25], [436, 669, 37, 30], [570, 678, 35, 31], [654, 641, 34, 26],
      [309, 718, 35, 29], [683, 693, 34, 27], [221, 734, 34, 27], [386, 748, 33, 24], [500, 720, 36, 29], [607, 739, 37, 28], [272, 782, 33, 25], [490, 787, 37, 29], [245, 834, 31, 24], [355, 816, 37, 30], [615, 819, 36, 28], [705, 815, 34, 26],
      [67, 863, 35, 27], [175, 873, 33, 29], [321, 871, 38, 29], [400, 867, 32, 27], [551, 873, 38, 33], [18, 910, 32, 30], [706, 881, 34, 28], [120, 922, 31, 29], [193, 945, 36, 33], [284, 939, 35, 28], [396, 934, 36, 29], [473, 925, 35, 29], [597, 938, 33, 31], [672, 940, 34, 28],
      [47, 979, 32, 26], [120, 995, 34, 26], [226, 1000, 32, 26], [298, 995, 33, 26], [385, 1004, 35, 26], [456, 989, 30, 29], [618, 994, 33, 25], [543, 1006, 30, 24], [700, 1010, 32, 24], [18, 734, 30, 28]];
    for (const [x, y, rx, ry] of blobs) {
      const sd = x * 7 + y;
      R.dome(P(blob(x, y, rx * 0.95, ry * 0.97, sd, 12, 0.08)), '#20d42c', 0.1, 0.1, 8, 2);
      R.dome(P(blob(x + 1, y - 2, rx * 0.95 * 0.6, ry * 0.97 * 0.6, sd + 1, 9, 0.15)), '#fafcf4', 0.18, 0.03, 4, 2);
    }
    // white boulder + front shark sit on the ground
    R.dome(P([[0, 752], [40, 748], [86, 770], [90, 812], [60, 832], [0, 830]]), '#d8d6d6', 0.16, 0.12, 20, 1);
    shark(136, 786, 50, 58);
    // grass tuft
    for (let i = 0; i < 14; i++) { const x = 690 + i * 3; a.strokeStyle = i % 2 ? '#d8e8d0' : '#6ab060'; a.lineWidth = 2; a.beginPath(); a.moveTo(x, 1030); a.quadraticCurveTo(x - 4 + (i % 3) * 4, 960, x - 10 + i * 1.5, 900 + (i % 4) * 10); a.stroke(); }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.12, shin: 12, wrap: 0.45, ao: 1.0, emis: 0.05 }),          // 1 white clay
        E.mat({ dif: 1, spec: 0.9, shin: 50, wrap: 0.35, coat: 0.12, ao: 0.4, emis: 0.1 }),  // 2 glossy green blobs
        E.mat({ dif: 1, spec: 0.2, shin: 12, wrap: 0.3, ao: 0.5 }),                          // 3 rocks
        E.mat({ dif: 1, spec: 0.35, shin: 24, wrap: 0.35, ao: 0.7 }),                         // 4 grey sharks / statue
        E.mat({ dif: 1, spec: 0.5, shin: 40, wrap: 0.2 })                                    // 5 black ground
      ],
      light: [-0.4, 0.5, 0.75], lc: [0.75, 0.75, 0.75], amb: [0.36, 0.36, 0.38],
      envTop: [1, 1, 1], envHor: [0.4, 0.4, 0.42], envBot: [0.05, 0.05, 0.05], envK: [0.3, 1.0, 0.4, 0],
      r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 110], shadow: [-5, 6, 0.55, 6]
    });

    // ── cream threads + coloured lights (drawn over the lit relief) ──
    const thread = (pts, wd) => { o.lineCap = 'round'; o.lineWidth = wd + 2; o.strokeStyle = '#3a3420'; o.stroke(P(pts, false)); o.lineWidth = wd; o.strokeStyle = '#e4dcae'; o.stroke(P(pts, false)); };
    thread([[300, 352], [306, 300], [326, 250], [360, 208], [404, 180], [456, 154], [504, 132], [548, 110], [590, 84], [628, 50], [656, 18], [668, -4]], 4);
    thread([[690, 236], [706, 206], [736, 160]], 4);
    thread([[-10, 838], [60, 798], [120, 760], [180, 722], [240, 680], [290, 640], [330, 612], [380, 588], [430, 570], [480, 553], [530, 536], [590, 522], [640, 518], [736, 514]], 5);
    thread([[416, 906], [470, 880], [520, 850], [570, 822], [620, 796], [670, 770], [736, 744]], 5);
    for (const [x, y, r, c] of [[205, 138, 12, '#30e070'], [280, 122, 11, '#ffe040'], [470, 238, 18, '#ff2010'], [392, 287, 10, '#ffd030'], [532, 186, 6, '#60f0e0']]) {
      const g = o.createRadialGradient(x, y, 0, x, y, r * 2.2); g.addColorStop(0, c); g.addColorStop(0.45, c); g.addColorStop(1, 'rgba(0,0,0,0)');
      o.fillStyle = g; o.fill(circleP(x, y, r * 2.2));
      o.fillStyle = c; o.fill(circleP(x, y, r * 0.9)); o.fillStyle = 'rgba(255,255,255,0.8)'; o.fill(circleP(x, y, r * 0.45));
    }
    E.grain(0.03, 29);
  }
});
