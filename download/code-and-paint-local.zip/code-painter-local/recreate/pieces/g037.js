'use strict';
// g037 — "Zebra-faced clay portrait": a glossy plasticine head on red and blue — pale-blue skin with
// green eyes, a spiral bump and a blue nose, a cow-spotted cheek, zebra stripes with two veined
// brown leaves, yellow hair under a light-blue bolster cap, and a royal-blue turtleneck.
REC.register('g037', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const W = 726, H = 1024, rr = rng(37);
    const CREAM = '#f3ecdc';
    const rot = (cx, cy, ang) => (u, v) => [cx + u * Math.cos(ang) - v * Math.sin(ang), cy + u * Math.sin(ang) + v * Math.cos(ang)];
    const capsule = (x1, y1, x2, y2, r) => {
      const an = Math.atan2(y2 - y1, x2 - x1), p = new Path2D();
      p.arc(x2, y2, r, an - Math.PI / 2, an + Math.PI / 2); p.arc(x1, y1, r, an + Math.PI / 2, an + Math.PI * 1.5); p.closePath(); return p;
    };
    const ridge = (pts, wd, h0 = 0.3, closed = false) => R.pipe(P(pts, closed), wd, CREAM, h0, 0.06, 1);
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    // tube along a centreline: list of [x, y]; returns outline
    const tube = (cl, w0, w1 = w0) => P(lock(cl, w0, w1, 1), true, true);

    // ── background: red with a blue field on the left and bottom ──
    R.flat(rrect(-10, -10, W + 20, H + 20, 0), '#ec1c1e', 0, 0);
    R.flat(P([[-10, 286], [120, 360], [300, 520], [520, 700], [600, 800], [640, 900], [680, 1040], [-10, 1040]], true, false), '#1a78c4', 0, 0);

    // ── sweater + neck ──
    const sweater = P([[96, 1040], [150, 980], [228, 935], [236, 878], [262, 850], [520, 838], [548, 858], [590, 900], [640, 950], [740, 1000], [740, 1040]]);
    R.pipe(sweater, 12, '#8ac6f0', 0.1, 0.05, 2);
    R.dome(sweater, '#1e3ed2', 0.1, 0.16, 50, 2);
    const neck = P([[255, 780], [530, 780], [532, 836], [480, 868], [330, 874], [266, 856]]);
    R.dome(neck, '#7aa4b4', 0.12, 0.1, 30, 2);
    { const g = a.createLinearGradient(0, 790, 0, 880); g.addColorStop(0, 'rgba(20,40,60,0.75)'); g.addColorStop(0.5, 'rgba(20,40,60,0.2)'); g.addColorStop(1, 'rgba(20,40,60,0)'); clipA(neck, () => { a.fillStyle = g; a.fillRect(250, 780, 290, 100); }); }
    const roll = P([[238, 880], [262, 852], [330, 878], [470, 872], [530, 842], [556, 862], [560, 905], [520, 936], [400, 950], [280, 940], [236, 915]]);
    R.dome(roll, '#2246d8', 0.2, 0.12, 30, 2);
    R.pipe(P([[262, 852], [330, 878], [470, 872], [530, 842]], false), 6, '#8ac6f0', 0.3, 0.03, 2);

    // ── head ──
    const head = P([[24, 330], [30, 250], [70, 170], [160, 112], [280, 78], [420, 40], [560, 12], [740, -5], [740, 774], [640, 790], [540, 800], [300, 808], [90, 802], [44, 772], [30, 700]]);
    R.pipe(head, 14, '#82c0ec', 0.12, 0.08, 2);
    R.dome(head, '#0d0b0c', 0.14, 0.04, 12, 3);
    // cow-spotted cheek (cream with black blobs)
    const cow = P([[30, 450], [120, 470], [190, 470], [205, 520], [212, 600], [228, 650], [240, 700], [250, 760], [260, 806], [90, 802], [44, 772], [30, 700]]);
    R.dome(cow, CREAM, 0.16, 0.04, 8, 2);
    const cowBlk = pth => R.dome(pth, '#0e0c0d', 0.2, 0.01, 4, 3);
    cowBlk(P(blob(62, 495, 17, 23, 1, 10, 0.15, 0.1)));
    cowBlk(P([[118, 486], [140, 478], [162, 520], [186, 566], [208, 612], [202, 642], [180, 636], [158, 596], [134, 552], [120, 516]]));
    cowBlk(P([[44, 560], [80, 550], [110, 560], [114, 586], [96, 602], [94, 632], [80, 650], [62, 642], [60, 602], [44, 592]]));
    cowBlk(P([[46, 690], [70, 662], [100, 646], [126, 654], [152, 690], [182, 724], [212, 758], [206, 784], [180, 782], [150, 748], [120, 712], [104, 692], [84, 702], [60, 714]]));
    cowBlk(P([[220, 700], [236, 690], [244, 730], [230, 760]]));
    // ── zebra stripes on the black (cream ridges and blobs) ──
    for (const s of [
      [[262, 154], [380, 128], [487, 100], [600, 80], [740, 62]],
      [[396, 166], [500, 140], [610, 120], [740, 104]],
      [[414, 226], [520, 196], [620, 170], [740, 160]],
      [[430, 300], [470, 280], [520, 250]],
      [[420, 520], [520, 500], [600, 470]],
      [[560, 560], [650, 545], [740, 538]],
      [[470, 720], [560, 700], [600, 690]],
      [[300, 780], [420, 770], [520, 774], [640, 760]],
      [[440, 760], [460, 790]]
    ]) ridge(s, 20, 0.22);
    
    R.dome(rrect(608, 662, 68, 46, 22), CREAM, 0.2, 0.06, 10, 1);
    R.dome(P([[452, 690], [500, 680], [530, 700], [520, 740], [490, 760], [460, 740]]), CREAM, 0.2, 0.06, 10, 1);
    R.dome(P(blob(480, 770, 30, 16, 12, 10, 0.2, 0)), CREAM, 0.2, 0.06, 8, 1);

    // ── brown veined leaves ──
    const leaf = (cl, w0, seed, w1 = w0 * 0.85) => {
      const pth = tube(cl, w0, w1);
      R.pipe(pth, 12, CREAM, 0.26, 0.06, 1);
      R.dome(pth, '#2e1311', 0.26, 0.1, 30, 4);
      // veins: a midrib + fishbone branches
      const r = rng(seed); R.pipe(P(cl, false), 3, '#e8d8cc', 0.42, 0.02, 1);
      for (let i = 1; i < cl.length - 1; i++) {
        const p = cl[i], q = cl[i + 1], dx = q[0] - p[0], dy = q[1] - p[1], L = Math.hypot(dx, dy) || 1;
        for (let k = 0; k < 4; k++) {
          const u = k / 4, x = p[0] + dx * u, y = p[1] + dy * u;
          for (const sg of [-1, 1]) {
            const len = w0 * (0.25 + r() * 0.15), nx = -dy / L * sg, ny = dx / L * sg;
            R.pipe(P([[x, y], [x + nx * len * 0.6 + dx / L * len * 0.3, y + ny * len * 0.6 + dy / L * len * 0.3], [x + nx * len + dx / L * len * 0.6, y + ny * len + dy / L * len * 0.6]], false), 2.2, '#efe2d6', 0.42, 0.015, 1);
          }
        }
      }
      return pth;
    };
    leaf([[560, 500], [618, 440], [656, 362], [680, 292], [690, 262]], 90, 23, 70);
    ridge([[318, 584], [420, 582], [520, 558], [620, 512], [690, 462]], 26, 0.24);
    leaf([[334, 524], [410, 494], [480, 448], [545, 380], [602, 300], [650, 232], [688, 194]], 120, 21, 76);
    leaf([[256, 708], [360, 684], [460, 646], [560, 612], [660, 584], [760, 560]], 94, 22);
    ridge([[300, 730], [400, 728], [500, 712], [580, 690]], 22, 0.24);

    // cream ladder down the right edge
    R.pipe(P([[716, 190], [712, 400], [716, 660]], false), 24, CREAM, 0.24, 0.06, 1);
    for (const y of [214, 262, 316, 372, 424, 472, 524, 584, 630]) R.dome(rrect(690, y - 10, 50, 20, 10), CREAM, 0.24, 0.06, 8, 1);
    R.dome(rrect(694, 660, 40, 90, 18), CREAM, 0.22, 0.06, 8, 1);

    // ── face skin ──
    const skin = P([[60, 340], [78, 280], [120, 256], [240, 248], [330, 256], [430, 278], [456, 322], [430, 410], [360, 460], [322, 520], [330, 600], [300, 640], [240, 684], [226, 640], [212, 590], [205, 500], [190, 470], [120, 470], [60, 460], [50, 400]]);
    R.pipe(skin, 12, CREAM, 0.28, 0.06, 1);
    R.dome(skin, '#a7cad3', 0.26, 0.08, 20, 2);
    // cream contour lines on the face + black brow channels
    R.groove(P([[66, 332], [120, 318], [200, 316], [250, 324]], false), 14, '#0c0a0a', 0.34, 0.08, 2);
    R.groove(P([[236, 312], [300, 302], [380, 300], [432, 310]], false), 12, '#0c0a0a', 0.34, 0.08, 2);
    ridge([[60, 312], [120, 300], [200, 296], [300, 286], [400, 284], [448, 296]], 9, 0.34);
    ridge([[66, 350], [130, 338], [210, 340], [252, 352]], 7, 0.34);
    ridge([[240, 290], [250, 360], [240, 430], [250, 500], [235, 520]], 9, 0.36);
    ridge([[60, 400], [110, 380], [180, 392], [230, 430]], 8, 0.36);
    ridge([[440, 320], [420, 300], [440, 280], [460, 300]], 6, 0.36);
    ridge([[300, 520], [300, 600], [270, 640]], 6, 0.36);
    // eyes
    const eye = (cx, cy, w, h, tilt, ir) => {
      const t = rot(cx, cy, tilt), pts = [];
      for (let i = 0; i <= 20; i++) { const u = -1 + 2 * i / 20; pts.push(t(u * w, -h * (1 - u * u) * (1 + 0.2 * u))); }
      for (let i = 19; i >= 1; i--) { const u = -1 + 2 * i / 20; pts.push(t(u * w, h * 0.75 * (1 - u * u))); }
      const pth = P(pts, true, false);
      R.pipe(pth, 14, CREAM, 0.3, 0.06, 1);
      R.dome(pth, '#f4eee0', 0.3, 0.06, 8, 2);
      clipA(pth, () => { a.fillStyle = '#16805e'; a.fill(circleP(cx, cy, ir)); a.fillStyle = '#28a07a'; a.fill(circleP(cx - ir * 0.15, cy + ir * 0.2, ir * 0.6)); a.fillStyle = '#060606'; a.fill(circleP(cx, cy, ir * 0.5)); a.fillStyle = '#ffffff'; a.fill(circleP(cx - ir * 0.25, cy - ir * 0.3, ir * 0.2)); });
      R.groove(P([t(-w * 0.95, -h * 0.4), t(-w * 0.3, -h * 1.25), t(w * 0.5, -h * 1.15), t(w, -h * 0.3)], false), 7, '#0c0a0a', 0.3, 0.06, 2);
    };
    eye(135, 430, 56, 34, 0.08, 24);
    eye(342, 380, 62, 36, -0.05, 26);
    // spiral bump on the forehead
    R.dome(circleP(216, 340, 32), CREAM, 0.3, 0.1, 14, 1);
    { const pts = []; for (let i = 0; i <= 120; i++) { const t = i / 120, an = t * Math.PI * 5, r = 3 + 24 * t; pts.push([216 + Math.cos(an) * r, 340 + Math.sin(an) * r]); } R.groove(P(pts, false, false), 5, '#3a2a28', 0.4, 0.06, 1); }
    // blue nose
    R.dome(ellipseP(256, 556, 50, 36, 0.05), '#64bcf0', 0.32, 0.14, 26, 2);
    R.groove(P([[236, 568], [258, 576], [282, 566]], false), 4, '#24508a', 0.46, 0.04, 2);
    // small cream dots on the skin
    for (const [x, y, r] of [[260, 400], [292, 452], [306, 468], [262, 470], [330, 470], [214, 380], [270, 520], [310, 560], [292, 620], [400, 340], [356, 302], [440, 360]].map(p => [p[0], p[1], 2.5 + rr() * 2.5])) R.bead(x, y, r, '#f6f2ea', 0.34, 0.04, 1);

    // ── hair ──
    const HAIR = '#f8de4a';
    const hairMass = P([[30, 300], [46, 232], [100, 192], [185, 170], [270, 168], [330, 182], [370, 192], [420, 178], [456, 166], [446, 198], [404, 222], [366, 244], [326, 232], [296, 256], [272, 250], [244, 232], [222, 264], [200, 258], [172, 262], [140, 252], [100, 258], [84, 290], [78, 336], [58, 350], [44, 404], [22, 430], [10, 380]]);
    R.dome(hairMass, HAIR, 0.32, 0.12, 14, 5);
    for (const [cl, w] of [
      [[[60, 240], [130, 206], [210, 190], [300, 190], [380, 200], [446, 176]], 10],
      [[[150, 210], [170, 230], [186, 248]], 8], [[[210, 204], [230, 228], [240, 248]], 8], [[[270, 200], [290, 222], [300, 238]], 8],
      [[[320, 204], [350, 222], [366, 232]], 8], [[[70, 250], [44, 300], [26, 360], [16, 410]], 10]
    ]) R.pipe(P(cl, false), w, '#f8dc60', 0.4, 0.05, 5);
    for (const [cl, w] of [[[[30, 330], [12, 380], [6, 432]], 22], [[[46, 350], [40, 400], [30, 440]], 16]]) R.dome(tube(cl, w, 3), HAIR, 0.32, 0.1, 8, 5);

    // ── cap: light-blue ribbed bolster + black ribbed band ──
    const bolCL = [[292, 112], [200, 130], [130, 152], [70, 182], [34, 228], [18, 290], [14, 344]];
    const bol = tube(bolCL, 82, 64);
    R.pipe(bol, 8, '#bfe0f6', 0.3, 0.06, 2);
    R.dome(bol, '#76b2e6', 0.32, 0.22, 30, 2);
    for (let i = 1; i < 7; i++) { const p = bolCL[i - 1], q = bolCL[i], m = [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2], dx = q[0] - p[0], dy = q[1] - p[1], L = Math.hypot(dx, dy);
      R.groove(P([[m[0] - dy / L * 36, m[1] + dx / L * 40], [m[0] + dy / L * 40, m[1] - dx / L * 40]], false), 6, '#4f8cc8', 0.54, 0.08, 2); }
    const bandCL = [[290, 88], [400, 64], [520, 40], [640, 20], [760, 2]];
    const band = tube(bandCL, 62, 62);
    R.dome(band, '#0a0a0c', 0.3, 0.22, 30, 6);
    for (let x = 340; x < 740; x += 62) { const y = 88 - (x - 290) * 0.19; R.groove(P([[x + 6, y - 30], [x - 6, y + 30]], false), 5, '#2a2a2e', 0.52, 0.1, 6); }
    R.pipe(P([[300, 118], [420, 94], [540, 72], [660, 52], [740, 40]], false), 8, '#9ccbee', 0.32, 0.04, 2);

    // ── black glossy capsule on the right ──
    R.dome(capsule(640, 838, 760, 800, 46), '#08080a', 0.3, 0.2, 40, 6);
    R.pipe(capsule(640, 838, 760, 800, 46), 6, '#6aa8dc', 0.3, 0.04, 2);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.55, shin: 40, wrap: 0.35, ao: 0.5, coat: 0.15 }),               // 1 glossy clay (cream / skin)
        E.mat({ dif: 1, spec: 0.7, shin: 50, wrap: 0.3, ao: 0.4, coat: 0.2 }),                  // 2 glossy coloured plastic
        E.mat({ dif: 1, spec: 0.9, shin: 70, wrap: 0.2, ao: 0.3, coat: 0.25 }),                 // 3 black gloss
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.3, ao: 0.5, grain: 0.15, coat: 0.1 }),     // 4 leather leaves
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.4, ao: 0.4, coat: 0.15 }),                 // 5 hair
        E.mat({ dif: 1, spec: 1.2, shin: 90, wrap: 0.1, ao: 0.3, coat: 0.35 })                  // 6 black chrome
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.85, 0.85, 0.85], amb: [0.36, 0.36, 0.38],
      envTop: [1, 1, 1], envHor: [0.5, 0.5, 0.55], envBot: [0.1, 0.1, 0.12], envK: [0.4, 1.0, 0.3, 0],
      rimC: [0.2, 0.25, 0.35], rimD: [0, 1, 0], r1: 1.4, r2: 6, k: [0, 0.6, 0.4, 80], shadow: [-4, 5, 0.5, 6]
    });
    E.grain(0.03, 37);
  }
});
