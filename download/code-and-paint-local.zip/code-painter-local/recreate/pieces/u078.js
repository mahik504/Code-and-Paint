'use strict';
// u078 — "Cow-print kart with gold spill": a black-and-white cow-print go-kart blob flooded with champagne-gold
// beaded liquid, a cow-helmeted goggle driver, speakers and tyres, under a gold baroque arch with maroon gear rings,
// pearls and a sea urchin, on a parking lot below a blue sky with one cloud.
REC.register('u078', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a, alpha = 1, op = 'source-over') => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clip = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, st, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), open = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };
    const FLAT = 0, GOLD = 1, BLACK = 2, WHITE = 3, MAROON = 4, PEARL = 5, RUBBER = 6, CHROME = 7;
    const GOLDC = '#d8c6a4';

    // ── 1. sky, cloud, hill, pole ──
    R.flat(rrect(-10, -10, 746, 1044, 0), lin(0, 0, 0, 420, [[0, '#6874b2'], [0.6, '#8290c4'], [1, '#a4a8c8']]), 0, FLAT);
    soft(x => { fill(P(blob(250, 112, 140, 26, 3, 14, 0.15)), '#d4d4e2', x); fill(P(blob(230, 96, 70, 26, 5, 10, 0.2)), '#e0e0ea', x); fill(P(blob(320, 104, 60, 20, 7, 10, 0.2)), '#d8d8e6', x); }, 6, 1);
    fill(poly([[-10, 50], [130, 180], [130, 250], [-10, 250]]), lin(0, 60, 120, 240, [[0, '#4a4a3a'], [1, '#5c5a44']]));
    R.pipe(open([[44, -10], [44, 250]]), 22, '#e8e6ee', 0.1, 0.1, WHITE);
    stroke(open([[0, 44], [12, -10]]), '#e0dcd8', 4);

    // ── 2. ground: asphalt, sand, road stripes ──
    R.flat(poly([[-10, 330], [740, 330], [740, 1040], [-10, 1040]]), '#6c5e60', 0, FLAT);
    soft(x => { fill(poly([[400, 470], [740, 440], [740, 600], [560, 560], [460, 600]]), '#b49c86', x); fill(poly([[0, 330], [400, 330], [400, 360], [0, 380]]), '#7a6c62', x); }, 18, 0.95);
    soft(x => { fill(poly([[560, 520], [740, 500], [740, 560], [600, 560]]), '#6a5c60', x); }, 10, 0.7);
    soft(x => { fill(poly([[-10, 926], [240, 846], [250, 878], [-10, 962]]), '#b8b0b0', x); fill(poly([[-10, 826], [90, 800], [96, 830], [-10, 850]]), '#c0b8b8', x);
      fill(poly([[-10, 640], [80, 700], [60, 720], [-10, 680]]), '#a8a0a0', x); }, 3, 0.95);
    // grey bleachers
    const BLEACH = poly([[118, 186], [405, 172], [405, 340], [118, 340]]);
    clip(BLEACH, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float row = fract((p.y - .11 * p.x) / 13.);
        vec3 c = vec3(.68, .65, .66) + .06 * smoothstep(.5, 1., row);
        float st = smoothstep(.7, .76, vnoise(vec2(p.x * .07, floor((p.y - .11 * p.x) / 13.) * 3.1))) * smoothstep(.55, .75, row) * smoothstep(1., .85, row);
        return mix(c, vec3(.2, .18, .2), st * .9); }`)));
    fill(poly([[118, 176], [405, 166], [405, 190], [118, 196]]), '#dcdad8');
    for (let i = 0; i < 18; i++) fill(ellipseP(160 + i * 13.5, 188 - i * 0.4, 3, 3.6), '#141216');

    // ── 3. golden arch structure (right) ──
    // maroon gear arches: elliptical bands with square windows and a white rim
    for (const [cx, cy, ox, oy, ix, iy] of [[620, 205, 185, 215, 140, 165], [610, 270, 150, 175, 112, 122]]) {
      const pt = (t, k) => [cx + Math.cos(t) * (ix + (ox - ix) * k), cy + Math.sin(t) * (iy + (oy - iy) * k)];
      const band = [], N = 48; for (let i = 0; i <= N; i++) band.push(pt(Math.PI * (1 + i / N), 1)); for (let i = N; i >= 0; i--) band.push(pt(Math.PI * (1 + i / N), 0));
      R.flat(poly(band), '#784446', 0.1, MAROON);
      for (let k = 0; k < 8; k++) { const t0 = Math.PI * (1.08 + k * 0.115), t1 = t0 + 0.07;
        R.flat(poly([pt(t0, 0.28), pt(t1, 0.28), pt(t1, 0.72), pt(t0, 0.72)]), '#8a98c8', 0.1, FLAT); }
      const rim = []; for (let i = 0; i <= N; i++) rim.push(pt(Math.PI * (1 + i / N), 1.06)); R.pipe(open(rim), 10, '#f2eee8', 0.12, 0.06, WHITE);
    }
    R.pipe(open([[440, 120], [500, 60], [580, 30], [660, 30], [700, 50]]), 34, GOLDC, 0.2, 0.14, GOLD);
    R.pipe(open([[700, 50], [720, 100], [726, 200]]), 26, GOLDC, 0.2, 0.12, GOLD);
    // the gold column and its melting roots
    R.pipe(open([[432, -10], [432, 100]]), 36, GOLDC, 0.2, 0.12, GOLD);
    for (const y of [60, 80, 100, 130]) R.pipe(open([[414, y], [450, y]]), 10, '#c8b48e', 0.3, 0.06, GOLD);
    R.dome(sm([[420, 130], [450, 120], [470, 180], [500, 230], [540, 250], [560, 300], [530, 330], [490, 340], [470, 380], [480, 420], [420, 420], [410, 380], [420, 300], [424, 220]]), GOLDC, 0.16, 0.16, 26, GOLD);
    for (const pts of [[[440, 330], [430, 380], [436, 420]], [[470, 340], [480, 400], [500, 420]], [[500, 240], [540, 220], [560, 230]]]) R.pipe(open(pts), 14, GOLDC, 0.24, 0.1, GOLD);
    // ring, urchin, pearls, big sphere
    R.pipe(circleP(612, 268, 68), 6, '#d0bc94', 0.24, 0.04, GOLD);
    for (let i = 0; i < 26; i++) { const t = -2.6 + i * 0.12; R.pipe(open([[588, 262], [588 + Math.cos(t) * 46, 262 + Math.sin(t) * 46]]), 2.5, '#5a4630', 0.26, 0.02, GOLD); }
    R.pipe(open([[560, 300], [570, 340], [575, 380], [572, 420]]), 18, '#7a6040', 0.22, 0.06, GOLD);
    R.dome(circleP(646, 378, 82), rad(620, 350, 100, [[0, '#f0e4c8'], [0.6, '#d0bc94'], [1, '#a89270']]), 0.24, 0.3, 70, GOLD);
    for (const [x, y, r] of [[497, 285, 28], [488, 352, 20], [528, 386, 15], [604, 290, 26], [418, 30, 18]]) R.bead(x, y, r, rad(x - r * 0.3, y - r * 0.3, r * 1.4, [[0, '#ffffff'], [0.5, '#f0e4e4'], [1, '#c4b0a4']]), 0.26, 0.12, PEARL);
    // little camera + hose
    R.dome(rrect(478, 434, 48, 22, 4), '#e8e8ec', 0.2, 0.06, 6, WHITE);
    R.pipe(open([[568, 440], [600, 460], [612, 500], [600, 540]]), 14, '#8a7a5a', 0.24, 0.06, GOLD);
    R.dome(rrect(690, 500, 40, 56, 6), '#e4e2e2', 0.2, 0.06, 8, WHITE);

    // ── 4. right side: zebra tyre, tan panel, zebra fabric ──
    R.dome(circleP(645, 642, 58), '#d8d6d6', 0.12, 0.16, 30, WHITE);
    clip(circleP(645, 642, 58), () => { for (const [t0, t1] of [[3.4, 4.6], [5.0, 6.0], [0.5, 1.3]]) { const p = new Path2D(); p.arc(645, 642, 52, t0, t1); stroke(p, '#141216', 13); } });
    R.dome(circleP(632, 642, 28), '#c8c6c8', 0.2, 0.08, 14, WHITE); R.bead(628, 642, 11, '#3a3a40', 0.26, 0.06, RUBBER);
    const ZEB = sm([[440, 770], [560, 740], [650, 740], [690, 780], [680, 860], [660, 940], [610, 1000], [500, 990], [440, 900]]);
    R.dome(ZEB, null, 0.08, 0.12, 20, WHITE);
    clip(ZEB, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float y = p.y + 0.35 * (p.x - 440.) + 22. * sin(p.x * .025) + 44. * (fbm(p * vec2(.008, .02)) - .5);
      float s = sin(y * .15) + .9 * (fbm(p * vec2(.03, .09) + 4.) - .5);
      return mix(vec3(.86, .85, .87), vec3(.05, .05, .06), smoothstep(-.4, -.15, s)); }`)));
    const PANEL = sm([[700, 700], [740, 690], [740, 976], [660, 976], [660, 880], [684, 840], [692, 760]]);
    R.dome(PANEL, '#d8c8b0', 0.14, 0.1, 14, WHITE);
    R.dome(circleP(750, 840, 46), '#141216', 0.2, 0.02, 4, BLACK);
    for (const [x, y] of [[716, 732], [690, 958]]) R.bead(x, y, 13, '#c0c4cc', 0.3, 0.12, CHROME);

    // ── 5. the cow-print blob ──
    const BLOB = sm([[0, 380], [60, 370], [110, 350], [180, 340], [240, 340], [330, 340], [380, 380], [440, 420], [480, 500], [470, 560], [460, 640], [430, 700], [400, 760], [360, 830], [330, 860], [280, 880], [200, 870], [140, 830], [100, 780],
      [80, 700], [60, 600], [10, 560]]);
    R.dome(BLOB, '#0e0c10', 0.08, 0.2, 60, BLACK);
    clip(BLOB, () => { const r = rng(78); for (let i = 0; i < 18; i++) fill(P(blob(90 + r() * 360, 400 + r() * 460, 6 + r() * 22, 4 + r() * 10, 300 + i, 10, 0.45, r() * 3)), '#ecebee');
      soft(x => { const r2 = rng(8); for (let i = 0; i < 160; i++) fill(circleP(70 + r2() * 420, 340 + r2() * 540, 0.6 + r2() * 1.2), '#ffffff', x); }, 0.3, 0.8); });
    // white cow patches on the left flank
    for (const pts of [[[96, 600], [126, 604], [142, 650], [138, 700], [108, 700], [100, 650]], [[160, 712], [204, 722], [222, 760], [214, 800], [180, 806], [160, 770]],
      [[60, 790], [120, 780], [190, 800], [200, 830], [150, 842], [80, 832]], [[300, 840], [340, 830], [350, 880], [320, 900]], [[200, 440], [236, 444], [226, 462], [200, 460]], [[120, 420], [150, 416], [150, 440], [124, 446]]])
      R.dome(sm(pts), '#ecebee', 0.18, 0.06, 10, WHITE);
    // gold half-disc under the kart
    R.dome(sm([[96, 700], [150, 690], [200, 700], [230, 760], [250, 860], [300, 870], [330, 880], [300, 900], [220, 890], [160, 870], [120, 820], [100, 760]]), lin(100, 700, 200, 880, [[0, '#f0dc8c'], [0.5, '#c8a050'], [1, '#a07838']]), 0.06, 0.16, 30, GOLD);
    // champagne gold spill with bead bumps
    const SPILL = sm([[130, 445], [180, 440], [240, 432], [300, 440], [330, 400], [350, 385], [380, 400], [400, 430], [440, 450], [455, 500], [450, 560], [445, 620], [440, 690], [400, 700], [375, 690],
      [330, 690], [290, 700], [270, 720], [250, 760], [222, 768], [206, 740], [220, 690], [220, 620], [250, 580], [300, 560], [310, 520], [280, 515], [200, 518], [150, 512], [130, 480]]);
    R.dome(SPILL, lin(200, 400, 460, 720, [[0, '#d2c2a4'], [0.5, '#c8b69a'], [1, '#b8a68a']]), 0.24, 0.14, 30, GOLD);
    R.dome(sm([[70, 300], [120, 290], [160, 300], [200, 322], [222, 350], [192, 380], [176, 420], [200, 450], [150, 462], [100, 452], [70, 420], [60, 370]]), lin(60, 290, 220, 460, [[0, '#d8c8a8'], [1, '#c4b294']]), 0.24, 0.1, 18, GOLD);
    R.dome(sm([[240, 345], [300, 330], [340, 335], [335, 370], [300, 380], [250, 366]]), '#c8b69a', 0.24, 0.1, 14, GOLD);
    R.dome(sm([[-10, 296], [20, 300], [36, 330], [30, 376], [-10, 380]]), '#c8b69a', 0.2, 0.1, 14, GOLD);
    for (const [x, y, r] of [[350, 392, 14], [380, 412, 12], [408, 434, 14], [438, 462, 14], [456, 520, 18], [250, 560, 16], [278, 584, 16], [300, 610, 14], [338, 670, 14], [372, 690, 16], [410, 640, 14], [440, 600, 16], [400, 560, 12], [350, 455, 12]])
      R.bead(x, y, r, '#d4c4a6', 0.36, 0.08, GOLD);

    // ── 6. arm, zebra limbs, driver ──
    R.pipe(open([[300, 330], [262, 300], [230, 290], [210, 300]]), 22, GOLDC, 0.3, 0.12, GOLD);
    R.dome(sm([[154, 220], [180, 204], [215, 214], [228, 248], [222, 282], [196, 296], [166, 286], [152, 256]]), rad(185, 240, 50, [[0, '#e0d0b0'], [1, '#b8a47e']]), 0.3, 0.12, 30, GOLD);
    R.pipe(open([[200, 290], [180, 320], [150, 330]]), 12, GOLDC, 0.3, 0.06, GOLD);
    const ZL = sm([[30, 268], [80, 260], [96, 300], [100, 340], [90, 372], [50, 376], [30, 360], [24, 330]]);
    R.dome(ZL, null, 0.12, 0.12, 16, WHITE);
    clip(ZL, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float s = sin((p.x + 8. * sin(p.y * .03)) * .32); return mix(vec3(.9, .89, .9), vec3(.05, .05, .06), smoothstep(-.2, .2, s)); }`)));
    R.pipe(open([[80, 180], [100, 220], [118, 250]]), 18, '#e8e6e8', 0.2, 0.08, WHITE);
    const RIB = sm([[-10, 440], [40, 436], [90, 470], [130, 520], [140, 566], [100, 588], [40, 580], [-10, 576]]);
    R.dome(RIB, lin(0, 440, 140, 590, [[0, '#d8d6da'], [0.4, '#f0eef2'], [0.7, '#c4c2c8'], [1, '#e8e6ea']]), 0.12, 0.1, 18, WHITE);
    clip(RIB, () => { for (const pts of [[[0, 470], [40, 480], [70, 510], [80, 560]], [[20, 520], [50, 540], [60, 580]], [[60, 470], [100, 500], [120, 540]]]) stroke(open(pts), '#141216', 7); });
    R.dome(sm([[-10, 556], [20, 552], [40, 580], [30, 604], [-10, 606]]), '#d0be98', 0.16, 0.08, 10, GOLD);
    R.dome(sm([[24, 392], [56, 384], [66, 420], [56, 440], [30, 440]]), '#e0dedf', 0.12, 0.08, 10, WHITE);
    R.dome(sm([[-10, 370], [70, 380], [70, 430], [-10, 440]]), '#141216', 0.1, 0.06, 10, BLACK);
    // driver: cow helmet, gold face, goggles
    R.dome(sm([[290, 270], [298, 238], [330, 222], [366, 226], [384, 248], [386, 290], [372, 320], [330, 330], [300, 316]]), '#efeef0', 0.3, 0.16, 26, WHITE);
    clip(sm([[290, 270], [298, 238], [330, 222], [366, 226], [384, 248], [386, 290], [372, 320], [330, 330], [300, 316]]), () => {
      for (const [x, y, rx, ry] of [[312, 240, 26, 18], [370, 262, 16, 20], [336, 230, 10, 6]]) fill(P(blob(x, y, rx, ry, x, 9, 0.3)), '#0e0c10'); });
    R.dome(sm([[284, 278], [330, 282], [380, 296], [384, 340], [360, 352], [320, 344], [290, 320]]), '#c8b490', 0.34, 0.08, 14, GOLD);
    R.dome(rrect(286, 300, 96, 26, 8), '#16141a', 0.38, 0.04, 6, BLACK);
    for (const [x, y, r] of [[318, 290, 10], [366, 330, 12]]) { R.bead(x, y, r, '#d8d4cc', 0.42, 0.06, CHROME); R.bead(x, y, r * 0.5, '#24303a', 0.46, 0.02, BLACK); }

    // ── 7. tyres, speakers, gold sphere, chain ──
    const tyre = (x, y, r, rot) => {
      R.dome(ellipseP(x, y, r, r * 1.05, rot), '#1a181c', 0.1, 0.14, r * 0.4, RUBBER);
      clip(ellipseP(x, y, r, r * 1.05, rot), () => { for (let i = 0; i < 40; i++) { const t = i / 40 * 6.283; stroke(open([[x + Math.cos(t) * r * 0.78, y + Math.sin(t) * r * 0.8], [x + Math.cos(t) * r, y + Math.sin(t) * r]]), '#3a383e', 2); } });
      R.dome(circleP(x - r * 0.08, y, r * 0.58), '#d8d6d8', 0.2, 0.08, r * 0.2, WHITE);
      R.dome(circleP(x - r * 0.12, y, r * 0.34), '#5a585e', 0.24, 0.06, r * 0.15, CHROME);
    };
    tyre(48, 650, 64, 0); tyre(290, 940, 54, 0);
    R.dome(circleP(434, 932, 92), '#1a181c', 0.12, 0.1, 30, RUBBER);
    R.groove(circleP(434, 932, 70), 6, '#0a0a0c', 0.2, 0.04, RUBBER);
    R.dome(circleP(434, 932, 50), '#2a282c', 0.16, 0.04, 20, RUBBER);
    R.bead(434, 932, 28, '#d8d8de', 0.24, 0.16, CHROME);
    R.dome(circleP(398, 800, 52), '#e6e4e6', 0.14, 0.08, 14, WHITE);
    R.groove(circleP(398, 800, 38), 10, '#141216', 0.2, 0.05, WHITE);
    R.dome(circleP(398, 800, 22), '#e6e4e6', 0.2, 0.04, 8, WHITE);
    R.dome(circleP(505, 735, 62), rad(482, 712, 80, [[0, '#f4eada'], [0.55, '#ccb890'], [1, '#9a8460']]), 0.24, 0.28, 54, GOLD);
    R.pipe(open([[505, 675], [520, 640], [540, 600], [560, 580], [570, 560]]), 16, GOLDC, 0.3, 0.1, GOLD);
    R.pipe(open([[470, 600], [520, 590], [560, 576]]), 12, GOLDC, 0.32, 0.08, GOLD);
    R.pipe(open([[540, 600], [600, 520], [620, 470]]), 14, GOLDC, 0.3, 0.08, GOLD);
    for (let i = 0; i < 8; i++) R.bead(470 - i * 4, 740 + i * 14, 5, '#c8b48e', 0.3, 0.04, GOLD);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.9, metal: 0.4, spec: 0.9, shin: 30, tint: [1.08, 1.0, 0.86], rim: 0.25, ao: 0.4, emis: 0.1 }), // 1 champagne gold
        E.mat({ dif: 1, spec: 1.2, shin: 60, coat: 0.25, ao: 0.4 }),                                    // 2 gloss black
        E.mat({ dif: 1, spec: 0.6, shin: 40, wrap: 0.3, ao: 0.4 }),                                     // 3 white plastic
        E.mat({ dif: 1, spec: 0.2, shin: 16, wrap: 0.3, ao: 0.4 }),                                     // 4 maroon
        E.mat({ dif: 1, spec: 1.0, shin: 50, wrap: 0.4, iri: 0.08, ao: 0.3, emis: 0.1 }),               // 5 pearl
        E.mat({ dif: 1, spec: 0.3, shin: 20, ao: 0.5 }),                                               // 6 rubber
        E.mat({ dif: 0.6, metal: 0.6, spec: 1.2, shin: 60, ao: 0.3 })                                   // 7 chrome
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.75, 0.73, 0.72], amb: [0.4, 0.4, 0.44],
      envTop: [1.0, 1.0, 1.05], envHor: [0.6, 0.58, 0.6], envBot: [0.25, 0.22, 0.22], envK: [0.25, 0.9, 0.3, 0],
      r1: 2, r2: 9, k: [0, 0.6, 0.4, 90], shadow: [-6, 7, 0.5, 6]
    });
    { const r = rng(3); for (let i = 0; i < 360; i++) fill(circleP(r() * 726, 330 + r() * 694, 0.5 + r() * 0.9), `rgba(255,255,255,${0.3 + r() * 0.5})`, o); }
    E.grain(0.045, 78);
  }
});
