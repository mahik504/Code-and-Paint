'use strict';
// g015 — "Cat tile in resin": a glossy resin tile of fine cream-and-black zebra stripes with a glass notch,
// a yellow cat-heart face with orange fringe and a cream drip, a bubbly glass swirl and fluffy blue
// coral tentacles with yellow stamens, floating on a yellow-to-green glow that fades into black.
REC.register('g015', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024;
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };

    // ── glowing backdrop ──
    const bg = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float u = p.x / 726., v = p.y / 1024.;
      vec3 yel = vec3(.81, .89, .43), grn = vec3(.03, .6, .46), olive = vec3(.55, .62, .26);
      vec3 c = mix(yel, grn, smoothstep(0.08, 0.9, u + 0.3 * v));
      c = mix(c, olive, smoothstep(0.05, 0.6, v) * (1. - smoothstep(0.1, 0.6, u)));
      c *= 1. - 0.12 * smoothstep(0.05, 0.4, v);
      float k1 = smoothstep(0.62, 0.98, u * 0.8 + v * 0.62);
      float k2 = smoothstep(0.55, 0.98, v * 0.85 + u * 0.35);
      c *= 1. - 0.97 * max(k1, k2);
      return c + 0.012; }`);
    R.flat(rrect(-10, -10, W + 20, H + 20, 0), '#000', 0, 0);
    img(bg);
    // dust specks on the dark side
    { const r = rng(5); a.fillStyle = '#e8ecec'; for (let i = 0; i < 40; i++) { a.globalAlpha = 0.3 + r() * 0.6; a.beginPath(); a.arc(540 + r() * 180, 300 + r() * 700, 0.5 + r() * 1.3, 0, 6.283); a.fill(); } a.globalAlpha = 1; }

    // ── tile: glass rim + zebra resin ──
    const tileO = [[140, 312], [200, 300], [300, 290], [400, 280], [482, 270], [504, 290], [532, 420], [552, 560], [556, 700], [546, 780], [510, 816], [420, 824], [300, 816], [200, 800], [140, 760], [104, 680], [94, 560], [98, 440], [112, 360]];
    const tileP = P(tileO, true, true);
    soft(x => { x.fillStyle = 'rgba(0,0,0,0.6)'; x.fill(P(tileO.map(([px, py]) => [px + 10, py + 16]), true, true)); }, 14, 0.8);
    R.dome(tileP, '#cfd8d2', 0.06, 0.1, 12, 2);
    const inner = P(tileO.map(([px, py]) => [325 + (px - 325) * 0.965, 550 + (py - 550) * 0.97]), true, true);
    const zcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 22. * vec2(fbm(p * 0.01), fbm(p * 0.01 + 3.1)) + 6. * vec2(sin(p.y * 0.05), cos(p.x * 0.04));
      float ph = (-0.42 * q.x + 0.9 * q.y) / 16.5 + 0.6 * sin(q.x * 0.012 + q.y * 0.004);
      // swirl inside the glass C
      vec2 d = p - vec2(234., 592.); float r = length(d);
      float sw = (1. - smoothstep(20., 80., r)) * 0.8;
      ph += sw * (1.6 * d.y / (r + 12.) + r / 34.);
      float v = sin(6.2832 * ph);
      vec3 cream = vec3(.95, .92, .82), blk = vec3(.06, .06, .07);
      return mix(blk, cream, smoothstep(-0.2, 0.2, v)); }`);
    R.dome(inner, '#ffffff', 0.1, 0.06, 24, 1);
    clipA(inner, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(zcv); a.restore(); });
    // lower part of the tile sits in shadow
    clipA(inner, () => soft(x => { fe(x, 360, 810, 240, 70, 0, 'rgba(70,64,60,0.4)'); fe(x, 530, 640, 50, 170, 0, 'rgba(40,40,40,0.45)'); }, 40, 1));

    // glass notch (top centre)
    const notch = P([[236, 304], [270, 318], [296, 350], [316, 384], [336, 384], [356, 346], [380, 312], [420, 292], [404, 286], [300, 292]], true, true);
    R.dome(notch, '#9ec8a8', 0.18, 0.04, 10, 2);
    clipA(notch, () => soft(x => { fe(x, 330, 300, 60, 12, 0, '#e8f4f0'); fe(x, 320, 360, 20, 20, 0, '#6aa080'); }, 8, 0.8));
    R.dome(circleP(316, 322, 7), '#d8ece4', 0.24, 0.04, 3, 2);

    // ── glass C swirl with bubbles ──
    const cOut = [[232, 452], [200, 456], [160, 470], [128, 500], [112, 548], [112, 610], [126, 660], [160, 700], [206, 718], [250, 712], [282, 690], [286, 660], [262, 650], [234, 654], [208, 640], [190, 610], [186, 580], [196, 550], [220, 530], [256, 524], [270, 500], [262, 470]];
    const cP = P(cOut, true, true);
    R.dome(cP, lin(110, 460, 280, 720, [[0, '#ccd6e2'], [0.5, '#aebccc'], [1, '#a0aebe']]), 0.14, 0.12, 22, 3);
    clipA(cP, () => soft(x => { fe(x, 240, 498, 34, 22, -0.3, '#a8d4f8'); fe(x, 150, 520, 20, 40, 0.3, '#e8eef4'); fe(x, 200, 690, 50, 14, 0, '#c4ccd4'); }, 10, 0.8));
    { const br = rng(9);
      for (let i = 0; i < 34; i++) {
        const t = br(), side = br();
        const pts = [[150, 500], [125, 560], [128, 630], [160, 690], [220, 708]];
        const k = Math.min(pts.length - 2, Math.floor(t * (pts.length - 1))), u = t * (pts.length - 1) - k;
        const x = pts[k][0] + (pts[k + 1][0] - pts[k][0]) * u + (side - 0.5) * 50, y = pts[k][1] + (pts[k + 1][1] - pts[k][1]) * u + (br() - 0.5) * 20;
        const rr = 2 + br() * br() * 9;
        if (!a.isPointInPath(cP, x * S, y * S)) continue;
        R.bead(x, y, rr, '#f4f8fc', 0.3, Math.min(0.12, rr * 0.012 + 0.03), 3);
      }
    }

    // ── cream drip + yellow cat-heart face ──
    const drip = P([[256, 506], [300, 494], [380, 492], [436, 498], [440, 530], [420, 540], [400, 536], [390, 552], [372, 548], [362, 536], [340, 540], [330, 560], [314, 562], [304, 546], [280, 548], [262, 540]], true, true);
    R.dome(drip, '#f2ecb8', 0.14, 0.1, 12, 4);
    const face = [[206, 352], [214, 336], [234, 332], [262, 350], [296, 380], [330, 392], [364, 366], [392, 336], [412, 330], [424, 346], [428, 400], [422, 460], [412, 500], [330, 508], [252, 506], [238, 480], [214, 420]];
    const faceP = P(face, true, true);
    // orange fringe on the sides
    const fringe = (pts, seed) => { const r = rng(seed); for (let i = 0; i < pts.length - 1; i++) for (let k = 0; k < 9; k++) { const u = k / 9, x = pts[i][0] + (pts[i + 1][0] - pts[i][0]) * u, y = pts[i][1] + (pts[i + 1][1] - pts[i][1]) * u; R.bead(x + (r() - 0.5) * 3, y, 5.5 + r() * 1.5, '#f49860', 0.2, 0.08, 5); } };
    R.dome(faceP, lin(220, 340, 420, 500, [[0, '#f8e870'], [0.6, '#f8e05c'], [1, '#f2d850']]), 0.22, 0.08, 18, 4);
    fringe([[220, 330], [204, 350], [206, 400], [218, 450], [240, 500]], 11);
    fringe([[392, 330], [414, 324], [432, 344], [434, 400], [430, 456], [420, 498]], 12);
    for (const [x, y] of [[285, 432], [378, 418]]) R.bead(x, y, 7, '#08080a', 0.3, 0.05, 6);
    R.pipe(P([[326, 474], [342, 471], [354, 470]], false), 3.5, '#0a0a0c', 0.3, 0.01, 0);
    { const fr = rng(13); for (let i = 0; i < 9; i++) R.bead(276 + fr() * 22, 458 + fr() * 32, 1.8 + fr(), '#fff8d8', 0.32, 0.02, 4); }

    // ── fluffy blue coral with tentacles ──
    const coral = P(blob(505, 452, 82, 108, 21, 18, 0.18, 0.2));
    R.dome(coral, '#62aae4', 0.16, 0.16, 30, 7);
    { const cr = rng(17);
      for (let i = 0; i < 260; i++) { const an = cr() * 6.283, rr = Math.sqrt(cr()); const x = 505 + Math.cos(an) * 80 * rr, y = 452 + Math.sin(an) * 106 * rr; R.bead(x, y, 5 + cr() * 7, cr() < 0.5 ? '#78b8ee' : '#5aa0e0', 0.22 + cr() * 0.12, 0.06, 7); }
    }
    const tent = (pts, w0, w1) => {
      R.dome(P(lock(pts, w0, w1, 0.9), true, true), '#5aa6e4', 0.34, 0.1, w0 * 0.5, 7);
      const pth = P(pts, false), r = rng(pts[0][0]); a.save(); a.strokeStyle = 'rgba(30,80,150,0.5)'; a.lineWidth = 1;
      for (let i = 0; i < pts.length - 1; i++) for (let k = 0; k < 6; k++) { const u = k / 6, x = pts[i][0] + (pts[i + 1][0] - pts[i][0]) * u, y = pts[i][1] + (pts[i + 1][1] - pts[i][1]) * u, dx = pts[i + 1][0] - pts[i][0], dy = pts[i + 1][1] - pts[i][1], L = Math.hypot(dx, dy) || 1; a.beginPath(); a.moveTo(x - dy / L * w0 * 0.4, y + dx / L * w0 * 0.4); a.lineTo(x + dy / L * w0 * 0.4, y - dx / L * w0 * 0.4); a.stroke(); }
      a.restore();
    };
    tent([[392, 488], [420, 462], [470, 444], [540, 440], [600, 446], [640, 456], [664, 470]], 22, 6);
    tent([[490, 450], [496, 520], [506, 580], [512, 640]], 24, 8);
    tent([[462, 470], [452, 520], [450, 570]], 18, 6);
    tent([[536, 456], [550, 500], [560, 540]], 18, 6);
    tent([[560, 450], [590, 474], [590, 520]], 16, 6);
    // yellow stamens
    for (const [x0, y0, x1, y1] of [[470, 400, 444, 352], [490, 396, 486, 346], [500, 396, 520, 362], [520, 400, 546, 372], [536, 404, 566, 380], [548, 408, 560, 354], [512, 394, 500, 350]]) {
      R.pipe(P([[x0, y0], [(x0 + x1) / 2 + 3, (y0 + y1) / 2], [x1, y1]], false), 4, '#f0d020', 0.36, 0.06, 4);
      R.bead(x1, y1, 5, '#f4d81c', 0.38, 0.06, 4);
    }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.9, shin: 70, wrap: 0.45, coat: 0.25, ao: 0.3 }),                         // 1 glossy resin
        E.mat({ dif: 0.6, metal: 0.3, spec: 1.3, shin: 110, coat: 0.5, rim: 0.4, ao: 0.2 }),               // 2 glass
        E.mat({ dif: 0.8, spec: 1.2, shin: 90, coat: 0.45, rim: 0.3, wrap: 0.3 }),                         // 3 glass C / bubbles
        E.mat({ dif: 1, spec: 0.6, shin: 40, wrap: 0.5, coat: 0.1, ao: 0.3 }),                            // 4 yellow clay
        E.mat({ dif: 1, spec: 0.2, shin: 14, wrap: 0.5, ao: 0.6, grain: 0.3 }),                            // 5 orange fringe
        E.mat({ dif: 1, spec: 1.2, shin: 80, coat: 0.2 }),                                                 // 6 black beads
        E.mat({ dif: 1, spec: 0.25, shin: 16, wrap: 0.5, ao: 0.7, grain: 0.4 })                            // 7 knitted blue
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.72, 0.72, 0.7], amb: [0.42, 0.42, 0.42],
      envTop: [1.2, 1.25, 1.2], envHor: [0.55, 0.62, 0.5], envBot: [0.05, 0.06, 0.05], envK: [0.4, 1.3, 0.3, 0],
      rimC: [0.5, 0.6, 0.45], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 110], shadow: [-5, 7, 0.55, 6]
    });
    E.grain(0.035, 15);
  }
});
