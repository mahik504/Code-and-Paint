'use strict';
// s15 — "Pewter face medallion": a pitted pewter disc with a red contour line framing a
// hard-lit embossed face (white planes, black trenches), a blue plastic arm, pins and
// holes, on a red ground with a black void on the right.
REC.register('s15', {
  w: 1024, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fillE = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const fillP = (x, pts, col) => { x.fillStyle = col; x.fill(P(pts)); };
    const line = (x, pts, w, col) => { x.strokeStyle = col; x.lineWidth = w; x.stroke(P(pts, false)); };

    // ── ground: red, black void on the right ──
    R.flat(rrect(-10, -10, 1044, 1044, 0), '#f0404e', 0, 0);
    R.flat(P([[840, -20], [1044, -20], [1044, 1044], [915, 1044], [912, 990], [880, 950], [960, 820], [1015, 560]], true, false), '#040404', 0, 0);
    soft(x => { fillE(x, 1004, 30, 34, 34, 0, '#f4ecd8'); fillE(x, 1024, 150, 16, 22, 0, '#e8dcc0'); }, 8, 0.95);

    // ── pewter disc ──
    const disc = [[150, 118], [245, 10], [330, -30], [860, -30], [930, 70], [990, 200], [1012, 320], [1014, 450], [1004, 580], [980, 700], [940, 810],
      [890, 900], [850, 950], [760, 972], [640, 978], [560, 990], [500, 1010], [440, 960], [330, 935], [250, 880], [120, 720], [60, 690], [-20, 660], [-20, 250], [60, 200]];
    const metal = a.createLinearGradient(0, 0, 1024, 1024);
    metal.addColorStop(0, '#8c9cab'); metal.addColorStop(0.4, '#98a6b0'); metal.addColorStop(0.7, '#86847e'); metal.addColorStop(0.9, '#666258'); metal.addColorStop(1, '#58544a');
    R.dome(P(disc), metal, 0.04, 0.26, 70, 1);

    // inner raised panel bounded by the red contour
    const panel = [[470, 22], [560, 60], [610, 92], [700, 108], [790, 150], [860, 215], [893, 310], [884, 430], [862, 540], [840, 650], [800, 735],
      [720, 805], [610, 862], [500, 866], [400, 852], [310, 884], [250, 820], [190, 740], [110, 625], [60, 560], [55, 470], [72, 380], [105, 290],
      [150, 210], [230, 130], [330, 62]];
    const pg = a.createLinearGradient(0, 0, 0, 900); pg.addColorStop(0, '#98aab8'); pg.addColorStop(0.6, '#94a0a8'); pg.addColorStop(1, '#6c6a62');
    R.dome(P(panel), pg, 0.28, 0.1, 40, 1);
    // dark warm bevel just outside the contour, cool sheen inside
    soft(x => { x.strokeStyle = '#3a3026'; x.lineWidth = 26; x.stroke(P(panel)); }, 10, 0.55);
    a.save(); a.strokeStyle = '#f0262c'; a.lineWidth = 5; a.stroke(P(panel)); a.restore();
    // red sawtooth on the left inner rim
    { const pts = []; for (let i = 0; i <= 14; i++) { const t = i / 14, y = 255 + t * 165, x = 118 - t * 50; pts.push([x, y], [x - 14, y + 6]); }
      a.save(); a.strokeStyle = '#f03a3a'; a.lineWidth = 3; a.stroke(P(pts, false, false)); a.restore(); }

    // forehead band (grey, pitted) and inner right rim (bubbly ridge)
    R.pipe(P([[330, 150], [420, 120], [520, 110], [570, 120]], false), 60, '#b0bcc4', 0.36, 0.08, 1);
    R.groove(P([[575, 95], [556, 150], [548, 210], [560, 262]], false), 8, '#4a4a4a', 0.44, 0.06, 1, 0.8);
    R.pipe(P([[640, 262], [730, 300], [790, 370], [814, 470], [812, 570], [792, 650], [760, 720]], false), 44, '#a8b8c6', 0.4, 0.08, 1);
    for (const [x, y] of [[800, 470], [806, 505], [798, 545], [810, 580], [785, 600], [800, 624], [778, 646], [790, 432], [812, 535], [770, 400]]) {
      R.groove(circleP(x, y, 8), 5, '#3a3a3a', 0.5, 0.05, 1, 0.8);
    }

    // ── the face (white planes, black trenches) ──
    const face = [[130, 250], [180, 215], [240, 238], [300, 250], [400, 258], [470, 280], [560, 262], [650, 282], [720, 328], [760, 420], [766, 540], [748, 650],
      [720, 740], [640, 792], [500, 802], [360, 782], [250, 722], [170, 642], [135, 540], [124, 420], [124, 300]];
    const fg = a.createLinearGradient(0, 200, 0, 800); fg.addColorStop(0, '#e6ecef'); fg.addColorStop(0.5, '#f4f7f8'); fg.addColorStop(1, '#dfe8ee');
    R.dome(P(face), fg, 0.36, 0.16, 46, 2);
    R.dome(ellipseP(352, 378, 118, 112, -0.1), '#f3f4f1', 0.5, 0.1, 30, 2);          // eye disc
    R.dome(ellipseP(350, 352, 92, 44, -0.06), '#8a6a48', 0.55, -0.07, 24, 2);         // socket band
    R.dome(P([[292, 560], [380, 548], [470, 552], [540, 570], [560, 610], [520, 640], [430, 650], [340, 645], [290, 620]]), '#f6f8f9', 0.5, 0.08, 24, 2);
    R.dome(P([[295, 655], [400, 650], [520, 645], [560, 660], [540, 700], [430, 712], [320, 700]]), '#eef3f6', 0.5, 0.06, 20, 2);
    R.dome(P([[560, 612], [640, 606], [710, 630], [728, 690], [700, 748], [620, 764], [566, 740], [548, 680]]), '#f2f6f8', 0.5, 0.08, 26, 2);
    R.dome(P([[560, 470], [650, 470], [720, 490], [728, 560], [690, 590], [620, 585], [575, 555]]), '#f4f7f8', 0.5, 0.06, 24, 2);
    R.dome(P([[140, 300], [200, 265], [235, 310], [230, 420], [215, 480], [170, 470], [140, 400]]), '#eef2f3', 0.5, 0.06, 24, 2);
    // black trenches: albedo painted slightly soft, height dropped
    const K = '#050404';
    const blk = [
      ['s', [[140, 280], [188, 232], [258, 208], [340, 198], [420, 216], [468, 252]], 30],
      ['p', [[212, 282], [242, 268], [252, 330], [243, 420], [258, 482], [238, 505], [212, 445], [204, 360]]],
      ['p', [[126, 468], [160, 478], [196, 556], [238, 618], [205, 640], [150, 585], [126, 525]]],
      ['p', [[468, 298], [520, 296], [600, 312], [680, 342], [724, 380], [704, 398], [640, 382], [580, 372], [520, 372], [488, 385]]],
      ['p', [[470, 280], [505, 300], [500, 420], [478, 500], [455, 480], [462, 400]]],
      ['s', [[512, 396], [560, 399], [612, 405], [660, 414], [690, 432]], 11],
      ['p', [[565, 452], [620, 446], [690, 460], [700, 486], [640, 496], [575, 485]]],
      ['s', [[716, 368], [737, 450], [742, 540], [732, 640], [706, 742]], 28],
      ['p', [[378, 556], [440, 534], [500, 526], [560, 533], [622, 544], [672, 565], [702, 602], [682, 616], [622, 600], [560, 600], [520, 612], [470, 592], [420, 576]]],
      ['s', [[265, 612], [300, 640], [360, 654], [430, 650], [500, 640], [552, 626]], 14],
      ['s', [[268, 690], [330, 712], [420, 722], [510, 716], [570, 700], [600, 668]], 18],
      ['s', [[332, 520], [292, 540], [266, 580], [264, 622]], 18],
      ['s', [[560, 612], [546, 652], [550, 700], [580, 742]], 10],
      ['s', [[556, 764], [640, 782], [712, 752]], 12],
      ['s', [[232, 500], [300, 516], [380, 512], [440, 492], [475, 450]], 16]
    ];
    soft(x => {
      x.strokeStyle = K; x.lineWidth = 14; x.beginPath(); x.ellipse(352, 380, 126, 119, -0.1, 0, 6.3); x.stroke(); x.lineWidth = 26; x.beginPath(); x.ellipse(356, 384, 128, 121, -0.1, -0.3, 2.4); x.stroke();
      for (const b of blk) { if (b[0] === 's') line(x, b[1], b[2], K); else fillP(x, b[1], K); }
      fillE(x, 350, 354, 82, 20, -0.06, '#241608'); fillE(x, 348, 440, 54, 16, 0, K);
      fillE(x, 583, 404, 13, 6, 0, '#8a7458');
    }, 7, 1);
    { const hx = R.h; hx.save(); hx.fillStyle = hc(0.4, 3); hx.strokeStyle = hc(0.4, 3);
      hx.lineWidth = 22; hx.beginPath(); hx.ellipse(352, 380, 128, 121, -0.1, 0, 6.3); hx.stroke();
      for (const b of blk) { if (b[0] === 's') { hx.lineWidth = b[2]; hx.stroke(P(b[1], false)); } else hx.fill(P(b[1])); }
      hx.fill(ellipseP(348, 440, 54, 16, 0)); hx.restore(); }
    soft(x => { fillE(x, 350, 330, 70, 18, -0.06, '#b08a60'); fillE(x, 350, 395, 70, 12, 0, '#c8b8a0'); }, 8, 0.8);
    soft(x => { x.fillStyle = '#fff'; x.beginPath(); x.arc(586, 402, 3, 0, 6.3); x.fill(); }, 1, 0.9);
    // cool blue-grey shading on the lower face planes
    soft(x => { fillE(x, 200, 600, 50, 60, 0, '#a8bccb'); fillE(x, 640, 760, 60, 20, 0, '#aac0d0'); }, 20, 0.6);

    // lower bands under the face (blue-grey ridges with dark grooves)
    R.pipe(P([[150, 628], [220, 684], [320, 734], [440, 764], [560, 778], [680, 764], [760, 704]], false), 26, '#b4c8d8', 0.44, 0.08, 1);
    R.pipe(P([[180, 706], [280, 764], [400, 798], [540, 818], [680, 804], [784, 744]], false), 24, '#a8bed0', 0.42, 0.08, 1);
    R.groove(P([[160, 666], [250, 724], [360, 766], [490, 790], [620, 794], [730, 760], [790, 712]], false), 8, '#1c1c1e', 0.46, 0.1, 1, 0.9);
    R.groove(P([[230, 800], [340, 826], [460, 840], [600, 844], [720, 820]], false), 7, '#2a2624', 0.42, 0.08, 1, 0.9);

    // ── holes, pins, eye ring ──
    const hole = (x, y, r, h = 0.3) => {
      R.dome(circleP(x, y, r * 1.45), null, h, 0.04, r * 0.45, 1);
      R.flat(circleP(x, y, r), '#070707', h - 0.12, 3);
    };
    for (const [x, y, r] of [[262, 85, 17], [175, 155, 17], [940, 210, 13], [940, 490, 17], [908, 578, 12], [872, 545, 10], [830, 382, 10], [706, 274, 10],
      [694, 205, 8], [656, 225, 7], [600, 237, 7], [765, 228, 7], [790, 185, 5], [520, 130, 8], [8, 430, 15], [40, 590, 16], [105, 525, 6], [645, 860, 14],
      [640, 905, 8], [440, 905, 10], [495, 975, 26], [785, 800, 15], [305, 800, 12], [940, 450, 8], [510, 208, 8], [470, 265, 9], [422, 182, 7], [380, 215, 12],
      [450, 170, 6], [520, 262, 9], [560, 280, 6], [400, 250, 6], [365, 160, 6], [590, 175, 5], [760, 300, 5]]) hole(x, y, r);
    R.flat(P([[730, 830], [790, 822], [800, 850], [740, 856]]), '#080808', 0.18, 3);
    const pin = (x, y, r) => { R.dome(circleP(x + 4, y + 8, r), '#2a2a2c', 0.34, 0.05, 4, 1); R.dome(circleP(x, y, r), '#b8bcc0', 0.36, 0.14, r * 0.8, 4); };
    pin(607, 40, 18); pin(988, 294, 21); pin(1002, 414, 20);
    R.flat(circleP(805, 290, 36), '#0a0a0a', 0.2, 3);
    R.pipe(circleP(805, 290, 19), 11, '#f4f2ea', 0.34, 0.08, 4);
    R.flat(circleP(805, 290, 11), '#050505', 0.26, 3);

    // ── blue plastic arm (lower left) + dark ring piece (upper left) ──
    const arm = [[-40, 700], [60, 660], [170, 690], [240, 760], [300, 870], [330, 1044], [-40, 1044]];
    const bg = a.createLinearGradient(0, 700, 300, 900);
    bg.addColorStop(0, '#0a90e0'); bg.addColorStop(0.5, '#1896e0'); bg.addColorStop(0.75, '#3a86c0'); bg.addColorStop(0.9, '#5a6878'); bg.addColorStop(1, '#4a4038');
    R.dome(P(arm), bg, 0.2, 0.3, 90, 5);
    R.dome(P([[-40, 880], [40, 900], [110, 1044], [-40, 1044]]), '#ece6d6', 0.3, 0.08, 20, 5);
    R.flat(P([[-40, 960], [20, 950], [70, 1044], [-40, 1044]]), '#f0404e', 0.36, 0);
    R.pipe(P([[-20, 170], [40, 145], [110, 150], [140, 175]], false), 44, '#1a2a44', 0.2, 0.18, 5);
    R.pipe(P([[-20, 215], [60, 190], [120, 200]], false), 30, '#243a5c', 0.2, 0.12, 5);
    // right dark tube with drip + slit
    R.pipe(P([[855, 770], [900, 820], [960, 850], [1040, 862]], false), 34, '#1c2a3e', 0.3, 0.14, 5);
    R.pipe(P([[948, 572], [990, 562], [1040, 560]], false), 14, '#10213a', 0.3, 0.06, 5);
    R.dome(ellipseP(962, 725, 42, 38, 0), '#9a9a96', 0.32, 0.12, 30, 1);

    R.pipe(P([[560, 990], [700, 960], [820, 935], [880, 925]], false), 30, '#1a2436', 0.3, 0.1, 5);
    R.flat(P([[880, 1044], [905, 960], [930, 930], [1044, 900], [1044, 1044]]), '#040404', 0, 0);
    // soft tints over the metal: cool top-right planes, warm bronze shadows
    soft(x => {
      fillE(x, 700, 170, 200, 90, 0.3, '#b4d0e4'); fillE(x, 880, 350, 60, 160, 0, '#aac4d8'); fillE(x, 140, 400, 60, 140, 0, '#9ab0c0');
    }, 30, 0.55);
    soft(x => {
      fillE(x, 930, 640, 60, 120, 0, '#6a5440'); fillE(x, 640, 900, 220, 60, 0, '#4e463a'); fillE(x, 380, 900, 90, 40, 0, '#5a5044'); fillE(x, 160, 700, 70, 40, 0.5, '#6a5040');
      fillE(x, 950, 900, 40, 40, 0, '#4a3a2e'); fillE(x, 330, 120, 90, 40, -0.4, '#7c6a58');
    }, 30, 0.6);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.6, shin: 26, wrap: 0.3, ao: 1.0, metal: 0.2, rim: 0.9, coat: 0.05, emis: 0.05 }),        // 1 pewter
        E.mat({ dif: 1, spec: 0.35, shin: 18, wrap: 0.5, ao: 1.0, rim: 0.3, emis: 0.22 }),                                // 2 white face planes
        E.mat({ dif: 1, spec: 0.3, shin: 40, ao: 0.5 }),                                                      // 3 hole / trench
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.2, ao: 0.4, rim: 0.4 }),                                 // 4 pins
        E.mat({ dif: 1, spec: 0.9, shin: 50, wrap: 0.3, ao: 0.4, coat: 0.12, rim: 0.4, emis: 0.25 })                     // 5 glossy plastic
      ],
      light: [-0.55, 0.6, 0.5], lc: [0.9, 0.9, 0.92], amb: [0.2, 0.21, 0.24], l2: [0.6, -0.6, 0.35, 3], l2c: [0.55, 0.38, 0.2],
      envTop: [0.95, 0.96, 1.0], envHor: [0.62, 0.62, 0.64], envBot: [0.36, 0.3, 0.24], envK: [0.25, 0.8, 0.3, 0],
      rimC: [0.6, 0.48, 0.34], rimD: [0.4, -0.5, 0.5], r1: 2.5, r2: 10, k: [0, 0.6, 0.4, 170], shadow: [8, -8, 0.6, 5]
    });
    E.draw(E.blur(E.snapshot(), 0.8), 1);
    E.grain(0.03, 15);
  }
});
