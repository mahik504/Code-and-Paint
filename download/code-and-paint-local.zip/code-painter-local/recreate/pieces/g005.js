'use strict';
// g005 — "Plasticine fang mask": a coral clay face with cream egg eyes, teal fangs with cream tips and
// red squiggle veins, wrapped in glossy zebra coils under a grey clay hood, on acid green with white noodles.
REC.register('g005', {
  w: 701, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    // 1-px read-backs between stages keep the relief buffers in CPU memory (GPU-backed ones can get dropped under heavy stroking)
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const r = rng(5);

    // ── acid green ground ──
    R.flat(rrect(-10, -10, 721, 1044, 0), '#1ed404', 0.0, 1);
    clipA(rrect(400, 150, 320, 900, 0), () => soft(x => { const g = x.createLinearGradient(450, 200, 700, 1000); g.addColorStop(0, '#30dc08'); g.addColorStop(0.6, '#14b004'); g.addColorStop(1, '#088a02'); x.fillStyle = g; x.fillRect(400, 150, 320, 900); }, 20, 0.9));
    // coral backdrop + glow behind the drape
    R.flat(rrect(-10, -10, 520, 140, 0), '#cc7a62', 0.0, 2);
    soft(x => { const g = x.createRadialGradient(285, 20, 4, 285, 20, 120); g.addColorStop(0, '#fff2a0'); g.addColorStop(0.3, '#ffb040'); g.addColorStop(1, 'rgba(230,110,60,0)'); x.fillStyle = g; x.fillRect(140, -80, 300, 220); }, 4, 1);
    // red squiggles helper (raised clay threads)
    const squig = (x0, y0, x1, y1, n, seed, wd) => {
      const sr = rng(seed);
      for (let i = 0; i < n; i++) {
        let x = x0 + sr() * (x1 - x0), y = y0 + sr() * (y1 - y0), ang = sr() * 6.28; const pts = [[x, y]];
        for (let k = 0; k < 6; k++) { ang += (sr() - 0.5) * 2.4; x += Math.cos(ang) * 9; y += Math.sin(ang) * 9; pts.push([x, y]); }
        R.pipe(P(pts, false), wd, '#e8160c', 0.12, 0.05, 6);
      }
    };
    squig(590, 290, 701, 470, 26, 11, 4);
    for (const [x, y, rr] of [[686, 515, 14], [692, 650, 8], [640, 520, 5]]) R.bead(x, y, rr, '#e8180c', 0.05, 0.1, 6);
    keep();

    // ── coral face ──
    const FACE = [[110, 300], [130, 262], [170, 228], [240, 196], [320, 168], [420, 150], [500, 152], [560, 200], [590, 290], [610, 380], [622, 470], [628, 540], [612, 610],
      [604, 680], [610, 760], [596, 820], [560, 860], [500, 880], [452, 920], [420, 980], [400, 1034], [262, 1034], [228, 990], [180, 910], [148, 820], [130, 720],
      [100, 650], [50, 600], [44, 520], [60, 470], [100, 430]];
    const faceP = P(FACE);
    const faceTex = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = fbm(p * 0.35) * 0.5 + hash(floor(p * 0.9)) * 0.5;
      vec3 c = mix(vec3(0.93, 0.47, 0.40), vec3(0.97, 0.55, 0.47), n);
      c = mix(c, vec3(0.86, 0.36, 0.20), smoothstep(380., 180., p.y) * 0.35);
      return c; }`));
    R.dome(faceP, faceTex, 0.1, 0.12, 30, 2);
    clipA(faceP, () => {
      // sprinkles
      for (let i = 0; i < 260; i++) { a.fillStyle = 'rgba(255,255,255,0.9)'; a.fill(circleP(60 + r() * 560, 160 + r() * 860, 1 + r() * 3)); }
    });
    squig(150, 690, 600, 1000, 150, 21, 6);
    squig(140, 160, 560, 480, 26, 23, 4);
    for (const [x, y, rr] of [[380, 838, 8], [278, 858, 6]]) { R.bead(x, y, rr, '#ffe060', 0.2, 0.06, 7); }
    // eye sockets (darker rings) + cream eggs
    const eggs = [[388, 258, 34, 44, 0.05], [170, 380, 43, 33, -0.1], [320, 402, 40, 38, 0], [540, 403, 40, 34, 0.1], [468, 444, 30, 34, 0], [486, 78, 40, 26, 0.15],
      [628, 18, 32, 24, 0], [35, 755, 40, 36, 0]];
    for (const [x, y, rx, ry, rot] of eggs.slice(0, 4)) R.groove(ellipseP(x, y + 2, rx + 6, ry + 6, rot), 8, '#c03a22', 0.16, 0.05, 2, 0.6);
    // dark creases
    const crease = (pts, wd) => R.groove(P(pts, false), wd, '#3a3e44', 0.2, 0.08, 3, 1);
    crease([[58, 470], [110, 452], [160, 444], [220, 438], [270, 446], [320, 468], [380, 484], [440, 478], [500, 468], [560, 460], [612, 470]], 13);
    crease([[262, 220], [248, 270], [244, 320], [262, 372]], 13); crease([[296, 222], [318, 270], [326, 320]], 11); crease([[330, 210], [352, 262], [372, 300], [392, 340]], 13);
    crease([[200, 270], [180, 300], [150, 330]], 7); crease([[430, 200], [442, 240], [460, 270]], 6); crease([[370, 210], [395, 200]], 5);
    keep();

    // ── gum line + teeth ──
    const gum = [];
    for (let i = 0; i <= 40; i++) { const x = 46 + i * 14.5; gum.push([x, 518 + Math.sin(i * 0.7) * 6 + (r() - 0.5) * 6]); }
    R.pipe(P(gum, false), 26, '#f2eeea', 0.2, 0.06, 4);
    const teeth = [[66, 548, 26, 70, 0], [112, 548, 26, 70, 0], [152, 548, 30, 128, 1], [198, 548, 32, 152, 1], [240, 556, 28, 132, 1], [282, 556, 28, 110, 0],
      [334, 560, 34, 154, 1], [402, 556, 30, 140, 1], [448, 552, 26, 100, 0], [496, 548, 34, 144, 1], [544, 548, 26, 100, 0], [568, 546, 28, 116, 1], [606, 546, 22, 78, 0]];
    for (const [x, y, hw, len, tip] of teeth) {
      const tooth = P([[x - hw, y], [x + hw, y], [x + hw * 0.95, y + len * 0.55], [x + hw * 0.6, y + len * 0.88], [x, y + len], [x - hw * 0.6, y + len * 0.88], [x - hw * 0.95, y + len * 0.55]]);
      R.dome(tooth, '#43706f', 0.22, 0.2, hw * 0.9, 3);
      if (tip) clipA(tooth, () => { a.fillStyle = '#f2d68e'; a.fill(P([[x - hw, y + len * 0.6], [x - hw * 0.4, y + len * 0.5], [x, y + len * 0.62], [x + hw * 0.5, y + len * 0.48], [x + hw, y + len * 0.58], [x + hw, y + len + 10], [x - hw, y + len + 10]])); });
    }
    // sprinkle crust on the gum
    clipA(P([[40, 500], [630, 500], [630, 565], [40, 565]], true, false), () => { for (let i = 0; i < 300; i++) { a.fillStyle = r() < 0.5 ? '#ffffff' : '#c8c4c0'; a.fill(circleP(46 + r() * 580, 504 + r() * 34, 1 + r() * 2)); } });
    keep();

    // ── zebra coils ──
    const ZB = [[-10, 128], [100, 96], [200, 84], [300, 96], [400, 88], [470, 84], [500, 108], [480, 140], [400, 172], [300, 198], [210, 236], [140, 274], [104, 310], [96, 370],
      [80, 430], [48, 470], [40, 540], [56, 610], [96, 670], [126, 720], [146, 800], [172, 870], [206, 930], [236, 990], [252, 1034], [-10, 1034]];
    const zbP = P(ZB);
    const zeb = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 10. * vec2(sin(p.y * 0.03 + 1.), sin(p.x * 0.025)) + 26. * vec2(vnoise(p * 0.01) - .5, vnoise(p * 0.01 + 3.) - .5);
      vec2 d = (q - vec2(360., 560.)) * vec2(1.0, 0.92);
      float D = length(d) + 30. * vnoise(p * 0.006);
      float f = fract(D / 34.);
      float blk = smoothstep(0.02, 0.07, f) * smoothstep(0.45, 0.4, f);
      return mix(vec3(0.97, 0.97, 0.96), vec3(0.03), blk); }`));
    R.dome(zbP, zeb, 0.12, 0.12, 24, 4);
    const zH = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 10. * vec2(sin(p.y * 0.03 + 1.), sin(p.x * 0.025)) + 26. * vec2(vnoise(p * 0.01) - .5, vnoise(p * 0.01 + 3.) - .5);
      vec2 d = (q - vec2(360., 560.)) * vec2(1.0, 0.92);
      float D = length(d) + 30. * vnoise(p * 0.006);
      float f = fract(D / 34.);
      float t = fract(f + 0.4);
      float hv = 0.16 + 0.09 * sqrt(max(0., 1. - (2. * t - 1.) * (2. * t - 1.))) * 1.;
      hv -= 0.05 * smoothstep(0.02, 0.06, f) * smoothstep(0.42, 0.38, f);
      float v = hv * 255., i = floor(v);
      return vec3(i / 255., 4. * 32. / 255., fract(v)); }`);
    R.h.save(); R.h.clip(zbP); R.h.setTransform(1, 0, 0, 1, 0, 0); R.h.drawImage(zH, 0, 0); R.h.restore();
    keep();

    // ── grey clay hood + top drape ──
    const greyTex = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = fbm(p * 0.25) * 0.6 + hash(floor(p * 0.8)) * 0.4;
      return mix(vec3(0.33, 0.39, 0.42), vec3(0.47, 0.52, 0.55), n); }`));
    const drape = P([[-10, 40], [60, 30], [130, 18], [190, -10], [215, 20], [245, 56], [285, 78], [325, 60], [352, 24], [372, -10], [600, -10], [600, 60], [520, 90], [470, 96], [430, 72], [380, 92], [330, 118], [280, 118], [230, 100], [-10, 100]]);
    R.dome(drape, greyTex, 0.15, 0.15, 26, 5);
    clipA(drape, () => { a.fillStyle = 'rgba(30,20,10,0.35)'; a.fill(rrect(-10, -10, 120, 40, 0)); });
    R.groove(P([[0, 80], [80, 70], [170, 66], [230, 86]], false), 6, '#2e3438', 0.28, 0.05, 5, 0.8);
    const hood = P([[470, -10], [711, -10], [711, 330], [662, 300], [630, 240], [606, 190], [572, 250], [528, 312], [478, 372], [436, 446], [416, 430], [424, 360], [450, 270],
      [492, 190], [480, 140], [462, 96], [486, 40]]);
    R.dome(hood, greyTex, 0.18, 0.2, 40, 5);
    R.groove(P([[560, 20], [540, 120], [520, 200], [480, 300]], false), 8, '#2e3438', 0.36, 0.06, 5, 0.8);
    R.groove(P([[640, 60], [620, 150], [600, 190]], false), 7, '#2e3438', 0.36, 0.06, 5, 0.8);
    R.groove(P([[690, 180], [670, 260]], false), 6, '#2e3438', 0.36, 0.06, 5, 0.8);
    keep();

    // ── cream eggs ──
    for (const [x, y, rx, ry, rot] of eggs) R.dome(ellipseP(x, y, rx, ry, rot), '#f6e4a4', 0.3, 0.24, Math.min(rx, ry) * 0.9, 3);

    // ── white clay noodles ──
    const noodle = (pts, wd) => R.pipe(P(pts, false), wd, '#f4f4f2', 0.34, 0.16, 3);
    noodle([[384, 384], [382, 352], [410, 326], [470, 312], [540, 298], [610, 262], [660, 212], [700, 160], [720, 140]], 22);
    noodle([[164, 484], [140, 468], [116, 440], [104, 400], [100, 330]], 18);
    noodle([[310, 890], [350, 902], [400, 940], [450, 990], [500, 1004], [530, 980], [500, 930], [470, 900], [490, 870], [560, 860], [640, 856], [720, 852]], 42);
    noodle([[720, 590], [670, 600], [636, 630], [628, 680], [650, 730], [700, 762], [720, 770]], 36);
    R.flat(circleP(301, 885, 7), '#202020', 0.36, 0);

    // ── glowing red bead + red ball ──
    soft(x => { const g = x.createRadialGradient(285, 35, 4, 285, 35, 110); g.addColorStop(0, 'rgba(255,240,140,1)'); g.addColorStop(0.35, 'rgba(255,170,40,0.9)'); g.addColorStop(1, 'rgba(255,90,20,0)'); x.fillStyle = g; x.fillRect(150, -80, 270, 230); }, 6, 1);
    R.bead(285, 62, 28, '#e01010', 0.36, 0.24, 7);
    R.bead(100, 1012, 138, '#e8170a', 0.2, 0.3, 6);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.05, shin: 10, wrap: 0.5 }),                                       // 1 green ground
        E.mat({ dif: 1, spec: 0.18, shin: 14, wrap: 0.5, ao: 0.5, grain: 0.15 }),                  // 2 coral clay
        E.mat({ dif: 1, spec: 0.55, shin: 40, wrap: 0.45, ao: 0.4, coat: 0.08 }),                  // 3 teeth / eggs / noodles
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.35, ao: 0.4, coat: 0.15 }),                   // 4 glossy zebra
        E.mat({ dif: 1, spec: 0.08, shin: 10, wrap: 0.45, ao: 0.6, grain: 0.3 }),                  // 5 grey clay
        E.mat({ dif: 1, spec: 0.9, shin: 70, wrap: 0.3, coat: 0.25, ao: 0.3 }),                    // 6 red gloss
        E.mat({ dif: 0.5, emis: 0.9, spec: 0.8, shin: 50 })                                       // 7 glowing
      ],
      light: [-0.5, 0.62, 0.6], lc: [0.85, 0.84, 0.82], amb: [0.36, 0.36, 0.38],
      envTop: [1.05, 1.03, 1.0], envHor: [0.55, 0.55, 0.58], envBot: [0.15, 0.15, 0.17], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.2, 0.2, 0.22], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 70], shadow: [-5, 6, 0.55, 6]
    });
    const o = E.out;
    { const g = o.createRadialGradient(285, 40, 0, 285, 40, 90); g.addColorStop(0, 'rgba(255,230,120,0.75)'); g.addColorStop(0.4, 'rgba(255,160,40,0.35)'); g.addColorStop(1, 'rgba(255,120,30,0)'); o.fillStyle = g; o.fillRect(180, -60, 220, 200); }
    E.bloom(0.1, 8);
    E.grain(0.03, 5);
  }
});
