'use strict';
// g085 — "Zebra-gilled leaf creature": a glossy leaf-shaped organism on red and black — a segmented black rim
// over a fan of zebra gills, a brown veined blade, blue engraved tubes studded with orange beads, a lilac starfish.
REC.register('g085', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const clipBoth = (path, fn) => { a.save(); R.h.save(); a.clip(path); R.h.clip(path); fn(); a.restore(); R.h.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const BLK = '#050505';

    // ── fields ──
    const zeb = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(156., -33.);
      float an = atan(d.y, d.x), r = length(d);
      float ph = an * 44. / 6.2832 - r * 0.004 + 0.2 * sin(r * 0.015) + 0.5;
      float v = sin(6.2832 * ph);
      return mix(vec3(.02), vec3(.97, .96, .94), smoothstep(-.05, .2, v)); }`));
    const speck = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(.38, .19, .21);
      float n = vnoise(p * 0.35), m = vnoise(p * 0.7 + 9.);
      c = mix(c, vec3(.27, .11, .13), smoothstep(.55, .75, n));
      c = mix(c, vec3(.48, .28, .30), smoothstep(.65, .82, m) * .6);
      return c; }`));
    const grit = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(.12, .08, .08);
      float n = hash(floor(p / 3.));
      c = mix(c, vec3(.55, .25, .2), step(.9, n));
      c = mix(c, vec3(.03), step(.5, vnoise(p * .2)) * .5);
      return c; }`));

    // ── background: red above, black below ──
    R.flat(rrect(-10, -10, 746, 1044, 0), lin(0, 0, 0, 1024, [[0, '#fc1422'], [0.58, '#fc1422'], [0.6, '#030303'], [1, '#020202']]), 0, 0);
    const sr = rng(85);
    for (let i = 0; i < 24; i++) { const x = sr() * 726, y = sr() < 0.6 ? sr() * 200 : 700 + sr() * 320; a.fillStyle = '#ffffff'; a.fill(circleP(x, y, 1.2 + sr() * 2.5)); }

    // ── organism silhouette ──
    const body = P([[-10, 214], [40, 190], [84, 176], [120, 152], [180, 118], [250, 84], [320, 60], [400, 50], [480, 54], [550, 78], [620, 112], [680, 152], [736, 196],
      [736, 590], [664, 630], [612, 644], [576, 682], [548, 722], [520, 770], [480, 816], [430, 858], [380, 896], [320, 936], [276, 962], [186, 1016], [170, 1034], [-10, 1034]], true, true);
    R.dome(body, '#3a2224', 0.04, 0.08, 20, 3);
    // brown blade
    const blade = P([[300, 330], [420, 340], [520, 316], [620, 280], [736, 250], [736, 580], [660, 620], [600, 640], [560, 700], [520, 760], [470, 810], [400, 860], [330, 880], [270, 860], [230, 790], [214, 700], [222, 600], [240, 520], [262, 440], [290, 370]], true, true);
    R.dome(blade, speck, 0.1, 0.06, 30, 3);
    keep();
    // white branching veins
    const vr = rng(7);
    const vein = (x, y, ang, len, wd) => {
      const pts = [[x, y]]; let cx = x, cy = y, an = ang;
      for (let k = 0; k < 12; k++) { an += (vr() - 0.5) * 0.18; cx += Math.cos(an) * len / 12; cy += Math.sin(an) * len / 12; pts.push([cx, cy]); }
      R.groove(P(pts, false, true), wd + 2, '#f4f0f0', 0.16, 0.02, 3, 1);
      a.lineWidth = wd; a.strokeStyle = '#f8f4f4'; a.lineCap = a.lineJoin = 'round'; a.stroke(P(pts, false, true));
      for (let k = 1; k < 12; k++) for (const sg of [-1, 1]) {
        if (vr() < 0.35) continue;
        const L = 8 + vr() * 16, b = an + sg * (0.5 + vr() * 0.5), [px, py] = pts[k];
        a.lineWidth = Math.max(1.2, wd * 0.4); a.stroke(P([[px, py], [px + Math.cos(b) * L, py + Math.sin(b) * L]], false, false));
      }
    };
    clipBoth(blade, () => {
      for (const [x, y, an, len] of [[480, 352, 3.08, 170], [476, 380, 2.9, 210], [470, 420, 2.7, 250], [470, 470, 2.45, 290], [490, 520, 2.25, 330], [520, 560, 2.12, 340], [530, 620, 2.05, 280], [510, 690, 1.98, 190]]) vein(x, y, an, len, 4.5);
    });
    keep();

    // ── blue engraved tubes with gritty gaps (left) ──
    const gap = P([[-10, 230], [100, 228], [200, 250], [300, 330], [290, 370], [262, 440], [240, 520], [222, 600], [214, 700], [230, 790], [270, 860], [300, 900], [276, 962], [186, 1016], [170, 1034], [-10, 1034]], true, true);
    R.flat(gap, grit, 0.12, 0);
    const endX = y => y < 340 ? 300 : y < 470 ? 300 - (y - 340) * 0.3 : y < 700 ? 262 - (y - 470) * 0.18 : y < 860 ? 220 + (y - 700) * 0.25 : 260;
    for (let i = 0; i < 15; i++) {
      const y0 = 258 + i * 55.5, ex = endX(y0 + 8);
      const tp = P([[-20, y0 - 4], [50, y0 + 12], [120, y0 + 2], [190, y0 + 18], [ex - 10, y0 + 24]], false, true);
      R.pipe(tp, 38, '#3e6ee0', 0.14, 0.12, 2);
      a.save(); a.lineWidth = 10; a.strokeStyle = 'rgba(140,180,255,0.45)'; a.translate(0, -7); a.stroke(tp); a.restore();
      const tr = rng(i + 3);
      for (let k = 0; k < 14; k++) { const x = 20 + k * 16 + tr() * 6; if (x > ex - 30) break; const yy = y0 + 8 + (x / 200) * 12; R.groove(P([[x, yy], [x + 6, yy + 2]], false, false), 2, '#1a3a90', 0.24, 0.02, 2, 0.9); }
      R.dome(circleP(ex - 10, y0 + 24, 19), '#4a7ae6', 0.16, 0.1, 16, 2);
    }
    keep();

    // ── nose + segmented black rim + zebra gills ──
    const zone = P([[186, 170], [230, 140], [300, 115], [400, 105], [480, 112], [550, 135], [610, 170], [650, 215], [640, 245], [600, 272], [520, 312], [470, 332], [400, 342], [320, 342], [260, 322], [210, 292], [188, 250]], true, true);
    R.flat(zone, '#060606', 0.1, 4);
    clipBoth(zone, () => { R.dome(P([[190, 150], [300, 112], [470, 108], [540, 180], [616, 252], [520, 316], [400, 336], [320, 336], [262, 318], [196, 280]], true, true), zeb, 0.1, 0.08, 10, 4); });
    // black gaps between stripes (re-ink darker for contrast)
    const rimPath = P([[176, 136], [250, 98], [320, 76], [400, 70], [480, 74], [550, 98], [620, 136], [680, 186], [736, 236]], false, true);
    R.pipe(rimPath, 58, '#1c1c1e', 0.22, 0.2, 1);
    for (const t of [0.12, 0.25, 0.38, 0.5, 0.62, 0.74, 0.86]) {
      const pts = [[176, 136], [250, 98], [320, 76], [400, 70], [480, 74], [550, 98], [620, 136], [680, 186], [736, 236]], k = t * (pts.length - 1), i = Math.floor(k), f = k - i;
      const x = pts[i][0] + (pts[i + 1][0] - pts[i][0]) * f, y = pts[i][1] + (pts[i + 1][1] - pts[i][1]) * f;
      const dx = pts[i + 1][0] - pts[i][0], dy = pts[i + 1][1] - pts[i][1], L = Math.hypot(dx, dy), nx = -dy / L, ny = dx / L;
      R.groove(P([[x - nx * 28, y - ny * 28], [x + nx * 28, y + ny * 28]], false, false), 6, '#000000', 0.42, 0.14, 1, 1);
    }
    R.pipe(P([[200, 160], [270, 128], [330, 108], [400, 102], [480, 108], [550, 128], [620, 170], [680, 226], [736, 270]], false, true), 5, '#7ab0e0', 0.2, 0.04, 2);
    const nose = P([[66, 206], [84, 168], [120, 146], [160, 134], [206, 132], [236, 150], [218, 178], [196, 200], [190, 234], [176, 258], [116, 258], [80, 240]], true, true);
    R.dome(nose, '#8cc4ea', 0.16, 0.18, 30, 2);
    R.bead(176, 186, 5, BLK, 0.32, 0.02, 1);
    keep();

    // ── lilac starfish ──
    const arms = [[[570, 420], [668, 330]], [[570, 420], [690, 432]], [[570, 420], [664, 556]], [[570, 420], [544, 560]], [[570, 420], [462, 494]], [[570, 420], [584, 330]]];
    for (const [p0, p1] of arms) R.pipe(P([p0, p1], false, false), 50, '#d4a4cc', 0.14, 0.14, 5);
    R.dome(P(blob(574, 424, 104, 92, 12, 16, 0.18)), '#d8acd2', 0.14, 0.16, 50, 5);
    for (const r of [44, 58, 72]) R.groove(ellipseP(574, 432, r, r * 0.7, -0.2), 2.5, '#f2e4f2', 0.3, 0.02, 5, 1);
    R.dome(circleP(570, 398, 34), '#5a5a62', 0.3, 0.06, 6, 1);
    R.dome(circleP(570, 398, 28), '#e0e2ea', 0.34, 0.06, 6, 1);
    R.dome(circleP(570, 398, 21), '#9cc8f0', 0.36, 0.1, 14, 2);
    // blue cone horns
    const cone = (x0, y0, x1, y1, w0) => { for (let k = 0; k < 7; k++) { const t = k / 7; R.dome(ellipseP(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, w0 * (1 - t * 0.75), w0 * (1 - t * 0.75) * 0.75, Math.atan2(y1 - y0, x1 - x0) + Math.PI / 2), '#8ec2ec', 0.3 + t * 0.05, 0.08, 6, 2); } };
    cone(660, 330, 736, 240, 30); cone(660, 560, 712, 626, 28); cone(540, 540, 544, 630, 16); cone(470, 494, 432, 506, 12); cone(680, 430, 724, 414, 10); cone(586, 330, 590, 312, 8);
    keep();

    // ── lower-right blue rim + big bead ──
    const rim2 = P([[736, 572], [664, 616], [612, 628], [574, 668], [546, 712], [516, 760], [474, 806], [424, 848], [372, 886], [312, 926], [266, 954], [180, 1006], [160, 1034]], false, true);
    R.pipe(rim2, 40, '#86c0ea', 0.12, 0.14, 2);
    R.pipe(rim2, 12, '#4a7ad0', 0.24, 0.04, 2);
    R.dome(circleP(282, 878, 42), '#8cc6ee', 0.2, 0.26, 40, 2);
    keep();

    // ── orange beads ──
    const beads = [[54, 196, 15], [26, 214, 14], [44, 222, 10], [70, 250, 12], [156, 286, 17], [52, 314, 17], [130, 342, 17], [36, 368, 16], [216, 356, 17], [270, 356, 17], [342, 326, 14], [250, 432, 16], [6, 444, 16], [60, 484, 16], [110, 488, 16], [196, 498, 15], [170, 540, 16], [46, 546, 16], [96, 586, 16], [210, 608, 15], [146, 656, 16], [36, 690, 14], [64, 724, 15], [142, 712, 14], [216, 720, 15], [40, 768, 16], [182, 786, 16], [104, 820, 17], [234, 798, 15], [26, 826, 17], [66, 874, 16], [194, 860, 16], [110, 936, 17], [16, 948, 14],
      [560, 312, 13], [520, 364, 12], [474, 386, 13], [508, 368, 11], [544, 354, 12], [612, 372, 13], [636, 418, 15], [690, 436, 14], [704, 492, 13], [628, 484, 15], [624, 518, 13], [510, 478, 12], [466, 448, 12], [462, 478, 13], [488, 548, 13], [604, 566, 14], [600, 346, 11]];
    for (const [x, y, r] of beads) R.bead(x, y, r, '#fa6a3c', 0.3, Math.min(0.35, r * 0.014 + 0.08), 6);
    const cr = rng(31);
    for (let i = 0; i < 26; i++) R.bead(588 + cr() * 60, 640 + cr() * 76 - cr() * 20, 8 + cr() * 5, '#f2643a', 0.18, 0.08, 6);
    for (let i = 0; i < 60; i++) R.bead(cr() * 240, 240 + cr() * 760, 2 + cr() * 4, '#e85a50', 0.14, 0.03, 6);
    // black spoon
    R.dome(ellipseP(708, 676, 46, 32, -0.3), '#141416', 0.12, 0.12, 20, 1);
    R.pipe(P([[660, 640], [690, 660]], false, false), 6, '#c8c8cc', 0.2, 0.04, 1);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.9, spec: 1.0, shin: 70, wrap: 0.3, ao: 0.5, coat: 0.35, rim: 0.2 }),      // 1 glossy black rim
        E.mat({ dif: 1, spec: 0.7, shin: 45, wrap: 0.4, ao: 0.5, coat: 0.18, rim: 0.1 }),        // 2 blue rubber
        E.mat({ dif: 1, spec: 0.35, shin: 25, wrap: 0.4, ao: 0.6, coat: 0.05 }),                 // 3 brown blade
        E.mat({ dif: 1, spec: 0.5, shin: 40, wrap: 0.4, ao: 0.5, coat: 0.1 }),                   // 4 zebra gills
        E.mat({ dif: 1, spec: 0.8, shin: 55, wrap: 0.5, ao: 0.4, coat: 0.18 }),                  // 5 lilac starfish
        E.mat({ dif: 1, spec: 1.1, shin: 80, wrap: 0.3, ao: 0.4, coat: 0.25, rim: 0.1 })        // 6 orange beads
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.7, 0.7, 0.7], amb: [0.45, 0.45, 0.46],
      envTop: [1, 1, 1], envHor: [0.5, 0.48, 0.5], envBot: [0.1, 0.06, 0.06], envK: [0.2, 1.1, 0.3, 0],
      r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 120], shadow: [-4, 6, 0.6, 7]
    });
    E.grain(0.03, 85);
  }
});
