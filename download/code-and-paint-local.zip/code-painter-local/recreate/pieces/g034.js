'use strict';
// g034 — "Specimen in the bell jar": a glass globe on a glass pillar holding a white owl-faced creature in gold
// spectacles and a red cap, wrapped in zebra stripes; white tangled tubes, a dark cable, a pastel glow, a spiked
// zebra tube and copper lace on a glass floor, all against cobalt blue.
REC.register('g034', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = cv => a.drawImage(cv, 0, 0, 726, 1024);
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, st, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const SC = [377, 285], SR = 213;
    const globe = circleP(SC[0], SC[1], SR);

    // ── cobalt ground + pastel glow on the right ──
    R.flat(rrect(-10, -10, 746, 1044, 0), lin(0, 0, 0, 1024, [[0, '#5680cc'], [1, '#567dc8']]), 0, 0);
    soft(x => {
      x.fillStyle = '#8a70d0'; x.fill(ellipseP(600, 250, 110, 60, 0));
      x.fillStyle = '#c8eef8'; x.fill(ellipseP(640, 390, 150, 60, 0));
      x.fillStyle = '#f494b4'; x.fill(ellipseP(640, 530, 170, 60, 0));
      x.fillStyle = '#f6b0b0'; x.fill(ellipseP(560, 640, 200, 70, 0)); x.fillStyle = '#f0a0b8'; x.fill(ellipseP(420, 700, 120, 60, 0));
    }, 26, 0.95);

    // ── dark cable + white tangled tubes (right) ──
    const DARK = '#3a2a2c';
    R.pipe(P([[560, 260], [590, 200], [640, 176], [690, 190], [726, 220]], false), 12, DARK, 0.06, 0.08, 2);
    R.pipe(P([[576, 330], [610, 400], [636, 480], [646, 560], [690, 600], [740, 610]], false), 12, DARK, 0.06, 0.08, 2);
    R.pipe(P([[600, 370], [650, 420], [700, 470], [740, 500]], false), 10, DARK, 0.06, 0.08, 2);
    const WT = '#f2f0ec';
    for (const [pts, w] of [
      [[[540, 130], [580, 100], [620, 70], [650, 60], [690, 40], [726, 50]], 26], [[[650, 10], [662, -10]], 26], [[[660, 0], [700, 10], [726, 30]], 24],
      [[[620, 80], [640, 120], [680, 150], [726, 140]], 24], [[[690, 140], [700, 200], [710, 260], [700, 330], [706, 400], [690, 470], [676, 490]], 26],
      [[[630, 110], [610, 150], [620, 170]], 20], [[[700, 60], [690, 100], [660, 110], [640, 90]], 18], [[[560, 120], [540, 150]], 18]]) R.pipe(P(pts, false), w, WT, 0.2, 0.14, 1);
    R.bead(676, 488, 18, WT, 0.2, 0.12, 1);

    // ── glass pillar + collar (behind the globe bottom) ──
    const col = rrect(290, 580, 176, 300, 4);
    R.flat(col, lin(290, 0, 466, 0, [[0, '#7a8ad0'], [0.2, '#c0a8d8'], [0.45, '#e8a8c0'], [0.7, '#b8a0d0'], [1, '#8a8ccc']]), 0.1, 0);
    clipA(col, () => { for (const [x, w, c] of [[300, 6, 'rgba(255,255,255,0.8)'], [326, 3, 'rgba(255,255,255,0.6)'], [420, 4, 'rgba(255,255,255,0.7)'], [448, 8, 'rgba(255,255,255,0.5)'], [380, 10, 'rgba(240,120,150,0.4)']]) { a.fillStyle = c; a.fillRect(x, 580, w, 300); } });
    const collar = rrect(240, 520, 276, 64, 30);
    R.dome(collar, lin(0, 520, 0, 584, [[0, '#b8c4e8'], [0.3, '#6a7cc0'], [0.6, '#c4cce8'], [1, '#5a6cb4']]), 0.12, 0.12, 22, 4);
    R.dome(rrect(300, 476, 156, 52, 18), lin(0, 476, 0, 528, [[0, '#a4b0e0'], [0.5, '#6c7ec4'], [1, '#b4c0e6']]), 0.12, 0.1, 16, 4);
    R.dome(rrect(286, 578, 184, 22, 10), '#9cacdc', 0.14, 0.06, 8, 4);

    // ── inside the globe ──
    R.flat(globe, rad(470, 300, 260, [[0, '#8098d8'], [0.6, '#5f7cc8'], [1, '#5070c0']]), 0.06, 0);
    clipA(globe, () => soft(x => { x.fillStyle = '#f4a8c8'; x.fill(ellipseP(560, 450, 90, 50, 0)); x.fillStyle = '#e8f2ff'; x.fill(ellipseP(560, 360, 60, 40, 0)); }, 22, 0.8));
    // zebra crescent: fine concentric arcs near the glass, broad stripes below
    const cres = P([[381, 96], [304, 108], [227, 146], [181, 214], [168, 290], [181, 368], [227, 422], [300, 466], [380, 478], [384, 440], [350, 380], [320, 320], [304, 260], [308, 190], [330, 140], [372, 112]]);
    R.dome(cres, null, 0.12, 0.2, 40, 5);
    clipA(cres, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(381., 314.); float r = length(d);
      float fine = sin(6.2832 * r / 12.5 + /*zc*/5.6);
      float broad = sin(6.2832 * (p.x + 0.25 * (p.y - 300.) + 10. * sin(p.y * 0.02)) / 36. + /*zb*/4.0);
      float m = smoothstep(170., 160., r) + smoothstep(240., 270., p.y) * smoothstep(190., 175., r);
      float s = mix(fine, broad, clamp(m, 0., 1.));
      return vec3(smoothstep(0., .3, s)) * .92 + .04; }`)));
    // creature: white head + drippy body, red cap
    const body = P([[282, 210], [300, 160], [340, 126], [400, 114], [450, 122], [486, 150], [498, 200], [492, 256], [470, 300], [448, 340], [430, 380], [420, 430], [400, 460], [370, 470],
      [340, 456], [310, 420], [290, 380], [300, 340], [286, 300], [278, 256]]);
    R.dome(body, '#f4f2ee', 0.14, 0.26, 50, 1);
    for (const [x, y, rr] of [[318, 440, 14], [296, 430, 10], [350, 470, 12], [280, 452, 8], [330, 340, 12], [356, 318, 9]]) R.bead(x, y, rr, '#f2f0ec', 0.2, 0.1, 1);
    const cap = P([[316, 192], [326, 154], [356, 126], [400, 114], [444, 120], [474, 140], [488, 176], [484, 200], [456, 186], [414, 180], [372, 182], [338, 194]]);
    R.dome(cap, '#a84c46', 0.34, 0.08, 18, 2);
    clipA(cap, () => { const r = rng(4); a.fillStyle = 'rgba(70,20,20,0.5)'; for (let i = 0; i < 500; i++) a.fillRect(326 + r() * 162, 116 + r() * 72, 1.2, 1.2); });
    // gold spectacles + nose ring + strap + ring
    const GOLD = '#d8a032';
    for (const [x, y, rr] of [[350, 210, 32], [437, 207, 33]]) { R.bead(x, y, rr - 4, '#f6f4f0', 0.3, 0.1, 1); R.bead(x, y, rr * 0.42, '#101018', 0.34, 0.08, 6); R.pipe(circleP(x, y, rr), 10, GOLD, 0.4, 0.06, 3); }
    R.bead(390, 248, 23, '#0c0c12', 0.36, 0.1, 6); R.pipe(circleP(390, 248, 27), 11, GOLD, 0.42, 0.06, 3);
    R.pipe(P([[380, 214], [384, 224]], false), 9, GOLD, 0.42, 0.04, 3); R.pipe(P([[398, 224], [404, 214]], false), 9, GOLD, 0.42, 0.04, 3);
    R.dome(rrect(380, 268, 24, 108, 6), GOLD, 0.38, 0.06, 6, 3);
    R.pipe(circleP(404, 398, 26), 7, GOLD, 0.4, 0.06, 3);
    // white coral + hanging tendril
    { const r = rng(12); for (let i = 0; i < 46; i++) { const x = 470 + r() * 80, y = 108 + r() * 160 * Math.pow(r(), 0.6); R.bead(x, y, 4 + r() * 9, '#f4f2ee', 0.24, 0.08, 1); } }
    R.pipe(P([[522, 250], [532, 300], [528, 350], [512, 384], [492, 392]], false), 13, '#f2f0ec', 0.22, 0.08, 1);
    R.bead(490, 392, 11, '#f2f0ec', 0.22, 0.08, 1);
    R.pipe(P([[470, 330], [462, 400], [470, 440], [488, 470]], false), 9, '#eeece8', 0.2, 0.06, 1);

    // ── copper lace plates ──
    const COP = '#b46c44';
    R.flat(rrect(-10, 780, 746, 260, 0), lin(0, 780, 0, 1024, [[0, '#8a9ad8'], [1, '#6e86cc']]), 0.02, 4);
    const plateL = P([[-10, 830], [60, 800], [140, 780], [220, 760], [300, 748], [380, 756], [340, 830], [260, 890], [170, 950], [110, 1034], [-10, 1034]]);
    R.dome(plateL, COP, 0.06, 0.08, 10, 2);
    const plateR = P([[480, 950], [560, 896], [640, 850], [740, 816], [740, 1034], [420, 1034]]);
    R.dome(plateR, COP, 0.06, 0.08, 10, 2);
    const hole = (x, y, rx, ry, rot) => { R.flat(ellipseP(x, y, rx * 0.72, ry * 0.62, rot), '#7088c8', 0.05, 0); R.pipe(ellipseP(x, y, rx * 0.86, ry * 0.8, rot), Math.max(8, rx * 0.28), '#d08a5c', 0.1, 0.1, 2); };
    for (const [x, y, rx, ry, rot] of [[46, 884, 54, 32, -0.25], [196, 836, 42, 26, -0.25], [266, 790, 30, 18, -0.25], [330, 772, 22, 13, -0.25], [116, 842, 30, 18, -0.25], [688, 846, 38, 22, -0.2], [506, 990, 52, 30, -0.15], [644, 994, 58, 32, -0.15], [10, 990, 30, 20, -0.2], [600, 876, 30, 16, -0.2], [250, 870, 30, 18, -0.25], [40, 950, 26, 16, -0.2]]) hole(x, y, rx, ry, rot);
    for (const [x, y, rr] of [[120, 930, 44], [600, 908, 46], [60, 970, 30]]) {
      for (let k = 0; k < 14; k++) { const t = k / 14 * 6.283; R.pipe(P([[x, y], [x + Math.cos(t) * rr, y + Math.sin(t) * rr * 0.55]], false), 9, '#c07048', 0.12, 0.06, 2); }
      R.bead(x, y, 10, '#b86840', 0.14, 0.06, 2);
    }
    R.dome(ellipseP(150, 820, 26, 13, -0.2), '#f4f2ee', 0.12, 0.06, 8, 1);

    // ── spiked zebra tube ──
    const A = [150, 1084], B = [800, 650], dx = B[0] - A[0], dy = B[1] - A[1], L = Math.hypot(dx, dy), ux = dx / L, uy = dy / L;
    const half = (t) => 100 - 32 * t;
    const top = [], bot = [];
    for (let i = 0; i <= 20; i++) { const t = i / 20, cx = A[0] + dx * t, cy = A[1] + dy * t, h = half(t); top.push([cx + uy * h, cy - ux * h]); bot.push([cx - uy * h, cy + ux * h]); }
    const tube = P([...top, ...bot.reverse()], true, false);
    R.dome(tube, null, 0.18, 0.34, 60, 6);
    clipA(tube, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float t = dot(p - vec2(150., 1084.), normalize(vec2(650., -434.)));
      float ph = -/*zk*/10. * log(1440. - t) + /*zt*/0.75;
      float v = smoothstep(0.34, 0.36, fract(ph)) * smoothstep(1., 0.98, fract(ph));
      return mix(vec3(.03, .02, .03), vec3(.97, .96, .95), v); }`)));
    // cones (white, dark at the base)
    for (const [bx, by, ax, ay, w] of [[372, 845, 290, 745, 92], [452, 792, 354, 670, 92], [528, 738, 452, 610, 68], [504, 757, 454, 689, 42], [580, 685, 500, 565, 63], [668, 663, 604, 583, 53], [716, 629, 680, 561, 37]]) {
      const nx = -(ay - by), ny = ax - bx, nl = Math.hypot(nx, ny), px = nx / nl * w / 2, py = ny / nl * w / 2;
      const cone = P([[ax, ay], [bx + px, by + py], [bx - px, by - py]], true, true);
      R.dome(cone, lin(ax, ay, bx, by, [[0, '#fbf8f4'], [0.45, '#f0ebe6'], [1, '#e2dad4']]), 0.4, 0.16, w * 0.4, 1);
      clipA(cone, () => soft(x => { x.fillStyle = '#140806'; x.fill(ellipseP(bx + (ax - bx) * 0.12 - px * 0.3, by + (ay - by) * 0.12 - py * 0.3, w * 0.5, w * 0.36, Math.atan2(ay - by, ax - bx))); }, w * 0.14, 1));
    }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.5, ao: 0.4, coat: 0.25, rim: 0.2 }),               // 1 white porcelain
        E.mat({ dif: 1, spec: 0.7, shin: 40, wrap: 0.4, ao: 0.5, coat: 0.2 }),                         // 2 copper lacquer / cap
        E.mat({ dif: 0.7, metal: 0.6, spec: 1.2, shin: 60, rim: 0.3, ao: 0.3, tint: [1.1, 0.95, 0.6] }),   // 3 gold
        E.mat({ dif: 0.6, spec: 1.3, shin: 120, wrap: 0.6, coat: 0.4, emis: 0.35, rim: 0.4 }),         // 4 glass
        E.mat({ dif: 1, spec: 0.8, shin: 60, wrap: 0.4, ao: 0.4, coat: 0.2, emis: 0.1 }),               // 5 zebra inside
        E.mat({ dif: 1, spec: 1.2, shin: 80, wrap: 0.4, ao: 0.3, coat: 0.3 })                          // 6 glossy black / tube
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.85, 0.85, 0.88], amb: [0.4, 0.42, 0.5],
      envTop: [1.0, 1.02, 1.1], envHor: [0.5, 0.58, 0.85], envBot: [0.25, 0.3, 0.6], envK: [0.3, 1.0, 0.3, 0],
      rimC: [0.3, 0.35, 0.6], rimD: [0, 1, 0.3], r1: 1.5, r2: 8, k: [0, 0.55, 0.45, 110], shadow: [-4, 6, 0.5, 6]
    });

    // ── glass globe overlay: tint, rim and highlights ──
    o.save(); o.clip(globe);
    o.fillStyle = 'rgba(200,215,255,0.04)'; o.fillRect(160, 70, 440, 430);
    o.lineWidth = 16; o.strokeStyle = 'rgba(230,238,255,0.35)'; o.stroke(circleP(SC[0], SC[1], SR - 6));
    o.restore();
    o.lineWidth = 3; o.strokeStyle = 'rgba(245,248,255,0.85)'; o.stroke(globe);
    soft(x => {
      x.lineCap = 'round'; x.strokeStyle = 'rgba(255,255,255,0.9)';
      x.lineWidth = 7; x.beginPath(); x.arc(SC[0], SC[1], SR - 16, 3.5, 4.3); x.stroke();
      x.lineWidth = 5; x.beginPath(); x.arc(SC[0], SC[1], SR - 14, 5.4, 6.0); x.stroke();
      x.lineWidth = 4; x.beginPath(); x.arc(SC[0], SC[1], SR - 20, 0.5, 1.0); x.stroke();
    }, 2, 0.9, o);
    E.grain(0.025, 34);
  }
});
