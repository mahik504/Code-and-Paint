'use strict';
// g114 — "Felt collage with spirals": a layered paper-and-felt collage — a coral field, a spiky maroon
// figure, a dotted pistachio pear, purple and teal cut-outs, black-and-white spiral discs, rope and a polka ball.
REC.register('g114', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const fill = (path, c) => { o.fillStyle = c; o.fill(path); };
    const stroke = (path, c, wd, cap = 'round') => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = cap; o.lineJoin = 'round'; o.stroke(path); };
    const clipped = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, r1, stops, x1 = x, y1 = y) => { const g = o.createRadialGradient(x, y, r0, x1, y1, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const L = pts => P(pts, false, true);
    // a cut-out card: soft drop shadow, then the fill
    const card = (path, c, sh = 1) => {
      if (sh > 0) { o.save(); o.filter = `blur(${4 * sh * S}px)`; o.translate(3 * sh, 5 * sh); fill(path, 'rgba(0,0,0,0.55)'); o.restore(); }
      fill(path, c);
    };
    const ropeL = (pts, wd = 14) => {
      const p = L(pts);
      o.save(); o.filter = `blur(${3 * S}px)`; o.translate(3, 4); stroke(p, 'rgba(0,0,0,0.5)', wd); o.restore();
      stroke(p, '#c85a2c', wd);
      // braided chevrons along a Catmull-Rom resampling of the control points
      const dense = [];
      for (let i = 0; i < pts.length - 1; i++) {
        const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
        for (let t = 0; t < 1; t += 0.05) {
          const t2 = t * t, t3 = t2 * t, f = (a0, a1, a2, a3) => 0.5 * (2 * a1 + (-a0 + a2) * t + (2 * a0 - 5 * a1 + 4 * a2 - a3) * t2 + (-a0 + 3 * a1 - 3 * a2 + a3) * t3);
          dense.push([f(p0[0], p1[0], p2[0], p3[0]), f(p0[1], p1[1], p2[1], p3[1])]);
        }
      }
      let acc = 0, k = 0;
      for (let i = 1; i < dense.length; i++) {
        const [x0, y0] = dense[i - 1], [x1, y1] = dense[i], d = Math.hypot(x1 - x0, y1 - y0); acc += d;
        if (acc < 6.5) continue; acc = 0; k++;
        const tx = (x1 - x0) / d, ty = (y1 - y0) / d, nx = -ty, ny = tx, h = wd * 0.42;
        const side = k % 2 ? 1 : -1;
        stroke(P([[x1 + nx * h * side, y1 + ny * h * side], [x1 + tx * 4, y1 + ty * 4]], false, false), '#f0905a', 3.2);
        stroke(P([[x1 + nx * h * side - tx * 3, y1 + ny * h * side - ty * 3], [x1 - tx * 1, y1 - ty * 1]], false, false), '#8a3416', 1.2);
      }
    };
    const felt = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = hash(floor(p * 1.3)) - .5; return vec3(.5 + .12 * n); }`));
    const feltOver = (path, a = 0.25) => { o.save(); o.globalAlpha = a; o.globalCompositeOperation = 'overlay'; fill(path, felt); o.restore(); };
    const rings = (cx, cy, e, Pp, k, ph, poly, dark, light) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = vec2(p.x - ${cx.toFixed(2)}, (p.y - ${cy.toFixed(2)}) * ${e.toFixed(4)}); ${poly || 'float g = 0.;'}
      float f = length(d) / ${Pp.toFixed(4)} + ${k.toFixed(4)} * atan(d.y, d.x) / 6.2832 + ${ph.toFixed(4)} + g + .25 * (vnoise(p * .08) - .5);
      return mix(vec3(${dark}), vec3(${light}), smoothstep(-.15, .15, cos(6.2832 * f))); }`));
    const polka = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p / 23.; vec2 i = floor(q), f = fract(q); float d = 9., d2 = 9.;
      for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) { vec2 g = vec2(x, y); vec2 r = g + vec2(hash(i + g), hash(i + g + 3.7)) * .7 + .15 - f; float l = length(r); if (l < d) { d2 = d; d = l; } else d2 = min(d2, l); }
      float h = hash(floor(q) + 9.);
      float cream = h < .55 ? step(d, .4) : step(abs(d - .3), .12);
      cream = max(cream, step(d2 - d, .06) * 0.);
      return mix(vec3(.50, .44, .42), vec3(.88, .89, .64), cream); }`));
    const camo = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float a = fbm(p * .025), b = fbm(p * .03 + 7.);
      vec3 c = vec3(.55, .70, .52);
      c = mix(c, vec3(.36, .52, .40), step(.52, a));
      c = mix(c, vec3(.22, .36, .30), step(.6, b));
      c = mix(c, vec3(.62, .58, .40), step(.62, a) * step(b, .45));
      return c; }`));
    const dotsW = (path, x0, y0, x1, y1, n, seed, rmin, rmax) => clipped(path, () => { const r = rng(seed); for (let i = 0; i < n; i++) fill(circleP(x0 + r() * (x1 - x0), y0 + r() * (y1 - y0), rmin + r() * (rmax - rmin)), 'rgba(250,250,245,0.92)'); });

    // ════════ base: black board, grey paper at the left edge ════════
    fill(rrect(0, 0, 726, 1024, 0), '#0b0b0d');
    fill(P([[0, -2], [22, -2], [30, 52], [43, 92], [52, 96], [47, 140], [59, 197], [59, 294], [30, 360], [0, 409]], true, true), '#cfd1d6');
    fill(P([[59, 372], [37, 407], [22, 458], [22, 499], [33, 543], [46, 536], [39, 469], [59, 396]], true, true), '#cfd1d6');
    fill(rrect(0, 1008, 726, 16, 0), '#c8c8cc');
    // top-left orange speckled patch + lilac drips along the top
    card(P([[18, -4], [118, -4], [116, 38], [104, 58], [92, 80], [72, 76], [50, 70], [34, 60], [24, 30]]), '#f07446');
    clipped(P([[18, -4], [118, -4], [116, 38], [104, 58], [92, 80], [72, 76], [50, 70], [34, 60], [24, 30]]), () => { const r = rng(4); for (let i = 0; i < 200; i++) fill(circleP(18 + r() * 100, r() * 84, 0.8 + r() * 1.2), 'rgba(140,40,20,0.7)'); });
    const drip = []; for (let x = 118; x <= 420; x += 14) drip.push([x, 6 + (x % 28 ? 14 : 4)]);
    card(P([[118, -4], [420, -4], ...drip.reverse()], true, false), '#9a90b8', 0.6);
    // white stripes on the black board
    stroke(L([[140, 62], [116, 100], [108, 170], [116, 222], [114, 270], [108, 296]]), '#f4f4f2', 18);
    fill(P([[132, 280], [111, 280], [98, 310], [49, 383], [25, 443], [22, 498], [37, 552], [28, 562], [23, 593], [34, 619], [55, 637], [61, 632], [43, 544], [42, 447], [63, 387], [119, 316]]), '#f4f6f8');
    stroke(L([[44, 116], [50, 186], [64, 256], [52, 300], [42, 326]]), '#f4f4f2', 7);
    stroke(L([[124, 368], [98, 416], [84, 470], [90, 515], [112, 552]]), '#eef2f8', 15);
    stroke(L([[352, 108], [392, 92], [436, 86]]), '#f4f4f2', 16);
    stroke(L([[352, 186], [392, 162], [436, 166]]), '#f4f4f2', 14);
    stroke(L([[630, 150], [680, 126], [728, 108]]), '#f4f4f2', 18);
    stroke(L([[690, 214], [728, 190]]), '#f4f4f2', 16);
    // purple felt lumps lower-left
    card(P([[0, 620], [60, 640], [120, 700], [190, 730], [220, 780], [150, 800], [80, 790], [0, 800]]), '#8a50f4');
    card(P([[0, 880], [60, 870], [110, 900], [120, 960], [80, 1006], [0, 1006]]), '#8a50f4');
    card(P([[330, 900], [400, 900], [430, 960], [428, 1006], [330, 1006]]), '#5a1a4c', 0.6);
    card(P([[150, 740], [200, 736], [214, 770], [184, 786], [156, 760]]), '#7a40e0', 0.6);
    // camo patch
    card(P([[0, 700], [40, 690], [90, 720], [110, 790], [100, 870], [60, 900], [0, 900]]), camo, 0.7);

    // ════════ coral field + maroon figure ════════
    const coral = P([[112, 100], [140, 62], [200, 54], [290, 58], [352, 52], [362, 100], [352, 180], [370, 215], [425, 216], [474, 228], [490, 264], [473, 314], [478, 329], [534, 321], [554, 317], [560, 332], [558, 355], [583, 359], [579, 384], [598, 394], [602, 424], [577, 469], [460, 500], [400, 560], [330, 640], [366, 722], [303, 760], [244, 778], [215, 775], [185, 730], [150, 650], [130, 500], [115, 350], [108, 200]], true, false);
    card(coral, lin(100, 50, 600, 700, [[0, '#f08a7e'], [0.5, '#fa9282'], [1, '#fb8f7e']]));
    feltOver(coral);
    card(P([[148, 72], [228, 58], [232, 88], [214, 92], [200, 82], [190, 96], [176, 86], [166, 98], [152, 92]]), '#a8a0ae', 0.5);
    for (const [x, y] of [[226, 80], [212, 92], [194, 100], [176, 94], [160, 98]]) fill(circleP(x, y, 4), '#a8a0ae');
    const fig = P([[299, 95], [276, 130], [228, 126], [224, 158], [194, 166], [224, 192], [224, 200], [209, 212], [231, 224], [231, 235], [223, 236], [223, 251], [151, 276], [132, 293], [121, 331], [116, 389], [129, 446], [120, 481], [128, 504], [147, 524], [152, 523], [157, 466], [184, 420], [161, 388], [159, 367], [169, 352], [155, 318], [159, 303], [181, 291], [214, 314], [234, 298], [241, 284], [265, 288], [284, 347], [305, 363], [310, 374], [303, 392], [268, 389], [236, 404], [243, 430], [227, 461], [208, 463], [185, 455], [178, 466], [169, 514], [175, 602], [169, 652], [160, 658], [160, 677], [152, 686], [148, 708], [120, 709], [126, 723], [140, 732], [155, 728], [184, 733], [172, 703], [186, 686], [194, 686], [239, 580], [249, 522], [307, 468], [325, 435], [347, 441], [347, 433], [365, 423], [367, 368], [356, 330], [378, 328], [387, 307], [350, 292], [329, 298], [324, 287], [306, 286], [297, 277], [294, 257], [307, 226], [317, 218], [344, 216], [351, 210], [352, 184], [343, 183], [342, 174], [354, 164], [350, 152], [334, 152], [341, 120], [309, 128]], true, false);
    card(fig, '#532c44');
    // fill the figure's inner gaps (body is solid in the collage)
    card(P([[132, 300], [180, 290], [230, 300], [270, 300], [300, 380], [260, 400], [236, 420], [200, 460], [175, 470], [160, 520], [130, 500], [118, 420]]), '#532c44', 0);
    feltOver(fig, 0.3);
    fill(circleP(262, 455, 22), '#0b0b0d');
    fill(circleP(250, 488, 6), '#f4f4f4');

    // light cyan splash (under the pear)
    card(P([[656, 290], [690, 282], [726, 286], [726, 420], [690, 416], [660, 404], [648, 380], [664, 350], [654, 320]]), '#c0e0ec', 0.6);
    // ════════ pistachio pear ════════
    const pear = P([[410, 77], [400, 96], [405, 111], [454, 160], [495, 251], [527, 280], [546, 286], [551, 296], [600, 296], [628, 285], [667, 245], [676, 225], [677, 182], [659, 144], [637, 125], [594, 109], [510, 102], [439, 69]]);
    card(pear, rad(600, 160, 10, 220, [[0, '#d6ec90'], [0.6, '#c6dc80'], [1, '#a8b868']]), 1.3);
    feltOver(pear, 0.35);
    dotsW(pear, 400, 65, 680, 300, 260, 14, 1.6, 3.4);
    // orange gears
    const gear = (x, y, r0, r1, n) => { const pts = []; for (let i = 0; i < n * 2; i++) { const a = i / (n * 2) * Math.PI * 2; pts.push([x + Math.cos(a) * (i % 2 ? r0 : r1), y + Math.sin(a) * (i % 2 ? r0 : r1)]); } return P(pts, true, false); };
    card(gear(570, 76, 34, 44, 10), '#f0501a', 0.7);
    fill(circleP(570, 76, 14), '#f88a70');
    card(gear(598, 348, 46, 58, 8), '#f0601a', 0.7);

    // ════════ purple, teal, cream sheet ════════
    const purple = P([[365, 425], [358, 436], [381, 450], [390, 466], [389, 500], [372, 519], [348, 524], [363, 548], [358, 563], [343, 565], [325, 556], [309, 560], [302, 606], [309, 633], [331, 671], [364, 713], [394, 736], [404, 723], [409, 692], [391, 679], [390, 668], [439, 642], [442, 618], [459, 605], [415, 567], [415, 555], [447, 529], [448, 501], [419, 497], [419, 459], [407, 435]]);
    card(purple, '#8a50f5');
    feltOver(purple, 0.25);
    const teal = P([[576, 473], [451, 499], [452, 525], [442, 544], [456, 553], [457, 570], [434, 577], [427, 555], [419, 558], [418, 569], [463, 605], [477, 604], [479, 582], [498, 575], [505, 558], [504, 523], [531, 516], [545, 524]], true, false);
    card(teal, '#1ed8a4');
    card(P([[654, 562], [553, 605], [569, 646], [606, 629], [599, 619], [602, 600], [616, 600], [626, 618], [669, 594]], true, false), '#1ed8a4', 0.6);
    card(P([[506, 644], [496, 639], [452, 691], [412, 700], [409, 719], [429, 719], [483, 684], [492, 661], [512, 660]], true, false), '#1ed8a4', 0.6);
    const cream = P([[725, 380], [651, 380], [644, 394], [615, 400], [625, 432], [603, 437], [599, 419], [590, 466], [573, 471], [573, 487], [552, 518], [559, 536], [541, 532], [523, 550], [533, 573], [553, 584], [546, 596], [560, 593], [566, 581], [587, 584], [661, 554], [692, 529], [700, 550], [726, 548]], true, false);
    card(cream, '#fdf2d8');
    clipped(cream, () => {
      for (let i = 0; i < 9; i++) stroke(L([[600 + i * 4, 400 + i * 10], [640, 410 + i * 12], [680, 404 + i * 13], [726, 414 + i * 12]]), i % 2 ? '#f0b830' : '#f8d050', 3);
      const r = rng(31); for (let i = 0; i < 22; i++) { const x = 540 + r() * 186, y = 460 + r() * 140; fill(circleP(x, y, 6 + r() * 4), '#16161a'); fill(circleP(x - 1, y - 1, 2.5), '#3a3a40'); }
    });
    // light-blue splash
    fill(P([[650, 330], [680, 320], [700, 340], [680, 360], [654, 356]]), '#6a7c9a');
    card(P([[362, 52], [420, 56], [432, 80], [410, 100], [372, 96]]), '#f6600a', 0.5);

    // ════════ dark bars + big spiral disc ════════
    card(P([[364, 729], [313, 758], [285, 786], [312, 794], [363, 767]], true, false), '#b9c751', 0.5);
    card(P([[366, 740], [400, 730], [404, 780], [370, 784]], true, false), '#16a781', 0.4);
    card(P([[500, 600], [560, 585], [726, 588], [726, 720], [560, 730], [500, 720]], true, false), '#45464f');
    card(P([[466, 606], [500, 600], [504, 668], [470, 672]], true, false), '#121216', 0.5);
    card(P([[690, 656], [726, 650], [726, 724], [690, 724]], true, false), '#5a1a4c', 0.3);
    card(P([[300, 780], [470, 700], [520, 760], [420, 830], [320, 840]], true, false), '#26272d');
    card(P([[576, 612], [646, 600], [652, 636], [584, 650]], true, false), '#bcdcf4', 0.5);
    const disc = P(blob(550, 846, 168, 168, 77, 28, 0.025));
    card(disc, '#2a2a2e', 1.4);
    const bigS = rings(559.83, 850.39, 0.8402, 17.6834, 0.0698, -1.0256,
      `vec2 n = (p - vec2(550., 845.)) / 165.; float X = n.x, Y = n.y; float g = -0.0055*Y + 1.1368*X + 0.9206*Y*Y + 0.1033*X*Y - 0.3959*X*X + 0.0620*Y*Y*Y - 0.1606*X*Y*Y - 0.0728*X*X*Y - 0.9194*X*X*X;`,
      '.04, .04, .05', '.97, .97, .96');
    const discIn = P(blob(552, 846, 156, 156, 78, 28, 0.03));
    fill(discIn, bigS);
    fill(P(blob(556, 846, 18, 22, 9, 8, 0.2)), '#f8f0a0');

    // ════════ small spiral discs ════════
    const sdisc = (x, y, r, sp, rim) => { card(circleP(x, y, r + 8), rim); fill(circleP(x, y, r), sp); };
    sdisc(75, 585, 50, rings(75.53, 584.49, 1.032, 9.8169, 0.2092, 0.7645, '', '.04, .04, .05', '.96, .96, .95'), '#584a4e');
    sdisc(350, 481, 36, rings(351.52, 481.19, 0.9201, 11.4063, -0.4097, 0.7806, '', '.58, .56, .56', '.93, .93, .92'), '#3a3a40');
    sdisc(268, 708, 46, rings(268.47, 710.68, 0.9797, 7.5791, -0.7089, -1.1621, '', '.04, .04, .05', '.96, .96, .95'), '#202024');

    // ════════ little felt bits ════════
    const tri = (pts, c) => card(P(pts, true, false), c, 0.6);
    tri([[124, 130], [170, 106], [176, 156]], '#4a8ab8'); tri([[150, 210], [182, 200], [176, 254]], '#4a8ab8');
    tri([[470, 318], [500, 270], [526, 318]], '#2a3a4a');
    for (const [x, y, r] of [[425, 245, 22], [488, 362, 18], [520, 450, 17], [270, 545, 22], [242, 626, 17], [600, 40, 0]]) if (r) { card(circleP(x, y, r + 3), '#3a3a20', 0.5); fill(circleP(x, y, r), '#b8c050'); }
    for (const [x, y, r] of [[425, 374, 27], [420, 304, 13], [462, 432, 13], [265, 80, 13], [560, 380, 15]]) { card(circleP(x, y, r + 3), '#1a1a20', 0.5); fill(circleP(x, y, r), '#4c7290'); }
    for (const [x, y, r] of [[440, 560, 15], [610, 610, 12], [472, 536, 10], [608, 600, 0]]) if (r) card(circleP(x, y, r), '#f8c828', 0.4);
    card(P([[300, 220], [330, 214], [356, 226], [358, 252], [338, 270], [314, 266], [300, 250]]), '#f0f0b8', 0.6);
    fill(circleP(320, 258, 12), '#1a1a20');
    card(P([[164, 312], [236, 296], [256, 330], [300, 316], [306, 366], [280, 372], [240, 376], [206, 382], [170, 372]], true, false), '#c4d4e4', 0.8);
    fill(circleP(184, 322, 9), '#2a2a30');
    card(P([[234, 290], [262, 292], [306, 360], [290, 380], [262, 370]], true, false), '#f0f0f2', 0.6);
    card(rrect(188, 410, 40, 34, 4), '#d47840', 0.5);
    card(rrect(108, 650, 40, 36, 4), '#d47840', 0.5);
    // purple comb + zebra fan
    clipped(P([[370, 610], [430, 600], [470, 650], [440, 690], [390, 690]]), () => { for (let x = 370; x < 470; x += 8) stroke(L([[x, 600], [x + 20, 700]]), '#f4f4f4', 3); });
    // grey rods
    for (const [p0, p1] of [[[166, 470], [58, 870]]]) { const p = L([p0, p1]); o.save(); o.filter = `blur(${3 * S}px)`; o.translate(3, 4); stroke(p, 'rgba(0,0,0,0.5)', 22); o.restore(); stroke(p, '#a8b0c0', 22); stroke(p, '#d8e0ec', 6); }

    // ════════ polka ball + ropes ════════
    const ball = circleP(228, 895, 122);
    card(ball, polka, 1.4);
    clipped(ball, () => fill(ball, rad(190, 840, 20, 150, [[0, 'rgba(255,255,255,0.15)'], [0.6, 'rgba(0,0,0,0)'], [1, 'rgba(30,10,30,0.45)']])));
    card(P([[202, 872], [236, 864], [244, 900], [214, 912]], true, false), '#d07840', 0.5);
    ropeL([[96, 408], [70, 470], [56, 540], [62, 610], [84, 680], [120, 750], [160, 810], [210, 860]]);
    ropeL([[168, 412], [152, 480], [150, 560], [146, 640], [138, 700], [120, 760]]);
    ropeL([[0, 818], [40, 840], [70, 880], [90, 930], [118, 980], [150, 1012]]);
    ropeL([[40, 900], [30, 960], [56, 1000]]);

    // ════════ top-right bits ════════
    card(rrect(468, -6, 34, 70, 4), '#3a3a40', 0.6);
    card(circleP(608, 18, 30), '#2a2a2e', 0.6); stroke(circleP(608, 18, 18), '#d8d8dc', 6); fill(circleP(608, 18, 8), '#1a1a1e');
    card(rrect(640, -4, 60, 26, 6), '#3a3a40', 0.5);
    for (const [x, c] of [[648, '#f8e040'], [658, '#4a8ae0'], [668, '#f0f0f0'], [678, '#e04040']]) fill(rrect(x, -2, 8, 22, 2), c);
    card(rrect(684, 64, 42, 64, 4), '#f0d030', 0.6);
    card(rrect(690, 168, 36, 40, 4), '#e8e8ec', 0.5);

    E.grain(0.06, 114);
  }
});
