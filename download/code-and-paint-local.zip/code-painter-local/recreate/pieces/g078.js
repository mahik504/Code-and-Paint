'use strict';
// g078 — "Pink sea-monster tentacles": a salmon-pink beast with a fat red lip and a teal eye trails periwinkle
// tentacles studded with orange beads and zebra streamers from a lilac anemone, by a grey brushed slab and a cyan sky.
REC.register('g078', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    keep();
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st) => { const g = a.createRadialGradient(x, y, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const F = (path, c) => { a.fillStyle = c; a.fill(path); };
    const K = (path, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.stroke(path); };
    const qpt = (p0, p1, p2, t) => [(1 - t) * (1 - t) * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0], (1 - t) * (1 - t) * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]];
    const qpath = (p0, p1, p2, n = 24) => { const pts = []; for (let i = 0; i <= n; i++) pts.push(qpt(p0, p1, p2, i / n)); return pts; };

    // ── textures ──
    const zebraTop = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float x = p.x + 14.3 * sin(p.y * 0.029 + p.x * 0.0101 + 3.343) - 1.57 * sin(p.y * 0.0732 + 2.022);
      float f = fract(x / 45.71 + 0.0108);
      return mix(vec3(.02), vec3(.98,.98,.96), smoothstep(0.49, 0.53, f) * smoothstep(1.0, 0.97, f)); }`));
    const greyTex = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float s = fbm(vec2(p.x * 0.09, p.y * 0.006)) ;
      float s2 = vnoise(vec2(p.x * 0.5, p.y * 0.01));
      vec3 c = mix(vec3(.38,.46,.57), vec3(.58,.66,.75), smoothstep(0.35, 0.75, s));
      c = mix(c, vec3(.62,.70,.78), smoothstep(0.75, 0.95, s2) * 0.5);
      c = mix(c, vec3(.60,.68,.76), smoothstep(200., 20., p.y) * 0.6 * smoothstep(640., 520., p.x));
      c *= 0.82 + 0.12 * hash(floor(p * 1.3));
      return c; }`));
    const skyTex = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = mix(vec3(.05,.55,.98), vec3(.35,.80,.98), smoothstep(30., 330., p.y));
      c = mix(c, vec3(.60,.96,.97), smoothstep(330., 620., p.y));
      float beam = smoothstep(14., 0., abs((p.x - 610.) * 0.83 + (p.y - 700.) * 0.55));
      c = mix(c, vec3(.98,.98,.80), beam * 0.7 * smoothstep(480., 560., p.y));
      return c; }`));
    const zRays = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(1269., -504.); float L = length(d);
      float an = atan(d.x, -d.y) + 0.0051 * sin(L * 0.018 + p.x * 0.01);
      float f = fract(an / 0.0195 + 0.7158);
      float w = smoothstep(0.54, 0.585, f) * smoothstep(1.0, 0.965, f);
      float pos = clamp((f - 0.563) / 0.437, 0., 1.);
      vec3 wc = mix(vec3(.62,.70,.86), vec3(.96,.97,.99), pow(sin(3.1416 * pos), 0.6));
      return mix(vec3(.02,.02,.025), wc, w); }`));
    const skinSpeck = (base1, base2, x0, y0, x1, y1) => lin(x0, y0, x1, y1, [[0, base1], [1, base2]]);

    // ── black ground + sky ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#040405', 0, 0);
    const SKY = P([[630, 22], [736, 22], [736, 690], [600, 690], [612, 520], [630, 300]], true, false);
    F(SKY, skyTex);
    F(P([[600, 650], [630, 638], [660, 630], [690, 634], [726, 628], [726, 672], [600, 672]], true, false), '#8682d0');
    F(P([[600, 660], [640, 652], [690, 655], [726, 650], [726, 672], [600, 672]], true, false), '#c08cb4');
    F(rrect(600, 670, 126, 20, 0), lin(0, 670, 0, 690, [[0, '#2a7ee8'], [1, '#4a9af4']]));
    { const q = rng(78); for (let i = 0; i < 26; i++) F(circleP(300 + q() * 426, 20 + q() * 1000, 0.8 + q() * 1.6), '#f4f4f4'); }

    // ── grey brushed slab ──
    const GREY = P([[500, 22], [640, 22], [640, 290], [630, 420], [614, 560], [606, 700], [600, 800], [590, 850], [560, 900], [500, 940], [420, 960], [400, 600], [400, 110]], true, false);
    R.flat(GREY, greyTex, 0.02, 0);
    { const q = rng(5);
      clipA(GREY, () => { for (let i = 0; i < 60; i++) { const x = 400 + q() * 230, y = 30 + q() * 400, L = 40 + q() * 120;
        K(P([[x, y], [x + (q() - 0.5) * 8, y + L]], false), q() < 0.5 ? 'rgba(170,186,204,0.55)' : 'rgba(70,86,110,0.5)', 1.5 + q() * 3); } });
      for (let y = 30; y < 700; y += 6) { const xr = y < 290 ? 640 : 640 - (y - 290) * 0.08; K(P([[xr - 2, y], [xr - 14 - q() * 12, y + (q() - 0.5) * 3]], false), 'rgba(230,236,240,0.7)', 1); }
    }
    // ragged left top edge of the slab (navy shadow beneath)
    F(P(ragged([[500, 22], [400, 110], [400, 140], [470, 70], [520, 22]], 0, 1, 8, 16, 3), true, false), greyTex);

    // ── zebra field top-left, yellow wedge, navy band ──
    const ZT = P([[0, 20], [292, 20], [292, 120], [240, 150], [180, 180], [130, 205], [0, 125]], true, false);
    F(ZT, zebraTop);
    F(P([[292, 20], [500, 20], [400, 110], [330, 120], [292, 120]], true, false), '#030305');
    const NAVY = P([[128, 232], [190, 200], [260, 160], [330, 122], [400, 108], [470, 70], [520, 22], [520, 60], [470, 130], [420, 170], [300, 230], [200, 250]], true, false);
    F(NAVY, lin(130, 230, 500, 40, [[0, '#1a2c56'], [1, '#22355e']]));
    R.dome(P([[0, 125], [60, 158], [130, 205], [152, 232], [80, 222], [0, 214]], true, false), lin(0, 130, 150, 230, [[0, '#d8bc38'], [1, '#b89a28']]), 0.04, 0.05, 10, 2);
    R.dome(P([[330, 112], [334, 92], [344, 66], [350, 92], [356, 110]], true), '#8e9ae8', 0.06, 0.06, 6, 3);
    R.bead(343, 105, 10, '#9aa4ec', 0.06, 0.06, 3);
    keep();

    // ── pink lower body (behind the zebra streamers) ──
    const BODY = P([[440, 600], [470, 575], [540, 566], [590, 590], [606, 680], [600, 800], [585, 860], [560, 910], [520, 970], [480, 1034], [370, 1034], [390, 920], [420, 800], [440, 700]]);
    R.dome(BODY, lin(420, 580, 560, 1030, [[0, '#b07a7c'], [0.3, '#d08880'], [0.6, '#cc7a72'], [0.8, '#b85a56'], [1, '#8a2a28']]), 0.04, 0.1, 50, 1);
    // grey bristles over the body
    const BR = [[420, 960], [420, 800], [440, 790], [452, 760], [470, 775], [482, 740], [495, 768], [508, 735], [520, 760], [535, 722], [548, 752], [560, 716], [575, 742], [590, 712], [606, 700], [600, 800], [590, 850], [560, 900], [520, 920], [480, 930], [440, 960]];
    F(P(ragged(BR, 0, 15, 5, 14, 9), true, false), greyTex);
    F(P(ragged([[380, 1034], [390, 960], [460, 935], [520, 925], [570, 880], [600, 840], [600, 900], [560, 960], [500, 1034]], 1, 5, 5, 10, 2), true, false), lin(0, 900, 0, 1034, [[0, '#c85450'], [1, '#801e1e']]));

    // ── head: cranium, red face, eye, lip tube, teeth ──
    const FACE = P([[0, 214], [80, 222], [152, 232], [200, 250], [235, 240], [250, 300], [300, 360], [470, 430], [470, 520], [300, 520], [0, 520]], true, false);
    R.dome(FACE, lin(0, 220, 300, 500, [[0, '#ec6a6c'], [0.6, '#e45c60'], [1, '#d85458']]), 0.06, 0.1, 40, 1);
    const CRAN = P([[238, 178], [270, 140], [320, 122], [380, 120], [430, 138], [470, 180], [492, 240], [500, 300], [500, 350], [470, 360], [400, 352], [320, 345], [276, 330], [252, 300], [240, 250]]);
    R.dome(CRAN, rad(360, 230, 210, [[0, '#e8b4a0'], [0.6, '#e4a894'], [1, '#de9282']]), 0.08, 0.2, 70, 1);
    { const q = rng(12); clipA(CRAN, () => { for (let i = 0; i < 120; i++) F(circleP(250 + q() * 250, 130 + q() * 220, 0.6 + q() * q() * 2.2), '#2a1414'); }); }
    { const q = rng(13); for (let i = 0; i < 40; i++) F(circleP(20 + q() * 200, 260 + q() * 140, 0.6 + q() * q() * 3.5), '#1a0808'); }
    // teeth
    clipA(P([[0, 214], [80, 222], [152, 232], [110, 244], [50, 250], [0, 250]], true, false), () => {
      F(rrect(0, 210, 160, 60, 0), '#d8d2c8');
      for (let x = 4; x < 150; x += 9) K(P([[x, 214], [x + 3, 262]], false), '#2a2020', 2.5);
    });
    R.dome(P([[0, 262], [40, 270], [70, 300], [60, 320], [20, 330], [0, 330]]), '#f07070', 0.08, 0.06, 14, 1);
    // eye
    R.dome(ellipseP(181, 318, 25, 21, 0), '#f6e8e0', 0.14, 0.05, 8, 2);
    R.dome(circleP(184, 318, 15), rad(184, 318, 15, [[0, '#103030'], [0.35, '#1a6a6a'], [0.75, '#48a8a8'], [1, '#1a4a4a']]), 0.18, 0.03, 6, 2);
    R.dome(circleP(184, 318, 6), '#060808', 0.2, 0.02, 3, 2);
    F(circleP(190, 311, 6), '#ffffff'); F(circleP(181, 324, 2.5), '#ffffff');
    K(P([[156, 312], [168, 298], [190, 296], [206, 306]], false), '#a03838', 3);
    // fat red lip tube
    soft(x => { x.fillStyle = 'rgba(60,10,12,0.9)'; x.fill(ellipseP(380, 452, 120, 20, -0.05)); }, 8, 1);
    const LIP = P([[230, 330], [300, 352], [380, 348], [450, 342], [520, 346], [552, 362], [556, 392], [536, 410], [480, 420], [420, 430], [360, 440], [300, 436], [250, 420], [226, 380]]);
    R.dome(LIP, lin(0, 340, 0, 440, [[0, '#f06a68'], [0.5, '#e45a5a'], [1, '#c84446']]), 0.14, 0.2, 40, 1);
    R.groove(circleP(237, 408, 13), 10, '#3a1818', 0.2, 0.1, 1);
    F(circleP(237, 409, 9), '#2a3c66');
    keep();

    // ── periwinkle tentacles (lower ones tuck under the zebra streamers) ──
    const ends = [325, 372, 420, 466, 512, 558, 604, 650, 698, 748, 798, 848, 896, 944, 992, 1040];
    const curves = [];
    ends.forEach((Ly, i) => {
      const Fp = [478 + (i % 3) * 8, 505 + i * 2];
      curves.push([[-30, Ly], [(Fp[0] - 30) / 2, (Ly + Fp[1]) / 2 + 40 - Math.max(0, Ly - 600) * 0.12], Fp]);
    });
    const wob = (p0, p1, p2, i, dy = 0) => { const pts = []; for (let k = 0; k <= 30; k++) { const t = k / 30, A = qpt(p0, p1, p2, t), B = qpt(p0, p1, p2, Math.min(1, t + 0.01));
        const dx = B[0] - A[0], dyy = B[1] - A[1], L = Math.hypot(dx, dyy) || 1, w = 7 * Math.sin(t * 9 + i * 1.7) * (1 - t);
        pts.push([A[0] - dyy / L * w, A[1] + dx / L * w + dy]); } return pts; };
    const drawT = (from, to) => {
      soft(x => { x.strokeStyle = 'rgba(0,0,0,0.95)'; x.lineWidth = 34; for (let i = from; i < to; i++) { const [p0, p1, p2] = curves[i]; x.stroke(P(wob(p0, p1, p2, i, 7), false)); } }, 4, 1);
      for (let i = from; i < to; i++) { const [p0, p1, p2] = curves[i]; R.pipe(P(wob(p0, p1, p2, i), false), 26 - (i % 3) * 2, '#5a96f2', 0.08 + 0.002 * i, 0.12, 3); }
      soft(x => { x.strokeStyle = 'rgba(150,200,255,0.4)'; x.lineWidth = 4; for (let i = from; i < to; i++) { const [p0, p1, p2] = curves[i]; x.stroke(P(wob(p0, p1, p2, i, -7), false)); } }, 2, 1);
    };
    drawT(7, curves.length);
    keep();
    // ── zebra streamers ──
    const ZB = P([[330, 560], [470, 490], [560, 560], [470, 600], [440, 700], [420, 800], [400, 900], [370, 1034], [70, 1034], [110, 900], [170, 780], [240, 680]], true, false);
    soft(x => { x.fillStyle = 'rgba(0,0,0,0.8)'; x.fill(ZB); }, 6, 1);
    R.flat(ZB, zRays, 0.04, 0);
    keep();
    drawT(0, 7);
    // white text runs on the tentacles
    a.save(); a.fillStyle = 'rgba(240,244,255,0.9)'; a.font = '600 12px monospace';
    const words = ['Iraow fyriicah', 'Towerdi godad', 'Beautify Jeric', 'Sericatt', 'Singraet Piccer', 'aafte', 'Cartom Liedrg Xirdi Chils', 'C ulro aeol', 'ehre', 'elngral Lxolt', 'inattaard', 'Ssmiras'];
    [[0, 0.12], [1, 0.3], [3, 0.08], [4, 0.25], [5, 0.3], [6, 0.05], [7, 0.1], [8, 0.3], [10, 0.05], [11, 0.1], [12, 0.08], [13, 0.2]].forEach(([ci, t], k) => {
      const [p0, p1, p2] = curves[ci], A = qpt(p0, p1, p2, t), B = qpt(p0, p1, p2, t + 0.02);
      a.save(); a.translate(A[0], A[1] + 4); a.rotate(Math.atan2(B[1] - A[1], B[0] - A[0])); a.fillText(words[k % words.length], 0, 0); a.restore();
    });
    a.restore();
    keep();

    // ── lilac anemone with antennae ──
    R.pipe(P([[612, 420], [640, 380], [664, 340], [690, 300], [726, 266]], false), 22, '#a4acec', 0.14, 0.12, 3);
    R.pipe(P([[630, 440], [660, 420], [690, 400], [726, 388]], false), 14, '#a4acec', 0.14, 0.1, 3);
    for (let k = 0; k < 18; k++) { const t = k / 18; const x = 615 + t * 105, y = 415 - t * 145; R.groove(P([[x - 7, y - 6], [x + 7, y + 6]], false), 3, '#7a82c8', 0.25, 0.04, 3, 0.8); }
    const FAN = P([[470, 480], [520, 420], [565, 410], [600, 420], [580, 520], [560, 560], [520, 590], [470, 560]]);
    R.dome(FAN, lin(470, 420, 600, 590, [[0, '#f0c8e4'], [0.5, '#c8b8ec'], [1, '#a4a8e8']]), 0.12, 0.08, 20, 3);
    for (let k = 0; k < 14; k++) { const an = Math.PI * (0.8 + k * 0.045); R.groove(P([[595 + Math.cos(an) * 30, 470 + Math.sin(an) * 30], [595 + Math.cos(an) * 120, 470 + Math.sin(an) * 110]], false), 4, '#9a90d0', 0.2, 0.04, 3, 0.6); }
    R.dome(circleP(595, 468, 50), rad(585, 455, 60, [[0, '#e0e2fa'], [0.7, '#b8bcf0'], [1, '#9498dc']]), 0.18, 0.16, 26, 3);
    R.pipe(P([[570, 455], [580, 440], [600, 438], [612, 452], [604, 470], [586, 470], [584, 458], [596, 454]], false), 6, '#c8ccf6', 0.32, 0.04, 3);
    for (const [x, y, x2, y2] of [[540, 560, 548, 610], [565, 560, 578, 640], [590, 545, 600, 590]]) R.pipe(P([[x, y], [(x + x2) / 2 + 6, (y + y2) / 2], [x2, y2]], false), 12, '#b8bcf0', 0.14, 0.08, 3);
    keep();

    // ── orange beads ──
    const bead = (x, y, r) => { R.bead(x, y, r, rad(x - r * 0.3, y - r * 0.3, r * 1.3, [[0, '#ffb070'], [0.4, '#ff6224'], [1, '#e04010']]), 0.2, 0.06, 4);
      soft(z => { z.fillStyle = 'rgba(255,110,40,0.6)'; z.fill(circleP(x + r * 0.5, y + r * 0.3, r * 1.1)); }, 4, 0.6); };
    { const q = rng(21);
      curves.forEach(([p0, p1, p2], i) => { const n = 2 + Math.floor(q() * 3); for (let k = 0; k < n; k++) { const t = 0.05 + q() * 0.8; const [x, y] = qpt(p0, p1, p2, t); bead(x + (q() - 0.5) * 6, y - 4, 8 + q() * 6); } });
      for (let k = 0; k < 14; k++) { const yy = 580 + q() * 440; bead(140 + (yy - 580) * -0.1 + q() * 220, yy, 8 + q() * 6); }
    }
    for (const [x, y, r] of [[600, 440, 6], [612, 452, 7], [622, 462, 6], [606, 466, 6], [590, 478, 7], [610, 482, 6], [576, 494, 8], [596, 498, 6], [460, 470, 7], [455, 485, 8], [500, 505, 7], [520, 568, 9], [540, 580, 8], [455, 553, 10], [600, 803, 9], [595, 820, 10], [430, 545, 8]]) bead(x, y, r);
    keep();

    // ── black & white dots ──
    const dot = (x, y, r, lit) => { R.dome(circleP(x, y, r), lit ? rad(x + r * 0.4, y + r * 0.4, r * 1.2, [[0, '#ffffff'], [0.5, '#e8e8ea'], [0.62, '#0a0a0c'], [1, '#040405']]) : '#040406', 0.1, 0.08, r * 0.6, lit ? 2 : 0); };
    dot(665, 553, 15, false); dot(705, 366, 14, false); dot(600, 553, 16, false); dot(597, 638, 17, true); dot(643, 701, 18, true); dot(586, 703, 18, true);
    dot(500, 722, 18, false); dot(456, 666, 17, false); dot(456, 880, 20, true);
    F(circleP(600, 553, 10), '#14306a');

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.9, spec: 0.5, shin: 30, wrap: 0.6, ao: 0.4, grain: 0.12, emis: 0.2 }),                    // 1 skin
        E.mat({ dif: 0.85, spec: 1.3, shin: 90, wrap: 0.4, ao: 0.4, coat: 0.2, emis: 0.18 }),                    // 2 glossy
        E.mat({ dif: 0.9, spec: 0.8, shin: 50, wrap: 0.6, ao: 0.4, emis: 0.18 }),                                // 3 soft plastic
        E.mat({ dif: 0.8, spec: 1.2, shin: 60, wrap: 0.5, ao: 0.3, emis: 0.35 })                                 // 4 orange beads
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.95, 0.94, 0.94], amb: [0.32, 0.32, 0.36],
      envTop: [1.0, 1.0, 1.05], envHor: [0.5, 0.5, 0.58], envBot: [0.1, 0.1, 0.14], envK: [0.3, 1.0, 0.3, 0],
      rimC: [0.08, 0.08, 0.12], rimD: [0, 1, 0], r1: 1.3, r2: 6, k: [0, 0.6, 0.4, 70], shadow: [-4, 6, 0.5, 7]
    });
    E.bloom(0.05, 6);
    E.grain(0.04, 78);
  }
});
