'use strict';
// s13 — "Bubblegum blob on the op-art slope": a glossy grey blob-creature with a pink bubblegum
// head and a sooty halftone belly slides past a rainbow arc; zebra stripes, a halftone wave,
// a zebra-swirl critter, a grey window and a green rock float on a flat cobalt ground.
REC.register('s13', {
  w: 1024, h: 580,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const W = 1024, H = 580;
    const soft = (fn, blur, alpha = 1, op = 'source-over', clip = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clip) a.clip(clip); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fillE = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const texIn = (path, cv, alpha = 1) => { a.save(); a.clip(path); a.globalAlpha = alpha; a.drawImage(cv, 0, 0, W, H); a.restore(); };
    const full = rrect(-10, -10, W + 20, H + 20, 0);
    // blend a polyline between two polylines (same point count)
    const lerpPts = (A, B, t) => A.map((p, i) => [p[0] + (B[i][0] - p[0]) * t, p[1] + (B[i][1] - p[1]) * t]);

    // ── grounds: black left, cobalt right, starry strip at top ──
    R.flat(full, '#0a0a0a', 0, 0);
    const blue = P([[300, -10], [1034, -10], [1034, 460], [380, 460], [340, 200]], true, false);
    const blueT = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        float n = fbm(px * 0.03), g = hash(floor(px * 0.5));
        vec3 c = vec3(0.14, 0.28, 0.83) * (0.92 + 0.1 * n + 0.06 * g);
        float sp = step(0.72, hash(floor(px / 3.0))) * smoothstep(120.0, 0.0, length((px - vec2(960.0, 30.0)) * vec2(0.7, 1.0)));
        return mix(c, vec3(0.9, 0.92, 1.0), sp * 0.8);
      }`);
    R.paint(blue, '#2448d4'); texIn(blue, blueT);
    const stars = P([[290, -10], [560, -10], [540, 40], [480, 70], [420, 90], [340, 100], [300, 60]]);
    R.paint(stars, '#050608');
    { const r = rng(4); a.save(); a.clip(stars); for (let i = 0; i < 90; i++) { a.fillStyle = '#f4f4f4'; a.fill(circleP(290 + r() * 270, r() * 100, 0.8 + r() * r() * 5)); } a.restore(); }
    // window strip + thin line
    a.fillStyle = '#10141c'; a.fillRect(448, 0, 350, 22);
    for (let i = 0; i < 5; i++) { a.fillStyle = '#2a50d0'; a.fillRect(452 + i * 69, 0, 62, 17); }
    { const r = rng(9); for (let i = 0; i < 120; i++) { a.fillStyle = 'rgba(200,210,255,0.8)'; a.fillRect(452 + r() * 340, r() * 17, 1.5, 1.5); } }
    a.fillStyle = '#10141c'; a.fillRect(795, 0, 3, 105);
    // white dots on the black
    for (const [x, y, r] of [[35, 22, 30], [20, 106, 8], [10, 232, 8], [26, 516, 3], [668, 288, 4], [668, 344, 4], [1002, 272, 5]]) R.paint(circleP(x, y, r), '#f8f8f8');
    // brick strip, far left
    R.paint(rrect(-5, 370, 22, 100, 0), '#6a2a1c');
    a.strokeStyle = '#3a1810'; a.lineWidth = 2; for (let y = 378; y < 470; y += 12) { a.beginPath(); a.moveTo(0, y); a.lineTo(17, y); a.stroke(); }

    // ── zebra stripes, bottom-left ──
    const zeb = P([[10, 300], [120, 280], [260, 400], [420, 420], [430, 590], [0, 590], [0, 360]], true, false);
    a.save(); a.clip(zeb); a.fillStyle = '#f4f4f4'; a.fillRect(0, 280, 440, 310);
    a.strokeStyle = '#080808'; a.lineWidth = 26;
    for (let i = -12; i < 14; i++) { a.beginPath(); a.moveTo(i * 58 - 60, 260); a.bezierCurveTo(i * 58 + 20, 360, i * 58 + 60, 460, i * 58 + 140, 600); a.stroke(); }
    a.restore();

    // ── rainbow arc ──
    const inner = [[262, -20], [262, 50], [290, 120], [340, 170], [400, 210], [450, 250]];
    const outer = [[78, -20], [80, 50], [100, 110], [150, 150], [260, 190], [380, 250]];
    const cols = ['#1a5ae8', '#1a6ef0', '#28b8f0', '#40c060', '#f0e020', '#f89020', '#f03a20'];
    cols.forEach((c, i) => { const t0 = i / cols.length, pts = lerpPts(outer, inner, t0 + 0.5 / cols.length); a.save(); a.strokeStyle = c; a.lineWidth = 190 / cols.length + 6; a.lineCap = 'butt'; a.stroke(P(pts, false)); a.restore(); });
    a.save(); a.strokeStyle = '#f070b0'; a.lineWidth = 5; a.stroke(P(lerpPts(outer, inner, 1.02), false)); a.restore();
    // iridescent halftone ribbon from the top
    const rib = P([[340, -10], [390, -10], [400, 60], [430, 130], [470, 190], [500, 230], [470, 250], [430, 200], [390, 150], [360, 80]]);
    const ribT = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        vec3 c = iri(px.y * 0.004 + px.x * 0.006 + 0.3) * 0.8 + 0.2;
        float d = step(0.5, hash(floor(px / 3.0)));
        return mix(c, vec3(0.9), d * 0.35);
      }`);
    texIn(rib, ribT);

    // ── halftone wave ──
    const waveTop = [[380, 330], [470, 360], [560, 395], [640, 390], [720, 370], [800, 368], [880, 380], [960, 410], [1034, 440]];
    const wave = P([...waveTop, [1034, 540], [900, 545], [700, 550], [520, 560], [400, 560]], true, true);
    const waveT = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        vec2 f = fract(px / 5.0) - 0.5;
        float stripe = 0.5 + 0.5 * sin((px.x * 0.55 - px.y * 0.9 + 25.0 * fbm(px * 0.01)) * 0.07);
        float r = mix(0.18, 0.46, stripe);
        float dot1 = step(length(f), r);
        return mix(vec3(0.86, 0.86, 0.84), vec3(0.06), dot1);
      }`);
    texIn(wave, waveT);
    const pinkT = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        float d = length(fract(px / 5.0) - 0.5), r = 0.22 + 0.2 * fbm(px * 0.03);
        return mix(vec3(0.96, 0.64, 0.64), vec3(0.62, 0.22, 0.26), step(d, r));
      }`);
    // pink halftone band under the rim, right part
    const pinkBand = P([...waveTop.slice(3), [1034, 520], [960, 480], [880, 450], [800, 440], [720, 450], [640, 455]], true, true);
    texIn(pinkBand, pinkT);
    // zebra stripes in the lower-left of the wave + black foot
    const zw = P([[380, 330], [470, 380], [560, 420], [600, 470], [640, 520], [700, 560], [380, 590]], true, true);
    a.save(); a.clip(wave); a.clip(zw); a.fillStyle = '#f0f0f0'; a.fillRect(370, 320, 340, 280); a.strokeStyle = '#080808'; a.lineWidth = 16;
    for (let i = 0; i < 12; i++) { a.beginPath(); a.moveTo(360, 360 + i * 24); a.bezierCurveTo(450, 380 + i * 24, 520, 420 + i * 22, 720, 470 + i * 20); a.stroke(); } a.restore();
    // cyan/green rim along its top edge + magenta foot
    a.save(); a.lineWidth = 14; a.strokeStyle = '#3cc8c0'; a.stroke(P(waveTop.slice(2), false)); a.lineWidth = 5; a.strokeStyle = '#e050c0'; a.stroke(P(waveTop.slice(0, 4), false)); a.restore();
    R.paint(P([[640, 575], [800, 556], [900, 548], [1034, 545], [1034, 590], [640, 590]], true, false), '#060606');
    a.save(); a.strokeStyle = '#e02880'; a.lineWidth = 6; a.stroke(P([[880, 562], [960, 559], [1034, 557]], false)); a.restore();

    // ── zebra-swirl critter ──
    const zc = P([[430, 245], [455, 222], [500, 212], [540, 222], [565, 238], [600, 232], [620, 250], [600, 275], [575, 300], [545, 318], [505, 312], [480, 290], [450, 272]]);
    const arms = [[[575, 240], [600, 215], [615, 195], [630, 180]], [[590, 250], [620, 232], [650, 218], [668, 198]], [[600, 262], [635, 262], [665, 256], [688, 248]], [[595, 280], [630, 290], [660, 292]], [[570, 300], [600, 318], [625, 330]], [[520, 225], [528, 200], [520, 185]]];
    a.save(); a.lineJoin = a.lineCap = 'round'; a.strokeStyle = '#e06ab0'; a.lineWidth = 8; a.stroke(zc); a.lineWidth = 22; for (const t of arms) a.stroke(P(t, false));
    a.fillStyle = '#f2f2f2'; a.fill(zc); a.strokeStyle = '#f2f2f2'; a.lineWidth = 16; for (const t of arms) a.stroke(P(t, false));
    a.strokeStyle = '#0a0a0a'; a.lineWidth = 3; for (const t of arms) a.stroke(P(t, false));
    a.save(); a.clip(zc); for (let k = 0; k < 14; k++) { a.beginPath(); a.moveTo(430, 230 + k * 7); a.bezierCurveTo(480, 200 + k * 9, 540, 250 + k * 5, 620, 225 + k * 6); a.stroke(); } a.restore();
    a.restore();

    // ── grey window ──
    R.paint(rrect(688, 248, 150, 104, 2), '#101418');
    R.paint(rrect(692, 252, 142, 96, 1), '#808080');

    // ── rock + green iridescent blob + paper scraps ──
    const rock = P([[870, 300], [885, 272], [920, 262], [960, 268], [990, 290], [980, 320], [930, 322]]);
    R.dome(rock, '#b0a8a0', 0.1, 0.08, 16, 2);
    const green = P([[900, 320], [960, 290], [1034, 280], [1034, 380], [980, 385], [930, 360]]);
    const gT = E.fx(`vec3 fx(vec2 uv, vec2 px){ return mix(vec3(0.35, 0.85, 0.55), vec3(0.95, 0.75, 0.35), fbm(px * 0.02)) * (0.8 + 0.3 * step(0.5, hash(floor(px / 3.0)))); }`);
    R.dome(green, '#60c880', 0.1, 0.06, 16, 3); texIn(green, gT);
    a.save(); a.strokeStyle = '#f4f4f4'; a.lineWidth = 6; for (let i = 0; i < 5; i++) { a.beginPath(); a.moveTo(840 + i * 6, 320 + i * 12); a.bezierCurveTo(880, 330 + i * 12, 930, 340 + i * 10, 1000, 350 + i * 10); a.stroke(); }
    a.strokeStyle = '#0a0a0a'; a.lineWidth = 3; for (let i = 0; i < 5; i++) { a.beginPath(); a.moveTo(840 + i * 6, 326 + i * 12); a.bezierCurveTo(880, 336 + i * 12, 930, 346 + i * 10, 1000, 356 + i * 10); a.stroke(); } a.restore();

    // ── the grey blob creature ──
    const blobP = P([[130, 150], [170, 120], [230, 112], [280, 125], [310, 150], [360, 175], [420, 225], [440, 290], [400, 330], [380, 380], [390, 440], [420, 490], [440, 540], [410, 556], [330, 550], [270, 520],
      [220, 510], [170, 500], [120, 520], [100, 470], [140, 420], [150, 360], [130, 300], [120, 240]]);
    a.save(); a.lineJoin = 'round'; a.lineWidth = 10; a.strokeStyle = '#d06ad8'; a.stroke(blobP); a.lineWidth = 4; a.strokeStyle = '#f0e040'; a.stroke(blobP); a.restore();
    R.dome(blobP, '#b8b6b4', 0.2, 0.15, 30, 1);
    // sooty halftone belly
    soft(x => { x.fillStyle = '#140c08'; x.fill(P([[200, 310], [260, 285], [330, 262], [400, 250], [440, 300], [420, 380], [380, 450], [330, 515], [260, 520], [180, 505], [130, 480], [165, 420], [220, 385], [215, 340]])); }, 20, 0.95, 'source-over', blobP);
    { const r = rng(8); a.save(); a.clip(blobP); for (let i = 0; i < 1800; i++) { const x = 120 + r() * 320, y = 240 + r() * 300; a.fillStyle = 'rgba(20,12,8,0.7)'; a.fillRect(x, y, 1.8, 1.8); } a.restore(); }
    // white gloss dashes
    for (const [x0, y0, x1, y1] of [[190, 128, 230, 124], [362, 196, 392, 216], [150, 316, 158, 330], [150, 384, 146, 398], [150, 452, 142, 466], [248, 480, 260, 488], [330, 534, 350, 540], [392, 222, 410, 244]])
      R.pipe(P([[x0, y0], [x1, y1]], false), 7, '#ffffff', 0.36, 0.04, 1);
    // pink bubblegum head
    a.save(); a.filter = 'blur(8px)'; a.fillStyle = 'rgba(255,60,60,0.8)'; a.fill(circleP(135, 212, 76)); a.restore();
    R.dome(circleP(135, 212, 70), '#f6a0b4', 0.4, 0.16, 50, 4);
    R.pipe(P([[160, 172], [182, 186]], false), 7, '#ffffff', 0.58, 0.04, 4);
    R.paint(circleP(118, 258, 6), '#101010'); R.paint(circleP(172, 150, 7), '#101010');
    a.save(); a.strokeStyle = '#101010'; a.lineWidth = 3; a.beginPath(); a.arc(178, 142, 8, -1.8, 0.8); a.stroke(); a.restore();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.8, emis: 0.3, spec: 0.5, shin: 30, wrap: 0.4, coat: 0.05 }),    // grey glossy blob
        E.mat({ dif: 0.8, emis: 0.3, spec: 0.1, shin: 10, wrap: 0.4, grain: 0.5 }),    // rock
        E.mat({ dif: 0.8, emis: 0.35, spec: 0.3, shin: 20, wrap: 0.4 }),               // green blob
        E.mat({ dif: 0.8, emis: 0.3, spec: 0.6, shin: 30, wrap: 0.4, coat: 0.05 })     // pink bubble
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.8, 0.8, 0.8], amb: [0.25, 0.25, 0.26],
      envTop: [1, 1, 1], envHor: [0.5, 0.5, 0.52], envBot: [0.1, 0.1, 0.1], envK: [0.3, 0.8, 0.4, 0],
      shadow: [-4, 4, 0.4, 8], r1: 2, r2: 8, k: [0, 0.6, 0.4, 60]
    });
    E.grain(0.03, 13);
  }
});
