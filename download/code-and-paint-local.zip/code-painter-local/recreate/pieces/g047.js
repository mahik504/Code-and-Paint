'use strict';
// g047 — "Rainbow knob collage": a contact-sheet collage on navy — a taupe zebra drape over a lavender sky,
// red glitter coral, a glossy maroon creature, a rainbow arc, black-and-white zebra bands and a big scalloped
// chrome knob, with a column of space / sky / turtle tiles and a row of zebra and starfield swatches.
REC.register('g047', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, rr = rng(47);
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    keep();
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st) => { const g = a.createRadialGradient(x, y, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const F = (path, c) => { a.fillStyle = c; a.fill(path); };
    const K = (path, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.stroke(path); };
    const dots = (x0, y0, w, h, n, cols, rmin, rmax, seed) => { const q = rng(seed); for (let i = 0; i < n; i++) F(circleP(x0 + q() * w, y0 + q() * h, rmin + q() * q() * (rmax - rmin)), cols[Math.floor(q() * cols.length)]); };

    // ── textures ──
    const zCloth = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 70. * vec2(fbm(p * 0.006), fbm(p * 0.006 + 7.)) ;
      float s = dot(q, vec2(0.80, -0.6)) / 58. + 0.9 * fbm(p * 0.008 + 3.);
      float v = abs(fract(s) - 0.5);
      float w = smoothstep(0.085, 0.06, v);
      vec3 base = vec3(.63,.54,.47) * (0.92 + 0.16 * fbm(p * 0.01));
      return mix(base, vec3(.95,.93,.90), w); }`));
    const zH = (per, frac, warp, ang, seed, ph0 = 0) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + ${warp.toFixed(1)} * vec2(fbm(p * 0.007 + ${seed.toFixed(1)}), fbm(p * 0.007 + ${(seed + 4).toFixed(1)}));
      float s = dot(q, vec2(cos(${ang.toFixed(3)}), sin(${ang.toFixed(3)}))) / ${per.toFixed(1)} + ${ph0.toFixed(3)};
      float v = fract(s);
      float b = smoothstep(${(1 - frac).toFixed(3)} - 0.04, ${(1 - frac).toFixed(3)}, v) * smoothstep(1.0, 0.96, v);
      return mix(vec3(.95,.93,.88), vec3(.03,.025,.025), b); }`));
    const zMid = zH(35, 0.5, 3, 1.66, 1, 0.53);
    const zLeftBand = zH(52, 0.48, 70, 0.75, 5);
    const zB2 = zH(22, 0.5, 40, 0.5, 9), zB3 = zH(17, 0.5, 30, 0.2, 13), zB4 = zH(20, 0.5, 26, 1.8, 17), zR4 = zH(18, 0.5, 30, 1.9, 21);
    const zPuff = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 40. * vec2(fbm(p * 0.008 + 2.), fbm(p * 0.008 + 6.));
      float s = dot(q - vec2(0., 200.), vec2(0.55, 0.83)) / 44.;
      float v = abs(fract(s) - 0.5);
      float w = smoothstep(0.16, 0.12, v);
      vec3 base = mix(vec3(.74,.68,.63), vec3(.86,.84,.84), smoothstep(250., 420., p.y));
      return mix(base, vec3(.97,.96,.93), w); }`));
    const glitter = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = vnoise(p * 0.12) * 0.6 + vnoise(p * 0.3) * 0.4;
      float g = smoothstep(95., 0., length((p - vec2(200., 350.)) * vec2(1., 0.8)));
      vec3 c = mix(vec3(.45,.03,.02), vec3(.86,.18,.06), smoothstep(.35,.7,n));
      c = mix(c, vec3(.98,.82,.25), g * smoothstep(.2,.6,n));
      c = mix(c, vec3(1.,.95,.6), g * g * 0.6);
      c *= 0.75 + 0.5 * step(0.55, n);
      return c; }`));
    const starfield = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float h = hash(floor(p * 0.34)); vec3 c = vec3(.012,.012,.02);
      float k = step(0.982, h); float t = hash(floor(p * 0.34) + 5.);
      c += k * mix(vec3(1.), mix(vec3(1.,.2,.3), vec3(.3,.8,1.), step(.5, hash(floor(p*0.34)+9.))), step(.6, t));
      return c; }`));

    // ── navy frame ──
    R.flat(rrect(-10, -10, 746, 1044, 0), lin(0, 0, 0, 1024, [[0, '#1a2030'], [1, '#162032']]), 0, 0);
    const MAIN = rrect(8, 8, 572, 854, 12);
    R.flat(MAIN, '#c8d2ea', 0.02, 0);

    clipA(MAIN, () => {
      // ── black starry corner + blue arc ──
      F(P([[0, 0], [130, 0], [90, 20], [55, 50], [35, 90], [24, 140], [0, 140]], true, false), '#05040a');
      dots(8, 8, 110, 130, 40, ['#ffffff', '#ff6060', '#80c0ff', '#ffd060'], 0.6, 2, 1);
      F(circleP(20, 78, 10), '#f04820'); F(circleP(55, 12, 6), '#c040e0');
      K(P([[22, 150], [28, 100], [50, 55], [80, 26], [118, 8]], false), '#0a2cf8', 13);
      // lavender sky gradient
      F(rrect(40, 8, 230, 330, 0), lin(40, 8, 260, 330, [[0, 'rgba(198,210,234,0)'], [1, 'rgba(204,214,238,0.5)']]));

      // ── big taupe zebra drape ──
      const cloth = P([[230, 0], [600, 0], [600, 272], [560, 270], [520, 282], [480, 304], [455, 335], [430, 370], [400, 390], [350, 392], [310, 372], [280, 340], [252, 300], [238, 250], [228, 180], [222, 110], [222, 40]]);
      R.dome(cloth, zCloth, 0.04, 0.1, 40, 1);
      clipA(cloth, () => {
        soft(x => { x.fillStyle = 'rgba(190,212,242,0.85)';
          x.fill(ellipseP(320, 260, 60, 110, 0.3)); x.fill(ellipseP(420, 230, 40, 70, 0.2)); x.fill(ellipseP(520, 200, 30, 60, 0.3)); x.fill(ellipseP(300, 120, 26, 60, 0.2)); x.fill(ellipseP(450, 330, 50, 30, 0)); }, 22, 0.9);
      });
      K(P([[300, 380], [350, 394], [400, 392], [432, 368], [460, 330], [490, 300], [530, 284], [580, 276]], false), '#0a0606', 4);
      K(P([[228, 4], [222, 60], [224, 140], [234, 230], [256, 304], [286, 344], [312, 372]], false), '#100808', 3);
      // glassy translucent wing on the left of the drape
      const wing = P([[174, 10], [234, 8], [226, 100], [230, 200], [248, 280], [282, 330], [306, 366], [258, 346], [228, 310], [200, 260], [184, 190], [176, 100]]);
      R.dome(wing, lin(170, 0, 300, 360, [[0, '#d4d8ea'], [0.35, '#c4c4d6'], [0.6, '#e2d4d0'], [0.85, '#f0b898'], [1, '#e4a888']]), 0.06, 0.05, 10, 3);
      K(P([[234, 8], [226, 100], [230, 200], [248, 280], [282, 330], [306, 366]], false), '#1a1010', 3);
      clipA(wing, () => soft(x => { x.fillStyle = '#ffffff'; x.fill(ellipseP(210, 120, 8, 60, 0.05)); x.fillStyle = '#f0a070'; x.fill(ellipseP(240, 290, 18, 30, -0.4)); }, 6, 0.7));
      // halftone patch
      clipA(P([[180, 210], [215, 190], [240, 250], [222, 280], [185, 270]]), () => { for (let y = 190; y < 290; y += 5) for (let x = 176; x < 245; x += 5) F(circleP(x + (y % 10 ? 2.5 : 0), y, 1.4), '#787880'); });

      // ── white blob + peach shapes on the right ──
      R.dome(P([[450, 340], [480, 300], [530, 286], [585, 282], [585, 470], [540, 460], [500, 440], [462, 410], [446, 380]]), '#fbfbfb', 0.06, 0.06, 30, 3);
      F(P([[470, 420], [520, 400], [560, 380], [585, 384], [585, 500], [540, 500], [500, 480], [476, 450]]), '#fbd4b3');
      F(P([[440, 440], [470, 420], [500, 430], [520, 460], [510, 490], [480, 470]]), '#f9c8a4');
      R.dome(rrect(498, 456, 30, 26, 10), '#c8c4c4', 0.1, 0.04, 8, 3);

      // ── grey zebra puff on the left + head creatures ──
      const puff = P([[0, 205], [60, 208], [110, 220], [145, 250], [160, 300], [156, 350], [135, 395], [100, 432], [60, 448], [0, 448]]);
      R.dome(puff, zPuff, 0.06, 0.2, 60, 4);
      soft(x => { x.fillStyle = 'rgba(255,255,255,0.9)'; x.fill(ellipseP(128, 380, 10, 22, 0.5)); }, 5, 1);
      // black-and-white head with yellow eye + red cap
      R.dome(P([[0, 118], [30, 122], [52, 145], [60, 178], [50, 205], [20, 212], [0, 205]]), '#121010', 0.1, 0.1, 20, 4);
      R.dome(ellipseP(16, 160, 16, 22, 0.2), '#f4f0e8', 0.18, 0.04, 10, 4);
      R.dome(circleP(36, 152, 10), '#ffe030', 0.2, 0.04, 6, 4); F(circleP(38, 152, 5), '#100c08');
      R.dome(P([[56, 175], [70, 160], [100, 158], [122, 172], [126, 200], [110, 214], [80, 212], [60, 200]]), '#e81010', 0.12, 0.12, 22, 4);
      R.dome(ellipseP(98, 186, 20, 14, 0), '#101010', 0.2, 0.04, 8, 4);
      R.dome(circleP(92, 188, 9), '#ffd020', 0.24, 0.03, 5, 4); F(ellipseP(96, 190, 6, 3, 0.4), '#100c08');

      // ── red glitter coral with a yellow glow ──
      const coral = P(ragged([[140, 255], [180, 242], [215, 262], [240, 296], [270, 330], [300, 370], [290, 420], [250, 470], [210, 505], [160, 510], [100, 500], [66, 470], [62, 430], [96, 405], [136, 380], [158, 330], [150, 290]], 0, 17, 8, 6, 3));
      R.flat(coral, glitter, 0.06, 0);
      F(P([[150, 335], [175, 330], [185, 360], [170, 395], [150, 395], [140, 365]]), '#30c040');
      dots(150, 340, 40, 50, 14, ['#ff40a0', '#40a0ff', '#ffe040'], 1, 3, 2);
      dots(90, 260, 220, 240, 26, ['#fff8d0'], 1.5, 5, 3);
      soft(x => { const q = rng(4); for (let i = 0; i < 14; i++) { x.fillStyle = '#fff0c0'; x.fill(circleP(100 + q() * 200, 270 + q() * 220, 4 + q() * 4)); } }, 4, 0.9);

      // ── glossy maroon creature ──
      const creature = P([[150, 425], [165, 392], [200, 368], [240, 356], [285, 356], [318, 372], [345, 392], [380, 392], [430, 400], [468, 425], [462, 470], [430, 492], [380, 502], [300, 508], [230, 506], [185, 492], [158, 465]]);
      R.dome(creature, lin(150, 360, 470, 505, [[0, '#140404'], [0.4, '#2c0808'], [0.7, '#1c0505'], [1, '#3a0e0c']]), 0.08, 0.22, 40, 5);
      soft(x => { x.fillStyle = 'rgba(150,40,30,0.55)'; x.fill(ellipseP(290, 420, 50, 20, 0)); x.fill(ellipseP(220, 470, 30, 14, 0)); }, 12, 1);
      R.dome(P([[242, 378], [262, 366], [292, 368], [308, 382], [296, 392], [270, 388], [252, 392]]), '#20c050', 0.3, 0.04, 6, 5);
      R.dome(ellipseP(268, 380, 9, 7, 0), '#0a0a0a', 0.34, 0.02, 4, 5);
      R.dome(circleP(342, 426, 14), '#30d060', 0.3, 0.06, 8, 5); R.dome(circleP(342, 426, 9), '#f0f8f0', 0.36, 0.03, 5, 5); R.dome(circleP(343, 427, 5), '#0a0a0a', 0.38, 0.02, 3, 5);
      R.dome(ellipseP(388, 392, 14, 13, 0), '#f08868', 0.3, 0.06, 7, 5);
      soft(x => { const q = rng(6); for (let i = 0; i < 10; i++) { x.fillStyle = '#ffe8b0'; x.fill(circleP(170 + q() * 120, 400 + q() * 90, 3 + q() * 3)); } }, 2, 1);
      keep();

      // ── rainbow arc ──
      { const cx = 470, cy = 610, sx = 1.42;
        const band = (r0, r1, c) => { const p = new Path2D(); p.ellipse(cx, cy, r1 * sx, r1, 0, Math.PI, 2 * Math.PI); p.ellipse(cx, cy, r0 * sx, r0, 0, 2 * Math.PI, Math.PI, true); p.closePath(); F(p, c); };
        F(ellipseP(cx, cy, 186 * sx, 186, 0), '#f02008');
        band(165, 186, '#f42a08'); band(142, 165, '#f99141'); band(118, 142, '#fcf208'); band(96, 118, '#e8240c');
        F(ellipseP(cx + 20, cy - 30, 70 * sx, 70, 0), '#f01c06');
        F(circleP(468, 516, 7), '#ffffff');
        // green / pink / blue ribbons on the right edge
        K(P([[560, 470], [572, 520], [586, 560]], false), '#0a9623', 18); K(P([[545, 450], [556, 500], [568, 560]], false), '#e891e2', 8); K(P([[575, 460], [586, 500]], false), '#3050e0', 6);
      }

      // ── zebra bands ──
      const leftBand = P([[0, 440], [60, 452], [130, 478], [200, 502], [180, 560], [150, 640], [120, 700], [60, 720], [0, 700]]);
      F(leftBand, zLeftBand);
      const midBand = P([[120, 512], [200, 522], [300, 532], [400, 542], [470, 556], [520, 576], [480, 640], [400, 680], [330, 700], [250, 712], [160, 716], [130, 700], [150, 600]]);
      F(midBand, zMid);
      K(P([[0, 440], [60, 452], [130, 484], [210, 520], [300, 530], [400, 540], [470, 554], [520, 574]], false), '#100808', 3);
      // cream splatter ground, bottom left
      F(P([[0, 690], [60, 716], [130, 712], [200, 716], [210, 760], [160, 800], [130, 870], [0, 870]]), '#efe8de');
      { const q = rng(7); for (let i = 0; i < 60; i++) { const x = 10 + q() * 200, y = 660 + q() * 200; F(circleP(x, y, 1 + q() * q() * 9), '#0a0606'); } }
      F(P([[120, 700], [200, 690], [260, 712], [240, 740], [180, 730], [140, 760], [118, 740]]), '#0a0606');
      // rainbow slug + teal speckle
      R.dome(P([[30, 862], [24, 820], [34, 790], [50, 765], [70, 752], [88, 760], [94, 790], [82, 820], [76, 862]]), lin(40, 750, 80, 862, [[0, '#20e040'], [0.35, '#d8f020'], [0.6, '#f8a010'], [1, '#f02040']]), 0.1, 0.12, 20, 4);
      soft(x => { x.fillStyle = '#80ffff'; x.fill(circleP(72, 768, 9)); }, 4, 1);
      F(circleP(72, 768, 4), '#e8ffff');
      clipA(P([[8, 800], [30, 795], [40, 830], [30, 862], [8, 862]]), () => { F(rrect(0, 790, 50, 80, 0), '#1a3c3c'); dots(8, 795, 32, 70, 90, ['#40c0c0', '#80e0e0', '#2090a0'], 0.8, 1.8, 8); });

      // ── diagonal rainbow ribbons bottom-middle ──
      { const base = [[110, 870], [180, 790], [250, 735], [330, 690]];
        const cols = ['#f0105a', '#f8f0f8', '#f040c0', '#20a040', '#f8f020', '#f8f0f8', '#2850e8', '#0a0a0a', '#e070e0', '#20a040', '#f8f020', '#0a0a0a'];
        clipA(P([[100, 870], [330, 690], [340, 870]]), () => {
          for (let i = 0; i < cols.length; i++) { const off = i * 16; K(P(base.map(([x, y]) => [x + off * 0.7, y + off]), false), cols[i], 17); }
        });
        K(P(base, false), '#f0105a', 8);
      }
      keep();

      // ── scalloped chrome knob ──
      const KX = 460, KY = 655, CX = 452, CY = 708;
      const lobed = (cx, cy, rx, ry, amp, n) => { const pts = []; for (let i = 0; i < n; i++) { const an = i / n * Math.PI * 2, k = 1 + amp * Math.pow(Math.abs(Math.cos(an * 5)), 0.6); pts.push([cx + Math.cos(an) * rx * k, cy + Math.sin(an) * ry * k]); } return P(pts, true, false); };
      const sil = lobed(CX, CY, 136, 144, 0.05, 160);
      R.dome(sil, null, 0.2, 0.32, 70, 6);   // gradient painted through a clip: a gradient fill of this many-point path wiped the CPU albedo buffer
      clipA(sil, () => { F(rrect(300, 550, 300, 320, 0), rad(KX - 60, KY - 70, 260, [[0, '#ffffff'], [0.45, '#efeae6'], [0.8, '#cfc6c0'], [1, '#a89e98']])); });
      keep();
      for (let i = 0; i < 10; i++) {   // puffy lobes between the grooves
        const pts = [], a0 = (i - 0.5) / 10 * Math.PI * 2, a1 = (i + 0.5) / 10 * Math.PI * 2;
        for (let k = 0; k <= 8; k++) { const an = a0 + (a1 - a0) * k / 8; pts.push([KX + Math.cos(an) * 58, KY + Math.sin(an) * 48]); }
        for (let k = 8; k >= 0; k--) { const an = a0 + (a1 - a0) * k / 8, kk = 1 + 0.05 * Math.pow(Math.abs(Math.cos(an * 5)), 0.6); pts.push([CX + Math.cos(an) * 136 * kk, CY + Math.sin(an) * 144 * kk]); }
        R.dome(P(pts, true, false), null, 0.3, 0.2, 26, 6);
        const c = Math.cos(a1), sn = Math.sin(a1);
        const p0 = [KX + c * 58, KY + sn * 48], p2 = [CX + c * 138, CY + sn * 146], p1 = [(p0[0] + p2[0]) / 2 + c * 4, (p0[1] + p2[1]) / 2 + 4];
        R.groove(P([p0, p1, p2], false), 6, '#5a524e', 0.32, 0.06, 6);
      }
      R.groove(lobed(KX, KY + 6, 104, 88, 0.06, 120), 4, '#8a827e', 0.5, 0.04, 6);
      R.dome(ellipseP(KX, KY, 62, 50, 0), '#4a4a50', 0.48, 0.02, 6, 2);
      R.pipe(ellipseP(KX, KY, 54, 44, 0), 14, '#d0d4dc', 0.46, 0.1, 2);
      R.pipe(ellipseP(KX, KY + 2, 38, 30, 0), 9, '#a0a4b0', 0.44, 0.06, 2);
      R.flat(ellipseP(KX, KY + 4, 26, 21, 0), '#030304', 0.34, 0);
      for (const [x, y] of [[338, 760], [410, 822], [505, 808], [560, 790]]) R.groove(ellipseP(x, y, 6, 5, 0), 6, '#2a2020', 0.4, 0.1, 6);
      keep();
    });
    // border of the main panel
    K(rrect(8, 8, 572, 854, 12), '#5a4aa0', 2);

    // ═════════ right column ═════════
    const tile = (x, y, w, h, col, fn) => { const p = rrect(x, y, w, h, 9); R.flat(p, '#000', 0.02, 0); clipA(p, fn); K(p, col, 2.5); };
    tile(590, 8, 130, 220, '#3a64b0', () => {
      F(rrect(590, 8, 130, 220, 0), starfield);
      F(rrect(590, 8, 130, 220, 0), 'rgba(10,14,60,0.5)');
      R.dome(circleP(612, 36, 24), rad(606, 28, 26, [[0, '#8080ff'], [1, '#2a20b0']]), 0.1, 0.1, 14, 2);
      R.pipe(circleP(612, 36, 26), 5, '#c0c4d0', 0.16, 0.04, 2);
      R.bead(678, 30, 22, '#40a090', 0.1, 0.12, 2); R.bead(664, 76, 15, '#505058', 0.1, 0.1, 2); R.bead(686, 158, 16, '#6050c0', 0.1, 0.1, 2); R.bead(700, 220, 24, '#405048', 0.1, 0.1, 2);
      F(P([[686, 60], [720, 40], [720, 228], [690, 210], [680, 150], [690, 110]]), '#7a7a80');
      dots(680, 60, 40, 160, 60, ['#303034', '#b0b0b8'], 1, 3, 30);
      soft(x => { for (const [px, py, r] of [[625, 158, 12], [652, 135, 8], [607, 205, 10], [640, 108, 5], [612, 120, 4], [655, 190, 7]]) { x.fillStyle = '#ffffff'; x.fill(circleP(px, py, r)); } }, 1.2, 1);
      { const q = rng(31); for (let i = 0; i < 40; i++) F(circleP(612 + q() * 34, 72 + q() * 34, 1 + q() * 2.5), '#f8f8f8'); }
    });
    tile(590, 244, 130, 201, '#6a40c0', () => {
      F(rrect(590, 244, 130, 201, 0), lin(590, 244, 590, 445, [[0, '#62a8f8'], [1, '#5ca0f8']]));
      R.dome(P([[630, 244], [720, 244], [720, 330], [700, 345], [672, 330], [650, 290]]), '#e8e8ea', 0.08, 0.06, 20, 3);
      F(P([[672, 332], [700, 330], [720, 320], [720, 445], [700, 445], [690, 400]]), '#0a0a12');
      dots(680, 330, 40, 115, 40, ['#f0d040', '#ffffff', '#ff6080'], 0.6, 1.6, 32);
      R.dome(ellipseP(683, 285, 22, 26, 0.3), '#d89040', 0.12, 0.08, 10, 3);
      clipA(ellipseP(683, 285, 22, 26, 0.3), () => { for (let i = 0; i < 9; i++) K(P([[660, 262 + i * 6], [706, 266 + i * 6]], false), '#a05a20', 1.2); });
      F(P([[650, 260], [668, 250], [672, 268]]), '#40a050'); F(P([[700, 250], [716, 256], [706, 270]]), '#f04060');
      const flower = (x, y, r) => { for (let k = 0; k < 5; k++) { const an = k / 5 * 6.283 - 1.57; F(circleP(x + Math.cos(an) * r * 0.55, y + Math.sin(an) * r * 0.55, r * 0.5), '#fce8f0'); } F(circleP(x, y, r * 0.3), '#f8d8e8'); };
      flower(617, 296, 20); flower(617, 410, 22);
      F(P([[655, 445], [662, 420], [680, 405], [700, 412], [720, 400], [720, 445]]), '#f8c8b0');
      dots(595, 300, 80, 140, 14, ['#ff4070', '#ffffff'], 1, 2.4, 33);
    });
    tile(590, 462, 130, 195, '#5ac040', () => {
      F(rrect(590, 462, 130, 195, 0), starfield);
      F(P([[590, 530], [640, 524], [680, 540], [700, 530], [720, 548], [720, 660], [590, 660]]), lin(590, 530, 720, 660, [[0, '#f8b070'], [1, '#e8a868']]));
      F(P([[590, 600], [720, 560], [720, 600], [640, 640], [590, 650]]), 'rgba(250,200,150,0.6)');
      F(circleP(640, 488, 6), '#ff2020'); F(circleP(684, 510, 4), '#40c0e0');
      R.dome(ellipseP(625, 622, 32, 18, -0.25), '#d89040', 0.12, 0.08, 10, 3);
      clipA(ellipseP(625, 622, 32, 18, -0.25), () => { for (let i = 0; i < 8; i++) K(P([[592, 600 + i * 6], [660, 590 + i * 6]], false), '#7a4a20', 1.4); });
      R.dome(ellipseP(658, 607, 10, 8, 0), '#3a7040', 0.14, 0.04, 5, 3);
      R.dome(P([[600, 600], [588, 590], [606, 594]]), '#3a7040', 0.12, 0.02, 3, 3);
    });
    tile(590, 672, 130, 190, '#4080c0', () => {
      F(rrect(590, 672, 130, 190, 0), zR4);
      F(P([[590, 672], [720, 672], [720, 700], [650, 690], [620, 720], [590, 730]]), '#8ef0f4');
      R.bead(612, 696, 22, '#3050a0', 0.1, 0.12, 2);
      F(circleP(632, 712, 6), '#e82030'); F(circleP(700, 708, 5), '#e82030');
      R.dome(ellipseP(665, 765, 42, 30, 0.2), '#a0522a', 0.14, 0.08, 12, 3);
      clipA(ellipseP(665, 765, 42, 30, 0.2), () => { for (let i = 0; i < 9; i++) { K(P([[620, 740 + i * 8], [710, 750 + i * 8]], false), '#5a2a10', 1.5); K(P([[630 + i * 10, 730], [626 + i * 10, 800]], false), '#5a2a10', 1.5); } });
      for (const [x0, y0, x1, y1] of [[630, 750, 606, 732], [700, 750, 716, 730], [640, 790, 618, 806], [694, 790, 712, 808]]) K(P([[x0, y0], [x1, y1]], false), '#8a4a20', 8);
      F(P([[590, 840], [620, 830], [650, 862], [590, 862]]), '#f8c020');
    });

    // ═════════ bottom row ═════════
    tile(8, 878, 129, 137, '#40b04a', () => {
      F(rrect(8, 878, 129, 137, 0), '#e6e0d4');
      for (let k = 0; k < 5; k++) { const an = k / 5 * 6.283 - 1.2; F(circleP(92 + Math.cos(an) * 22, 952 + Math.sin(an) * 22, 17), '#0c0808'); } F(circleP(92, 952, 20), '#0c0808');
      for (const [x, y, r] of [[20, 900, 5], [22, 930, 6], [14, 1000, 7], [50, 905, 3]]) F(circleP(x, y, r), '#0c0808');
      F(circleP(20, 898, 4), '#e83020');
    });
    tile(153, 878, 137, 137, '#e8a040', () => { F(rrect(153, 878, 137, 137, 0), zB2); F(P(blob(232, 948, 26, 24, 5, 10, 0.4)), '#efe8de'); F(circleP(278, 902, 6), '#f02020'); });
    tile(305, 878, 127, 137, '#e05a90', () => { F(rrect(305, 878, 127, 137, 0), zB3); });
    tile(450, 878, 130, 137, '#40b0d8', () => {
      F(rrect(450, 878, 130, 137, 0), zB4);
      F(P([[450, 878], [540, 878], [520, 900], [480, 930], [450, 960]]), '#f0ece6');
      R.dome(circleP(492, 942, 9), '#f8d020', 0.1, 0.04, 5, 3); F(circleP(486, 952, 6), '#f04020');
    });
    tile(590, 878, 130, 137, '#7050d0', () => {
      F(rrect(590, 878, 130, 137, 0), starfield);
      soft(x => { x.fillStyle = '#ff2040'; x.fill(circleP(630, 885, 8)); x.fill(circleP(712, 948, 10)); }, 4, 1);
      dots(595, 885, 120, 125, 18, ['#ffffff', '#ff4060', '#40a0ff'], 1, 3, 40);
    });
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1.0, spec: 0.5, shin: 30, wrap: 0.6, ao: 0.4, emis: 0.08 }),                                // 1 satin drape
        E.mat({ dif: 0.5, metal: 0.7, spec: 1.4, shin: 80, ao: 0.4, rim: 0.3, coat: 0.2 }),                      // 2 chrome / glass
        E.mat({ dif: 1.0, spec: 0.4, shin: 30, wrap: 0.6, ao: 0.3, emis: 0.1 }),                                 // 3 matte
        E.mat({ dif: 0.95, spec: 1.2, shin: 80, wrap: 0.5, ao: 0.5, coat: 0.2, emis: 0.05 }),                     // 4 glossy plastic
        E.mat({ dif: 0.9, spec: 1.6, shin: 120, wrap: 0.3, ao: 0.4, coat: 0.35, emis: 0.1 }),                     // 5 wet creature
        E.mat({ dif: 0.85, metal: 0.3, spec: 1.4, shin: 70, wrap: 0.5, ao: 0.6, coat: 0.35, rim: 0.2, emis: 0.08 })            // 6 satin chrome knob
      ],
      light: [-0.4, 0.62, 0.68], lc: [0.85, 0.84, 0.82], amb: [0.36, 0.36, 0.38],
      envTop: [1.1, 1.08, 1.06], envHor: [0.62, 0.58, 0.56], envBot: [0.2, 0.16, 0.16], envK: [0.3, 1.2, 0.3, 0],
      rimC: [0.1, 0.1, 0.12], rimD: [0, 1, 0], r1: 1.4, r2: 7, k: [0, 0.6, 0.4, 80], shadow: [-4, 6, 0.5, 7]
    });
    E.bloom(0.06, 6);
    E.grain(0.03, 47);
  }
});
